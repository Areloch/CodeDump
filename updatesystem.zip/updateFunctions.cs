// Copyright Spunky games 2005
// Copyright Chris Labombard

function showMainMenu()
{
   Canvas.setContent(mainMenuGui);
}

function goToUpdate()
{
	gotoWebpage("http://www.spunkygames.com/" @ $patchloc);
}

function goToUpdateFailedPage()
{
	if($patchloc $= "")
	{
		$patchloc = "thefunk/updatefailed.php?version=" @ $pref::version;
	}
	gotoWebpage("http://www.spunkygames.com/" @ $patchloc);
}

