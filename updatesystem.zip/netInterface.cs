$updateCheck = 0; // 0=not checked yet ... 1=no update needed ... 2=update needed... 5 = BOOM!!!

function updateSelf()
{
	if (isObject($tcpServ))
	{
		$tcpserv.delete();
	}

	$tcpserv = new TCPObject(); 
	$tcpserv.connect("www.yourDomain.com:80");
}

function TCPObject::onConnected(%this)
{
	%postdata = "version=" @ $Pref::version;
	$tcpserv.send("POST /checkForUpdate.php HTTP/1.1\r\nHost: www.yourDomain.com\r\nContent-type: application/x-www-form-urlencoded\r\nContent-length: " @ strlen(%postdata) @ "\r\n\r\n" @ %postdata @ "\r\n");
}

function TCPObject::onConnectFailed(%this)
{
	echo("Connection Failed");
	$updateCheck = 1;
}


function TCPObject::onLine(%this, %line)
{
	%index = 0;
	%done = false;

	while (!%done)
	{
		%recordCheck = getField(%line,%index);
		%webaddy = getField(%line,%index+1);

		if (%recordcheck $= "")
		{
			%done = true;
		}
		else if(%recordCheck $= "***")
		{
			$patchloc = %webaddy;
		}
		else if(%recordCheck $= "ENDFILES")
		{
			$updateCheck = 2;
		}
		else if(%recordCheck $= "INVALIDVERSION")
		{
			$updateCheck = 5;
		}
		else if(%recordCheck $= "NOFILES")
		{
			$updateCheck = 1;
		}

		%index += 3;
	}
}
