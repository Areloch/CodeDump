<?
// checkForUpdate.php
$version = $_POST[version];



if ($version == "0.01") {
//return this:
echo "NEWVERSION\t0.3\n";
echo "***\tTom/TheFunk.zip\n";
echo "ENDFILES\n";
} else if ($version == "0.2") {
// return this:
echo "NOFILES";
} else if ($version == "0.3") {
// return this:
echo "NOFILES";
}
else
{
echo "INVALIDVERSION";
}


?>
