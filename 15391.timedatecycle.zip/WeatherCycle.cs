//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//
// weather 09/2008 Matsouliadis Dimitris
//------------------------------------------

$RainTimeCounter =0;
$StartRainNow = 0;

function weatherCheck()
{
		if($MySeason == 0)
			%CloudLevel = 30;
		if($MySeason == 1)
			%CloudLevel = 50;
		if($MySeason == 2)
			%CloudLevel = 30;
		if($MySeason == 3)
			%CloudLevel = 10;
		
		%timeStorm = getword($season[$MySeason] ,2);
		$timeRain = %timeStorm;
		if($RainTimeCounter == 0)
		{
			%GotoRain = getRandom(1, (100 -%timeStorm));
			//echo("GO to Rain Random : " @ %GotoRain);
			if(%GotoRain == 35)
			{
				$SetCloudLevel = getRandom(1 ,%CloudLevel);
				$StartRainNow = 3;
			}
		}

			if($StartRainNow == 1)
			{
				$IsStorm = 2;
				startTheRain();
			}
			if($StartRainNow == 2)
			{
				SetDefaultSeasonSky();
			}
			if($StartRainNow == 3)
			{
				SetRainPrepare();
			}
}


function startTheRain()
{
	$RainTimeCounter++;
        
	//echo("Rain counter : " @ $RainTimeCounter);
	if($RainTimeCounter == getword($season[$MySeason] ,2))
	{
		$RainTimeCounter =0;
		$StartRainNow = 2;
		//SetDefaultSeasonSky();
	}
	if($RainTimeCounter >= (getword($season[$MySeason] ,2) -3))
	{
		if(isObject(MyRain))
			MyRain.delete();
		if(isObject(MyLightning))
			MyLightning.delete();
	}
	if($RainTimeCounter <= 1 && $StartRainNow == 1)
	{
		$MySkyCloud1 = getword($season[$MySeason], 6)/100;
		$MySkyCloud2 = getword($season[$MySeason], 7)/100;
		$MySkyCloud3 = getword($season[$MySeason], 8)/100;
	
		$IsStorm = getRandom(1 ,8);
		//$IsStorm = 8;
		$MySkyClSpeed1 = ("0.0001" * $IsStorm);
		$MySkyClSpeed2 = ("0.0001" * ($IsStorm /2));
		$MySkyClSpeed3 = ("0.0001" * ($IsStorm /3));
	//echo("Storm size : " @ $IsStorm);
		%SetDropsNumber = $IsStorm * 3000;
	if($IsStorm >=3)
	{	
		if($MySeason <=2){
			if($IsStorm ==8)
			$IsStorm =7;
		}
		%setRain = "Rain";
		%SetSpeedmin = $IsStorm /3;
		%SetSpeedmax = $IsStorm /2;
		if($IsStorm >= 5 && $IsStorm <=6 )
			{
			%setRain = "Rain";
			StartTheLighting();
			}
		if($IsStorm ==7 )
			{
			%setRain = "HeavyRain";
			StartTheLighting();
			}
		if($IsStorm >=8)
			{
			%setRain = "Snow";
			%SetSpeedmin = "0.3";
			%SetSpeedmax = "0.5";
			}
		new Precipitation(MyRain)
		{
	    	datablock = %setRain;
	    	minSpeed = %SetSpeedmin;
	    	maxSpeed = %SetSpeedmax;
	    	numDrops = %SetDropsNumber;
	    	boxWidth = "200";
	    	boxHeight = "100";
	   	minMass = "1.0";
	    	maxMass = "2.0";
	    	rotateWithCamVel = true;
	    	doCollision = true;
	    	useTurbulence = false;
		};
		MyRain.modifyStorm(0.1, getword($season[$MySeason] ,2));
	   }
		changeTheSky();
	}
		if(isObject(MyMoon)){
			MyMoon.delete();
		}
}

function StartTheLighting()
{
      %GetStrikes = $IsStorm *2;
      %GetStrikesWidth = $IsStorm * 0.01;
      %GetPos = "0 0 0";
      %numHumans = 0;
      %count = ClientGroup.getCount();
      for (%i = 0; %i < %count; %i++)
      {
        %client = ClientGroup.getObject(%i);
        if( !%client.isAIControlled() )
        {
              if(isObject(%client.player))
              {
                 %numHumans++;
                 %pos = VectorAdd(%pos, %client.player.position);
              }
        }
      }

    %GetPos = VectorScale(%pos, 1.0 / (%numHumans ));

    if (!isObject(MyLightning))
    {
       new Lightning(MyLightning)
       {
         position = %GetPos;
         scale = "250 350 450";
         dataBlock = "LightningStorm";
         strikesPerMinute = %GetStrikes;
         strikeWidth = %GetStrikesWidth;
         chanceToHitTarget = "0.02";
         strikeRadius = "500";
         boltStartRadius = "20";
         color = "1 1 1 1";
         fadeColor = "8 8 8 1";
         useFog = "1";
         locked = "false";
      };
    }
}

function SetDefaultSeasonSky()
{
	%nowCloud1 =  getword($season[$MySeason], 3)/10;
	%nowCloud2 =  getword($season[$MySeason], 4)/10;
	%nowCloud3 =  getword($season[$MySeason], 5)/10;
	%Cloud1 = $MySkyCloud1 * 10;
		%Cloud1--;
		if(%Cloud1<= %nowCloud1){
			%Cloud1 = %nowCloud1;
		}
	%Cloud2 = $MySkyCloud2 * 10;
		%Cloud2--;
		if(%Cloud2  <= %nowCloud2){
			%Cloud2 = %nowCloud2;
		}
	%Cloud3 = $MySkyCloud3 * 10;
		%Cloud3--;
		if(%Cloud3  <= %nowCloud3){
			%Cloud3 = %nowCloud3;
		}
	$MySkyCloud1 = %Cloud1 /10;
	$MySkyCloud2 = %Cloud2 /10;
	$MySkyCloud3 = %Cloud3 /10;
	$MySkyClSpeed1 = getword($season[$MySeason], 2)/220000;
	$MySkyClSpeed2 = getword($season[$MySeason], 2)/260000;
	$MySkyClSpeed3 = getword($season[$MySeason], 2)/300000;
	changeTheSky();

	//echo($MySkyCloud1 SPC $MySkyCloud2 SPC $MySkyCloud2);	
	if(($MySkyCloud1 *10) <= %nowCloud1 && ($MySkyCloud2 *10) <= %nowCloud2 && ($MySkyCloud3 *10) <= %nowCloud3)
	{
	if($MySeason == 0)
		$MyHeliosMaxBrt = "0.9";
	if($MySeason == 1)
		$MyHeliosMaxBrt = "1";
	if($MySeason == 2)
		$MyHeliosMaxBrt = "0.8";
	if($MySeason == 4){
		$MyHeliosMaxBrt = "0.6";
		}
		CreateTheSun();
		$StartRainNow = 0;
	}
}

function SetRainPrepare()
{
	%nowCloud1 =  getword($season[$MySeason], 6)/10;
	%nowCloud2 =  getword($season[$MySeason], 7)/10;
	%nowCloud3 =  getword($season[$MySeason], 8)/10;
	%Cloud1 = $MySkyCloud1 * 10;
		%Cloud1++;
		if(%Cloud1>= %nowCloud1){
			%Cloud1 = %nowCloud1;
		}
	%Cloud2 = $MySkyCloud2 * 10;
		%Cloud2++;
		if(%Cloud2  >= %nowCloud2){
			%Cloud2 = %nowCloud2;
		}
	%Cloud3 = $MySkyCloud3 * 10;
		%Cloud3++;
		if(%Cloud3  >= %nowCloud3){
			%Cloud3 = %nowCloud3;
		}
	$MySkyCloud1 = %Cloud1 /10;
	$MySkyCloud2 = %Cloud2 /10;
	$MySkyCloud3 = %Cloud3 /10;
	changeTheSky();

	//echo("Prapare>> " @ $MySkyCloud1 SPC $MySkyCloud2 SPC $MySkyCloud2);	
	if(($MySkyCloud1 *10) >= %nowCloud1 && ($MySkyCloud2 *10) >= %nowCloud2 && ($MySkyCloud3 *10) >= %nowCloud3)
		$RainTimeCounter =0;
		$StartRainNow = 1;
		$MyHeliosMaxBrt = "0.2";
		CreateTheSun();
}

//-----------------------------------------------------------------------------
datablock SFXProfile(MyHeavyRainSound)
{
   fileName = "~/data/sound/environment/HeavyRain";
   description = AudioLooping2d;
   preload = true;
};

datablock SFXProfile(MyRainSound)
{
   fileName = "~/data/sound/environment/Rain";
   description = AudioLooping2d;
   preload = true;
};

datablock SFXProfile(MySnowSound)
{
   fileName = "~/data/sound/environment/snow";
   description = AudioLooping2d;
   preload = true;
};


datablock PrecipitationData(Rain)
{
    soundProfile = "MyRainSound";
    dropTexture = "~/data/environment/rain";
    splashTexture = "~/data/environment/water_splash";
    dropSize = 0.2;
    splashSize = 0.01;
    useTrueBillboards = false;
    splashMS = 250;
};

datablock PrecipitationData(HeavyRain)
{
    soundProfile = "MyHeavyRainSound";
    dropTexture = "~/data/environment/rain";
    splashTexture = "~/data/environment/water_splash";
    dropSize = 0.3;
    splashSize = 0.05;
    useTrueBillboards = false;
    splashMS = 250;
};

datablock PrecipitationData(Snow)
{
    soundProfile = "MySnowSound";
    dropTexture = "~/data/environment/snow";
    splashTexture = "~/data/environment/Snow_Down.png";
    dropSize = 0.1;
    splashSize = 0.01;
    useTrueBillboards = true;
    splashMS = 0;
};

datablock SFXProfile(ThunderCrash1Sound)
{
   fileName = "~/data/sound/environment/thunder1";
   description = AudioClose3d;
   preload = true;
};

datablock SFXProfile(ThunderCrash2Sound)
{
   fileName = "~/data/sound/environment/thunder2";
   description = AudioClose3d;
   preload = true;
};

datablock SFXProfile(ThunderCrash3Sound)
{
   fileName = "~/data/sound/environment/thunder3";
   description = AudioClose3d;
   preload = true;
};

datablock SFXProfile(ThunderCrash4Sound)
{
   fileName = "~/data/sound/environment/thunder4";
   description = AudioClose3d;
   preload = true;
};


			
datablock LightningData(LightningStorm)
{
    strikeTextures[0]  = "~/data/environment/lightning.dml";
    thunderSounds[0] = ThunderCrash1Sound;
    thunderSounds[1] = ThunderCrash2Sound;
    thunderSounds[2] = ThunderCrash3Sound;
    thunderSounds[3] = ThunderCrash4Sound;
};
