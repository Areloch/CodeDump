//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//
// day/night 09/2008 Matsouliadis Dimitris
//------------------------------------------

// sunrise set for winter
$Skymaterial = "scriptsAndAssets/data/skies/sky_blue/sky_blue.dml";
$FogSet = 150;
$fogColor = "0.92 0.69 0.431373 0";	
$checkSunPlace = 0;
$MySundrl = 1.3;
$MyMoonDate =1;
$MySkyCloud1 = "0.05";
$MySkyCloud2 = "0.2";
$MySkyCloud3 = "0";
$MySkyClSpeed1 = "0.0001";
$MySkyClSpeed2 = "0.0001";
$MySkyClSpeed3 = "0.0001";
$MyHeliosMaxBrt = 0.6;

// ------------- checking the sun elevation
function SunCycle(%MySun,%duration)
  {
	if(isObject(%MySun)) 
		{
		//%MySun.Elevation++
		if($MySunElevationNow> 359)
			{
				$MySunElevationNow = 0;
			}

		%MySun.Elevation = $MySunElevationNow;
		%Sunelv = %MySun.Elevation;			//support the sun degree
		//echo("weatherCheck");
		weatherCheck();

  if($checkSunPlace == $MySunElevationNow)
	{
		//support the weather 
	}
	else
	{
		$checkSunPlace = $MySunElevationNow;
			
	if(%Sunelv >=160 && %Sunelv <= 230)	//sunset
		{
		$FogSet =690 -(%Sunelv * 3);
		if($FogSet <=1)
			$FogSet=1;

			%fogClRed = "0.92" +((159 -%Sunelv) /70);
			%fogClGreen = "0.92" +((159 -%Sunelv) /60);
			%fogClBlue = "0.92" +((159 -%Sunelv) /45);
			%nightLight = getword($season[$MySeason], 9) / 100;
				if(%fogClRed <= %nightLight)
					%fogClRed = %nightLight;
				if(%fogClGreen <= %nightLight)
					%fogClGreen = %nightLight;
				if(%fogClBlue <= %nightLight)
					%fogClBlue = %nightLight;
			$fogColor = (%fogClRed SPC %fogClGreen SPC %fogClBlue SPC "0");
			%MySun.LocalFlareBitmap = "common/lighting/corona.png";
		changeTheSky();
		}

	if(%Sunelv >=311)			//sunrise
		{
		$FogSet = %Sunelv -300;
		if(%Sunelv >=340)
			{
			%fogClRed = ((%Sunelv -339) /22.2);
			%fogClGreen = ((%Sunelv -339) /29);
			%fogClBlue = ((%Sunelv -339) /46.5);
			$fogColor = (%fogClRed SPC %fogClGreen SPC %fogClBlue SPC "0");
			%MySun.LocalFlareBitmap = "common/lighting/corona.png";
			}
		changeTheSky();
		}

	if(%Sunelv >=1 && %Sunelv <= 90)	//step to midday
		{
		$FogSet = 60 + (%Sunelv * 10);
		if($FogSet >= 500)
			$FogSet=500;
		    if(%Sunelv >=1 && %Sunelv <= 60)
			{
			%fogClRed = "0.92";
			%fogClGreen = "0.69" + (%Sunelv /261);
			%fogClBlue = "0.43" + (%Sunelv /120);
			$fogColor = (%fogClRed SPC %fogClGreen SPC %fogClBlue SPC "0");
			if(%Sunelv >=30)
			%MySun.LocalFlareBitmap = "common/lighting/corona.png";
			}
		changeTheSky();
		}

	if($MySundrl <= 0.01)
		{
		$MySundrl = 0.01;
		}

		%MySun.DrlMultiplier = $MySundrl;
		%MySun.apply();
		
	if(%Sunelv == 1) 
		{
		$Skymaterial = "scriptsAndAssets/data/skies/sky_blue/sky_blue.dml";
		$MySundrl = 1.3;
		changeTheSky();
		if(isObject(MyMoon))
			MyMoon.delete();
		}
	if(%Sunelv == 160) 
		{
		$MyMoonDate++;
		if($StartRainNow == 0)
			CreateTheMoon();
		}
	if(%Sunelv == 170) 
		{
		$Skymaterial = "scriptsAndAssets/data/skies/sky_middle/sky_middle.dml";
		$MySundrl = 0.8;
		changeTheSky();
		}
	if(%Sunelv == 210) 
		{
		$Skymaterial = "scriptsAndAssets/data/skies/sky_night/sky_night.dml";
		$MySundrl = 0.1;
		changeTheSky();
		}
	if(%Sunelv == 350) 
		{
		$Skymaterial = "scriptsAndAssets/data/skies/sky_middle/sky_middle.dml";
		$MySundrl = 0.6;
		changeTheSky();
		}

	//schedule(%duration, 0, "SunCycle", %MySun, %duration);
		}
	}
  }

function changeTheSky(){

	if($StartRainNow == 1)
	{
		%fogRain = getword($season[$MySeason], 10);
		$FogSet = %fogRain;
	}

	%VisibleSet = $FogSet +100;
	if(%VisibleSet >= 600)
		%VisibleSet =600;
	if(%VisibleSet <= 250)
		%VisibleSet =250;

      	Sky.canSaveDynamicFields = "1";
      	Sky.Enabled = "1";
      	Sky.position = "336 136 0";
      	Sky.rotation = "1 0 0 0";
      	Sky.scale = "1 1 1";
      	Sky.materialList = $Skymaterial;
      	Sky.cloudHeightPer[0] = $MySkyCloud1;
      	Sky.cloudHeightPer[1] = $MySkyCloud2;
      	Sky.cloudHeightPer[2] = $MySkyCloud3;
      	Sky.cloudSpeed1 = $MySkyClSpeed1;
      	Sky.cloudSpeed2 = $MySkyClSpeed2;
      	Sky.cloudSpeed3 = $MySkyClSpeed3;
      	Sky.visibleDistance = %VisibleSet;
      	Sky.fogDistance = $FogSet;
      	Sky.fogColor = $fogColor;
      	Sky.fogStorm1 = "0";
      	Sky.fogStorm2 = "0";
      	Sky.fogStorm3 = "0";
      	Sky.fogVolume1 = "0 0 0";
      	Sky.fogVolume2 = "0 0 0";
      	Sky.fogVolume3 = "0 0 0";
      	Sky.windVelocity = "5 1 0";
      	Sky.SkySolidColor = "0.6 0.6 0.6 0.1";
      	Sky.useSkyTextures = "1";
      	Sky.renderBottomTexture = "0";
      	Sky.noRenderBans = "0";
      	Sky.renderBanOffsetHeight = "50";
      	Sky.skyGlow = "0";
      	Sky.skyGlowColor = "0 0 0 0";
        Sky.fogVolumeColor1 = "128 128 128 -2.22768e+038";
        Sky.fogVolumeColor2 = "128 128 128 0";
        Sky.fogVolumeColor3 = "128 128 128 -1.70699e+038";
        Sky.windEffectPrecipitation = "1";
	Sky.locked = "false";
	Sky.applySkyChanges(); // This need some fix in engine:)
}

function CreateTheSun(){

if(isObject(MyHelios)) 
	{
	MyHelios.delete();
	}
	%MyHeliosMinBrt = $MyHeliosMaxBrt /2;
 new fxSunLight(MyHelios) {
      canSaveDynamicFields = "1";
      Enabled = "0";
      position = "3774.41 772.596 26.5183";
      rotation = "1 0 0 0";
      scale = "1 1 1";
      Enable = "1";
      LocalFlareBitmap = "common/lighting/corona.png";
      RemoteFlareBitmap = "common/lighting/corona.png";
      SunAzimuth = "50";
      SunElevation = "10";
      LockToRealSun = "1";
      FlareTP = "1";
      Colour = "1 1 1 1";
      Brightness = "1";
      FlareSize = "1";
      LocalScale = "1";
      FadeTime = "0.1";
      BlendMode = "0";
      AnimColour = "1";
      AnimBrightness = "1";
      AnimRotation = "1";
      AnimSize = "0";
      AnimAzimuth = "0";
      AnimElevation = "0";
      LerpColour = "1";
      LerpBrightness = "1";
      LerpRotation = "1";
      LerpSize = "1";
      LerpAzimuth = "1";
      LerpElevation = "0";
      LinkFlareSize = "0";
      SingleColourKeys = "1";
      MinColour = "0.45 0.25 0.03 0";
      MaxColour = "0.35 0.20 0.04 0";
      MinBrightness = %MyHeliosMinBrt;
      MaxBrightness = $MyHeliosMaxBrt;
      MinRotation = "0";
      MaxRotation = "359";
      minSize = "0.5";
      MaxSize = "1";
      MinAzimuth = "0";
      MaxAzimuth = "359";
      MinElevation = "0";
      MaxElevation = "360";
      RedKeys = "AZA";
      GreenKeys = "AZA";
      BlueKeys = "AZA";
      BrightnessKeys = "AZA";
      RotationKeys = "AZA";
      SizeKeys = "AZA";
      AzimuthKeys = "AZ";
      ElevationKeys = "AZ";
      ColourTime = "5";
      BrightnessTime = "5";
      RotationTime = "600";
      SizeTime = "5";
      AzimuthTime = "5";
      ElevationTime = "200";
   };
MissionGroup.add(MyHelios);
}

function CreateTheMoon(){
	 
	if($MyMoonDate >=7) //7 days cycle (27 normal)
		$MyMoonDate = 1;
	
	if($MyMoonDate >=1)
		%MyMoonFace ="common/lighting/MyMoon.png";
	if($MyMoonDate >=2)
		%MyMoonFace ="common/lighting/MyMoon1.png";
	if($MyMoonDate >=3)
		%MyMoonFace ="common/lighting/MyMoon2.png";
	if($MyMoonDate >=4)
		%MyMoonFace ="common/lighting/MyMoon3.png";
	if($MyMoonDate >=5)
		%MyMoonFace ="common/lighting/MyMoon4.png";
	if($MyMoonDate >=6)
		%MyMoonFace ="common/lighting/MyMoon5.png";
		
	if(isObject(MyMoon))
		MyMoon.delete();

new fxSunLight(MyMoon) {
      canSaveDynamicFields = "1";
      Enabled = "1";
      position = "3774.41 772.596 26.5183";
      rotation = "1 0 0 0";
      scale = "1 1 1";
      Enable = "1";
      LocalFlareBitmap = %MyMoonFace;
      RemoteFlareBitmap = %MyMoonFace;
      SunAzimuth = "30";
      SunElevation = "0";
      LockToRealSun = "0";
      FlareTP = "1";
      Colour = "1 1 1 1";
      Brightness = "1";
      FlareSize = "1";
      LocalScale = "1";
      FadeTime = "0.1";
      BlendMode = "0";
      AnimColour = "1";
      AnimBrightness = "1";
      AnimRotation = "0";
      AnimSize = "0";
      AnimAzimuth = "0";
      AnimElevation = "1";
      LerpColour = "1";
      LerpBrightness = "1";
      LerpRotation = "1";
      LerpSize = "1";
      LerpAzimuth = "1";
      LerpElevation = "1";
      LinkFlareSize = "0";
      SingleColourKeys = "1";
      MinColour = "0.5 0.45 0.35 0";
      MaxColour = "0.65 0.5 0.4 0";
      MinBrightness = "0.6";
      MaxBrightness = "0.9";
      MinRotation = "0";
      MaxRotation = "359";
      minSize = "0.5";
      MaxSize = "1";
      MinAzimuth = "20";
      MaxAzimuth = "160";
      MinElevation = "45";
      MaxElevation = "270";
      RedKeys = "AZA";
      GreenKeys = "AZA";
      BlueKeys = "AZA";
      BrightnessKeys = "AZA";
      RotationKeys = "AZA";
      SizeKeys = "AZA";
      AzimuthKeys = "AZ";
      ElevationKeys = "AZ";
      ColourTime = "200";
      BrightnessTime = "500";
      RotationTime = "600";
      SizeTime = "5";
      AzimuthTime = "5";
      ElevationTime = $MyMoonElevationTime;
   };
MissionGroup.add(MyMoon);
echo("The moon is rissing at: " @ MyMoon.SunElevation @ " with face: " @ %MyMoonFace );
}