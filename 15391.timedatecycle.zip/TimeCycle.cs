//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//
// Time/date 09/2008 Matsouliadis Dimitris
//------------------------------------------

//seasons = "seasonNow, Name, TimeEffect, baseEffect1, baseEffect2, baseEffect3, maxEffect1, maxEffect2, maxEffect3, Nightlight, fogRain"
$season[0] = "0 Spring 20 0 10 10 10 50 50 8 30";
$season[1] = "1 Summer 10 0 10 0 0 50 10 10 50";
$season[2] = "2 Autumn 30 0 10 10 10 50 50 5 20";
$season[3] = "3 Winter 60 0 10 10 1 50 50 1 10";

//Months = "SeasonIs, MonthName, DaysHave"
$setMonths = "12";
$Month[0] = "3 January 31";
$Month[1] = "3 February 28";
$Month[2] = "0 March 31";
$Month[3] = "0 April 30";
$Month[4] = "0 May 31";
$Month[5] = "1 June 30";
$Month[6] = "1 july 31";
$Month[7] = "1 August 31";
$Month[8] = "2 September 30";
$Month[9] = "2 October 31";
$Month[10] = "2 November 30";
$Month[11] = "3 December 31";

//weekdays = "Daynumder. Dayname"
$setWeekDays = "7";
$weekDay[0] = "0 Sunday";
$weekDay[1] = "1 Monday";
$weekDay[2] = "2 Tuesday";
$weekDay[3] = "3 Wednesday";
$weekDay[4] = "4 Thursday";
$weekDay[5] = "5 Friday";
$weekDay[6] = "6 Saturday";

	$MyTime = new ScriptObject(Mytime);
	MissionCleanup.add(Mytime);

	// Starring values for >> Sunrise, Winter, Sunday 1 January of 380 BC
	$MyTime.Year = "380 0";		//0= year ++. 1= year --
	$MySeason = 3;
	$MyTime.Month = 0;
	$MyTime.week = 0;
	$MyTime.hours = 7;
	$MyTime.Day = 0;
	$MyTime.MonthDay =1;
	$MySunElevationNow = 1;
	$ElevatorStep = 0;
	$setSunRissing = 7;

//---------------------- Timer -----------------
function TimeCycle(%Mytime,%duration)
{
    	%Mytime.TimeCycleSec = %duration;
	if((%Mytime.Pulse % %Mytime.TimeCycleSec) == 0)
    		{
			$SetTheDuration = %duration;
			$MyMoonElevationTime = $SetTheDuration * 10;
			serverCmdDoTime();
    		}
	%Mytime.Pulse++;
    	if(%Mytime.Pulse >= 3600)
		%Mytime.Pulse = 0;
    schedule(%duration, 0, "TimeCycle", %Mytime, %duration);
}
//---------------------------------------------

function serverCmdDoTime(%client)
{    
    if(isObject(MyTime))
    {
	$MyTime.minutes++;
		$ElevatorStep++;
		if($ElevatorStep >= 4)
			{
			$ElevatorStep = 0;
			$MySunElevationNow++;
			suncycle(Mysun,$SetTheDuration);
			}
	if($MyTime.minutes >=60)
	{
		$MyTime.minutes = 0;
		$MyTime.hours++;
		if(MyTime.hours >= 24)
		{
			$MyTime.hours = 0;
			$MyTime.Day++;
			$MyTime.MonthDay++;
			%DayOfMonth = getword($Month[$MyTime.Month] , 2) +1;
				if($MyTime.MonthDay >= %DayOfMonth)
				{
					$MyTime.MonthDay = 1;
					$MyTime.Month++;
					SetDefaultSeasonSky();

					if($MyTime.Day >= $setWeekDays)
					{
						$MyTime.Day = 0;
						$MyTime.week++;
						if($MyTime.week >= 53)
						$MyTime.week =0;
					}
					if($MyTime.Month >=$setMonths)
					{
						$MySeason = getword($Month[$MyTime.Month], 0);
						$MyTime.Month = 0;
						%yearSet = getword($MyTime.Year, 1);
						%yearNow = getword($MyTime.Year, 0);
						if(%yearSet == "0")
							{
							%yearNow++;
							$MyTime.Year= (%yearNow SPC %yearSet);
							}
							else
							{
							%yearNow--;
							$MyTime.Year= (%yearNow SPC %yearSet);
							}
			
						
					}
				}	
		}
    	}
   }
	$DayNow = getword($weekDay[$MyTime.Day], 1);
	$MonthNow= getword($Month[$MyTime.Month], 1);
	$YearNow = getword($MyTime.Year, 0);
	//%client = $playernow;
	//%MyTimeWord = ("Time is: " @ $MyTime.hours @ ":" @ $MyTime.minutes  SPC $MyTime.MonthDay SPC $DayNow SPC $MonthNow @ " of year " @ $YearNow);
	//messageClient(%client, 'MyTime', %MyTimeWord);
	
	if($MyTime.minutes == $MyTime.Prev)
	{

	}
	else
	{
		$MyTime.Prev = $MyTime.minutes;
		%SetClock = ($MyTime.hours @ ":" @ $MyTime.minutes);
		%SetDater =($DayNow SPC $MyTime.MonthDay SPC $MonthNow @ " of " @ $YearNow SPC "BC");
		isMyclock.text = %SetClock;
		isMyDater.text = %SetDater;
	}


}


	


