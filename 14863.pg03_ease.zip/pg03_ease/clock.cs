// Plastic Gem #3: Ease

// clock.cs

//   IN/OUT codes...
//   $Ease::InOut
//   $Ease::In
//   $Ease::Out
//
//   EASE codes...
//   $Ease::Linear
//   $Ease::Quadratic
//   $Ease::Cubic
//   $Ease::Quartic
//   $Ease::Quintic
//   $Ease::Sinusoidal
//   $Ease::Exponential
//   $Ease::Circular
//   $Ease::Elastic
//   $Ease::Back
//   $Ease::Bounce
//

// this shows how we can use Torque script data-inheritence ...
datablock StaticShapeData(AnalogClockBase)
{
   // functions for this datablock will be in the AnalogClock namespace...
   className = "AnalogClock";

   // load this asset at mission load time...
   preload = true;

};

// since we derive from the analog clock base our className is AnalogClock
// and therefore this datablock's methods are in the AnalogClock namespace...
datablock StaticShapeData(GrandfatherClock : AnalogClockBase)
{
   // shape file containing the clock...
	shapeFile = "plastic/data/shapes/clock/clock.dts";
 
   // what category in mission editor when placing this magnet...
   // we can't put this on the base class because then that abstract
   // class would be placeable (which we don't want)
	category = "Plastic";
};

// ANALOG clock namespace...

// this is called when an object with a clock datablock is created...
function AnalogClock::onAdd(%this,%obj)
{
   // model is constructed 2x what we want...we can scale down here
   // but we ONLY scale down if the scale is not already set...
   if (%obj.getScale() $= "1 1 1")
      %obj.setScale("0.5 0.5 0.5");
      
   // run the 'pendulum' blend animation on thread 0...
   %obj.playThread(0, "pendulum");   
   
   // let's try out a non linear ease
   %ease = $Ease::InOut SPC $Ease::Sinusoidal;
   %obj.setEase(0, %ease);

   // and go a bit slower...
   %obj.setThreadSpeed(0, 0.5);   
   
   // run the 'hourhand' blend anim on thread 1 and pause it...
   %obj.playThread(1, "hourhand");
   %obj.pauseThread(1);

   // run the 'minutehand' blend anim on thread 2 and pause it...
   %obj.playThread(2, "minutehand");
   %obj.pauseThread(2);
   
   // set the default hour to 10:30
   %this.setAnalogClockTime(%obj, "10", "30");
}

function AnalogClock::onEndSequence(%this, %obj, %slot)
{
   // if this is the pendulum swing on slot 0...reverse
   // the thread direction so it will keep going in the other direction
   if (%slot == 0)
   {
      %dir = !%obj.getThreadDir(0);      
      %obj.setThreadDir(0, %dir);
   }
}

// this function manipulates the threads to show the given hour and minutes...
function AnalogClock::setAnalogClockTime(%this, %obj, %hour, %min)
{
   // translate the range "0..12 to the range 0..1
   %obj.setThreadPos(1, %hour / 12.0);
   
   // translate the range "0..60 to the range 0..1
   %obj.setThreadPos(2, %min / 60.0);
}
