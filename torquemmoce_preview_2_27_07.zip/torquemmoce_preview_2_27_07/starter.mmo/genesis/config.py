
import sys


def SetConfig():
    
    #control world creation
    CONFIG.doAll = True
    
    #CONFIG.doItems = True
    CONFIG.singleStat = False
    for a in sys.argv:
        if a.upper() == "-SINGLESTAT":
            CONFIG.singleStat = True



class ConfigDict(dict):
    def __setattr__(self,item,val):
        dict.__setitem__(self,item,val)
        
    def __getattr__(self,item):
        return dict.__getitem__(self,item)
        

CONFIG = ConfigDict()

SetConfig()

#if CONFIG.doAll:
#    CONFIG.doItems = True
    
        
        


    