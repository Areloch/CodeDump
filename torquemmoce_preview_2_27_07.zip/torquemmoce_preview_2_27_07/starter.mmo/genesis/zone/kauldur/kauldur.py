from genesis.dbdict import DBZone
from mud.world.zone import ZoneLink
from mud.world.defines import *

zone = DBZone()
zone.name = "kauldur"
zone.niceName = "The City of Kauldur"
zone.missionFile = "evilcity.mis"
zone.climate = RPG_CLIMATE_TEMPERATE
zone.immTransform = "-236.8 -802.65 150.14 0 0 -1 8.53"

ZoneLink(name = "kauldur_to_wasteland",dstZoneName="wasteland",dstZoneTransform="503.126 1383.12 134.136 0 0 1 237.932")
ZoneLink(name = "kauldur_to_swamp",dstZoneName="swamp",dstZoneTransform="-876.48 -534.13 59.8 0 0 1 48.73")

import spawns
import spawngroups


