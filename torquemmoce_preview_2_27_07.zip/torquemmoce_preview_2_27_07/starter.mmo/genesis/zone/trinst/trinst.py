
from genesis.dbdict import DBZone
from mud.world.zone import ZoneLink

zone = DBZone()
zone.name = "trinst"
zone.niceName = "The City of Trinst"
zone.missionFile = "city.mis"
zone.immTransform = "31.7995 -275.432 126 0 0 1 20.4259"

ZoneLink(name = "city_to_desert",dstZoneName="desertmohrum",dstZoneTransform="-1724.51 -909.035 356.976 0 0 1 63.6632")
ZoneLink(name = "city_to_mountain",dstZoneName="mountain",dstZoneTransform="1426.81 1531.41 193.725 0 0 1 210.593")
ZoneLink(name = "city_to_sewer",dstZoneName="trinstsewer",dstZoneTransform="82.21 -387.12 292.26 0 0 1 179.28")


import spawns
import spawngroups
