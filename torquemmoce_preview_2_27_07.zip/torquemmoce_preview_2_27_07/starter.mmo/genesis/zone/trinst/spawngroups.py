
#--- TRINST SPAWNS

from mud.world.defines import *
from genesis.dbdict import DBSpawnInfo,DBSpawnGroup

#--- wolf   
wolf = DBSpawnInfo(spawn="Grey Wolf")
sg = DBSpawnGroup(zone="trinst",groupName="GREYWOLF")
sg.addSpawnInfo(wolf)
