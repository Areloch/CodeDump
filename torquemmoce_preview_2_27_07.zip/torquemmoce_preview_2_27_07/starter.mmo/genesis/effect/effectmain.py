
from genesis.dbdict import DBEffectProto
from mud.world.defines import *

