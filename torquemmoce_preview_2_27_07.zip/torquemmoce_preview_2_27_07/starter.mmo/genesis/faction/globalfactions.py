
from genesis.dbdict import DBFaction, DBFactionRelation
from mud.world.defines import *


#assassins and necros
DBFaction(name="House Penumbra",level = 5, attackMsg = "Insignificant worm!  Now you shall be crushed by House Penumbra!",enemyMsg = "Die, vile servant of darkness!") 

#elder spiral tbd

#--- Dwarven Houses
#--- House Stoneblood
DBFaction(name="House Stoneblood",level = 5, attackMsg = "The Dwarves will survive!  Zharim, aid us in crushing our enemies!",enemyMsg = "Die, enemy of House Stoneblood!")

#--- House Greystone
DBFaction(name="House Greystone",level = 4, attackMsg = "The Dwarves will survive!  Zharim, aid us in crushing our enemies!",enemyMsg = "Die, enemy of House Greystone!")

#--- House Taskmore
DBFaction(name="House Taskmore",level = 4, attackMsg = "The Dwarves will survive!  Zharim, aid us in crushing our enemies!",enemyMsg = "Die, enemy of House Taskmore!")

#--- Drakken Holds
#--- Veerdakk Hold
DBFaction(name="Veerdakk Hold",level = 4, attackMsg = "None shall rule over Veerdakk Hold!  Feel the might of the Profane!",enemyMsg = "Die, enemy of Veerdakk Hold!")

#--- Rasek Hold
DBFaction(name="Rasek Hold",level = 5, attackMsg = "The might of the Blightborn will crush you!",enemyMsg = "Die, enemy of Rasek Hold!")

#--- House Saurilacer- A Saurian only House
DBFaction(name="House Saurilacer",level = 3, attackMsg = "My past is my strength! Feel the power of my ancestors!",enemyMsg = "Die, enemy of House Saurilacer!")

#--- Faction Relations
DBFactionRelation(faction="Veerdakk Hold", otherFaction = "Rasek Hold", relation = RPG_FACTION_LIKED)
DBFactionRelation(faction="House Saurilacer", otherFaction = "Rasek Hold", relation = RPG_FACTION_DISLIKED)
DBFactionRelation(faction="Rasek Hold", otherFaction = "House Greystone", relation = RPG_FACTION_HATED)
DBFactionRelation(faction="Rasek Hold", otherFaction = "House Stoneblood", relation = RPG_FACTION_HATED)
DBFactionRelation(faction="Rasek Hold", otherFaction = "House Taskmore", relation = RPG_FACTION_HATED)
DBFactionRelation(faction="House Stoneblood", otherFaction = "House Greystone", relation = RPG_FACTION_LIKED)
DBFactionRelation(faction="House Stoneblood", otherFaction = "House Taskmore", relation = RPG_FACTION_LIKED)
DBFactionRelation(faction="House Taskmore", otherFaction = "House Greystone", relation = RPG_FACTION_LIKED)
