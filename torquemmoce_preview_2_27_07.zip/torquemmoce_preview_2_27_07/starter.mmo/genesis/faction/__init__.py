
import globalfactions
