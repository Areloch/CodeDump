import math
from genesis.dbdict import DBDialog,DBDialogLine,DBDialogChoice,DBDialogAction,DBDialogRequirement
from mud.world.defines import *
from mud.world.core import GenMoneyText

