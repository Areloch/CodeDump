from genesis.dbdict import DBItemProto
from mud.world.defines import *


#--- Chest
#--- Light Armor
item = DBItemProto()
item.itemType = ['COMMON','LIGHT','ARMOR']
item.name = "Leather Jerkin"
item.skill="Light Armor"
item.armor = 5
item.repairMax = 15
item.bitmap = "EQUIPMENT/CHEST/38"
item.worthTin = 50
item.slots = (RPG_SLOT_CHEST,)
item.material = "BODY/BODY28"

item.clone(name = "Ornate Cuirass",skill = "Light Armor",armor = 2,bitmap = "EQUIPMENT/CHEST/4", worthTin=100, material="BODY/BODY1")
item.clone(name = "Templar's Cuirass",skill = "Light Armor",armor = 2,bitmap = "EQUIPMENT/CHEST/6", worthTin=100, material="BODY/BODY1")
item.clone(name = "Leather Cuirass",skill = "Light Armor",armor = 4,bitmap = "EQUIPMENT/CHEST/5", worthCopper=20, material="BODY/BODY28")

item = item.clone(name = "White Shirt",armor = 1,bitmap = "EQUIPMENT/CHEST/7", worthTin=50, worthCopper=0, material="BODY/BODY11")
item.clone(name = "Red Shirt",armor = 1,bitmap = "EQUIPMENT/CHEST/8", worthTin=50, material="BODY/BODY11")
item.clone(name = "Yellow Shirt",armor = 1,bitmap = "EQUIPMENT/CHEST/9", worthTin=50, material="BODY/BODY11")
item.clone(name = "Stylish Tunic",armor = 2,bitmap = "EQUIPMENT/CHEST/10", worthTin=100, material="BODY/BODY14")

item.clone(name = "Plain Tunic",armor = 3,bitmap = "EQUIPMENT/CHEST/11", worthCopper=10, material="BODY/BODY70")
item.clone(name = "Red Tunic",armor = 3,bitmap = "EQUIPMENT/CHEST/12", worthCopper=10, material="BODY/BODY1")
item.clone(name = "Quilted Tunic",armor = 5,bitmap = "EQUIPMENT/CHEST/13", worthCopper=30, material="BODY/BODY25")
item.clone(name = "Leather Tunic",armor = 6,bitmap = "EQUIPMENT/CHEST/14", worthCopper=40, material="BODY/BODY29")
item.clone(name = "Padded Tunic",armor = 6,bitmap = "EQUIPMENT/CHEST/14", worthCopper=40, material="BODY/BODY26")
item.clone(name = "Ornate Leather Tunic",armor = 6,bitmap = "EQUIPMENT/CHEST/15", worthCopper=40, material="BODY/BODY13")
item.clone(name = "Traveller's Tunic",armor = 6,bitmap = "EQUIPMENT/CHEST/16", worthCopper=40, material="BODY/BODY11")
item.clone(name = "Primitive Tunic",armor = 6,bitmap = "EQUIPMENT/CHEST/17", worthCopper=40, material="BODY/BODY11")
item.clone(name = "Iron Worker's Tunic",armor = 7,bitmap = "EQUIPMENT/CHEST/18", worthCopper=50, material="BODY/BODY19")

item.clone(name = "Woven Garment",armor = 4,bitmap = "EQUIPMENT/CHEST/29", worthCopper=20, material="BODY/BODY11")


#-- Medium Armor
item.clone(name = "Chain Chest",skill = "Medium Armor",armor = 8,itemType = ['COMMON','MEDIUM','ARMOR'],bitmap = "EQUIPMENT/CHEST/1", worthCopper=60, material="BODY/BODY19")
item.clone(name = "Brass Chest",skill = "Medium Armor",armor = 10,itemType = ['COMMON','MEDIUM','ARMOR'],bitmap = "EQUIPMENT/CHEST/1", worthCopper=80, material="BODY/BODY23")

#-- heavy armor

item.clone(name = "Steel Chest",skill = "Heavy Armor",armor = 14,itemType = ['COMMON','HEAVY','ARMOR'],bitmap = "EQUIPMENT/CHEST/3", worthSilver=20, material="BODY/BODY20")
item.clone(name = "Iron Chest",skill = "Heavy Armor",armor = 12,itemType = ['COMMON','HEAVY','ARMOR'],bitmap = "EQUIPMENT/CHEST/2", worthCopper=100, material="BODY/BODY22")
item.clone(name = "Plate Chest",skill = "Heavy Armor",armor = 18,itemType = ['COMMON','HEAVY','ARMOR'],bitmap = "EQUIPMENT/CHEST/3", worthSilver=60, material="BODY/BODY27")
item.clone(name = "Platinum Chest",skill = "Heavy Armor",armor = 22,itemType = ['COMMON','HEAVY','ARMOR'],bitmap = "EQUIPMENT/CHEST/37", worthSilver=100, material="BODY/BODY24")











