from genesis.dbdict import DBItemProto
from mud.world.defines import *

from genesis.dbdict import DBSpellProto,DBEffectProto
from mud.world.defines import *


def CreatePotion(name,stat,value,message,level,desc):
    effect = DBEffectProto(name = name)
    effect.addPermanentStat(stat,value)
    
    spell = DBSpellProto(name = name)
    spell.target = RPG_TARGET_SELF
    spell.duration = 0
    spell.castTime = 0
    spell.recastTime = 0
    spell.harmful = False
    spell.addEffect(name)
    spell.beginMsg = message
    spell.sndBegin = "sfx/Pickup_Special12.ogg"
    
    item = DBItemProto(name = name)
    item.addSpell(name,RPG_ITEM_TRIGGER_USE,1)
    item.level = level
    if value == 1:
        item.bitmap = "STUFF/13"
    else:
        item.bitmap = "STUFF/40"
        
    item.useMax = 1
    item.desc = desc
    item.stackMax = 20
    item.stackDefault = 1
    
    
#strength    
desc = "This cloudy potion increases strength permanently by 1 point.  You must be level 5 or higher to use it."    
CreatePotion("Potion of Strength","strBase",1,"$tgt's muscles bulge and grow!",5,desc)

desc = "This cloudy potion increases strength permanently by 4 points.  You must be level 5 or higher to use it."    
CreatePotion("Fortified Potion of Strength","strBase",4,"$tgt's muscles bulge and grow!",5,desc)

desc = "This cloudy elixir increases strength permanently by 5 points.  You must be level 25 or higher to use it."    
CreatePotion("Elixir of Strength","strBase",5,"$tgt's muscles bulge and grow!",25,desc)

#dex
desc = "This clear potion increases dexterity permanently by 1 point.  You must be level 5 or higher to use it."    
CreatePotion("Potion of Dexterity","dexBase",1,"$tgt has become more dextrous!",5,desc)

desc = "This clear potion increases dexterity permanently by 4 points.  You must be level 5 or higher to use it."    
CreatePotion("Fortified Potion of Dexterity","dexBase",4,"$tgt has become more dextrous!",5,desc)


desc = "This clear elixir increases dexterity permanently by 5 points.  You must be level 25 or higher to use it."    
CreatePotion("Elixir of Dexterity","dexBase",5,"$tgt has become more dextrous!",25,desc)

#ref
desc = "This green potion increases reflexes permanently by 1 point.  You must be level 5 or higher to use it."    
CreatePotion("Potion of Reflex","refBase",1,"$tgt's reflexes have improved!",5,desc)

desc = "This green potion increases reflexes permanently by 4 points.  You must be level 5 or higher to use it."    
CreatePotion("Fortified Potion of Reflex","refBase",4,"$tgt's reflexes have improved!",5,desc)


desc = "This green elixir increases reflexes permanently by 5 points.  You must be level 25 or higher to use it."    
CreatePotion("Elixir of Reflex","refBase",5,"$tgt's reflexes have improved!",25,desc)

#agi
desc = "This shimmering potion increases agility permanently by 1 point.  You must be level 5 or higher to use it."    
CreatePotion("Potion of Agility","agiBase",1,"$tgt becomes more agile!",5,desc)

desc = "This shimmering potion increases agility permanently by 4 points.  You must be level 5 or higher to use it."    
CreatePotion("Fortified Potion of Agility","agiBase",4,"$tgt becomes more agile!",5,desc)


desc = "This shimmering elixir increases agility permanently by 5 points.  You must be level 25 or higher to use it."    
CreatePotion("Elixir of Agility","agiBase",5,"$tgt becomes more agile!",25,desc)
    
#wisdom
desc = "This radiant potion increases wisdom permanently by 1 point.  You must be level 5 or higher to use it."    
CreatePotion("Potion of Wisdom","wisBase",1,"$tgt gains new wisdom!",5,desc)

desc = "This radiant potion increases wisdom permanently by 4 points.  You must be level 5 or higher to use it."    
CreatePotion("Fortified Potion of Wisdom","wisBase",4,"$tgt gains new wisdom!",5,desc)

desc = "This radiant elixir increases wisdom permanently by 5 points.  You must be level 25 or higher to use it."    
CreatePotion("Elixir of Wisdom","wisBase",5,"$tgt gains new wisdom!",25,desc)
    
#Body
desc = "This hearty potion increases body permanently by 1 point.  You must be level 5 or higher to use it."    
CreatePotion("Potion of Body","bdyBase",1,"$tgt has become more substantial!",5,desc)

desc = "This hearty potion increases body permanently by 4 points.  You must be level 5 or higher to use it."    
CreatePotion("Fortified Potion of Body","bdyBase",4,"$tgt has become more substantial!",5,desc)


desc = "This hearty elixir increases body permanently by 5 points.  You must be level 25 or higher to use it."    
CreatePotion("Elixir of Body","bdyBase",5,"$tgt has become more substantial!",25,desc)

#mnd
desc = "This chunky potion increases mind permanently by 1 point.  You must be level 5 or higher to use it."    
CreatePotion("Potion of Mind","mndBase",1,"$tgt's mind expands!",5,desc)

desc = "This chunky potion increases mind permanently by 4 points.  You must be level 5 or higher to use it."    
CreatePotion("Fortified Potion of Mind","mndBase",4,"$tgt's mind expands!",5,desc)

desc = "This chunky elixir increases mind permanently by 5 points.  You must be level 25 or higher to use it."    
CreatePotion("Elixir of Mind","mndBase",5,"$tgt's mind expands!",25,desc)

#mysticism

desc = "This dark potion increases mysticism permanently by 1 point.  You must be level 5 or higher to use it."    
CreatePotion("Potion of Mysticism","mysBase",1,"$tgt gains insight into the mystic!",5,desc)

desc = "This dark potion increases mysticism permanently by 4 points.  You must be level 5 or higher to use it."    
CreatePotion("Fortified Potion of Mysticism","mysBase",4,"$tgt gains insight into the mystic!",5,desc)

desc = "This dark elixir increases mysticism permanently by 5 points.  You must be level 25 or higher to use it."    
CreatePotion("Elixir of Mysticism","mysBase",5,"$tgt gains insight into the mystic!",25,desc)

#scroll of learning
effect = DBEffectProto(name = "Scroll of Learning")
effect.addPermanentStat("advancementPoints",2)

spell = DBSpellProto(name = "Scroll of Learning")
spell.target = RPG_TARGET_SELF
spell.duration = 0
spell.castTime = 0
spell.recastTime = 0
spell.harmful = False
spell.addEffect("Scroll of Learning")
spell.beginMsg = "$tgt devours knowledge and has gained 2 advancement points!"
spell.sndBegin = "sfx/Pickup_Special12.ogg"

item = DBItemProto(name = "Scroll of Learning")
item.addSpell("Scroll of Learning",RPG_ITEM_TRIGGER_USE,1)
item.level = 10
item.bitmap = "STUFF/2"
    
item.useMax = 1
item.desc = "This scroll contains knowledge.  You must be level 10 or higher to apply it.  Knowledge is power!"
item.stackMax = 20
item.stackDefault = 1

#book of learning
effect = DBEffectProto(name = "Book of Learning")
effect.addPermanentStat("advancementPoints",10)

spell = DBSpellProto(name = "Book of Learning")
spell.target = RPG_TARGET_SELF
spell.duration = 0
spell.castTime = 0
spell.recastTime = 0
spell.harmful = False
spell.addEffect("Book of Learning")
spell.beginMsg = "$tgt devours knowledge and has gained 10 advancement points!"
spell.sndBegin = "sfx/Pickup_Special12.ogg"

item = DBItemProto(name = "Book of Learning")
item.addSpell("Book of Learning",RPG_ITEM_TRIGGER_USE,1)
item.level = 50
item.bitmap = "STUFF/25"
    
item.useMax = 1
item.desc = "This book contains knowledge.  You must be level 50 or higher to apply it.  Knowledge is power!"
item.stackMax = 20
item.stackDefault = 1



