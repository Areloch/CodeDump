from genesis.dbdict import DBItemProto
from mud.world.defines import *

from genesis.dbdict import DBSpellProto,DBEffectProto
from mud.world.defines import *


def CreatePotion(name,effect,desc):
    
    spell = DBSpellProto(name = name)
    spell.target = RPG_TARGET_SELF
    spell.duration = 0
    spell.castTime = 0
    spell.recastTime = 0
    spell.harmful = False
    spell.addEffect(effect)
    
    item = DBItemProto(name = name)
    item.addSpell(name,RPG_ITEM_TRIGGER_USE,1)
    item.bitmap = "STUFF/3"
        
    item.useMax = 1
    item.desc = desc
    item.stackMax = 20
    item.stackDefault = 1
    
        
#CreatePotion("Potion of Anidaen Gate","SELF TP ANIDAEN FOREST","This potion will gate you to the Anidaen Forest.")
#CreatePotion("Potion of Frostbite Gate","SELF TP FROSTBITE ISLANDS","This potion will gate you to the Frostbite Islands.")
#CreatePotion("Potion of Jakreth Gate","SELF TP JAKRETH JUNGLE","This potion will gate you to the Jakreth Jungle.")
#CreatePotion("Potion of Talrim Gate","SELF TP TALRIM HILLS","This potion will gate you to the Talrim Hills.")
#CreatePotion("Potion of Mohrum Gate","SELF TP MOHRUM DESERT","This potion will gate you to the Desert of Mohrum.")
#CreatePotion("Potion of Trinst Gate","SELF TP TRINST","This potion will gate you to the City of Trinst.")
#CreatePotion("Potion of Kauldur Gate","SELF TP KAULDUR","This potion will gate you to the City of Kauldur.")
#CreatePotion("Potion of Swamp Gate","SELF TP SWAMP","This potion will gate you to the Swamp of Ruin.")



 