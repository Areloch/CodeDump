from genesis.dbdict import DBItemProto
from mud.world.defines import *



#--- 1H Pierce
item = DBItemProto()
item.itemType = ['COMMON','WEAPON']
item.name = "Longsword"
item.skill="1H Slash"
item.wpnDamage = 4
item.wpnRate = 11
item.wpnRange = 2
item.repairMax = 10
item.bitmap = "EQUIPMENT/SWORDS/24"
item.model = "weapons/sword01.dts"
item.worthCopper = 45
item.slots = (RPG_SLOT_PRIMARY,RPG_SLOT_SECONDARY)