from genesis.dbdict import *
from mud.world.defines import *
 

#--- Flamedance
item = DBItemProto(name="Flamedance")
item.itemType = ["COMMON","COMPONENT"]
item.desc = "This precious gemstone dances in the light."
item.bitmap = "STUFF/73"
item.stackMax = 20
item.stackDefault = 5
item.worthGold = 10
item.worthPlatinum = 25

item = DBItemProto(name="Blue Quartz")
item.itemType = ["COMMON","COMPONENT"]
item.desc = "This precious gemstone is used in spell casting."
item.bitmap = "STUFF/71"
item.stackMax = 20
item.stackDefault = 5
item.worthCopper = 2

item = DBItemProto(name="Fire Agate")
item.itemType = ["COMMON","COMPONENT"]
item.desc = "This precious gemstone is used in spell casting."
item.bitmap = "STUFF/70"
item.stackMax = 20
item.stackDefault = 5
item.worthCopper = 2

item = DBItemProto(name="Malachite")
item.itemType = ["COMMON","COMPONENT"]
item.desc = "This precious gemstone is used in spell casting."
item.bitmap = "STUFF/68"
item.stackMax = 20
item.stackDefault = 5
item.worthCopper = 2
