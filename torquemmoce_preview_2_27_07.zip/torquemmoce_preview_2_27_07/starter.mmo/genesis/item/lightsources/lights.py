from genesis.dbdict import DBItemProto
from mud.world.defines import *


item = DBItemProto()
item.itemType = ['COMMON','LIGHTSOURCE']
item.name = "Torch"
item.bitmap = "STUFF/6"
item.light = 3
item.worthTin = 50
item.worthCopper = 3
item.slots = (RPG_SLOT_LIGHT,)

item.clone(name = "Gnomish Lantern",bitmap = "STUFF/4", worthGold = 50, worthPlatinum = 20,light = 6)
item.clone(name = "Candle",bitmap = "STUFF/11", worthTin = 25,light = 2)
item.clone(name = "Candelabra",bitmap = "STUFF/5", worthTin = 25,worthSilver=10,worthGold=2,light = 4)

