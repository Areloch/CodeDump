
from genesis.dbdict import DBSpellProto
from mud.world.defines import *

