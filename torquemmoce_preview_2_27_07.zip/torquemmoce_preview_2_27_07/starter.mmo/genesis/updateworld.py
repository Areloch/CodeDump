
#this is called from the game, so we don't have to drop all the tables
#we also need some way to patch the world, that'll have to come later


#table import
from mud.common.persistent import Persistent
from mud.world.theworld import World
from mud.world.player import Player
from mud.world.character import Character,CharacterSpell,StartingGear
from mud.world.zone import Zone,ZoneLink
from mud.world.loot import LootItem,LootProto
from mud.world.dialog import JournalEntry,Dialog,DialogLine,DialogChoice,DialogRequirement,DialogRequireClass,DialogRequireRace,DialogRequireRealm,DialogRequireSkill,DialogRequireItem,DialogAction,DialogTakeItem,DialogGiveItem,DialogCheckItem,DialogFaction,DialogCheckMinFaction,DialogCheckMaxFaction,DialogTrainSkill,DialogCheckSkill
from mud.world.vendor import VendorItem,VendorProto
from mud.world.spawn import Spawn,SpawnSkill,SpawnSpell,SpawnInfo,SpawnGroup,SpawnSoundProfile,SpawnKillFaction,SpawnResistance,SpawnStat
from mud.world.item import ItemStat,ItemSlot,ItemRace,ItemClass,ItemSpell,Item,ItemSet,ItemProto,ItemSoundProfile,ItemSetStat,ItemSetSpell,ItemSetRequirement,ItemSetPower,ItemSetProto
from mud.world.faction import Faction,FactionRelation
from mud.world.effect import EffectProto,EffectStat,EffectDamage,EffectPermanentStat,EffectLeech,EffectDrain,EffectRegen,EffectIllusion
from mud.world.spell import SpellProto,SpellClass,SpellComponent,SpellParticleNode
from mud.world.skill import ClassSkill,ClassSkillRaceRequirement,ClassSkillQuestRequirement
from mud.world.career import ClassProto
from mud.world.crafting import RecipeIngredient,Recipe
#battles
from mud.world.battle import BattleGroup,BattleSequence,BattleResult,BattleProto,BattleMustSurvive

import traceback,sys

#certain tables are entirely recreated upon update
def RecreateTables():
    tables = [StartingGear,ZoneLink,LootItem,LootProto,
    JournalEntry,DialogLine,DialogChoice,DialogRequirement,DialogRequireClass,DialogRequireRace,DialogRequireRealm,DialogRequireSkill,DialogRequireItem,DialogAction,DialogTakeItem,DialogGiveItem,DialogCheckItem,DialogFaction,DialogCheckMinFaction,DialogCheckMaxFaction,DialogTrainSkill,DialogCheckSkill,
    VendorItem,VendorProto,SpawnSkill,SpawnInfo,SpawnGroup,SpawnSoundProfile,SpawnKillFaction,SpawnResistance,SpawnSpell,SpawnStat,ItemStat,ItemSlot,ItemSpell,ItemRace,ItemClass,ItemSoundProfile,ItemSet,ItemSetStat,ItemSetSpell,ItemSetRequirement,ItemSetPower,ItemSetProto,
    Faction,FactionRelation,EffectStat,EffectPermanentStat,EffectDamage,EffectLeech,EffectDrain,EffectRegen,EffectIllusion,SpellClass,SpellComponent,SpellParticleNode,ClassSkill,ClassSkillRaceRequirement,ClassSkillQuestRequirement,
    BattleGroup,BattleSequence,BattleResult,BattleProto,BattleMustSurvive,RecipeIngredient,Recipe]

    for t in tables:
        t.dropTable(ifExists=True)
        t.createTable()

import sys, __builtin__

class RollbackImporter:
    def __init__(self):
        "Creates an instance and installs as the global importer"
        self.previousModules = sys.modules.values()[:]
        self.realImport = __builtin__.__import__
        __builtin__.__import__ = self._import
                
    def _import(self, name, globals=None, locals=None, fromlist=[]):
        result = apply(self.realImport, (name, globals, locals, fromlist))
        return result
        
    def uninstall(self):
        keys = []
        for name,mod in sys.modules.iteritems():
            if mod not in self.previousModules:
                keys.append(name)
                
        for name in keys:
            # Force reload when modname next imported
            del(sys.modules[name])
        __builtin__.__import__ = self.realImport

def DoIt():
    
    
    from dbdict import DBDict
    DBDict.clearRegistry()
    
    #hm
    for cp in list(ClassProto.select()):
        for cs in cp.skills:
            cp.removeClassSkill(cs)

    
    RecreateTables()
    
    
    import item.itemmain
    import dialog.dialogmain
    import vendor.vendormain
    import spawn.spawnmain
    import effect.effectmain
    import spell.spellmain
    import zone.zonemain
    import genesis.skill
    import genesis.career
    import genesis.faction
    import genesis.battles
    import genesis.crafting
    import genesis.othercontent

    try:
        import genesis.mystuff
    except:
        traceback.print_exception(sys.exc_info()[0],sys.exc_info()[1],sys.exc_info()[2])
        pass
    
    DBDict.createRows('SpellProto') #all effects used should be drug in (this is before itemproto, so scrolls are made)
    DBDict.createRows('ItemSetPower')
    DBDict.createRows('ItemSetProto')
    DBDict.createRows('ItemProto')
    DBDict.createRows('ClassSkill')
    DBDict.createRows('ClassProto')
    DBDict.createRows('Dialog')
    DBDict.createRows('Spawn')
    DBDict.createRows('SpawnInfo')
    DBDict.createRows('SpawnGroup')
    DBDict.createRows('Zone')
    DBDict.createRows('FactionRelation')
    DBDict.createRows('Recipes')
    
def UpdateWorld():
    
    import time
    beginTime = time.time()

    #commit database
    w = World.byName("TheWorld")
    #w.commit()
    rollback = RollbackImporter()
    
    conn = Persistent._connection.getConnection()
    cursor = conn.cursor()
    cursor.execute("END;")
    cursor.execute("BEGIN;")
    try:
        DoIt()
        cursor.execute("END;")
    except:
        traceback.print_exception(sys.exc_info()[0],sys.exc_info()[1],sys.exc_info()[2])
        cursor.execute("ROLLBACK;")
        
    cursor.execute("BEGIN;")
    
    #w.commit()
        
    rollback.uninstall()
    
    cursor.close()
    
    
    return int(time.time()-beginTime)
