//--- OBJECT WRITE BEGIN ---
datablock sgUniversalStaticLightData(poot) {
className = "sgUniversalStaticLightData";
};
//--- OBJECT WRITE END ---
