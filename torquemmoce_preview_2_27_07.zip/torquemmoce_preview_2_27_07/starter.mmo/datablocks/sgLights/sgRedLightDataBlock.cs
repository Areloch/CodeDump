//-----------------------------------------------
// Copyright � Synapse Gaming 2003
// Written by John Kabus
//-----------------------------------------------

//--- OBJECT WRITE BEGIN ---
datablock sgUniversalStaticLightData(sgRedLightDataBlock)
{
   Colour = "0.6 0.0 0.0";
   radius = 10;
   FlareOn = false;
   SpotLight = false;
   StaticLight = true;
   EffectsDTSObjects = false;
   AdvancedLightingModel = false;
};
//--- OBJECT WRITE END ---





