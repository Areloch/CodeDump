
function initDatablocks()
{
    exec("./audioProfiles.cs");
    exec("./camera.cs");
    exec("./crossbow.cs");
    exec("./markers.cs");
    exec("./player.cs");
    exec("./sgLights.cs");
    exec("./weather.cs");
    exec("./zonetrigger.cs");
    exec("./spells/init.cs");
    exec("./particles/init.cs");
}


