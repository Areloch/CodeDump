//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

addMaterialMapping( "drygrass3" , "sound: 0" , "color: 0.46 0.36 0.26 0.4 0.0" ); 
addMaterialMapping( "grass01" , "sound: 0" , "color: 0.46 0.36 0.26 0.4 0.0" ); 
addMaterialMapping( "sand006" , "sound: 0" , "color: 0.46 0.36 0.26 0.4 0.0" );
addMaterialMapping( "sand003" , "sound: 0" , "color: 0.46 0.36 0.26 0.4 0.0" ); 
addMaterialMapping( "stone05a" , "sound: 0" , "color: 0.46 0.36 0.26 0.4 0.0" );  