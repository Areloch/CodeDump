
from mud.gamesettings import USE_TGEA

if USE_TGEA:
    from pytgea import *
else:
    from pytge import *
