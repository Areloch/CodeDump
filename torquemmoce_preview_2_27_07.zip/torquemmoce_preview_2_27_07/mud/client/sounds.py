
from mud.world.shared.sounddefs import *

SOUNDS = {
SND_INVENTORY : "sfx/Pickup_Armour_FlakVest2.ogg",
SND_ITEMEQUIP : "sfx/Pickup_ArmourShield05.ogg",
SND_COINS : "sfx/Pickup_Coins01.ogg"
} 