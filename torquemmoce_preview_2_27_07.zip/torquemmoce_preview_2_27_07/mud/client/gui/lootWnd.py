from tgenative import *
from mud.tgepython.console import TGEExport
from mud.world.defines import *


LOOTWND = None


class LootWnd:
    def __init__(self):
        self.lootButtons = {}
        self.window = TGEObject("LOOTWND_WINDOW")
        for x in xrange(0,16):
            self.lootButtons[x]=TGEObject("LOOT_BUTTON%i"%x)
            
    def setLoot(self,loot):
        self.loot = loot
        
        for button in self.lootButtons.itervalues():
            button.visible = False
            button.number = -1
            
        for x,ghost in loot.iteritems():
            button = self.lootButtons[x]
            button.setBitmap("~/data/ui/items/"+ghost.BITMAP+"/0_0_0")
            button.visible = True
            if ghost.STACKMAX>1:
                button.number = ghost.STACKCOUNT

def OnReallyLootButtonAlt(args):
    from partyWnd import PARTYWND
    charIndex = int(args[1])
    slot = int(args[2])
    
    PARTYWND.mind.lootAlt(charIndex,slot)
    

def OnLootButtonAlt(args):
    from partyWnd import PARTYWND
    from allianceWnd import ALLIANCEWND
    curIndex = PARTYWND.curIndex #just in case current character changes we want to make choice reflect dialog no matter what
    cinfo = PARTYWND.charInfos[curIndex]
    name = cinfo.NAME
    
    slot = int(args[1])
    try:
        ghost = LOOTWND.loot[slot]
        if ghost.FLAGS&RPG_ITEM_SOULBOUND and not int(TGEGetGlobal("$Py::ISSINGLEPLAYER")) and ALLIANCEWND.allianceInfo:
            TGEEval('MessageBoxYesNo("Loot Item?", "Do you really want %s to loot this SOULBOUND item?","Py::OnReallyLootButtonAlt(%i,%i);");'%(name,curIndex,slot))
        else:
            TGEEval('Py::OnReallyLootButtonAlt(%i,%i);'%(curIndex,slot))
    except KeyError:
        return



def OnReallyLootButton(args):
    from partyWnd import PARTYWND
    charIndex = int(args[1])
    slot = int(args[2])
    
    PARTYWND.mind.loot(charIndex,slot)
    

def OnLootButton(args):
    from partyWnd import PARTYWND
    curIndex = PARTYWND.curIndex #just in case current character changes we want to make choice reflect dialog no matter what
    cinfo = PARTYWND.charInfos[curIndex]
    name = cinfo.NAME
    
    slot = int(args[1])
    try:
        ghost = LOOTWND.loot[slot]
        if ghost.FLAGS&RPG_ITEM_SOULBOUND and not int(TGEGetGlobal("$Py::ISSINGLEPLAYER")):
            TGEEval('MessageBoxYesNo("Loot Item?", "Do you really want %s to loot this SOULBOUND item?","Py::OnReallyLootButton(%i,%i);");'%(name,curIndex,slot))
        else:
            TGEEval('Py::OnReallyLootButton(%i,%i);'%(curIndex,slot))
    except KeyError:
        return
        
def OnReallyDestroyCorpse():
    from partyWnd import PARTYWND
    PARTYWND.mind.destroyCorpse()
    
        
def OnDestroyCorpse(args):
    print args
    if int(args[1]):
        OnReallyDestroyCorpse()
        return
        
    
    TGEEval('MessageBoxYesNo("Destroy Corpse?", "Do you really want destroy this corpse?","Py::OnReallyDestroyCorpse();");')
        
    
def OnCloseLootWnd():
    from partyWnd import PARTYWND
    PARTYWND.mind.closeLootWnd()
    
    

def PyExec():
    global LOOTWND
    LOOTWND = LootWnd()
    
    
    
    TGEExport(OnCloseLootWnd,"Py","OnCloseLootWnd","desc",1,1)
    
    TGEExport(OnLootButton,"Py","OnLootButton","desc",2,2)
    TGEExport(OnReallyLootButton,"Py","OnReallyLootButton","desc",3,3)

    TGEExport(OnLootButtonAlt,"Py","OnLootButtonAlt","desc",2,2)
    TGEExport(OnReallyLootButtonAlt,"Py","OnReallyLootButtonAlt","desc",3,3)
    

    
    TGEExport(OnDestroyCorpse,"Py","OnDestroyCorpse","desc",2,2)
    TGEExport(OnReallyDestroyCorpse,"Py","OnReallyDestroyCorpse","desc",1,1)
    