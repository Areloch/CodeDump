
from tgenative import *
from mud.tgepython.console import TGEExport
from mud.gamesettings import *
import tarfile
import traceback

import re

LINK_PARSER = re.compile(r'~~+[a-zA-Z0-9\'\s-]*~~+[:,.;%()a-zA-Z0-9\'\s-]*~~+')

HTMLLINK_PARSER = re.compile(r'<a +[\s\S]*</a>+\s+')

HEADER1_PARSER = re.compile(r'YYYZ+.*')
HEADER2_PARSER = re.compile(r'XXXZZ+.*')
HEADER3_PARSER = re.compile(r'AAABBB+.*')
HEADER4_PARSER = re.compile(r'LLLMMMM+.*')



METAINFO_PARSER = re.compile(r'%META:TOPICINFO+[\s\S]*%+\s+')

QUICKLINK_PARSER = re.compile(r'\*Quick Links:+.*\s+')

TAG_PARSER = re.compile(r'#[a-zA-Z]*\s+')

BOLD_PARSER = re.compile(r'\*+[\w :,]*\*+\s+')


ENCYC = {}

HEADER = """<color:2DCBC9><linkcolor:AAAA00><shadowcolor:000000><shadow:1:1><just:center><lmargin%:2><rmargin%:98><font:Arial Bold:20>Minions of Mirth Encyclopedia
<font:Arial:14><just:left>"""

HOME = """
<a:ZoneIndex>Zones</a>
<a:SpawnIndex>Spawns</a>
<a:SpawnIndexByLevel>Spawns by Level</a>
<a:ItemIndex>Items</a>
<a:QuestIndex>Quests</a>
<a:SpellIndex>Spells</a>
<a:SkillIndex>Skills</a>
<a:ClassIndex>Classes</a>
<a:RecipeIndex>Recipes</a><br>
<a:EnchantingDisenchantingIndex>Enchanting / Disenchanting</a>
"""

PAGECACHE = {}

ENCWND = None

class EncWindow:
    def __init__(self):
        self.encText = TGEObject("ENCYC_TEXT")
        self.encScroll = TGEObject("ENCYC_SCROLL")
        self.history = []
        self.positions = {}
        self.curIndex = -1
        
        
    def setPage(self,mypage,append = True):
        
        try:
            page = ENCYC[mypage]
        except:
            return
        
        text = ""
        if PAGECACHE.has_key(mypage):
            text = PAGECACHE[mypage]
            

        pos = self.encScroll.childRelPos.split(" ")
        self.positions[self.curIndex]=(pos[0],pos[1])
        
        
        if append:
            
            if self.curIndex >= 0:
                self.history = self.history[:self.curIndex+1]
                self.history.append(mypage)
                self.curIndex = len(self.history)-1
            else:
                self.history.append(mypage)
                self.curIndex+=1
                
        
        if not text:
            text = HEADER+page
            
            text = text.replace("---++++","LLLMMMM")
            text = text.replace("---+++","AAABBB")
            text = text.replace("---++","XXXZZ")
            text = text.replace("---+","YYYZ")
            
            #strip out html links
            for hlink in HTMLLINK_PARSER.findall(text):
                text = text.replace(hlink,"")
                
            for meta in METAINFO_PARSER.findall(text):
                text = text.replace(meta,"")
                
            for qlink in QUICKLINK_PARSER.findall(text):
                text = text.replace(qlink,"")
                
            for tag in TAG_PARSER.findall(text):
                text = text.replace(tag,"")
                
                
            for bold in BOLD_PARSER.findall(text):
                s = bold.replace("*","")
                t = "<font:Arial Bold:14>"+s+"<font:Arial:14>"
                text = text.replace(bold,t)
            
            #HEADERS
            for header in HEADER1_PARSER.findall(text):
                t = "<font:Arial Bold:20><color:2DCBC9><just:center>"+header[5:]+"<font:Arial:14><just:left><color:D5E70A>"
                text = text.replace(header,t)
                
            for header in HEADER2_PARSER.findall(text):
                t = "<font:Arial Bold:18><color:2DCBC9><just:center>"+header[6:]+"<font:Arial:14><just:left><color:D5E70A>"
                text = text.replace(header,t)
    
            for header in HEADER3_PARSER.findall(text):
                t = "<font:Arial Bold:17><color:2DCBC9><just:center>"+header[7:]+"<font:Arial:14><just:left><color:D5E70A>"
                text = text.replace(header,t)
    
            for header in HEADER4_PARSER.findall(text):
                t = "<font:Arial Bold:16><color:2DCBC9><just:center>"+header[8:]+"<font:Arial:14><just:left><color:D5E70A>"
                text = text.replace(header,t)
            
            # Text coloring
            text = text.replace(r'%GREEN%',"<color:00FF00>")
            text = text.replace(r'%BLUE%',"<color:3030FF>")
            text = text.replace(r'%RED%',"<color:FF0000>")
            text = text.replace(r'%YELLOW%',"<color:FFC000>")
            text = text.replace(r'%ENDCOLOR%',"<color:D5E70A>")
    
            
            text = text.replace('[',"~")
            text = text.replace(']',"~") 
            text = text.replace('\r',"\\r")
            text = text.replace('\n',"\\n") #valid quote
            text = text.replace('\a',"\\a") #valid quote
            text = text.replace('"','\\"') #invalid quote
            
            
            
            
            for link in LINK_PARSER.findall(text):
                wlink = link.split("~~")
                nlink = r'<a:%s>%s</a>'%(wlink[1],wlink[2])
                text = text.replace(link,nlink)
            
        
        
        
        TGEEval(r'ENCYC_TEXT.setText("");')
        
        #get around some tge poop
        x = 0
        while x < len(text):
            add = 1024
            t = text[x:x+add]
            if t[len(t)-1]=='\\':
                add+=1
                t = text[x:x+add]
                
            TGEEval(r'ENCYC_TEXT.addText("%s",false);'%t)
            x+=add
            
        PAGECACHE[mypage]=text
            
        #reformat
        TGEEval(r'ENCYC_TEXT.addText("\n",true);')
        
    def home(self):
        self.curIndex = -1
        self.history = []

        self.setPage("Home")
        
    def back(self):
        if self.curIndex < 1:
            return
        
        pos = self.encScroll.childRelPos.split(" ")
        self.positions[self.curIndex]=(pos[0],pos[1])

        
        
        self.setPage(self.history[self.curIndex-1],False)
        self.curIndex-=1
        pos = self.positions[self.curIndex]     
        
        self.encScroll.scrollRectVisible(pos[0],pos[1],1,444)
        
    def forward(self):
        if self.curIndex >= len(self.history)-1 or not len(self.history):
            return
        
        pos = self.encScroll.childRelPos.split(" ")
        self.positions[self.curIndex]=(pos[0],pos[1])
        
        
        
        self.setPage(self.history[self.curIndex+1],False)
        self.curIndex+=1
        pos = self.positions[self.curIndex]
        self.encScroll.scrollRectVisible(pos[0],pos[1],1,444)


def encyclopediaSearch(searchvalue):
    if not ENCWND:
        PyExec()
    from mud.worlddocs.utils import GetTWikiName
    formatted = GetTWikiName(searchvalue)
    page = None
    if ENCYC.has_key("Item%s"%formatted):
        page = "Item%s"%formatted
    elif ENCYC.has_key("Spell%s"%formatted):
        page = "Spell%s"%formatted
    elif ENCYC.has_key("Recipe%s"%formatted):
        page = "Recipe%s"%formatted
    elif ENCYC.has_key("Skill%s"%formatted):
        page = "Skill%s"%formatted
    elif ENCYC.has_key("Class%s"%formatted):
        page = "Class%s"%formatted
    elif ENCYC.has_key("Spawn%s"%formatted):
        page = "Spawn%s"%formatted
    elif ENCYC.has_key("Quest%s"%formatted):
        page = "Quest%s"%formatted
    elif ENCYC.has_key("Zone%s"%formatted):
        page = "Zone%s"%formatted
    
    if page:
        ENCWND.setPage(page)
    else:
        TGECall("MessageBoxOK","Entry not found","No entry for %s in encyclopedia."%searchvalue)
    return

def OnEncyclopediaOnURL(args):
    page = args[1]
    ENCWND.setPage(page)
    

def OnEncyclopediaHome():
    ENCWND.home()

def OnEncyclopediaBack():
    ENCWND.back()

def OnEncyclopediaForward():
    ENCWND.forward()

def PyExec():
    
    global ENCWND
    ENCWND = EncWindow()
    
    #read the encyclopedia
    try:
        tar = tarfile.open("./%s/data/ui/encyclopedia/momworld.tar.gz"%GAMEROOT,'r:gz')
        for tarinfo in tar:
            if tarinfo.name.startswith("twiki/data/MoMWorld") and tarinfo.isreg():
                f = tar.extractfile(tarinfo)
                data = f.read()
                ENCYC[tarinfo.name[20:-4]]=data
        tar.close()
    except:
        traceback.print_exc()
        
    
    ENCYC["Home"]=HOME
    
    ENCWND.setPage("Home")
    
    TGEExport(OnEncyclopediaOnURL,"Py","OnEncyclopediaOnURL","desc",2,2)
    
    TGEExport(OnEncyclopediaHome,"Py","OnEncyclopediaHome","desc",1,1)
    TGEExport(OnEncyclopediaForward,"Py","OnEncyclopediaForward","desc",1,1)
    TGEExport(OnEncyclopediaBack,"Py","OnEncyclopediaBack","desc",1,1)
    
    
    
