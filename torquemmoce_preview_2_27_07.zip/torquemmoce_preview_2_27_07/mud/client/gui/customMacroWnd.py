
#custom macros and editing

from tgenative import *
from mud.tgepython.console import TGEExport

CUSTOMMACROWND = None
CINDEX = MACROINDEX = CHOSENICON = None

class CustomMacroWnd:
    def __init__(self):
        self.iconButton = TGEObject("CM_ICON")
        

def ChooseIcon(chosen):
    global CHOSENICON
    CHOSENICON = chosen
    
    if chosen:
        icon = chosen
        if icon.startswith("SPELLICON_"):
            split = icon.split("_")
            index=int(split[2])
            u0=(float(index%6)*40.0)/256.0
            v0=(float(index/6)*40.0)/256.0
            u1=(40.0/256.0)
            v1=(40.0/256.0)
            
            CUSTOMMACROWND.iconButton.setBitmapUV("~/data/ui/icons/spells0%s"%split[1],u0,v0,u1,v1)
        else:
            CUSTOMMACROWND.iconButton.setBitmap("~/data/ui/icons/%s"%icon)

        
    else:
        CUSTOMMACROWND.iconButton.setBitmap("")
        



def OnCustomMacroSave():
    from macro import CreateMacro,CustomMacro
    
    cm = CustomMacro()
    cm.name = TGEObject("CM_NAME").getValue()
    cm.icon = CHOSENICON
    for x in xrange(1,11):
        cm.lines[x-1] = TGEObject("CM_LINE%i"%x).getValue()
    for x in xrange(1,11):
        try:
            cm.delays[x-1] = int(TGEObject("CM_DELAY%i"%x).getValue())
            if cm.delays[x-1] < 0:
                cm.delays[x-1] = 0
            
        except:
            #import traceback
            #traceback.print_exc()
            cm.delays[x-1] = 0
            
        
    CreateMacro(CINDEX,MACROINDEX,"CUSTOMMACRO",cm)
    
    cm.parseSkillsAndSpells()
    
    TGEEval("canvas.popDialog(CustomMacroWnd);")
    

def OnMacroChooseIcon():
    from chooseIconWnd import SetChooseIconCallback
    SetChooseIconCallback(ChooseIcon)
    TGEEval("canvas.pushDialog(ChooseIconWnd);")
    
def ClearMacroEditor():
    global CHOSENICON
    CHOSENICON = None
    TGEObject("CM_NAME").setText("")
    TGEObject("CM_ICON").setBitmap("")
    
    TGEObject("CM_HOTKEY").setSelected(0)
    
    
    for x in xrange(1,11):
        TGEObject("CM_LINE%i"%x).setText("")
        TGEObject("CM_DELAY%i"%x).setText("")

def SetIcon(icon):
    global CHOSENICON
    if icon:
        CHOSENICON = icon
        
        
        if icon.startswith("SPELLICON_"):
            split = icon.split("_")
            index=int(split[2])
            u0=(float(index%6)*40.0)/256.0
            v0=(float(index/6)*40.0)/256.0
            u1=(40.0/256.0)
            v1=(40.0/256.0)
            
            TGEObject("CM_ICON").setBitmapUV("~/data/ui/icons/spells0%s"%split[1],u0,v0,u1,v1)
        else:
            TGEObject("CM_ICON").setBitmap("~/data/ui/icons/%s"%icon)


        
    else:
        CHOSENICON = None
        TGEObject("CM_ICON").setBitmap("")
    


def OpenMacroEditor(cindex,mindex):
    from macro import CHARMACROS
    from partyWnd import PARTYWND
    
    global CINDEX
    global MACROINDEX
    global CHOSENICON
    
    #virtual page
    vpage = 0
    try:
        if int(TGEGetGlobal("$Py::Input::ShiftDown")):
            vpage = 1
            
    except:
        pass

    try:
        if int(TGEGetGlobal("$Py::Input::ControlDown")):
            vpage = 2
            
    except:
        pass
    
    mindex = mindex+vpage*10
    CINDEX,MACROINDEX = cindex,mindex
    
    CHOSENICON = None
    
    
    cinfo = PARTYWND.charInfos[cindex]

    

    
    m = CHARMACROS[cindex].get(mindex)
    
        
    if m and m.customMacro:
        cm = m.customMacro
        TGEObject("CM_NAME").setText(cm.name)
        
        
        
        
        SetIcon(cm.icon)
        
            
        for index,line in cm.lines.iteritems():
            if line:
                TGEObject("CM_LINE%i"%(index+1)).setText(line)
            else:
                TGEObject("CM_LINE%i"%(index+1)).setText("")
                
        for index,delay in cm.delays.iteritems():
            try:
                f = int(delay)
                if f:
                    f = str(f)
                else:
                    f = ""
            except:
                f = ""
                
            TGEObject("CM_DELAY%i"%(index+1)).setText(f)
                
    else:
        ClearMacroEditor()
        #fill from one of the other macros
        if m and m.skill:
            from skillinfo import GetSkillInfo
            sinfo = GetSkillInfo(m.skill)
            if not sinfo:
                return
            
            text = sinfo.name
            icon = sinfo.icon
            cmd = "/skill %s"%m.skill
            TGEObject("CM_LINE1").setText(cmd)
            TGEObject("CM_NAME").setText(text)
            SetIcon(icon)
            
        if m and m.spellSlot != None:
            if cinfo.SPELLS.has_key(m.spellSlot):
                
                sinfo = cinfo.SPELLS[m.spellSlot].SPELLINFO
                
                TGEObject("CM_NAME").setText(sinfo.NAME)
                name = sinfo.BASENAME
                        
                TGEObject("CM_LINE1").setText("/cast %s"%name)
                
                
                icon = sinfo.SPELLBOOKPIC
                SetIcon(icon)

        if m and m.defaultCommand:
            SetIcon(m.defaultCommand.icon)
            TGEObject("CM_NAME").setText(m.defaultCommand.name)
            TGEObject("CM_LINE1").setText(m.defaultCommand.makeCommand)
            
    if m and m.hotKey:
        TGEObject("CM_HOTKEY").setText(m.hotKey)
    else:
        TGEObject("CM_HOTKEY").setText("None")
    
    TGEEval("Canvas.pushDialog(CustomMacroWnd);")
    
    
#copy, paste, clear, save


def OnCustomMacroClear():
    ClearMacroEditor()
    
COPY_NAME = None
COPY_LINES = ["","","","","","","","","",""]
COPY_ICON = ""
COPY_DELAYS = [0,0,0,0,0,0,0,0,0,0]
COPY_HOTKEY = ""

def OnCustomMacroCopy():
    global COPY_NAME
    global COPY_LINES
    global COPY_ICON
    global COPY_DELAYS
    global COPY_HOTKEY
    
    
    
    COPY_NAME = TGEObject("CM_NAME").getValue()
    COPY_ICON = CHOSENICON
    for x in xrange(1,11):
        COPY_LINES[x-1] = TGEObject("CM_LINE%i"%x).getValue()
    for x in xrange(1,11):
        try:
            COPY_DELAYS[x-1] = int(TGEObject("CM_DELAY%i"%x).getValue())
            if COPY_DELAYS[x-1] < 0:
                COPY_DELAYS[x-1] = 0
            
        except:
            #import traceback
            #traceback.print_exc()
            COPY_DELAYS[x-1] = 0
            
    
    COPY_HOTKEY = TGEObject("CM_HOTKEY").getText()
    

def OnCustomMacroPaste():    
    global CHOSENICON
    ClearMacroEditor()
    
    
    TGEObject("CM_NAME").setValue(COPY_NAME)
    CHOSENICON = COPY_ICON
    SetIcon(COPY_ICON)
    
    for x in xrange(1,11):
        TGEObject("CM_LINE%i"%x).setValue(COPY_LINES[x-1])
    for x in xrange(1,11):
        if COPY_DELAYS[x-1]:
            TGEObject("CM_DELAY%i"%x).setValue(COPY_DELAYS[x-1])
        else:
            TGEObject("CM_DELAY%i"%x).setValue("")

    TGEObject("CM_HOTKEY").setText(COPY_HOTKEY)

def PyExec():
    global CUSTOMMACROWND
    CUSTOMMACROWND = CustomMacroWnd()
    
    
    
    hk = TGEObject("CM_HOTKEY")
    hk.clear()
    hklist=("None","1","2","3","4","5","6","7","8","9","0","F7","F8","F9","F10","F11","F12")
    x=0
    for s in hklist:
        hk.add(s,x)
        x+=1

    
    TGEExport(OnMacroChooseIcon,"Py","OnMacroChooseIcon","desc",1,1)
    TGEExport(OnCustomMacroSave,"Py","OnCustomMacroSave","desc",1,1)
    TGEExport(OnCustomMacroClear,"Py","OnCustomMacroClear","desc",1,1)
    TGEExport(OnCustomMacroCopy,"Py","OnCustomMacroCopy","desc",1,1)
    TGEExport(OnCustomMacroPaste,"Py","OnCustomMacroPaste","desc",1,1)
    