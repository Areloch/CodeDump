
from tgenative import *
from mud.tgepython.console import TGEExport
from mud.world.defines import *


def CmdAutoWalk(args):
    if int(TGEGetGlobal("$mvAutoForward")):
        TGESetGlobal("$mvAutoForward",2) #turn off
    else:
        TGESetGlobal("$mvAutoForward",1)
    
    
def CmdPlayTrack(args):
    from mud.client.jukebox import PlayTrack
    PlayTrack(args)

def CmdLocalTime(args):
    import datetime
    
    from tomeGui import TOMEGUI
    n = datetime.datetime.now()
    s = n.strftime("%A %B %d %I:%M:%S %p %Y")
    TOMEGUI.receiveGameText(RPG_MSG_GAME_WHITE,"The local time is %s.\\n"%s)
    return

def CmdIgnored(args):
    
    from mud.client.irc import IGNORED
    
    if len(IGNORED):
        text = "You are currently ignoring: %s\\n"%', '.join(IGNORED)
    else:
        text = "You aren't ignoring anyone.\\n"

    
    from tomeGui import TOMEGUI
    TOMEGUI.receiveGameText(RPG_MSG_GAME_WHITE,text)
    

CLIENTCOMMANDS = {}
CLIENTCOMMANDS['AUTOWALK']=CmdAutoWalk
CLIENTCOMMANDS['PLAYTRACK']=CmdPlayTrack
CLIENTCOMMANDS['LOCALTIME']=CmdLocalTime
CLIENTCOMMANDS['IGNORED']=CmdIgnored


def DoClientCommand(cmd):
    
    
    cmd = cmd[1]
    
    args = cmd.split(" ")
    cmd = args[0][1:].upper()
    
    args = args[1:]
    
    if not CLIENTCOMMANDS.has_key(cmd):
        print "WARNING: Unknown client command %s"%cmd
        return
    
    CLIENTCOMMANDS[cmd](args)
    
    
TGEExport(DoClientCommand,"Py","DoClientCommand","desc",2,2)