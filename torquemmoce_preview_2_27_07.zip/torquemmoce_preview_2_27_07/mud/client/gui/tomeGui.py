from tgenative import *
from mud.tgepython.console import TGEExport
from mud.world.defines import *
import math
from mud.world.core import CoreSettings

TOMEGUI = None

"""
RPG_MSG_GAME_GLOBAL = 0
RPG_MSG_GAME_COMBAT = 1 #generic combat
RPG_MSG_GAME_COMBAT_HIT = 2 #player's char hit somone
RPG_MSG_GAME_COMBAT_GOTHIT = 3 #player's char got hit
RPG_MSG_GAME_CASTING = 4 #player's char got hit
RPG_MSG_GAME_SPELLBEGIN = 5 #player's char got hit
RPG_MSG_GAME_SPELLEND = 6 #player's char got hit
RPG_MSG_GAME_DENIED = 7
RPG_MSG_GAME_GAINED = 8
RPG_MSG_GAME_LOST = 9
RPG_MSG_GAME_LOOT = 10
RPG_MSG_GAME_LEVELGAINED = 11
RPG_MSG_GAME_LEVELLOST = 12
RPG_MSG_GAME_CHARDEATH = 13
RPG_MSG_GAME_PARTYDEATH = 14
RPG_MSG_GAME_GOOD = 15
RPG_MSG_GAME_BAD = 16
RPG_MSG_GAME_EVENT = 17
"""

SPEECHCOLORCODES = {
#speech text
RPG_MSG_SPEECH_WORLD:"C8B560",
RPG_MSG_SPEECH_ZONE:"B8C323",
RPG_MSG_SPEECH_PARTY:"2896EA",
RPG_MSG_SPEECH_SAY:"28EA44",
RPG_MSG_SPEECH_AUCTION:"EA4828",
RPG_MSG_SPEECH_GLOBAL:"06FFFC",
RPG_MSG_SPEECH_ALLIANCE:"2896EA",
RPG_MSG_SPEECH_SYSTEM:"FFFF00",
RPG_MSG_SPEECH_TELL:"BBBBFF",
RPG_MSG_SPEECH_TOLD:"BBFFBB",
RPG_MSG_SPEECH_EMOTE:"ECB3EB",
RPG_MSG_SPEECH_OT:"E7E2EF",
RPG_MSG_SPEECH_HELP:"79FF21",
RPG_MSG_SPEECH_PLAYERJOINED:"CCCC33",
RPG_MSG_SPEECH_GUILD:"96FDED",
RPG_MSG_SPEECH_ERROR:"FF1100",

}
#game text
GAMECOLORCODES = {
RPG_MSG_GAME_GLOBAL:"FFFFFF",
RPG_MSG_GAME_COMBAT:"FFFFFF",
RPG_MSG_GAME_COMBAT_HIT:"28EFED",
RPG_MSG_GAME_COMBAT_GOTHIT:"EF7C28",
RPG_MSG_GAME_CASTING:"38EAE8",
RPG_MSG_GAME_SPELLBEGIN:"EA67E8",
RPG_MSG_GAME_SPELLEND:"EADB67",
RPG_MSG_GAME_DENIED:"FF1100",
RPG_MSG_GAME_GAINED:"00FF00",
RPG_MSG_GAME_LOST:"EA9E67",
RPG_MSG_GAME_LOOT:"67EABD",
RPG_MSG_GAME_LEVELGAINED:"E8EA38",
RPG_MSG_GAME_LEVELLOST:"FF0000",
RPG_MSG_GAME_CHARDEATH:"FF0000",
RPG_MSG_GAME_PARTYDEATH:"FF0000",
RPG_MSG_GAME_GOOD:"00FF00",
RPG_MSG_GAME_BAD:"FF0000",
RPG_MSG_GAME_EVENT:"FFFFFF",
RPG_MSG_GAME_GREEN:"00FF00",
RPG_MSG_GAME_BLUE:"09ADDC",
RPG_MSG_GAME_WHITE:"FFFFFF",
RPG_MSG_GAME_YELLOW:"F5F816",
RPG_MSG_GAME_RED:"FF1100",
RPG_MSG_GAME_NPC_SPEECH:"BAEA38",
RPG_MSG_GAME_PET_SPEECH:"E0EA38",
RPG_MSG_GAME_CASTING_NPC:"EE6644"
}

class TomeGui:
    def __init__(self):
        self.gameText = ""
        self.speechText = ""
        self.gameTextScroll = TGEObject("Tome_GameTextScroll")
        self.speechTextScroll = TGEObject("Tome_SpeechTextScroll")
        self.gameTextCtrl = TGEObject("Tome_GameText")
        self.speechTextCtrl = TGEObject("Tome_SpeechText")
        self.tomeCommandCtrl = TGEObject("Tome_CommandText")
        self.tomeGui = TGEObject("TomeGui_Window")
        
        
        
    def receiveGameText(self,textCode,text):
        try:
            fontsize = int(math.floor(float(TGEGetGlobal("$pref::Game::GameFontSize"))))
            fontsize+=3
        except:
            fontsize = 13
            
        if fontsize < 13:
            fontsize = 13
        if fontsize > 23:
            fontsize = 23
            
        TGESetGlobal("$pref::Game::GameFontSize",fontsize-3)
        
        import datetime
        n = datetime.datetime.now()
        s = n.strftime("%I:%M:%S %p")
        logtext=text.replace("\\n","\n")
        logtext=logtext.replace(r'\"',r'"')
        logtext=logtext.replace(r'\'',"'")
        CoreSettings.LOGGAME.write("%s - %s"%(s,logtext))
        

        
        self.gameText += r'<color:%s>%s'%(GAMECOLORCODES[textCode],text)
        while len(self.gameText)>4000: #lex is set to a 4096 buffer for evaluating, beware raising this
            self.gameText = self.gameText[1000:] 
            #try to break on a color statement
            index = self.gameText.find("<color:")
            if index != -1:
                self.gameText = self.gameText[index:]

        pos = self.gameTextScroll.childRelPos.split(" ")
        eval = 'Tome_GameText.setText("<font:Arial:%i><shadowcolor:000000><shadow:1:1>%s");'%(fontsize,self.gameText)
        TGEEval(eval)
        if not int(self.gameTextScroll.isMouseLocked()):
            self.gameTextScroll.scrollToBottom()
        else:
        
            extenty = self.gameTextScroll.extent.split(" ")[1]
            self.gameTextScroll.scrollRectVisible(pos[0],pos[1],1,extenty)
            
    def receiveSpeechText(self,textCode,text):
        
        
        try:
            fontsize = int(math.floor(float(TGEGetGlobal("$pref::Game::ChatFontSize"))))
            fontsize+=3
            
        except:
            fontsize = 13
            
        if fontsize < 13:
            fontsize = 13
        if fontsize > 23:
            fontsize = 23
        
        TGESetGlobal("$pref::Game::ChatFontSize",fontsize-3)     
        
        import datetime
        n = datetime.datetime.now()
        s = n.strftime("%I:%M:%S %p")
        logtext=text.replace("\\n","\n")
        logtext=logtext.replace(r'\"',r'"')
        logtext=logtext.replace(r'\'',"'")

        CoreSettings.LOGCHAT.write("%s - %s"%(s,logtext))

        
        self.speechText += r'<color:%s>%s'%(SPEECHCOLORCODES[textCode],text)
        while len(self.speechText)>4000:#lex is set to a 4096 buffer for evaluating, beware raising this
            self.speechText = self.speechText[1000:] 
            #try to break on a color statement
            index = self.speechText.find("<color:")
            if index != -1:
                self.speechText = self.speechText[index:]
            
        eval = 'Tome_SpeechText.setText("<font:Arial:%i><shadowcolor:000000><shadow:1:1>%s");'%(fontsize,self.speechText)
        
        pos = self.speechTextScroll.childRelPos.split(" ")
        TGEEval(eval)
        if not int(self.speechTextScroll.isMouseLocked()):
            self.speechTextScroll.scrollToBottom()
        else:
            extenty = self.speechTextScroll.extent.split(" ")[1]
            self.speechTextScroll.scrollRectVisible(pos[0],pos[1],1,extenty)
        

def OnChatFontSizeChanged():
    
    try:
        fontsize = int(math.floor(float(TGEGetGlobal("$pref::Game::ChatFontSize"))))
        fontsize+=3
    except:
        fontsize = 13
        
    if fontsize < 13:
        fontsize = 13
    if fontsize > 23:
        fontsize = 23
    
    eval = 'Tome_SpeechText.setText("<font:Arial:%i><shadowcolor:000000><shadow:1:1>%s");'%(fontsize,TOMEGUI.speechText)
    
    TGEEval(eval)
def OnGameFontSizeChanged():
    try:
        fontsize = int(math.floor(float(TGEGetGlobal("$pref::Game::GameFontSize"))))
        fontsize+=3
    except:
        fontsize = 13
        
    if fontsize < 13:
        fontsize = 13
    if fontsize > 23:
        fontsize = 23
    
    eval = 'Tome_GameText.setText("<font:Arial:%i><shadowcolor:000000><shadow:1:1>%s");'%(fontsize,TOMEGUI.gameText)
    
    TGEEval(eval)
    
def InitTomeGui():
    TOMEGUI.gameText = ""
    TOMEGUI.speechText = ""
    TOMEGUI.gameTextCtrl.setText("")
    TOMEGUI.speechTextCtrl.setText("")
    

def PyOnGlobalChannelToggle(v=None):
    from mud.client.irc import FilterChannel
    if v == None:
        v = int(TGEObject("CHATGUI_GLOBAL_TOGGLE").getValue())
    else:
        TGEObject("CHATGUI_GLOBAL_TOGGLE").setValue(v)
    FilterChannel('M',v)
    if v:
        TOMEGUI.receiveGameText(RPG_MSG_GAME_GAINED,r'You are are now listening to mom chat.\n')
    else:
        TOMEGUI.receiveGameText(RPG_MSG_GAME_GAINED,r'You are are no longer listening to mom chat.\n')


def PyOnWorldChannelToggle():
    from mud.client.playermind import PLAYERMIND
    v = int(TGEObject("CHATGUI_WORLD_TOGGLE").getValue())
    if v:
        PLAYERMIND.doCommand("CHANNEL",[0,"world","on"])
    else:
        PLAYERMIND.doCommand("CHANNEL",[0,"world","off"])

def PyOnZoneChannelToggle():
    from mud.client.playermind import PLAYERMIND
    v = int(TGEObject("CHATGUI_ZONE_TOGGLE").getValue())
    if v:
        PLAYERMIND.doCommand("CHANNEL",[0,"zone","on"])
    else:
        PLAYERMIND.doCommand("CHANNEL",[0,"zone","off"])

def PyOnOffTopicChannelToggle(v=None):
    from mud.client.irc import FilterChannel
    if v == None:
        v = int(TGEObject("CHATGUI_OFFTOPIC_TOGGLE").getValue())
    else:
        TGEObject("CHATGUI_OFFTOPIC_TOGGLE").setValue(v)
        
    FilterChannel('O',v)
    if v:
        TOMEGUI.receiveGameText(RPG_MSG_GAME_GAINED,r'You are are now listening to off-topic chat.\n')
    else:
        TOMEGUI.receiveGameText(RPG_MSG_GAME_GAINED,r'You are are no longer listening to off-topic chat.\n')


def PyOnHelpChannelToggle(v=None):
    from mud.client.irc import FilterChannel
    if v == None:
        v = int(TGEObject("CHATGUI_HELP_TOGGLE").getValue())
    else:
        TGEObject("CHATGUI_HELP_TOGGLE").setValue(v)
        
    FilterChannel('H',v)
    
    if v:
        TOMEGUI.receiveGameText(RPG_MSG_GAME_GAINED,r'You are are now listening to help chat.\n')
    else:
        TOMEGUI.receiveGameText(RPG_MSG_GAME_GAINED,r'You are are no longer listening to help chat.\n')
        


def PyExec():
    global TOMEGUI
    TOMEGUI = TomeGui()
    
    TGEExport(OnChatFontSizeChanged,"Py","OnChatFontSizeChanged","desc",1,1)
    TGEExport(OnGameFontSizeChanged,"Py","OnGameFontSizeChanged","desc",1,1)
    
    TGEExport(PyOnGlobalChannelToggle,"Py","OnGlobalChannelToggle","desc",1,1)
    TGEExport(PyOnWorldChannelToggle,"Py","OnWorldChannelToggle","desc",1,1)
    TGEExport(PyOnZoneChannelToggle,"Py","OnZoneChannelToggle","desc",1,1)
    TGEExport(PyOnHelpChannelToggle,"Py","OnHelpChannelToggle","desc",1,1)
    TGEExport(PyOnOffTopicChannelToggle,"Py","OnOffTopicChannelToggle","desc",1,1)
