from tgenative import *
from mud.tgepython.console import TGEExport
from twisted.internet import reactor
import time
import math
#both command windows

COMMANDWND = None

class CharCmdPane:
    def __init__(self, index):
        
        self.cmdPage = 0
        
        self.castingTick = None
        
        
        self.paneCtrl = TGEObject("CMDWND_CHAR%i_PANE"%index)
        
        self.targetCtrl = TGEObject("CMDWND_CHAR%i_TARGET"%index)
        self.targetHealthCtrl = TGEObject("CMDWND_CHAR%i_TARGETHEALTH"%index)
        
        self.manaCtrl = TGEObject("CMDWND_CHAR%i_MANA"%index)
        self.healthCtrl = TGEObject("CMDWND_CHAR%i_HEALTH"%index)
        self.staminaCtrl = TGEObject("CMDWND_CHAR%i_STAMINA"%index)
        
        self.picCtrl = TGEObject("CMDWND_CHAR%i_PIC"%index)

        self.effectCtrls = {}
        for x in xrange(0,12):
            self.effectCtrls[x]=TGEObject("CMDWND_CHAR%i_EFFECT%i"%(index,x))
            
        self.cmdCtrls = {}
        for x in xrange(0,4):
            self.cmdCtrls[x]=TGEObject("CMDWND_CHAR%i_CMD%i"%(index,x))
            
        self.castingCtrl = TGEObject("CMDWND_CHAR%i_CASTING"%index)
        self.castingCtrl.visible = False
        
        self.pxpBar  = TGEObject("CMDWND_CHAR%i_XP1"%index)
        self.sxpBar  = TGEObject("CMDWND_CHAR%i_XP2"%index)
        self.txpBar  = TGEObject("CMDWND_CHAR%i_XP3"%index)
        self.petHealth  = TGEObject("CMDWND_CHAR%i_PETHEALTH"%index)
        self.petText = TGEObject("CMDWND_CHAR%i_PETTEXT"%index)
        
        #CMDWND_CHAR1_PETHEALTH
        #Py::OnTargetPetTarget(0);
        
        #self.nextCmdCtrl = TGEObject("CMDWND_CHAR%i_NEXTCMDS"%index)
        #self.prevCmdCtrl = TGEObject("CMDWND_CHAR%i_PREVCMDS"%index)
        
        self.lastTime = time.time()
        
    def setCharInfo(self,cinfo):
        if cinfo.DEAD:
            self.picCtrl.setBitmap("~/data/ui/icons/dead")
        else:
            self.picCtrl.setBitmap("~/data/ui/charportraits/%s"%cinfo.PORTRAITPIC)
            
        self.pxpBar.setValue(cinfo.PXPPERCENT)
        self.sxpBar.setValue(cinfo.SXPPERCENT)
        self.txpBar.setValue(cinfo.TXPPERCENT)
        
        rInfo = cinfo.RAPIDMOBINFO
        
        
        if rInfo.AUTOATTACK and not cinfo.DEAD:
            self.picCtrl.pulseRed = True
        else:
            self.picCtrl.pulseRed = False
        
        self.healthCtrl.SetValue(rInfo.HEALTH/rInfo.MAXHEALTH)
        if rInfo.MAXMANA:
            self.manaCtrl.SetValue(rInfo.MANA/rInfo.MAXMANA)
        else:
            self.manaCtrl.SetValue(0)
            
        if cinfo.UNDERWATERRATIO != 1.0:
            self.staminaCtrl.setProfile("GuiBreathBarProfile")
            self.staminaCtrl.SetValue(cinfo.UNDERWATERRATIO)       
        else:
            self.staminaCtrl.setProfile("GuiStaminaBarProfile")
            self.staminaCtrl.SetValue(rInfo.STAMINA/rInfo.MAXSTAMINA)
            
        if rInfo.PETNAME:
            self.petHealth.setValue(rInfo.PETHEALTH)
            self.petHealth.visible = True
            self.petText.setValue(rInfo.PETNAME)
        else:
            self.petHealth.visible = False    
        
        if rInfo.TGT:
            self.targetCtrl.SetValue(rInfo.TGT)
            self.targetCtrl.visible = True
            self.targetHealthCtrl.SetValue(rInfo.TGTHEALTH)
            self.targetHealthCtrl.visible = True
        else:
            self.targetCtrl.visible = False
            self.targetHealthCtrl.visible = False
            
        #spell effects
        
        tm = time.time()
        if tm - self.lastTime > 2:
            self.lastTime = tm
            
        delta = tm - self.lastTime
        self.lastTime = tm
        delta/=2.0 #why?
        
            
        
        x = 0
        for effect in cinfo.SPELLEFFECTS:
            ctrl = self.effectCtrls[x]
            
            ICON = ""
            if effect.SRCMOBID == cinfo.MOBID:
                ICON = effect.ICONSRC
            if effect.DSTMOBID == cinfo.MOBID:
                ICON = effect.ICONDST
                
                
            if ICON:
                
                effect.TIME-=delta
                
                if effect.TIME < 0:
                    effect.TIME = 0
                
                if effect.TIME < 12:
                    if math.sin(tm*4)>0:
                        ctrl.visible = False
                        x+=1
                        if x == 12:
                            break
                        continue
                    
                minutes,seconds = divmod(effect.TIME,60)
                tim = ""
                if minutes:
                    if seconds < 10:
                        tim = " - %i:0%i"%(minutes,seconds)
                    else:
                        tim = " - %i:%i"%(minutes,seconds)
                elif seconds:
                    if seconds < 10:
                        tim = " - :0%i"%(seconds)
                    else:
                        tim = " - :%i"%(seconds)
                        
                
                ctrl.toolTip = "XXX:"+effect.NAME+tim
                
                ctrl.visible = True

                
                
                    
                if "/" not in ICON:
                    if ICON.startswith("SPELLICON_"):
                        split = ICON.split("_")
                        
                        #gems are 10x10
                        page = int(split[1])-1
                        index=int(split[2])
                        
                        slot = page*36+index
                        page = slot/100+1
                        slot = slot%100
                        
                        
                        u0=(float(slot%10)*24.0)/256.0
                        v0=(float(slot/10)*24.0)/256.0
                        u1=(24.0/256.0)
                        v1=(24.0/256.0)
                        
                        ctrl.setBitmapUV("~/data/ui/icons/gemicons0%i"%page,u0,v0,u1,v1)
                    else:
                        ctrl.setBitmap("~/data/ui/icons/%s"%ICON)
                    
                else:
                    ctrl.setBitmap("~/data/ui/%s"%ICON)
                    
                if effect.HARMFUL:
                    ctrl.setActive(False)
                else:
                    ctrl.setActive(True)
                x+=1
                if x == 12:
                    break
                    
        for y in xrange(x,12):
            ctrl = self.effectCtrls[y]
            ctrl.toolTip = ""
            ctrl.visible=False
            ctrl.setActive(False)
            
    def tickCasting(self):
        #print self.castingTime,self.castingMaxTime
        self.castingTime+=.1
        
        if self.castingTime >= self.castingMaxTime:
            self.castingTime = 0
            self.castingCtrl.visible = False
            self.castingTick = None
            return
            
        percent = 1 - (self.castingTime/self.castingMaxTime)
        
        self.castingCtrl.SetValue(percent)
        
        self.castingTick = reactor.callLater(.1,self.tickCasting)
            
    def beginCasting(self,time):
        if self.castingTick:
            self.castingTick.cancel()
            self.castingTick = None
        self.castingMaxTime = time
        self.castingTime = 0
        self.castingTick = reactor.callLater(.1,self.tickCasting)
        
        self.castingCtrl.visible = True
        self.castingCtrl.SetValue(1)
        
    def endCasting(self):
        if self.castingTick:
            self.castingTick.cancel()
            self.castingTick = None
        
        self.castingCtrl.visible = False
        
    def enableMacroButtons(self):
        for ctrl in self.cmdCtrls.itervalues():
            ctrl.setValue(0)
            ctrl.toggleLocked = False
    
    def disableMacroButtons(self):
        for ctrl in self.cmdCtrls.itervalues():
            ctrl.setValue(1)
            ctrl.toggleLocked = True

class CommandWnd:
    def __init__(self):
            
        self.charInfos = None
        
        self.cmdWnd1 = TGEObject("CommandWnd1_Window")
        self.cmdWnd2 = TGEObject("CommandWnd2_Window")
        self.cmdWnd3 = TGEObject("CommandWnd3_Window")
        self.cmdWnd4 = TGEObject("CommandWnd4_Window")
        self.cmdWnd5 = TGEObject("CommandWnd5_Window")
        self.cmdWnd6 = TGEObject("CommandWnd6_Window")
        
        self.cmdWnd1.setActive(False)
        self.cmdWnd2.setActive(False)
        self.cmdWnd3.setActive(False)
        self.cmdWnd4.setActive(False)
        self.cmdWnd5.setActive(False)
        self.cmdWnd6.setActive(False)

        self.cmdWnd1.visible = False
        self.cmdWnd2.visible = False
        self.cmdWnd3.visible = False
        self.cmdWnd4.visible = False
        self.cmdWnd5.visible = False
        self.cmdWnd6.visible = False

        
        self.panes = []
        for x in xrange(1,7):
            self.panes.append(CharCmdPane(x))
            
        for pane in self.panes:
            pane.paneCtrl.visible = False
            
    def beginCasting(self,charIndex,time):
        self.panes[charIndex].beginCasting(time)
        
    def endCasting(self,charIndex):
        self.panes[charIndex].endCasting()
        
    def tick(self):
        if not self.charInfos:
            return
            
        from partyWnd import PARTYWND
        
        #health, mana, stamina are on "fast update" from server
        #target, target health
        
        #keep this order independent so we can swap characters around on command windows
        
        for index,cinfo in self.charInfos.iteritems():
            pane = self.panes[index]
            
            if index == PARTYWND.curIndex:
                pane.paneCtrl.setProfile("MoMSelectedWndProfile")
            else:
                pane.paneCtrl.setProfile("MoMBorderlessWndProfile")
                
            
            pane.setCharInfo(cinfo)
        
    def setCharInfos(self,cinfos):
        
        self.charInfos = cinfos
        
        TGEObject("TOME_COMMANDWND2TOGGLE").visible = False
        TGEObject("TOME_COMMANDWND3TOGGLE").visible = False
        TGEObject("TOME_COMMANDWND4TOGGLE").visible = False
        TGEObject("TOME_COMMANDWND5TOGGLE").visible = False
        TGEObject("TOME_COMMANDWND6TOGGLE").visible = False
        TGEEval("canvas.popDialog(CommandWnd2);")
        TGEEval("canvas.popDialog(CommandWnd3);")
        TGEEval("canvas.popDialog(CommandWnd4);")
        TGEEval("canvas.popDialog(CommandWnd5);")
        TGEEval("canvas.popDialog(CommandWnd6);")
        
        if len(cinfos)>1:
            TGEObject("TOME_COMMANDWND2TOGGLE").visible = True
        else:
            TGEEval("canvas.popDialog(CommandWnd2);")

        if len(cinfos)>2:
            TGEObject("TOME_COMMANDWND3TOGGLE").visible = True
        else:
            TGEEval("canvas.popDialog(CommandWnd3);")

        if len(cinfos)>3:
            TGEObject("TOME_COMMANDWND4TOGGLE").visible = True
        else:
            TGEEval("canvas.popDialog(CommandWnd4);")

        if len(cinfos)>4:
            TGEObject("TOME_COMMANDWND5TOGGLE").visible = True
        else:
            TGEEval("canvas.popDialog(CommandWnd5);")

        if len(cinfos)>5:
            TGEObject("TOME_COMMANDWND6TOGGLE").visible = True
        else:
            TGEEval("canvas.popDialog(CommandWnd6);")

        
        num = len(cinfos)
        
        self.cmdWnd1.visible = True
        self.cmdWnd1.setActive(True)
        self.cmdWnd1.setText(cinfos[0].NAME)
        
        if num > 1:
            self.cmdWnd2.visible = True
            self.cmdWnd2.setActive(True)
            self.cmdWnd2.setText(cinfos[1].NAME)
            
        if num > 2:
            self.cmdWnd3.visible = True
            self.cmdWnd3.setActive(True)
            self.cmdWnd3.setText(cinfos[2].NAME)

        if num > 3:
            self.cmdWnd4.visible = True
            self.cmdWnd4.setActive(True)
            self.cmdWnd4.setText(cinfos[3].NAME)
        if num > 4:
            self.cmdWnd5.visible = True
            self.cmdWnd5.setActive(True)
            self.cmdWnd5.setText(cinfos[4].NAME)
        
        if num > 5:
            self.cmdWnd6.visible = True
            self.cmdWnd6.setActive(True)
            self.cmdWnd6.setText(cinfos[5].NAME)
            
        num = len(cinfos)
        for x in xrange(0,num):
            self.panes[x].paneCtrl.visible = True
            
        
        
#def PyOnTargetPet(args):
#    cindex = int(args[1])
#    from partyWnd import PARTYWND
#    #def doCommand(self,cmd,args):
#    args = [cindex,"PET"]
#    PARTYWND.mind.doCommand("TARGET",args)


def PyExec():
    global COMMANDWND
    COMMANDWND = CommandWnd()
        
    
#    TGEExport(PyOnTargetPet,"Py","OnTargetPet","desc",2,2)
    