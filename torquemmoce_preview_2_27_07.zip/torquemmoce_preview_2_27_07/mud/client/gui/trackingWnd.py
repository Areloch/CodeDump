
from tgenative import *
from mud.tgepython.console import TGEExport
import traceback


TRACKINGWND = None

class TrackingWnd:
    def __init__(self):     
        
        self.trackingBitmap = TGEObject("TRACKING_TRACKBITMAP")
        self.trackingList = TGEObject("TRACKING_TRACKINGLIST")
        self.trackingScroll = TGEObject("TRACKING_SCROLL")
        self.trackingText = TGEObject("TRACKING_TEXT")
        self.tracking = {}
        self.trackingId = 0
        self.trackLocation = (0,0,0)
        self.trackInterest = ""
        self.interestLookup = {}
        

    def set(self,tracking):
        try:
            try:
                mw = TGEObject("MapViewPort")
            except:
                return #TGEA
            mw.clearContacts()
            
            from pointsOfInterest import GetPointsOfInterest
            poi = GetPointsOfInterest()
            self.interestLookup = {}
            x = -1
            found = False
            
            for p in poi:
                if self.trackInterest == p[0]:
                    found = True
                    self.trackLocation = (p[1],p[2],p[3])
                mw.addContact(p[0],6,p[1],p[2],p[3])
                self.interestLookup[x]=p[0]
                x-=1
                
            if not found:
                self.trackInterest = ""
            
            self.tracking = tracking
            
            
            self.trackingId = tracking['TRACKINGID']
            if not self.trackInterest:
                if self.tracking.has_key(self.trackingId):
                    self.trackLocation=self.tracking[self.trackingId][1]
            
            self.range = tracking['RANGE']
            del tracking['RANGE']
            del tracking['TRACKINGID']
            
            if not self.trackingId and not self.trackInterest:
                #self.trackingBitmap.setBitmap("") <--- handled in playermind
                self.trackingText.visible = False
            else:
                if self.trackInterest:
                    self.trackingText.setText("<font:Arial Bold:14><just:center><shadow:1:1><shadowcolor:000000>Tracking: %s"%(self.trackInterest))
                else:
                    self.trackingText.setText("<font:Arial Bold:14><just:center><shadow:1:1><shadowcolor:000000>Tracking: %s at %im"%(self.tracking[self.trackingId][0],self.tracking[self.trackingId][2]))
                    
                self.trackingText.visible = True
                
                
            prevSelected = int(self.trackingList.getSelectedId())
            #tcell = int(self.trackingList.topCell)
            #if tcell < 0:
            #    tcell = 0
            x,y = self.trackingScroll.childRelPos.split(" ")
            #print self.trackingScroll.childPos
            
            
            tc = self.trackingList
            tc.setVisible(False)
            tc.clear()
            
            found = False
            for id,values in tracking.iteritems():
                
                #(m.name,m.simObject.position,r)
                mw.addContact(values[0],values[3],values[1][0],values[1][1],values[1][2])
                
                if id == prevSelected:
                    found = True
                if id == self.trackingId:
                    TGEEval(r'TRACKING_TRACKINGLIST.addRow(%i,"\c2%s" TAB %i @"m");'%(id,values[0],int(values[2])))
                else:
                    if values[3]==1:
                        TGEEval(r'TRACKING_TRACKINGLIST.addRow(%i,"\c3%s" TAB %i @"m");'%(id,values[0],int(values[2])))
                    else:
                        TGEEval(r'TRACKING_TRACKINGLIST.addRow(%i,"%s" TAB %i @"m");'%(id,values[0],int(values[2])))
                        
                
                
            
            tc.sortNumerical(1)
            
            id = -1
            for p in poi:
                mw.addContact(p[0],6,p[1],p[2],p[3])
                TGEEval(r'TRACKING_TRACKINGLIST.addRow(%i,"\c4%s" TAB " ");'%(id,p[0]))
                
                if id == prevSelected:
                    found = True
                    
                id-=1


            if not found:
                row = 0
            else:
                row = tc.getRowNumById(prevSelected)
                
                
    
            
            tc.setSelectedRow(row)
            self.trackingScroll.scrollTo(x,y)
            #tc.scrollVisible(tcell)
            
            
            tc.setActive(True)
            tc.setVisible(True)
            
            TGEObject("TRACKINGWND_Window").setText("Tracking - Range %im"%self.range)
        except:
            traceback.print_exc()

            
        
        

def OnTrack():
    from mud.client.playermind import PLAYERMIND
    if not int(TRACKINGWND.trackingList.rowCount()):
        return
    id = int (TRACKINGWND.trackingList.getSelectedId())
    
    if id>=0:
        TRACKINGWND.trackInterest = ""
        PLAYERMIND.perspective.callRemote("PlayerAvatar","track",id)
    else:
        #we're tracking a location
        TRACKINGWND.trackInterest = TRACKINGWND.interestLookup[id]
        
        TRACKINGWND.trackingText.setText("<font:Arial Bold:15><just:center><shadow:1:1><shadowcolor:000000>Tracking: %s"%(TRACKINGWND.trackInterest))
        TRACKINGWND.trackingText.visible = True
        
        from pointsOfInterest import GetPointsOfInterest
        poi = GetPointsOfInterest()
        for p in poi:
            if TRACKINGWND.trackInterest == p[0]:
                TRACKINGWND.trackLocation = (p[1],p[2],p[3])
                break
    
    
    


#"Py::OnTrack();";
def PyExec():
    global TRACKINGWND
    TRACKINGWND = TrackingWnd()
    TGEExport(OnTrack,"Py","OnTrack","desc",1,1)