from tgenative import *
from mud.tgepython.console import TGEExport
from mud.world.defines import *


CRAFTINGWND = None


class CraftingWnd:
    def __init__(self):
        self.craftingButtons = {}
        self.window = TGEObject("CRAFTINGWND_WINDOW")
        for x in xrange(RPG_SLOT_CRAFTING_BEGIN,RPG_SLOT_CRAFTING_END):
            self.craftingButtons[x]=TGEObject("CRAFTING_BUTTON%i"%(x-RPG_SLOT_CRAFTING_BEGIN))
            
            
    def setFromCharacterInfo(self,cinfo):
        from partyWnd import PARTYWND
        
        self.window.setText(cinfo.NAME+"'s Crafting")
        
        self.charInfo = cinfo
        for slot,butt in self.craftingButtons.iteritems():
            butt.number = -1
            if not cinfo.ITEMS.has_key(slot): #only clear the ones we need to so we don't have to relock texture!
                butt.SetBitmap("")

        for slot,ghost in cinfo.ITEMS.iteritems():
            if self.craftingButtons.has_key(slot):
                self.craftingButtons[slot].setBitmap("~/data/ui/items/"+ghost.BITMAP+"/0_0_0")
                if ghost.STACKMAX > 1:
                    self.craftingButtons[slot].number = ghost.STACKCOUNT


    

def OnCraftingButtonAlt(args):
    OnCraftingButton(args)


def OnCraftingButton(args):
    from partyWnd import PARTYWND
    curIndex = PARTYWND.curIndex #just in case current character changes we want to make choice reflect dialog no matter what
    cinfo = PARTYWND.charInfos[curIndex]
    name = cinfo.NAME
    
    slot = int(args[1])
    
    PARTYWND.mind.onInvSlot(cinfo,slot+RPG_SLOT_CRAFTING_BEGIN)
        
def OnReallyCraft():
    pass
    
        
def OnCraft():
    #TGEEval('MessageBoxYesNo("Destroy Corpse?", "Do you really want destroy this corpse?","Py::OnReallyDestroyCorpse();");')
    from partyWnd import PARTYWND
    PARTYWND.mind.onCraft()
        
    
def OnCraftingToggle():
    if int(CRAFTINGWND.window.isAwake()):
        TGEEval("Canvas.popDialog(CraftingWnd);")
    else:
        TGEEval("Canvas.pushDialog(CraftingWnd);")
    
    
    

def PyExec():
    global CRAFTINGWND
    CRAFTINGWND = CraftingWnd()
    
    
    TGEExport(OnCraftingButton,"Py","OnCraftingButton","desc",2,2)
    #TGEExport(OnReallyCraftingButton,"Py","OnReallyCraftingButton","desc",3,3)

    TGEExport(OnCraftingButtonAlt,"Py","OnCraftingButtonAlt","desc",2,2)
    #TGEExport(OnReallyCraftingButtonAlt,"Py","OnReallyCraftingButtonAlt","desc",3,3)
    
    TGEExport(OnCraftingToggle,"Py","OnCraftingToggle","desc",1,1)
    
    TGEExport(OnCraft,"Py","OnCraft","desc",1,1)
    TGEExport(OnReallyCraft,"Py","OnReallyCraft","desc",1,1)
    