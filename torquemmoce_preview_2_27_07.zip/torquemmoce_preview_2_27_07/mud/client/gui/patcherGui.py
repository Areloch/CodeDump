
from tgenative import *
from mud.tgepython.console import TGEExport
from mud.world.defines import *
from mud.gamesettings import *
from twisted.internet import reactor,ssl
from twisted.web.client import HTTPDownloader,HTTPPageDownloader,_parse
from twisted.spread import pb
from twisted.cred.credentials import UsernamePassword

import sys,imp,os
from traceback import print_exc
from base64 import encodestring
from sha import new as newSHA
from cPickle import loads,load,dump
from zipfile import ZipFile,ZIP_DEFLATED
from shutil import copyfile,rmtree,copytree,copy as shutilCopy
from time import time,sleep
from md5 import md5

from masterLoginDlg import DoMasterLogin

if sys.platform[:6] != 'darwin':
    import win32api
    PLATFORM = "windows"
else:
    PLATFORM = "mac"
    
ABORT = False

REMOTEMANIFESTSRECEIVED = 0
LOCALMANIFEST = {}
REMOTEMANIFEST = {}


DUSERNAME = USERNAME = None
DPASSWORD = PASSWORD = None
DPATCHSERVERADDRESS = None

#legacy
if GAMEROOT == "minions.of.mirth":
    DUSERNAME = USERNAME = "demo"
    DPASSWORD = PASSWORD = "changeover"
    DPATCHSERVERADDRESS = "https://dev.prairiegames.com/svn/demo"

    if not RPG_BUILD_DEMO and not RPG_BUILD_LIVE:
        DPATCHSERVERADDRESS = "https://dev.prairiegames.com/svn/testing"

PATCHFILES = []
PATCHFILESIZES = {}

GRANDTOTALPATCHSIZE =0
TOTALPATCHSIZE = 0

CURRENTPATCHSIZE = 0
CURRENTPATCHTOTALSIZE = 0

PROGRESSCOUNTER = 0.0

SWAPBIN = False

#where are we patching from multi, live update

HAVE_PATCHED = False

# 0 is LIVE UPDATE #1 is MULTI
PATCH_CODE = 0

#PATCHER_CURRENTFILE_PROGRESS
#PATCHER_TOTAL_TEXT
#PATCHER_TOTAL_PROGRESS

IGNORE = [
"manifest.zip","manifest.sha","common/manifest.zip","common/manifest.sha","common/console.log",
"common/%s/client/config.cs"%GAMEROOT,"common/%s/client/prefs.cs"%GAMEROOT,
"cache/"
]

PATCHSERVERADDRESS=None
PATCHTAG = None
VERSION = None


def SetupPatchInfo(demo,live=RPG_BUILD_LIVE):
    global PATCHSERVERADDRESS,PATCHTAG,VERSION

    if GAMEROOT == "minions.of.mirth":
        if demo:
            PATCHSERVERADDRESS = "https://dev.prairiegames.com/svn/demo"
            PATCHTAG = ""
        else:
            PATCHSERVERADDRESS = None
            if live:
                PATCHTAG = "branches/live"
            else:
                PATCHTAG = "trunk"
                
        if demo:
            VERSION = "demo"
        else:
            VERSION = "testing"
    else:
        PATCHSERVERADDRESS = None
        PATCHTAG = ""
        VERSION = "testing"
        
def DisplayPatchInfo():
    try:
        f = file('./patchlist.txt','r')
        text = "<shadowcolor:000000><shadow:1:1><font:Arial Bold:14>"+f.read()
        
        text = text.replace('\r',"\\r")
        text = text.replace('\n',"\\n") #valid quote
        text = text.replace('\a',"\\a") #valid quote
        text = text.replace('"','\\"') #invalid quote
        f.close()
    
        text = text[:4000]+ "  *** SNIP *** see patchlist.txt if you'd like to read more"
    
    
        TGEEval('patchinfownd_text.setText("%s");'%text)
    
        #TGECall("CloseMessagePopup")
        #TGEEval("canvas.setContent(MultiplayerGui);")
        TGEEval("canvas.pushDialog(PatchInfoWnd);")
        
    except:
        pass
    
    



def LoadManifestCache(base):
    try:
        f = file("./cache/%s_manifest.cache"%base,'rb')
        cache = load(f)
        f.close()
    except:
        cache = {}
        
    return cache

def SaveManifestCache(base,cache):
    try:
        f = file("./cache/%s_manifest.cache"%base,'wb')
        dump(cache,f)
        f.close()
    except:
        print "WARNING: couldn't save manifest cache"
        

#a list of sha checksums every 64k of a file

def getsha(filename):
    f = open(filename, "rb")
    data = f.read()
    tsize = size=len(data)
    shalist = []
    start = 0
    while (size>0):
        
        m = newSHA()
        d = data[start:start+65535]
        m.update(d)
        shalist.append(m.hexdigest())
        size -= 65535
        start+= 65535
        
    f.close()
        
    return tsize,shalist


def dirwalk(dir,ignore):
    "walk a directory tree, using a generator"
    
    try:
        dirlist = os.listdir(dir)
    except:
        return #permission denied most likely
    
    for f in dirlist:
        fullpath = os.path.join(dir,f)
        fullpath = fullpath.replace("\\","/")
        if fullpath.upper().find(".SVN")!=-1:
            continue
        
        ignored = False
        for i in ignore:
            if fullpath.upper().find(i) != -1:
                ignored = True
                break
            
        if ignored:
            continue
        
        if os.path.isdir(fullpath) and not os.path.islink(fullpath):
            for x in dirwalk(fullpath,ignore):  # recurse into subdir
                yield x
        else:
            yield fullpath
     
    
def GetNumManifestFiles(path,ignore):    
    numfiles = 0
    for elem in dirwalk(path,ignore):
        elem = elem.replace('\\','/')
        if not os.path.isfile(elem):
            continue
        numfiles+=1
        
    return numfiles


FILEDESC = {}
def GenerateManifest(path,BASE,ignore = [],callback=None,cache={}):
    global FILEDESC
    FILEDESC = {}    
    
    ptime = time()
    
    totalfiles = GetNumManifestFiles(path,ignore)
    numfiles = 0
    
    for elem in dirwalk(path,ignore):
        elem = elem.replace('\\','/')
        if not os.path.isfile(elem):
            continue
        
        if BASE == "common":
            fd = elem[elem.find(BASE):]
        else:
            fd = elem[len(BASE):]
            
        fsize = os.path.getsize(elem)
        ctime = os.path.getctime(elem)
        mtime = os.path.getmtime(elem)
        
        
        if cache.has_key((elem,fsize,ctime,mtime)):
            #use cache
            size,shalist = cache[(elem,fsize,ctime,mtime)]
        else:
            for v in cache.itervalues():
                if v[0]==elem:
                    del cache[v]
                    break
            size,shalist = getsha(elem)
            cache[(elem,fsize,ctime,mtime)]=(size,shalist)
        
            
            
        FILEDESC[fd]=(size,shalist)
        
        numfiles+=1
        
        if time() - ptime > .1:
            if callback:
                callback(float(numfiles)/float(totalfiles))
            ptime = time()
            yield True

class MyHTTPPageDownloader(HTTPPageDownloader):

    def rawDataReceived(self, data):
        global TOTALPATCHSIZE
        global GRANDTOTALPATCHSIZE
        global CURRENTPATCHSIZE
        global TOTALPATCHSIZE
        global PROGRESSCOUNTER
        global ABORT
        
        HTTPPageDownloader.rawDataReceived(self,data)
        
        if ABORT:
            self.transport.loseConnection()
            return
        
        
        if TOTALPATCHSIZE:
            TOTALPATCHSIZE -= len(data)
            TGEObject("PATCHER_TOTAL_TEXT").setText("%i KB Remaining"%(TOTALPATCHSIZE/1024)) 
            TGEObject("PATCHER_TOTAL_PROGRESS").setValue(1.0-(float(TOTALPATCHSIZE)/float(GRANDTOTALPATCHSIZE)))
            
            if TOTALPATCHSIZE < 0:#hrm
                TGEObject("PATCHER_TOTAL_TEXT").setText("") 
                

        if CURRENTPATCHSIZE:
            CURRENTPATCHSIZE -= len(data)
            TGEObject("PATCHER_CURRENTFILE_PROGRESS").setValue(1.0-(float(CURRENTPATCHSIZE)/float(CURRENTPATCHTOTALSIZE)))


        #manifest
        if not TOTALPATCHSIZE and not CURRENTPATCHSIZE:
            PROGRESSCOUNTER+=.05
            if PROGRESSCOUNTER > 1.0:
                PROGRESSCOUNTER = 0.0
                
            
            TGEObject("PATCHER_TOTAL_PROGRESS").setValue(PROGRESSCOUNTER)
            TGEObject("PATCHER_CURRENTFILE_PROGRESS").setValue(PROGRESSCOUNTER)
            
        
class MyHTTPDownloader(HTTPDownloader):
    protocol = MyHTTPPageDownloader
    


def DownloadPage(url, file, contextFactory=None, *args, **kwargs):
    """Download a web page to a file.

    @param file: path to file on filesystem, or file-like object.
    
    See HTTPDownloader to see what extra args can be passed.
    """
    scheme, host, port, path = _parse(url)
    factory = MyHTTPDownloader(url, file, *args, **kwargs)
    if scheme == 'https':
        if contextFactory is None:
            contextFactory = ssl.ClientContextFactory()
        reactor.connectSSL(host, port, factory, contextFactory)
    else:
        reactor.connectTCP(host, port, factory)
    return factory.deferred

def Error(value):
    if not ABORT:
        TGEEval('MessageBoxOK("Patcher Error","Unable to retrieve remote manifests.","Py::OnPatchError();");')

def GotManifest(value,page):
    try:

        global REMOTEMANIFESTSRECEIVED

        if ABORT:
            return
        
        zfile = ZipFile("./cache/%s_manifest.zip"%page,'r')
        manifest = loads(zfile.read('./manifest'))
        zfile.close()
        
        for key,value in manifest.iteritems():
            REMOTEMANIFEST[key]=value
            
        REMOTEMANIFESTSRECEIVED+=1
        
        if REMOTEMANIFESTSRECEIVED == 2:
            CompareManifests()            
    except:
        TGEEval('MessageBoxOK("Patcher Error","%s manifest error","Py::OnPatchError();");'%page)
        print_exc()
     
def ErrorPatchFile(value):
    
    if not ABORT:
    
        filename = PATCHFILES[0]
    
        TGEEval('MessageBoxOK("Patcher Error","Error retrieving file %s","Py::OnPatchError();");'%filename)    
     
     

def GotPatchFile(value):
    global SWAPBIN
    
    filename = PATCHFILES[0]
    
    #XXX DEBUG!!!! You must not be running WorldManager, Genesis.exe, etc while patching!
    root,ext = os.path.splitext(filename)
    ext = ext.lower()
    if ext == ".pyd" or ext == ".dll" or ext == ".exe":
        SWAPBIN = True
    #if "library.zip" in filename.lower():
    #    SWAPBIN = True
    
    try:
    
        global CURRENTPATCHSIZE
        global CURRENTPATCHTOTALSIZE
        
        if ABORT:
            return
        
        PATCHFILES.remove(filename)
        
        if len(PATCHFILES):
            
            TGEObject("PATCHER_CURRENTFILE_TEXT").setText(os.path.basename(PATCHFILES[0]))
            TGEObject("PATCHER_CURRENTFILE_PROGRESS").setValue(0)
            TGEEval("canvas.repaint()");
            
        
            
            pfilename = file="./patch_files/%s"%PATCHFILES[0]
            try:
                os.makedirs(os.path.normpath(os.path.dirname(pfilename)))
            except:
                pass
                
            webfile = PATCHFILES[0].replace(" ", r'%20')
        
            uname,pword = USERNAME,PASSWORD
            waddress = PATCHSERVERADDRESS
            
            if webfile.startswith("common/"):
                uname,pword = DUSERNAME,DPASSWORD
                waddress = DPATCHSERVERADDRESS
            
            extraHeaders = {}
            extraHeaders['Authorization'] = 'Basic ' + \
                        encodestring(uname + ':' + pword).strip()    
                        
                    
            
            if not webfile.startswith("common/"):
                if PLATFORM == "windows":
                    if PATCHTAG:
                        webfile = "windows/%s/%s"%(PATCHTAG,webfile)
                    else:
                        webfile = "windows/"+webfile
                else:
                    if PATCHTAG:
                        webfile = "mac/%s/%s"%(PATCHTAG,webfile)
                    else:
                        webfile = "mac/"+webfile
            else:
                if PATCHTAG and not RPG_BUILD_LIVE:
                    w = webfile[7:]
                    webfile = "common/%s/%s"%(PATCHTAG,w)

                
            CURRENTPATCHSIZE=CURRENTPATCHTOTALSIZE=PATCHFILESIZES[PATCHFILES[0]]
        
            p = "%s/%s"%(waddress,webfile)
            d = DownloadPage(p, file=pfilename,headers=extraHeaders)
            d.addCallbacks(GotPatchFile,ErrorPatchFile)
        
            
    except:
        TGEEval('MessageBoxOK("Patcher Error","Error receiving %s","Py::OnPatchError();");'%filename)
        print_exc()
        return
        
    if not len(PATCHFILES):
        TGEObject("PATCHER_TOTAL_TEXT").visible = False
        TGEObject("PATCHER_TOTAL_PROGRESS").visible = False

        gen = VerifyPatchFiles()
        VerifyPatchFilesTick(gen)
        


def TickProgressCounter(value):
    global PROGRESSCOUNTER
    
    PROGRESSCOUNTER=value
        
        
    text = "Inspecting and Caching Local Files"
    TGEObject("PATCHER_CURRENTFILE_TEXT").setText(text)
    TGEObject("PATCHER_TOTAL_TEXT").setText(text)
        
    
    TGEObject("PATCHER_TOTAL_PROGRESS").setValue(PROGRESSCOUNTER)
    TGEObject("PATCHER_CURRENTFILE_PROGRESS").setValue(PROGRESSCOUNTER)
    #TGEEval("canvas.repaint();")
    
def VerifyPatchFilesTick(gen):
    try:
        gen.next()
        reactor.callLater(0.01,VerifyPatchFilesTick,gen)
        
    except StopIteration:
        pass

    

def VerifyPatchFiles():
    
    global SWAPBIN
    
    if ABORT:
        return
    
    
    TGEObject("PATCHER_CURRENTFILE_TEXT").setText("")
    TGEObject("PATCHER_TOTAL_TEXT").setText("")
    TGEObject("PATCHER_STATUS_TEXT").setText("Verifying Patch Files (Please Wait)")
    
    TGEEval("canvas.repaint();")
    
    
    try:
        gen=GenerateManifest("./patch_files/","./patch_files/",[],TickProgressCounter,{})
        while 1:
            try:
                gen.next()
                yield True
            except StopIteration:
                break
        
        manifest = FILEDESC
        
        e = False
        for k in sorted(manifest.iterkeys()):
            if not REMOTEMANIFEST.has_key(k):
                continue
            
            if REMOTEMANIFEST[k]!=manifest[k]:
                e = True
                TGEEval('MessageBoxOK("Patcher Error","Error verifying file \'%s\'","Py::OnPatchError();");'%k)
                try:
                    os.remove("./patch_files/%s"%k)
                except:
                    print_exc()
        if e:
            print "ERROR VERIFYING FILE %s"%k
            return
            
        #files verified it's now time to patch
        
        if SWAPBIN and PLATFORM == "windows":
            try:
                rmtree("tempbin")
            except:
                if os.path.exists("tempbin"):
                    TGEEval('MessageBoxOK("Patcher Error","Error removing tempbin folder","Py::OnPatchError();");')
                    print_exc()
                    return

        try:
            rmtree("restore")
        except:
            if os.path.exists("restore"):
                TGEEval('MessageBoxOK("Patcher Error","Error removing restore folder","Py::OnPatchError();");')
                print_exc()
                return

        if SWAPBIN and PLATFORM == "windows":    
            copytree("bin","tempbin")
            if os.path.exists("./patch_files/bin"):
                for f in os.listdir("./patch_files/bin"):
                    shutilCopy('./patch_files/bin/%s'%f,'tempbin/%s'%(f))
                    
        TGEObject("PATCHER_CURRENTFILE_TEXT").setText("")
        TGEObject("PATCHER_TOTAL_TEXT").setText("")
        TGEObject("PATCHER_STATUS_TEXT").setText("Restart Needed")
        
        TGEEval("canvas.repaint();")

                
        TGEEval('MessageBoxOK("Restart Needed","Minions of Mirth has been patched and needs to be restarted","Py::OnPatchRestart();");')
        
    except:
        TGEEval('MessageBoxOK("Patcher Error","Error verifying patch files","Py::OnPatchError();");')
        print_exc()
        
def CompareManifests():
    
    global PATCHFILESIZES
    global PATCHFILES
    global TOTALPATCHSIZE
    global GRANDTOTALPATCHSIZE
    global CURRENTPATCHSIZE
    global CURRENTPATCHTOTALSIZE
    global HAVE_PATCHED
    global SWAPBIN

    if ABORT:
        return
    
    TGEObject("PATCHER_CURRENTFILE_TEXT").setText("")
    TGEObject("PATCHER_TOTAL_TEXT").setText("")
    TGEObject("PATCHER_STATUS_TEXT").setText("Comparing Manifests (Please Wait)")
    
    TGEEval("canvas.repaint();")

    
    try:
        #first count files to download
        
        PATCHFILES = []
        PATCHFILESIZES = {}
        TOTALPATCHSIZE = 0
        
        pfile = False
        for k in sorted(REMOTEMANIFEST.iterkeys()):
            
            if k in IGNORE:
                continue
            
            value = REMOTEMANIFEST[k]
            
            #case insensitive
            local = LOCALMANIFEST.get(k.lower())
            if local != value:                
                #compare to downloaded file that may be in patch files
                pf = LOCALMANIFEST.get("patch_files/%s"%(k.lower()),None)
                if pf != value:
                    PATCHFILESIZES[k]=value[0]
                    TOTALPATCHSIZE+=value[0]
                    PATCHFILES.append(k)
                else:
                    root,ext = os.path.splitext(k)
                    ext = ext.lower()
                    if ext == ".pyd" or ext == ".dll" or ext == ".exe":
                        SWAPBIN = True
                    pfile = True
            else:                
                pf = LOCALMANIFEST.get("patch_files/%s"%(k.lower()),None)
                if pf:
                    try:
                        if os.path.exists("patch_files/%s"%k):
                            os.remove("patch_files/%s"%k)
                    except:
                        pass
                    if os.path.exists("patch_files/%s"%k):
                        TGEEval('MessageBoxOK("Patcher Error","Error removing patch file %s","Py::OnPatchError();");'%k)
                        raise "Patch Error"
                        
                                
                
                
                
            
        if len(PATCHFILES):
            #kick start downloading
            
            
            TGEObject("PATCHER_TOTAL_TEXT").visible = True
            TGEObject("PATCHER_TOTAL_PROGRESS").visible = True

            
            TGEObject("PATCHER_STATUS_TEXT").setText("Downloading Patch Files...")
                        
            GRANDTOTALPATCHSIZE = TOTALPATCHSIZE
            TGEObject("PATCHER_CURRENTFILE_TEXT").setText(os.path.basename(PATCHFILES[0]))
            TGEObject("PATCHER_TOTAL_TEXT").setText("%i KB Remaining"%(TOTALPATCHSIZE/1024))
            
            TGEObject("PATCHER_TOTAL_PROGRESS").setValue(0)
            TGEObject("PATCHER_CURRENTFILE_PROGRESS").setValue(0)
            TGEEval("canvas.repaint()");
           
            
            
            pfilename = file="./patch_files/%s"%PATCHFILES[0]
            try:
                os.makedirs(os.path.normpath(os.path.dirname(pfilename)))
            except:
                pass
                
            webfile = PATCHFILES[0].replace(" ", r'%20')
            
            uname,pword = USERNAME,PASSWORD
            waddress = PATCHSERVERADDRESS
            
            if webfile.startswith("common/"):
                uname,pword = DUSERNAME,DPASSWORD
                waddress = DPATCHSERVERADDRESS

    
            
            extraHeaders = {}
            extraHeaders['Authorization'] = 'Basic ' + \
                        encodestring(uname + ':' + pword).strip()    
                        
            
            if not webfile.startswith("common/"):
                if PLATFORM == "windows":
                    
                    if PATCHTAG:
                        webfile = "windows/%s/%s"%(PATCHTAG,webfile)
                    else:
                        webfile = "windows/"+webfile
                        
                else:
                    if PATCHTAG:
                        webfile = "mac/%s/%s"%(PATCHTAG,webfile)
                    else:
                        webfile = "mac/"+webfile
            else:
                if PATCHTAG and not RPG_BUILD_LIVE:
                    w = webfile[7:]
                    webfile = "common/%s/%s"%(PATCHTAG,w)
                    
                    
                
            CURRENTPATCHSIZE=CURRENTPATCHTOTALSIZE=PATCHFILESIZES[PATCHFILES[0]]
                
            p = "%s/%s"%(waddress,webfile)
                
            d = DownloadPage(p, file=pfilename,headers=extraHeaders)
            d.addCallbacks(GotPatchFile,ErrorPatchFile)
            
        else:
            if pfile:
                #have some local patch files
                gen = VerifyPatchFiles()
                VerifyPatchFilesTick(gen)
                return

            #no files to patch, we're good to go
            HAVE_PATCHED = True
            
            #remove old patch files
            try:
                if os.path.exists("./patch_files"):
                    rmtree("./patch_files")
                if os.path.exists("./restore"):
                    rmtree("./restore")

            except:
                print_exc()
            
            
            os.chdir("./common")
            if PATCH_CODE == 1:
                DoMasterLogin()
                #TGEEval("canvas.setContent(MultiplayerGui);")
            else:
                TGEEval("canvas.setContent(MainMenuGui);")
                DisplayPatchInfo()
                TGEEval('MessageBoxOK("Live Update","Your game is up to date.");')
                
            
    except:
        TGEEval('MessageBoxOK("Patcher Error","Error comparing manifests","Py::OnPatchError();");')
        print_exc()
            

def GenerateLocalManifestsTick(gen):
    try:
        gen.next()
        reactor.callLater(0.01,GenerateLocalManifestsTick,gen)
        
    except StopIteration:
        RetrieveRemoteManifests()


def GenerateLocalManifests():
    global LOCALMANIFEST
    
    try:
        
        
        global PROGRESSCOUNTER
        
        PROGRESSCOUNTER = 0.0
    
        TGEObject("PATCHER_CURRENTFILE_TEXT").setText("")
        TGEObject("PATCHER_TOTAL_TEXT").setText("")
        TGEObject("PATCHER_STATUS_TEXT").setText("Generating Local Manifest (Please Wait)")
        
        TGEObject("PATCHER_TOTAL_PROGRESS").setValue(0)
        TGEObject("PATCHER_CURRENTFILE_PROGRESS").setValue(0)
        
        TGEEval("canvas.Repaint();")
    
        
        #generate local manifest of files
        COMPONENTS = ["./","common"]
        
        LOCALMANIFEST = {}
        
        for COMPONENT in COMPONENTS:
        
            try:
                ignore = []
                if COMPONENT == "./":
                    ignore = ["./COMMON"]
                else:
                    ignore = ["COMMON/CONSOLE.LOG"]
                
                
                if COMPONENT == "./":
                    base = "base"
                else:
                    base = "common"
                                
                cache = LoadManifestCache(base)
                gen=GenerateManifest(COMPONENT,COMPONENT,ignore,TickProgressCounter,cache)
                while 1:
                    try:
                        gen.next()
                        yield True
                    except StopIteration:
                        break
               
                
                SaveManifestCache(base,cache)
                
                manifest = FILEDESC
                
                for key,value in manifest.iteritems():
                    LOCALMANIFEST[key.lower()]=value
                
            except:
                print_exc()
                LOCALMANIFEST = {}
        
        TGEEval("canvas.Repaint();")
    except:
        TGEEval("canvas.Repaint();")

        TGEEval('MessageBoxOK("Patcher Error","Error generating local manifest","Py::OnPatchError();");')
        print_exc()
        
    
def RetrieveRemoteManifests():
    global PROGRESSCOUNTER
    
    if ABORT:
        return
    
    PROGRESSCOUNTER = 0.0
    
    TGEObject("PATCHER_TOTAL_PROGRESS").setValue(PROGRESSCOUNTER)
    TGEObject("PATCHER_CURRENTFILE_PROGRESS").setValue(PROGRESSCOUNTER)
    
    TGEObject("PATCHER_CURRENTFILE_TEXT").setText("")
    TGEObject("PATCHER_TOTAL_TEXT").setText("")
    TGEObject("PATCHER_STATUS_TEXT").setText("Retrieving Remote Manifests (Please Wait)")
    
    TGEEval("canvas.repaint();")
        
    extraHeaders = {}
    extraHeaders['Authorization'] = 'Basic ' + \
                encodestring(DUSERNAME + ':' + DPASSWORD).strip()
                
    
    p = "%s/common/manifest.zip"%DPATCHSERVERADDRESS
    if PATCHTAG and not RPG_BUILD_LIVE:
        p = "%s/common/%s/manifest.zip"%(DPATCHSERVERADDRESS,PATCHTAG)
        
    d = DownloadPage(p, file="./cache/base_manifest.zip",headers=extraHeaders)
    d.addCallbacks(GotManifest,Error,("base",))
    
    extraHeaders = {}
    extraHeaders['Authorization'] = 'Basic ' + \
                encodestring(USERNAME + ':' + PASSWORD).strip()
    
    
    if PLATFORM == 'windows':
        p = "%s/windows/manifest.zip"%PATCHSERVERADDRESS
        if PATCHTAG:
            p = "%s/windows/%s/manifest.zip"%(PATCHSERVERADDRESS,PATCHTAG)
            
        d = DownloadPage(p, file="./cache/windows_manifest.zip",headers=extraHeaders)
        d.addCallbacks(GotManifest,Error,("windows",))
    else:
        p = "%s/mac/manifest.zip"%PATCHSERVERADDRESS
        if PATCHTAG:
            p = "%s/mac/%s/manifest.zip"%(PATCHSERVERADDRESS,PATCHTAG)
        d = DownloadPage(p, file="./cache/mac_manifest.zip",headers=extraHeaders)
        d.addCallbacks(GotManifest,Error,("mac",))
        

    
def Patch():
    global REMOTEMANIFESTSRECEIVED
    global TOTALPATCHSIZE
    global CURRENTPATCHSIZE
    global ABORT
    global SWAPBIN
    
    SWAPBIN = False
    
    TGEObject("PATCHER_TOTAL_TEXT").visible = False
    TGEObject("PATCHER_TOTAL_PROGRESS").visible = False
    
    TGEEval("canvas.setContent(PatcherGui);canvas.Repaint();")

    
    
    
    try:
        ABORT = False
        TOTALPATCHSIZE = 0
        CURRENTPATCHSIZE = 0
        
        REMOTEMANIFESTSRECEIVED = 0
        
        os.chdir("../")
        
        #try cookies to speed up access?
        try:
            os.makedirs("./cache")
        except:
            pass
                
        gen = GenerateLocalManifests()
        GenerateLocalManifestsTick(gen)
        
        
    except:
        print_exc()
        TGEEval('MessageBoxOK("Patcher Error","There was an error during the patching process.","Py::OnPatchError();");')
        
    
def main_is_frozen():
   return (hasattr(sys, "frozen") or # new py2exe
           hasattr(sys, "importers") # old py2exe
           or imp.is_frozen("__main__")) # tools/freeze


        
def OnPatchError():
    os.chdir("./common")
    TGEEval("canvas.setContent(MainMenuGui);")
    

def copyfileobj(fsrc, fdst, length=16*1024):
    """copy data from file-like object fsrc to file-like object fdst"""
    while 1:
        buf = fsrc.read(length)
        if not buf:
            break
        fdst.write(buf)
def copyfile(src, dst):
    """Copy data from src to dst"""
    fsrc = None
    fdst = None
    try:
        fsrc = open(src, 'rb')
        fdst = open(dst, 'wb')
        copyfileobj(fsrc, fdst)
    finally:
        if fdst:
            fdst.close()
        if fsrc:
            fsrc.close()


def DoPatchOSX():    
    

    try:
        import stat
        #copy to restore
        
        os.makedirs("./restore")
        os.chmod("./restore",stat.S_IRWXO|stat.S_IRWXG|stat.S_IRWXU)
        
        for dirpath,dirnames,filenames in os.walk("./patch_files"):
            for file in filenames:
                full = os.path.normpath(dirpath+"/"+file)
                os.chmod(full,stat.S_IRWXO|stat.S_IRWXG|stat.S_IRWXU)
                
                error = True
                dst = full.replace("patch_files",".")                        
                
                #THESE DIRS PERMISSIONS ARE NOT +O-RWX!
                if os.path.exists(dst):
                    try:
                        os.makedirs(os.path.normpath(os.path.dirname("./restore/"+dst[2:])))
                    except:
                        pass
                    shutilCopy(dst,"./restore/"+dst[2:])
                    os.chmod("./restore/"+dst[2:],stat.S_IRWXO|stat.S_IRWXG|stat.S_IRWXU)
                
                head,tail = os.path.split(dst)
                
                try:
                    os.makedirs(head)
                except:
                    pass
                    
                
                starttime = time()
                while time()-starttime < 10:
                    try:
                        copyfile(full,dst)
                        #os.chmod(full,stat.S_IRWXO|stat.S_IRWXG|stat.S_IRWXU)
                        error = False
                        break
                    except:
                        sleep(1)
                        pass
                    
                if error:
                    #restore
                    for dirpath,dirnames,filenames in os.walk("./restore"):
                        for file in filenames:
                            rfull = os.path.normpath(dirpath+"/"+file)
                            dst = rfull[8:] #get rid of restore   
                            try:                         
                                copyfile(rfull,dst)
                                #os.chmod(full,stat.S_IRWXO|stat.S_IRWXG|stat.S_IRWXU)
                                
                            except:
                                print_exc()
                     
                    TGEEval('MessageBoxOK("Patcher Error","Unable to copy file %s.","Py::OnPatchError();");'%full)           
                    
                    return False
    except:
        print_exc()
        
        TGEEval('MessageBoxOK("Patcher Error","There was an error encountered during patching.  Please check your console.","Py::OnPatchError();");')           
        return False
    
    return True
        


 
def OnPatchRestart():
    #export prefs
    
        
    #in theory we are ready to launch
    if not main_is_frozen():
        
        cmd  =  r'C:\Python25\python.exe'
        args = r' C:\PrairieGames\mom\MinionsOfMirth.py'
        args+= r' -patch'
        
        os.spawnl(os.P_DETACH,cmd,args)
        reactor.stop()
        TGEEval("quit();")            
    else:
        if PLATFORM == "windows":
            d = "bin"
            if SWAPBIN:
                d = "tempbin"
            pid = win32api.GetCurrentProcessId()
            if GAMEROOT == "minion.of.mirth":
                cmd = os.getcwd()+"/%s/MinionsOfMirth.exe"%d
            else:
                cmd = os.getcwd()+"/%s/Client.exe"%d
            
            args = r'-patch -pid=%i'%pid
            
            #we'll be killed by patcher process
            os.spawnl(os.P_NOWAIT,cmd,args)
            os.chdir("./common")
            TGEEval("quit();")
        else:
            if DoPatchOSX():
                #os.spawnl(os.P_NOWAIT,"./MinionsOfMirth.app/Contents/MacOS/MinionsOfMirth","./MinionsOfMirth.app/Contents/MacOS/MinionsOfMirth")
                os.chdir("./common")
                
                TGEEval("quit();")
            
        
def OnPatchCancel():
    global ABORT
    ABORT = True
    os.chdir("./common")
    TGEEval("canvas.setContent(MainMenuGui);canvas.repaint();")
    
    

def PatchServerResults(args,perspective):
    global DPATCHSERVERADDRESS,PATCHSERVERADDRESS,USERNAME,PASSWORD,DUSERNAME,DPASSWORD
    
    perspective.broker.transport.loseConnection()
    
    TGECall("CloseMessagePopup")
    if args[0]:
        TGECall("MessageBoxOK","Error!",args[1])
        return
    
    PATCHSERVERADDRESS,USERNAME,PASSWORD = args[1]
    DPATCHSERVERADDRESS,DUSERNAME,DPASSWORD = args[1]
    
    if len(args)>2 and args[2]:
        DPATCHSERVERADDRESS,DUSERNAME,DPASSWORD = args[2]
        
    #if not RPG_BUILD_DEMO and not RPG_BUILD_LIVE:
    #    DUSERNAME,DPASSWORD = USERNAME,PASSWORD
    
    Patch()
    
def PatchLoginConnected(perspective):
    TGECall("CloseMessagePopup")
    
    #request the patcher information
    TGECall("MessagePopup","Communicating with Master Server...","Please wait...")
    perspective.callRemote("PlayerAvatar","getPatchServerInfo",PLATFORM,VERSION).addCallbacks(PatchServerResults,Failure,(perspective,))
    

def Failure(reason):
    TGECall("CloseMessagePopup")
    
    #todo, proper error messages
    #TGECall("MessageBoxOK","Error!",reason)        
    
    TGECall("MessageBoxOK","Error!",reason.getErrorMessage())        

    
def OnPatchLogin():
    if PATCH_CODE:
        regkey = TGEObject("MASTERLOGIN_PUBLICNAME").getValue()
        password = TGEObject("MASTERLOGIN_PASSWORD").getValue()
    else:
        regkey = TGEObject("PATCHLOGIN_PUBLICNAME").getValue()
        password = TGEObject("PATCHLOGIN_PASSWORD").getValue()

    TGESetGlobal("$pref::PublicName",regkey)
    TGESetGlobal("$pref::MasterPassword",password)
                    
    if not len(regkey) or not len(password):
        TGECall("MessageBoxOK","Error","Invalid username or password.")                
        return
    
    TGEObject("PATCHLOGIN_PUBLICNAME").setText(regkey)
    TGEObject("PATCHLOGIN_PASSWORD").setText(password)
    TGEObject("MASTERLOGIN_PUBLICNAME").setText(regkey)
    TGEObject("MASTERLOGIN_PASSWORD").setText(password)



    #todo, validate email form
    masterIP = TGEGetGlobal("$Py::MasterIP")
    masterPort = int(TGEGetGlobal("$Py::MasterPort"))
    
    TGECall("MessagePopup","Logging into Master Server...","Please wait...")
    
    factory = pb.PBClientFactory()
    reactor.connectTCP(masterIP,masterPort,factory)
    password = md5(password).digest()

    factory.login(UsernamePassword("%s-Player"%regkey, password),pb.Root()).addCallbacks(PatchLoginConnected, Failure)


def OnPatch():
    global PATCH_CODE
    PATCH_CODE = 0
    
    SetupPatchInfo(RPG_BUILD_DEMO)
    
    if main_is_frozen():
        if not RPG_BUILD_DEMO:
            TGEEval('canvas.pushDialog("PatchLoginDlg");')
        else:
            Patch()

def OnMultiplayer():
    TGEEval('canvas.pushDialog("MasterLoginDlg");')
    
def OnMasterLogin():
    
    global PATCH_CODE
    PATCH_CODE = 1
    
    SetupPatchInfo(RPG_BUILD_DEMO)
        
    if main_is_frozen():
        if RPG_BUILD_DEMO:
            if not HAVE_PATCHED:
                regkey = TGEObject("MASTERLOGIN_PUBLICNAME").getValue()
                password = TGEObject("MASTERLOGIN_PASSWORD").getValue()
                
                if not len(regkey) or not len(password):
                    TGEEval("Canvas.setContent(MainMenuGui);")
                    TGECall("MessageBoxOK","Error","Invalid username or password.")                
                    return

                Patch()
            else:
                DoMasterLogin()
        else:
            if not HAVE_PATCHED:
                OnPatchLogin()
            else:
                DoMasterLogin()
                
    else:
        DoMasterLogin()
        

def OnPatchToPremium():
    #only happens from demo
    global HAVE_PATCHED,PATCH_CODE
    PATCH_CODE = 0
    HAVE_PATCHED = False
    
    SetupPatchInfo(False,True) #for testing we patch to live
    #TGESetGlobal("$pref::Video::fullScreen",1)
    #TGESetGlobal("$pref::Video::resolution", "1024 768 32")
    TGEEval('canvas.pushDialog("PatchLoginDlg");')
                

def PyExec():
    TGEExport(OnMultiplayer,"Py","OnMultiplayer","desc",1,1)
    TGEExport(OnPatch,"Py","OnPatch","desc",1,1)
    
    TGEExport(OnPatchRestart,"Py","OnPatchRestart","desc",1,1)
    TGEExport(OnPatchCancel,"Py","OnPatchCancel","desc",1,1)
    TGEExport(OnPatchError,"Py","OnPatchError","desc",1,1)
    
    TGEExport(OnPatchLogin,"Py","OnPatchLogin","desc",1,1)
    TGEExport(OnMasterLogin,"Py","OnMasterLogin","desc",1,1)
    
    TGEExport(DisplayPatchInfo,"Py","DisplayPatchInfo","desc",1,1)
    
    #PTP_BUTTON
    #Py::OnPatchToPremium();
    TGEExport(OnPatchToPremium,"Py","OnPatchToPremium","desc",1,1)
    if not RPG_BUILD_DEMO:
        TGEObject("PTP_BUTTON").visible = False 
    else:
        TGEObject("PTP_BUTTON").visible = True
        
        
    pname=TGEGetGlobal("$pref::PublicName")
    pw=TGEGetGlobal("$pref::MasterPassword")
    if pname == None:
        pname = ""
    if pw == None:
        pw = ""
        
        
    TGEObject("PATCHLOGIN_PUBLICNAME").setText(pname)
    TGEObject("PATCHLOGIN_PASSWORD").setText(pw)
    TGEObject("MASTERLOGIN_PUBLICNAME").setText(pname)
    TGEObject("MASTERLOGIN_PASSWORD").setText(pw)

        



 