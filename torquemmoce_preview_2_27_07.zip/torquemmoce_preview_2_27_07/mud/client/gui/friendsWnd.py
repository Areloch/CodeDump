from tgenative import *
from mud.tgepython.console import TGEExport
from mud.world.defines import *
from mud.gamesettings import *
from traceback import print_exc
from cPickle import load,dump
from time import time

#$pref::game::friendsAudioAlerts;

FRIENDS = []
FRIENDSWND = None

def ReceiveGameText(textCode,text):
    from tomeGui import TOMEGUI
    #XXX todo, filter better!
    text = text.replace('\\"',"@$#") #valid quote
    text = text.replace('"','\\"') #invalid quote
    text = text.replace('@$#','\\"') #replace valid qoutes
    TOMEGUI.receiveGameText(textCode,text)


class FriendsWnd:
    def __init__(self):
        self.addEditCtrl = TGEObject("FRIENDSWND_ADDEDIT")
        self.scrollCtrl = TGEObject("FRIENDSWND_SCROLL")
        self.textList = TGEObject("FRIENDSWND_LIST")
        self.remoteFriendsInfo = {}
        self.active = []
        self.lastSoundTime = time()-15
        
    

    def update(self,finfo=None,fromServer=False):
        try:
            global FRIENDS
            if finfo == None:
                finfo = self.remoteFriendsInfo
            else:
                self.remoteFriendsInfo = finfo
                
            playsound = False
            if fromServer:                 
                if time() - self.lastSoundTime >=15:               
                    if TGEGetGlobal("$pref::game::friendsAudioAlerts") == "1":
                        playsound = True
                        
                
            #previndex = int(self.itemList.getSelectedId())
            pos = self.scrollCtrl.childRelPos.split(" ")
            
            tc = self.textList
            tc.setVisible(False)
            tc.clear()
            i=0
            
            added = []
            for f in FRIENDS:
                if finfo.has_key(f):
                    
                    cname,wname,zname = finfo[f]
                    added.append(cname)
                    TGEEval(r'FRIENDSWND_LIST.addRow(%i,"%s" TAB "%s" TAB "%s");'%(i,cname,wname,zname))
                    
                else:                
                    TGEEval(r'FRIENDSWND_LIST.addRow(%i,"%s" TAB "Away" TAB "");'%(i,f))
                    
                    
                i+=1
                
            if fromServer:    
                for n in added:
                    if n not in self.active:
                        ReceiveGameText(RPG_MSG_GAME_LEVELGAINED,r'Your friend %s has joined the game!\n'%n)
                        if playsound:   
                            TGEEval('alxPlay(alxCreateSource(AudioMessage, "%s/data/sound/sfx/Heartbeat_Loop1.ogg"));'%GAMEROOT)
                            self.lastSoundTime = time()
    
                        
            if fromServer:
                for n in self.active:
                    if n not in added:
                        ReceiveGameText(RPG_MSG_GAME_BLUE,r'Your friend %s has left the game!\n'%n)
                        if playsound:
                            TGEEval('alxPlay(alxCreateSource(AudioMessage, "%s/data/sound/sfx/BoneTowerPercussionRattle7.ogg"));'%GAMEROOT)
                            self.lastSoundTime = time()
                    
                    
            self.active = added
    
            tc.setActive(True)
            tc.setVisible(True)
            
            self.scrollCtrl.scrollRectVisible(pos[0],pos[1],1,444)
        except:
            print_exc()
            
        
        
        
def SetFriendsInfo(finfo):
    try:
        FRIENDSWND.update(finfo,True)
    except:
        print_exc()
    
def SubmitFriendsList():
    from mud.client.playermind import PLAYERMIND
    if not PLAYERMIND or not PLAYERMIND.perspective:
        return
    try:
        PLAYERMIND.perspective.callRemote("PlayerAvatar","submitFriends",FRIENDS)
    except:
        pass
        
    FRIENDSWND.update()
    
def LoadFriendList():
    global FRIENDS
    try:
        f = file("%s/data/settings/friends.dat"%GAMEROOT,'rb')
        FRIENDS = load(f)
        f.close()
        if type(FRIENDS) != type(list()):
            FRIENDS = []        
    except:
        FRIENDS = []
        
def SaveFriendList():
    global FRIENDS
    try:
        f = file("%s/data/settings/friends.dat"%GAMEROOT,'wb')
        dump(FRIENDS,f)
        f.close()
    except:
        pass

def OnAddFriend(name=None):
    if len(FRIENDS)>=64:
        ReceiveGameText(RPG_MSG_GAME_DENIED,r'You may have up to 64 friends in your list.\n')
        return
    text = ""
    if name!=None:
        text = name
    else:
        text = FRIENDSWND.addEditCtrl.getValue()
        
    if not text or len(text)<4:
        ReceiveGameText(RPG_MSG_GAME_DENIED,r'Add friend: invalid name.\n')
        return
    
    text = text.upper()
    if text in FRIENDS:
        ReceiveGameText(RPG_MSG_GAME_DENIED,r'This friend is already in your list.\n')
        return
    
    ReceiveGameText(RPG_MSG_GAME_GAINED,r'You have added %s as a friend.  It might take a moment to refresh their status.\n'%text)
    
    FRIENDS.append(text)
    
    FRIENDS.sort()
        
    SaveFriendList()
    SubmitFriendsList()
    
    FRIENDSWND.update()
    
    
def OnRemoveFriend(name=None):
    global FRIENDS
    
    if name == None:
        if len(FRIENDS)<=0:
            return
        index = int(FRIENDSWND.textList.getSelectedId())
        if index > len(FRIENDS):
            return
        
        f = FRIENDS[index]
        if f in FRIENDS:
            FRIENDS.remove(f)
        ReceiveGameText(RPG_MSG_GAME_GAINED,r'You have removed %s from your friend list.\n'%f)
    else:
        name = name.upper()
        if name in FRIENDS:
            FRIENDS.remove(name)
            ReceiveGameText(RPG_MSG_GAME_GAINED,r'You have removed %s from your friend list.\n'%name)
        else:
            ReceiveGameText(RPG_MSG_GAME_DENIED,r'%s is not in your friend list.\n'%name)
            
            
    SaveFriendList()
    SubmitFriendsList()
    
    FRIENDSWND.update()

def PyExec():
    global FRIENDSWND
    FRIENDSWND = FriendsWnd()

    TGEExport(OnAddFriend,"Py","OnAddFriend","desc",1,1)
    TGEExport(OnRemoveFriend,"Py","OnRemoveFriend","desc",1,1)    
    
    LoadFriendList()
    
