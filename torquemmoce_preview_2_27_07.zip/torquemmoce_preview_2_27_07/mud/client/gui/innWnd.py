from tgenative import *
from mud.tgepython.console import TGEExport
from math import floor
from mud.world.defines import *
from twisted.internet import reactor
from twisted.spread import pb

INNWND = None
DARKNESS = False



class InnWnd(pb.Root):
    def __init__(self):
        self.partyListCtrl = TGEObject("INNPARTY_SCROLLLIST")
        self.charListCtrl = TGEObject("INNCHARS_SCROLLLIST")
        self.inn = None
        self.partyList = []
        self.charList = []
        
    def remote_set(self,cList,pList,darkness):
        self.partyList = pList
        self.charList = cList
        
        #PARTY LIST
        tc = self.partyListCtrl
        tc.setVisible(False)
        tc.clear()
        i=0
        for ci in pList:
            name = ci.name
            klass = ci.klasses[0]
            level = ci.levels[0]
            status = ci.status
            
            TGEEval(r'INNPARTY_SCROLLLIST.addRow(%i,"%s" TAB "%s (%i)" TAB "%s");'%(i,name,klass,level,status))
            i+=1
            
        tc.setSelectedRow(0)
        tc.scrollVisible(0)
        tc.setActive(True)
        tc.setVisible(True)

        #CHAR LIST
        tc = self.charListCtrl
        tc.setVisible(False)
        tc.clear()
        i=0
        for ci in cList:
            name = ci.name
            klass = ci.klasses[0]
            level = ci.levels[0]
            status = ci.status
            
            TGEEval(r'INNCHARS_SCROLLLIST.addRow(%i,"%s" TAB "%s (%i)" TAB "%s");'%(i,name,klass,level,status))
            i+=1
            
        tc.sort(0)
        tc.setSelectedRow(0)
        tc.scrollVisible(0)
        tc.setActive(True)
        tc.setVisible(True)
        
        
    def remote_open(self,inn,title):
        self.inn = inn
        TGEObject("INNWND_PARTYBUTTON").performClick()
        TGEObject("INNWND_Window").setText(title)
        TGEEval("canvas.pushDialog(InnWnd);")
        
        
    def remote_close(self):
        self.inn = None
        TGEEval("canvas.popDialog(InnWnd);")
    
#Py::OnInnWndClose();
#Py::OnInnAddtoParty();
#Py::OnInnRemoveFromParty();

def PyOnInnAddToParty():
    if not len(INNWND.charList) or len(INNWND.partyList)==6:
        return
    sr = int(INNWND.charListCtrl.getSelectedId())
    INNWND.inn.callRemote("addToParty",INNWND.charList[sr].name)

def PyOnInnRemoveFromParty():
    if len(INNWND.partyList) == 1:
        return
    sr = int(INNWND.partyListCtrl.getSelectedId())
    INNWND.inn.callRemote("removeFromParty",INNWND.partyList[sr].name)

def PyOnInnWndClose():
    INNWND.inn.callRemote("leaveInn")
    
    
#creation

    
"""

Py::OnInnDelete();
InnNameCtrl


Py::InnOnRaceChanged();
Py::InnOnClassChanged();
Py::InnOnSexChanged();

"""
def GotDeleteCharacterResult(result):
    TGECall("CloseMessagePopup")
    
    code = result[0]
    msg = result[1]
    
    
    if code:
        title = "Error!"
    else:
        #success
        title = "Success!"        
    
    TGECall("MessageBoxOK",title,msg)


dname = None #blah couldn't get it passed in right, deadline
def InnOnReallyDelete():
    TGECall("MessagePopup","Banishing Character...","Please wait...")
    INNWND.inn.callRemote("deleteCharacter",dname).addCallbacks(GotDeleteCharacterResult,Failure)
    
def InnOnDelete():
    global dname
    if not len(INNWND.charList):
        return
    sr = int(INNWND.charListCtrl.getSelectedId())
    name = INNWND.charList[sr].name
    dname = name
    TGEEval('MessageBoxYesNo("Banish Character?", "Do you really want to banish %s?","Py::OnInnReallyDelete();");'%(name))    

    
def Failure(reason):
    TGECall("CloseMessagePopup")
    TGECall("MessageBoxOK","Error!",reason)        




def PyInnOnParty():
    TGEObject("INNWND_PARTYPANE").visible = True
    TGEObject("INNWND_CREATIONPANE").visible = False
    

    
    

    
 
def PyExec():
    global INNWND
    INNWND = InnWnd()
    
    
    TGEExport(PyOnInnAddToParty,"Py","OnInnAddToParty","desc",1,1)
    TGEExport(PyOnInnRemoveFromParty,"Py","OnInnRemoveFromParty","desc",1,1)
    TGEExport(PyOnInnWndClose,"Py","OnInnWndClose","desc",1,1)
    
    TGEExport(PyInnOnParty,"Py","InnOnParty","desc",1,1)
    
    TGEExport(InnOnDelete,"Py","OnInnDelete","desc",1,1)
    TGEExport(InnOnReallyDelete,"Py","OnInnReallyDelete","desc",1,1)
