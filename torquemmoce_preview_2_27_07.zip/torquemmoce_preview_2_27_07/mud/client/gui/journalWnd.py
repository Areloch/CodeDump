from tgenative import *
from mud.tgepython.console import TGEExport
from mud.world.defines import *
from mud.gamesettings import *
from cPickle import load,dump
import os
from md5 import new as newMD5
from math import floor

#ADD DEFAULT JOURNAL ENTRY!!!

JOURNALWND = None
JOURNAL = {}

def CreateDefaultJournal():
    global JOURNAL
    JOURNAL = {}
    k=JOURNAL["Welcome to Minions of Mirth"]={}
    
    k["A little help please!!!!"]="""<color:BBBBFF>Click on the 'Help' button on your Tome window."""
    
    k["Getting Started"]="""<color:BBBBFF>To get started, type the 'I' key to view 
your inventory. Each character has a starting item in their inventory.  To begin your character quest, 
click the 'I' button on your tome to bring up your information window.  Move your mouse cursor 
over the first item in your inventory to find out who your trainer in Trinst is. Take this road 
into town and locate your trainer in one of the 4 guild buildings.  To toggle autorun type 'V' 
and to toggle mouse look type 'Q'\\n"""
    
    k["How do I find my trainer?"]="""<color:BBBBFF>Type 'M' to open your map.  Each player has a tracking 
range based upon their skill level.  Once your trainer is within range, you will see their name on 
your map.  All trainers can be found in one of the 4 guild buildings located in the city walls.  Make 
sure to complete the starting quest for each player in your party!\\n"""

    k["Where are the guild buildings?"]="""<color:BBBBFF>The mage's guild is in the northwest corner of 
town.  The rogue's guild is in the southwest area of town in the residential district.  The 
combatant's guild and the priest's guild are in the northeast corner near the entrance into the 
Trinst Sewers.\\n"""

    k["Where can I get a quest?"]="""<color:BBBBFF>Locate Captain Pedrail, he will have something for you to do.\\n"""
    
    k["Where can I buy supplies?"]="""<color:BBBBFF>There are several vendors inside of Trinst that sell armor, weapons, and various items.\\n"""

    

class JournalWnd:
    def __init__(self):
        self.journalScroll = TGEObject("JOURNAL_SCROLL")
        self.journalText = TGEObject("JOURNAL_TEXT")
        
        self.topicScroll = TGEObject("JOURNAL_TOPICSCROLL")
        self.topicTextList = TGEObject("JOURNAL_TOPICTEXTLIST")
        
        self.entryScroll = TGEObject("JOURNAL_ENTRYSCROLL")
        self.entryTextList = TGEObject("JOURNAL_ENTRYTEXTLIST")
        
    
    def setJournal(self):
        tc=self.entryTextList
        tc.setVisible(False)
        tc.clear()
        tc.setVisible(True)

        tc=self.topicTextList
        tc.setVisible(False)
        tc.clear()
        i=0

        for topic in JOURNAL.iterkeys():
            tc.addRow(i,topic)
            i+=1
            

        tc.sort(0) # this sorts alphabetically
        tc.setSelectedRow(0)
        tc.scrollVisible(0)
        tc.setActive(True)
        tc.setVisible(True)
        
        if not i:
            TGEEval('JOURNAL_TEXT.setText("");')
            tc=JOURNALWND.entryTextList
            tc.clear()

        
        
            
    def addEntry(self,topic,entry,text):
        global JOURNAL
        from tomeGui import TOMEGUI
        from npcWnd import NPCWND
        
        tc=self.topicTextList
        sr = int(tc.getSelectedId())
        ptopic = tc.getRowTextById(sr)
        
        tc=self.entryTextList
        sr = int(tc.getSelectedId())
        pentry = tc.getRowTextById(sr)
        
        if NPCWND.title:
            text = "<color:FFFFFF>%s: <color:BBBBFF>%s"%(NPCWND.title,text)
        else:
            text = "<color:BBBBFF>%s"%text
            
        
        t = JOURNAL.get(topic)
        if t:
            e = t.get(entry)
            if e==text:
                return #already have it
        
        if not t:
            t = JOURNAL[topic]={}   
             
        t[entry]=text
        
        SaveJournal()
        
        self.setJournal()
        
        TOMEGUI.receiveGameText(RPG_MSG_GAME_GAINED,r'Your journal\'s \"%s\" topic has been updated with a \"%s\" entry!\n'%(topic,entry))
        eval = 'alxPlay(alxCreateSource(AudioMessage, "%s/data/sound/sfx/Pencil_WriteOnPaper2.ogg"));'%GAMEROOT
        TGEEval(eval)

        if ptopic:
            for x in xrange(0,int(JOURNALWND.topicTextList.rowCount())):
                if JOURNALWND.topicTextList.getRowText(x) == ptopic:
                    JOURNALWND.topicTextList.setSelectedRow(x)
                    break
        if pentry:
            for x in xrange(0,int(JOURNALWND.entryTextList.rowCount())):
                if JOURNALWND.entryTextList.getRowText(x) == pentry:
                    JOURNALWND.entryTextList.setSelectedRow(x)
                    break
    

def SaveJournal():
    global JOURNAL
    
    worldname = TGEGetGlobal("$Py::WORLDNAME")
    #aren't we clever... this nukes any undesireably characters :)
    wdirname = newMD5(worldname).hexdigest()

    single = int(TGEGetGlobal("$Py::ISSINGLEPLAYER"))
    if single:
        gdirname = "single"
    else:
        gdirname = "multiplayer"
        
    dirname = "%s/data/settings/%s/%s"%(GAMEROOT,gdirname,wdirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
        
    filename = "%s/journal.dat"%dirname
    if int(TGEGetGlobal("$Py::REALM")) == RPG_REALM_DARKNESS:
        filename = "%s/journal_dark.dat"%dirname
    if int(TGEGetGlobal("$Py::REALM")) == RPG_REALM_MONSTER:
        filename = "%s/journal_monster.dat"%dirname

    
    f = file(filename,'wb')
    dump(JOURNAL,f)
    f.close()
    
    
    
def LoadJournal():
    global JOURNAL
    
    worldname = TGEGetGlobal("$Py::WORLDNAME")
    #aren't we clever... this nukes any undesireably characters :)
    wdirname = newMD5(worldname).hexdigest()

    single = int(TGEGetGlobal("$Py::ISSINGLEPLAYER"))
    if single:
        gdirname = "single"
    else:
        gdirname = "multiplayer"
        
    dirname = "%s/data/settings/%s/%s"%(GAMEROOT,gdirname,wdirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
        
    filename = "%s/journal.dat"%dirname
    
    if int(TGEGetGlobal("$Py::REALM")) == RPG_REALM_DARKNESS:
        filename = "%s/journal_dark.dat"%dirname
        
    if int(TGEGetGlobal("$Py::REALM")) == RPG_REALM_MONSTER:
        filename = "%s/journal_monster.dat"%dirname

        
        
    try:
        f = file(filename,'rb')
        JOURNAL = load(f)
        f.close()
    except:
        CreateDefaultJournal()
        SaveJournal()
        
        
    JOURNALWND.setJournal()
        



def OnJournalTopic():
    #get topic
    tc=JOURNALWND.topicTextList
    sr = int(tc.getSelectedId())
    topic = tc.getRowTextById(sr)
    
    #setup entry list
    tc=JOURNALWND.entryTextList
    tc.setVisible(False)
    tc.clear()
    i=0

    for entry in JOURNAL[topic].iterkeys():
        tc.addRow(i,entry)
        i+=1
        

    tc.sort(0) # this sorts alphabetically
    tc.setSelectedRow(0)
    tc.scrollVisible(0)
    tc.setActive(True)
    tc.setVisible(True)
    
    if not i:
        TGEEval('JOURNAL_TEXT.setText("");')
        tc=JOURNALWND.entryTextList
        tc.clear()
        
    
    
    
def OnJournalEntry():
    #get topic
    tc=JOURNALWND.entryTextList
    sr = int(tc.getSelectedId())
    entry = tc.getRowTextById(sr)
  
    tc=JOURNALWND.topicTextList
    sr = int(tc.getSelectedId())
    topic = tc.getRowTextById(sr)
    
    
    
    
    try:
        fontsize = int(floor(float(TGEGetGlobal("$pref::Game::ChatFontSize"))))
        fontsize+=3
        
    except:
        fontsize = 13
        
    if fontsize < 13:
        fontsize = 13
    if fontsize > 23:
        fontsize = 23
    
    if not JOURNAL.get(topic) or not JOURNAL[topic].get(entry):
        eval = 'JOURNAL_TEXT.setText("");'
    else:
        eval = 'JOURNAL_TEXT.setText("<font:Arial:%i><shadowcolor:000000><shadow:1:1>%s");'%(fontsize,JOURNAL[topic][entry])
        eval = eval.replace("\n","")
    TGEEval(eval)
    
    

def OnJournalClearTopic():
    tc=JOURNALWND.topicTextList
    sr = int(tc.getSelectedId())
    topic = tc.getRowTextById(sr)
    if JOURNAL.has_key(topic):
        del JOURNAL[topic]
        SaveJournal()
        JOURNALWND.setJournal()

def OnJournalClearEntry():
    
    tc=JOURNALWND.topicTextList
    sr = int(tc.getSelectedId())
    topic = tc.getRowTextById(sr)
    
    tc=JOURNALWND.entryTextList
    sr = int(tc.getSelectedId())
    entry = tc.getRowTextById(sr)
    
    t = JOURNAL.get(topic)
    if t:
        if t.has_key(entry):
            del t[entry]
            
            if not len(t):
                OnJournalClearTopic()
            else:
                SaveJournal()
                JOURNALWND.setJournal()
                
    for x in xrange(0,int(JOURNALWND.topicTextList.rowCount())):
        if JOURNALWND.topicTextList.getRowText(x) == topic:
            JOURNALWND.topicTextList.setSelectedRow(x)
            break
            
                
    
                
            
            

        
def PyExec():
    global JOURNALWND
    JOURNALWND = JournalWnd()
    
    TGEExport(OnJournalTopic,"Py","OnJournalTopic","desc",1,1)
    TGEExport(OnJournalEntry,"Py","OnJournalEntry","desc",1,1)
    TGEExport(OnJournalClearTopic,"Py","OnJournalClearTopic","desc",1,1)
    TGEExport(OnJournalClearEntry,"Py","OnJournalClearEntry","desc",1,1)
    
    