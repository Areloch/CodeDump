from tgenative import *
from mud.tgepython.console import TGEExport


INVALID = [
"mouse2"
]

def KeyCanBeRemapped(args):
    key = args[1]
    if key in INVALID:
        return 0
    return 1

def SetGameDifficulty():
    from mud.world.core import CoreSettings
    v = int(TGEGetGlobal("$pref::gameplay::difficulty"))
    
    if v==1:
        CoreSettings.DIFFICULTY = 0
    elif v ==2:
        CoreSettings.DIFFICULTY = 2
    else:
        CoreSettings.DIFFICULTY = 1
    
    
    
def OnRespawnTime():
    value = float(TGEGetGlobal("$pref::gameplay::monsterrespawn"))
    
    from mud.world.core import CoreSettings
    CoreSettings.RESPAWNTIME = value
    

def PyExec():
    TGEExport(KeyCanBeRemapped,"Py","KeyCanBeRemapped","desc",2,2)
    TGEExport(OnRespawnTime,"Py","OnRespawnTimeChanged","desc",1,1)
    TGEExport(SetGameDifficulty,"Py","SetGameDifficulty","desc",1,1)
