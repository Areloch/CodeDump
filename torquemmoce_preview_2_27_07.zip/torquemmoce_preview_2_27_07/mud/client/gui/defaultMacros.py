
from tgenative import *
from macro import Macro
from defaultCommandsWnd import GetDefaultCommand
from copy import copy
from cPickle import dump
from md5 import new as newMD5
import os
from mud.gamesettings import *


def SaveDefaultMacros(cname,macros):
    worldname = TGEGetGlobal("$Py::WORLDNAME")
    #aren't we clever... this nukes any undesireably characters :)
    wdirname = newMD5(worldname).hexdigest()
    
    single = int(TGEGetGlobal("$Py::ISSINGLEPLAYER"))
    if single:
        gdirname = "single"
    else:
        gdirname = "multiplayer"
        
    dirname = "%s/data/settings/%s/%s"%(GAMEROOT,gdirname,wdirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)

    save = {}
    
    y = 0
    for macro in macros:
        d = copy(macro.__dict__)
        del d['controls']
        del d['enabled'] #todo
        save[y]=d
        y+=1
    
    clientSettings = {}
    clientSettings['LINKMOUSETARGET'] = 1
    clientSettings['LINKTARGET'] = None
    clientSettings['DEFAULTTARGET'] = None
    clientSettings['PXPGAIN'] = 1
    clientSettings['SXPGAIN'] = 0
    clientSettings['TXPGAIN'] = 0        

    save['CLIENTSETTINGS']=clientSettings
    
    filename = "%s/%s_macros.dat"%(dirname,cname)
    f = file(filename,'wb')
    dump(save,f)
    f.close()
    
def Warrior(cinfo):
    
    macros = []
    
    m = Macro()
    m.defaultCommand = GetDefaultCommand("Attack")
    m.index = 0
    m.hotKey = "1"
    macros.append(m)
    
    m = Macro()
    m.skill = "Kick"
    m.index = 1
    m.hotKey = "2"
    macros.append(m)

    
    SaveDefaultMacros(cinfo.NAME,macros)

def Ranger(cinfo):
    
    macros = []
    
    m = Macro()
    m.defaultCommand = GetDefaultCommand("Attack")
    m.index = 0
    m.hotKey = "1"
    macros.append(m)
    
    m = Macro()
    m.defaultCommand = GetDefaultCommand("Ranged Attack")
    m.index = 1
    m.hotKey = "2"
    macros.append(m)
    
    m = Macro()
    m.skill = "Kick"
    m.index = 2
    m.hotKey = "3"
    macros.append(m)

    
    SaveDefaultMacros(cinfo.NAME,macros)
    
    

def Bard(cinfo):
    
    macros = []
    
    m = Macro()
    m.defaultCommand = GetDefaultCommand("Attack")
    m.index = 0
    m.hotKey = "1"
    macros.append(m)
    
    m = Macro()
    m.skill = "Kick"
    m.index = 1
    m.hotKey = "2"
    macros.append(m)

    m = Macro()
    m.defaultCommand = GetDefaultCommand("Stop Cast")
    m.index = 2
    m.hotKey = "3"
    macros.append(m)

    
    SaveDefaultMacros(cinfo.NAME,macros)
    
def Barbarian(cinfo):
    
    macros = []
    
    m = Macro()
    m.defaultCommand = GetDefaultCommand("Attack")
    m.index = 0
    m.hotKey = "1"
    macros.append(m)
    
    m = Macro()
    m.skill = "Kick"
    m.index = 1
    m.hotKey = "2"
    macros.append(m)



    
    SaveDefaultMacros(cinfo.NAME,macros)
    
def Paladin(cinfo):
    
    macros = []
    
    m = Macro()
    m.defaultCommand = GetDefaultCommand("Attack")
    m.index = 0
    m.hotKey = "1"
    macros.append(m)
    
    m = Macro()
    m.skill = "Kick"
    m.index = 1
    m.hotKey = "2"
    macros.append(m)

    
    SaveDefaultMacros(cinfo.NAME,macros)


def Tempest(cinfo):
    
    macros = []
    
    m = Macro()
    m.defaultCommand = GetDefaultCommand("Attack")
    m.index = 0
    m.hotKey = "1"
    macros.append(m)

    m = Macro()
    m.defaultCommand = GetDefaultCommand("Stop Cast")
    m.index = 1
    m.hotKey = "2"
    macros.append(m)
    
    SaveDefaultMacros(cinfo.NAME,macros)
    
def Wizard(cinfo):
    
    macros = []
    
    m = Macro()
    m.defaultCommand = GetDefaultCommand("Attack")
    m.index = 0
    m.hotKey = "1"
    macros.append(m)

    m = Macro()
    m.defaultCommand = GetDefaultCommand("Stop Cast")
    m.index = 1
    m.hotKey = "2"
    macros.append(m)
    
    SaveDefaultMacros(cinfo.NAME,macros)

def Revealer(cinfo):
    
    macros = []
    
    m = Macro()
    m.defaultCommand = GetDefaultCommand("Attack")
    m.index = 0
    m.hotKey = "1"
    macros.append(m)

    m = Macro()
    m.defaultCommand = GetDefaultCommand("Stop Cast")
    m.index = 1
    m.hotKey = "2"
    macros.append(m)
    
    SaveDefaultMacros(cinfo.NAME,macros)


def Thief(cinfo):
    
    macros = []
    
    m = Macro()
    m.defaultCommand = GetDefaultCommand("Attack")
    m.index = 0
    m.hotKey = "1"
    macros.append(m)
    
    SaveDefaultMacros(cinfo.NAME,macros)

def Doom_Knight(cinfo):
    
    macros = []
    
    m = Macro()
    m.defaultCommand = GetDefaultCommand("Attack")
    m.index = 0
    m.hotKey = "1"
    macros.append(m)
    
    m = Macro()
    m.skill = "Kick"
    m.index = 1
    m.hotKey = "2"
    macros.append(m)

    m = Macro()
    m.defaultCommand = GetDefaultCommand("Stop Cast")
    m.index = 2
    m.hotKey = "3"
    macros.append(m)

    
    SaveDefaultMacros(cinfo.NAME,macros)

def Assassin(cinfo):
    
    macros = []
    
    m = Macro()
    m.defaultCommand = GetDefaultCommand("Attack")
    m.index = 0
    m.hotKey = "1"
    macros.append(m)
    
    SaveDefaultMacros(cinfo.NAME,macros)

def Shaman(cinfo):
    
    macros = []
    
    m = Macro()
    m.defaultCommand = GetDefaultCommand("Attack")
    m.index = 0
    m.hotKey = "1"
    macros.append(m)
    
    m = Macro()
    m.defaultCommand = GetDefaultCommand("Stop Cast")
    m.index = 1
    m.hotKey = "2"
    macros.append(m)

    
    SaveDefaultMacros(cinfo.NAME,macros)

def Druid(cinfo):
    
    macros = []
    
    m = Macro()
    m.defaultCommand = GetDefaultCommand("Attack")
    m.index = 0
    m.hotKey = "1"
    macros.append(m)
    
    m = Macro()
    m.defaultCommand = GetDefaultCommand("Stop Cast")
    m.index = 1
    m.hotKey = "2"
    macros.append(m)

    
    SaveDefaultMacros(cinfo.NAME,macros)


def Cleric(cinfo):
    
    macros = []
    
    m = Macro()
    m.defaultCommand = GetDefaultCommand("Attack")
    m.index = 0
    m.hotKey = "1"
    macros.append(m)
    
    
    m = Macro()
    m.defaultCommand = GetDefaultCommand("Stop Cast")
    m.index = 1
    m.hotKey = "2"
    macros.append(m)

    SaveDefaultMacros(cinfo.NAME,macros)

def Monk(cinfo):
    
    macros = []
    
    m = Macro()
    m.defaultCommand = GetDefaultCommand("Attack")
    m.index = 0
    m.hotKey = "1"
    macros.append(m)
    
    m = Macro()
    m.skill = "Kick"
    m.index = 1
    m.hotKey = "2"
    macros.append(m)

    
    SaveDefaultMacros(cinfo.NAME,macros)

    
def Necromancer(cinfo):
    
    macros = []
    
    m = Macro()
    m.defaultCommand = GetDefaultCommand("Attack")
    m.index = 0
    m.hotKey = "1"
    macros.append(m)
    
    m = Macro()
    m.defaultCommand = GetDefaultCommand("Stop Cast")
    m.index = 1
    m.hotKey = "2"
    macros.append(m)


    m = Macro()
    m.defaultCommand = GetDefaultCommand("PetAtk")
    m.index = 2
    m.hotKey = "3"
    macros.append(m)

    m = Macro()
    m.defaultCommand = GetDefaultCommand("PetSd")
    m.index = 3
    m.hotKey = "4"
    macros.append(m)

    m = Macro()
    m.defaultCommand = GetDefaultCommand("PetFlw")
    m.index = 4
    m.hotKey = "5"
    macros.append(m)

    m = Macro()
    m.defaultCommand = GetDefaultCommand("PetStay")
    m.index = 5
    m.hotKey = "6"
    macros.append(m)
    
    m = Macro()
    m.defaultCommand = GetDefaultCommand("PetDis")
    m.index = 6
    m.hotKey = "7"
    macros.append(m)

    SaveDefaultMacros(cinfo.NAME,macros)

   
CLASSES = {}
CLASSES['Warrior']=Warrior 
CLASSES['Monk']=Monk
CLASSES['Ranger']=Ranger
CLASSES['Paladin']=Paladin
CLASSES['Barbarian']=Barbarian

CLASSES['Necromancer']=Necromancer 
CLASSES['Revealer']=Revealer
CLASSES['Wizard']=Wizard

CLASSES['Cleric']=Cleric
CLASSES['Tempest']=Tempest
CLASSES['Shaman']=Shaman
CLASSES['Druid']=Druid

CLASSES['Bard']=Bard
CLASSES['Thief']=Thief
CLASSES['Assassin']=Assassin
CLASSES['Doom Knight']=Doom_Knight

def CreateDefaultMacros(cinfo):
    if CLASSES.has_key(cinfo.PCLASS):
        CLASSES[cinfo.PCLASS](cinfo)
    
    