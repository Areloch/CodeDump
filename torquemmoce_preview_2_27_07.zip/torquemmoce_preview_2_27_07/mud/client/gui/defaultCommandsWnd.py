
from tgenative import *
from mud.tgepython.console import TGEExport

#Py::OnDefaultCommand(0)
#Py::OnDefaultCommandNext()
#Py::OnDefaultCommandPrev()

class DefaultCommand:
    def __init__(self,name,tooltip,makeCommand = "",breakCommand=None,clientCommand = False, icon = ""):
        self.name = name
        self.makeCommand = makeCommand
        self.breakCommand = breakCommand
        self.clientCommand = clientCommand
        self.icon = icon
        self.tooltip = tooltip
        
DEFAULTCOMMANDS = {}
DEFAULTCOMMANDS['Attack']=DefaultCommand('Attack','Toggles Auto-Attack on and off','/attack toggle',None,False,"standardmeleeupgrade")
DEFAULTCOMMANDS['PetAtk']=DefaultCommand('PetAtk','Order your pet to attack','/pet attack',None)
DEFAULTCOMMANDS['PetSd']=DefaultCommand('PetSd','Order your pet to stand down','/pet standdown',None)
DEFAULTCOMMANDS['PetFlw']=DefaultCommand('PetFlw','Order your pet to follow you','/pet followme',None)
DEFAULTCOMMANDS['PetStay']=DefaultCommand('PetStay','Order your pet to stay','/pet stay',None)
DEFAULTCOMMANDS['PetDis']=DefaultCommand('PetDis','Dismiss your pet','/pet dismiss',None)
DEFAULTCOMMANDS['Stop Cast']=DefaultCommand('Stop Cast','Stop casting your current spell','/stopcast',None,False,"SPELLICON_3_17")
DEFAULTCOMMANDS['Ranged Attack']=DefaultCommand('Ranged Attack','Perform a ranged attack','/rangedattack',None,False,"SPELLICON_4_19")

DEFAULTCOMMANDS = [DEFAULTCOMMANDS[k] for k in sorted(DEFAULTCOMMANDS.iterkeys())]

def GetDefaultCommand(cmd):
    for c in DEFAULTCOMMANDS:
        if cmd == c.name:
            return c
            
    return None

DEFAULTCOMMANDWND = None

class DefaultCommandWnd:
    def __init__(self):
        self.currentPage = 0
        self.commandButtons = {}
        for x in xrange(0,10):
            butt = TGEObject("DefaultCommand%i"%x)
            self.commandButtons[x]=butt
            butt.visible = False
            
        self.setPage(self.currentPage)
        
    def setPage(self,page):
        self.currentPage = page
        for x in xrange(0,10):
            dcindex = x + page*10
            if dcindex < len(DEFAULTCOMMANDS):
                dc = DEFAULTCOMMANDS[dcindex]
                if dc.icon:
                    if dc.icon.startswith("SPELLICON_"):
                        split = dc.icon.split("_")
                        index=int(split[2])
                        u0=(float(index%6)*40.0)/256.0
                        v0=(float(index/6)*40.0)/256.0
                        u1=(40.0/256.0)
                        v1=(40.0/256.0)
                        
                        self.commandButtons[x].setBitmapUV("~/data/ui/icons/spells0%s"%split[1],u0,v0,u1,v1)
                    else:
                        self.commandButtons[x].setBitmap("~/data/ui/icons/%s"%dc.icon)
                    self.commandButtons[x].setText("")
                    self.commandButtons[x].tooltip = dc.tooltip
                else:                    
                    self.commandButtons[x].setText(dc.name)
                    self.commandButtons[x].tooltip = dc.tooltip
                self.commandButtons[x].visible = True
            else:
                self.commandButtons[x].visible=False
                

from macro import SetCursorMacro
def OnDefaultCommand(args):
    index = int(args[1])
    dcindex =  DEFAULTCOMMANDWND.currentPage*10+index
    if dcindex < len(DEFAULTCOMMANDS):
        button = DEFAULTCOMMANDWND.commandButtons[index]
        SetCursorMacro("CMD",DEFAULTCOMMANDS[dcindex],button)

    
def OnDefaultCommandPrev():
    pass

def OnDefaultCommandNext():
    pass

def PyExec():
    global DEFAULTCOMMANDWND
    DEFAULTCOMMANDWND = DefaultCommandWnd()
    TGEExport(OnDefaultCommand,"Py","OnDefaultCommand","desc",2,2)
    TGEExport(OnDefaultCommandNext,"Py","OnDefaultCommandNext","desc",1,1)
    TGEExport(OnDefaultCommandPrev,"Py","OnDefaultCommandPrev","desc",1,1)
    