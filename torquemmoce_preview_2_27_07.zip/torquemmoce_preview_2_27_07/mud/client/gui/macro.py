#MAGICALLY HACKILICOUS!

from tgenative import *
from mud.tgepython.console import TGEExport
from mud.client.playermind import PyDoCommand
from clientcommands import DoClientCommand
from copy import copy
from cPickle import load,dump
from md5 import new as newMD5
import os
from mud.world.defines import *
from mud.gamesettings import *
from traceback import print_exc,print_stack
from time import time
from twisted.internet import reactor
from journalWnd import LoadJournal
from defaultCommandsWnd import GetDefaultCommand
from skillinfo import GetSkillInfo
from customMacroWnd import OpenMacroEditor

WINDOW_DAT_VERSION = 2

DEFAULT_WINDOW_POSITIONS ={
    'PARTYWND_WINDOW':'671 0',
    'CHARMINIWND_WINDOW':'0 0',
    'MACROWND_WINDOW':'302 580',
    'TOMEGUI_WINDOW':'340 0',
    'CHATGUI_WINDOW':'732 580',
    'GAMETEXTGUI_WINDOW':'0 580',
    'ITEMINFOWND_WINDOW':'352 158',
    'DEFAULTCOMMANDSWND_WINDOW':'464 196',
    'NPCWND_WINDOW':'119 79',
    'GAMEOPTIONSWND_WINDOW':'434 302',
    'ALLIANCEWND_WINDOW':'456 0',
    'LEADERWND_WINDOW':'192 232',
    'TRACKINGWND_WINDOW':'370 282',
    'MAPWND_WINDOW':'0 0',
    'HELPWND_WINDOW':'337 180',
    'JOURNALWND_WINDOW':'337 180',
    'PETWND_WINDOW':'337 180',
    'BUFFWND_WINDOW':'903 0',
    'VAULTWND_WINDOW':'541 170',
    'FRIENDSWND_WINDOW':'309 77'
}

def CreateDefaultWindowSettings():

    #defaults at 1024x768
    pos = DEFAULT_WINDOW_POSITIONS
    active = {
    'PARTYWND_WINDOW':0,
    'CHARMINIWND_WINDOW':1,
    'MACROWND_WINDOW':1,
    'TOMEGUI_WINDOW':1,
    'CHATGUI_WINDOW':1,
    'GAMETEXTGUI_WINDOW':1,
    'ITEMINFOWND_WINDOW':0,
    'DEFAULTCOMMANDSWND_WINDOW':0,
    #'NPCWND_WINDOW':0,
    #'GAMEOPTIONSWND_WINDOW':0,
    'ALLIANCEWND_WINDOW':0,
    'LEADERWND_WINDOW':0,
    'TRACKINGWND_WINDOW':0,
    'MAPWND_WINDOW':0,
    'HELPWND_WINDOW':0,
    'JOURNALWND_WINDOW':0,
    'BUFFWND_WINDOW':0,
    'FRIENDSWND_WINDOW':0
    }
    extents = {
    #'TOMEGUI_WINDOW':'353 375',
    'MAPWND_WINDOW':'300 325',
    'CHATGUI_WINDOW':'292 188',
    'GAMETEXTGUI_WINDOW':'292 188'
    }
    
    
    dirname = "%s/data/settings"%GAMEROOT
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    
    ws = {}
    ws["POS"]=pos
    ws["ACTIVE"]=active
    ws["EXTENTS"]=extents
    ws["VERSION"]=WINDOW_DAT_VERSION
    f = file("%s/data/settings/windows.dat"%GAMEROOT,'wb')
    dump(ws,f)
    f.close()


def CheckWindowPositions():
    res = TGECall("getRes").split(" ")
    sw = int(res[0])
    sh = int(res[1])

    windows = [
    'PARTYWND_WINDOW',
    'CHARMINIWND_WINDOW',
    'MACROWND_WINDOW',
    'TOMEGUI_WINDOW',
    'CHATGUI_WINDOW',
    'GAMETEXTGUI_WINDOW',
    'ITEMINFOWND_WINDOW',
    'DEFAULTCOMMANDSWND_WINDOW',
    'NPCWND_WINDOW',
    'GAMEOPTIONSWND_WINDOW',
    'ALLIANCEWND_WINDOW',
    'LEADERWND_WINDOW',
    'TRACKINGWND_WINDOW',
    'MAPWND_WINDOW',
    'HELPWND_WINDOW',
    'JOURNALWND_WINDOW',
    'PETWND_WINDOW',
    'BUFFWND_WINDOW',
    'VAULTWND_WINDOW',
    'FRIENDSWND_WINDOW'
    ]
    
    for window in windows:
        w = TGEObject(window)
        px,py = w.position.split(" ")
        width,height = w.extent.split(" ")
        px = int(px)
        py = int(py)
        width = int(width)
        height = int(height)
        
        if px+width > sw+5 or py+height>sh+5:
            w.position = DEFAULT_WINDOW_POSITIONS[window]
    

FIRSTTIME = True
def LoadWindowSettings():
    global FIRSTTIME
    filename = "%s/data/settings/windows.dat"%GAMEROOT
    try:
        f = file(filename,'rb')
        ws = load(f)
        f.close()
        if ws['VERSION']!=WINDOW_DAT_VERSION:
            raise "oldversion"
    except:
        try:
            CreateDefaultWindowSettings()
            f = file(filename,'rb')
            ws = load(f)
            f.close()
        except:
            print_exc()
            return

        
        
    try: 
        pos = ws['POS']
        active = ws['ACTIVE']
        extents = ws.get("EXTENTS")
        
        for window,position in pos.iteritems():
            try:
                w = TGEObject(window)
            except:
                continue

            if extents and extents.has_key(window):
                hm = pos[window]+" "+extents[window]
                hm = hm.split(" ")
                w.resize(hm[0],hm[1],hm[2],hm[3])
            else:
                w.position = pos[window]
            
        
        for window,active in active.iteritems():
            try:
                w = TGEObject(window)
            except:
                continue
            if active:
                eval = """
                canvas.pushDialog(%s);
                """%window[:-7]
                TGEEval(eval)
    except:
        print_exc()
        
        
    #try:
    #    if FIRSTTIME:
    #        if int(TGEGetGlobal("$Py::ISSINGLEPLAYER")):
    #            TGEEval("Canvas.pushDialog(SPGlobalChatGui);")
    #            TGEObject("SPGCUSERTEXT").makeFirstResponder(True)
        
    #except:
    #    pass
    
    FIRSTTIME = False
    
    CheckWindowPositions()
        
def SaveWindowSettings():

#add to check position call if you add here    
    windows = [
    'PARTYWND_WINDOW',
    'CHARMINIWND_WINDOW',
    'MACROWND_WINDOW',
    'TOMEGUI_WINDOW',
    'CHATGUI_WINDOW',
    'GAMETEXTGUI_WINDOW',
    'ITEMINFOWND_WINDOW',
    'DEFAULTCOMMANDSWND_WINDOW',
    'NPCWND_WINDOW',
    'GAMEOPTIONSWND_WINDOW',
    'ALLIANCEWND_WINDOW',
    'LEADERWND_WINDOW',
    'TRACKINGWND_WINDOW',
    'MAPWND_WINDOW',
    'HELPWND_WINDOW',
    'JOURNALWND_WINDOW',
    'PETWND_WINDOW',
    'BUFFWND_WINDOW',
    'VAULTWND_WINDOW',
    'FRIENDSWND_WINDOW'
    ]

    awindows = [
    'PARTYWND_WINDOW',
    'CHARMINIWND_WINDOW',
    'MACROWND_WINDOW',
    'TOMEGUI_WINDOW',
    'CHATGUI_WINDOW',
    'GAMETEXTGUI_WINDOW',
    'ITEMINFOWND_WINDOW',
    'DEFAULTCOMMANDSWND_WINDOW',
    #'NPCWND_WINDOW',
    #'GAMEOPTIONSWND_WINDOW',
    'ALLIANCEWND_WINDOW',
    'LEADERWND_WINDOW',
    'TRACKINGWND_WINDOW',
    'MAPWND_WINDOW',
    'HELPWND_WINDOW',
    'JOURNALWND_WINDOW',
    'BUFFWND_WINDOW',
    'FRIENDSWND_WINDOW'
    ]
    
    ewindows = [
    #'TOMEGUI_WINDOW',
    'MAPWND_WINDOW',
    'CHATGUI_WINDOW',
    'GAMETEXTGUI_WINDOW'

    ]
    
    ws = {}
    
    pos = {}
    active = {}
    extents = {}
    
    for w in windows:
        pos[w]=TGEObject(w).position
    for w in awindows:
        active[w]=int(TGEObject(w).isAwake())
    for w in ewindows:
        extents[w]=TGEObject(w).extent
    
    ws["POS"]=pos
    ws["ACTIVE"]=active
    ws["EXTENTS"]=extents
    ws["VERSION"]=WINDOW_DAT_VERSION
    
    f = file("%s/data/settings/windows.dat"%GAMEROOT,'wb')
    dump(ws,f)
    f.close()
    
    

CHARMACROS = {}
CURSORMACROTYPE = None
CURSORMACROINFO = None
CURSORMACROCINDEX = -1

def SaveMacros():
    from partyWnd import PARTYWND
    worldname = TGEGetGlobal("$Py::WORLDNAME")
    #aren't we clever... this nukes any undesireably characters :)
    wdirname = newMD5(worldname).hexdigest()
    
    single = int(TGEGetGlobal("$Py::ISSINGLEPLAYER"))
    if single:
        gdirname = "single"
    else:
        gdirname = "multiplayer"
        
    dirname = "%s/data/settings/%s/%s"%(GAMEROOT,gdirname,wdirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    
    cinfos = PARTYWND.charInfos
    for x,cinfo in cinfos.iteritems():
        save = {}
        for y,macro in CHARMACROS[x].iteritems():
            d = copy(macro.__dict__)
            del d['controls']
            del d['enabled'] #todo
            del d['disableTime'] #todo
            del d['invID'] 
            try:
                del d['customGenerator']
            except:
                pass
            if macro.customMacro:
                cm = {}
                cm['name']=macro.customMacro.name
                cm['icon']=macro.customMacro.icon
                cm['lines']=macro.customMacro.lines
                cm['delays']=macro.customMacro.delays
                d['customMacro']=cm
            else:
                d['customMacro']=None
                
            save[y]=d
        save['CLIENTSETTINGS']=cinfo.clientSettings
        
        f = file("%s/%s_macros.dat"%(dirname,cinfo.NAME),'wb')
        dump(save,f)
        f.close()


def LoadMacros():
    global CHARMACROS
    from partyWnd import PARTYWND
    
    try:
        #we'll stuff this here
        LoadJournal()
    except:
        print_exc()
            
    CHARMACROS = {}
    
    
    worldname = TGEGetGlobal("$Py::WORLDNAME")
    #aren't we clever... this nukes any undesireably characters :)
    wdirname = newMD5(worldname).hexdigest()

    single = int(TGEGetGlobal("$Py::ISSINGLEPLAYER"))
    if single:
        gdirname = "single"
    else:
        gdirname = "multiplayer"
        
    dirname = "%s/data/settings/%s/%s"%(GAMEROOT,gdirname,wdirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    
    cinfos = PARTYWND.charInfos
    for x,cinfo in cinfos.iteritems():
        CHARMACROS[x] = {}
        
        filename = "%s/%s_macros.dat"%(dirname,cinfo.NAME)
        
        if not os.path.exists(filename):
            from defaultMacros import CreateDefaultMacros
            CreateDefaultMacros(cinfo)
        try:
            f = file(filename,'rb')
            m = load(f)
            f.close()
            cinfo.clientSettings = m['CLIENTSETTINGS']
            
            del m['CLIENTSETTINGS']
            
            for y,mm in m.iteritems():
                macro=CHARMACROS[x][y]=Macro()
                
                for k,v in mm.iteritems():
                    if k == 'invID':
                        continue #old
                    elif k == "defaultCommand":
                        if v:
                            v = GetDefaultCommand(v.name) #in case anything changed
                    elif k == 'customMacro':
                        if v:
                            cm = CustomMacro()
                            cm.name = v['name']
                            cm.icon = v['icon']
                            cm.lines = v['lines']
                            cm.delays = v['delays']
                            #tricky!
                            v = cm
                            
                            cm.parseSkillsAndSpells()

                    setattr(macro,k,v)            
                
                #overwrite
                macro.cindex=x
        except:
            print_exc()
            CHARMACROS[x]={}




def EnableAllItemMacros(cindex):
    for macro in CHARMACROS[cindex].itervalues():
        if macro.invID!=-1:
            macro.enable()


def EnableAllSkillMacros(cindex):
    for macro in CHARMACROS[cindex].itervalues():
        if macro.skill:
            macro.enable()


def EnableAllSpellMacros(cindex):
    for macro in CHARMACROS[cindex].itervalues():
        if macro.spellSlot:
            macro.enable()


def DisableAllSpellMacros(cindex):
    for macro in CHARMACROS[cindex].itervalues():
        if macro.spellSlot != None:
            macro.disable()
            
        if macro.customMacro and len(macro.customMacro.spells):
            macro.disable()



def DisableAllMacros(cindex):
    for macro in CHARMACROS[cindex].itervalues():
        macro.disable()


def EnableSkillMacro(cindex,skillname,enable):
    u = skillname.upper()
    for macro in CHARMACROS[cindex].itervalues():
        if macro.skill == skillname:
            if enable:
                macro.enable()
            else:
                macro.disable()
        
        if macro.customMacro and u in macro.customMacro.skills:
            if enable:
                macro.enable()
            else:
                macro.disable()


def SetFromCharacterInfos(cinfos):
    AttachMacroButtons()

CLEARCURSORMACRODEF = None

def ClearCursorMacro():
    global CLEARCURSORMACRODEF
    if not CLEARCURSORMACRODEF:
        print_stack()
        print "AssertionError: cursor macro has already been cleared!"
        return
    CLEARCURSORMACRODEF = None
    
    SetCursorMacro(None,None)


def SetCursorMacro(type,info,button=None,cindex = -1):
    global CURSORMACROTYPE,CURSORMACROINFO,CURSORMACROCINDEX,CLEARCURSORMACRODEF
    
    cursor = TGEObject("DefaultCursor")
    cursor.bitmapName = ""
    cursor.u0=cursor.v0 = 0
    cursor.u1=cursor.v1 = 1
    cursor.sizeX =-1
    cursor.sizeY=-1
    
    if CLEARCURSORMACRODEF:
        CLEARCURSORMACRODEF.cancel()
        CLEARCURSORMACRODEF = None
    
    if type:
        CLEARCURSORMACRODEF = reactor.callLater(14,ClearCursorMacro)
    
    CURSORMACROTYPE,CURSORMACROINFO, CURSORMACROCINDEX = type,info,cindex
    
    if button:
        TGEObject("DefaultCursor").cursorControl = button
    else:
        TGEObject("DefaultCursor").cursorControl = ""



class CustomMacro:
    def __init__(self):
        self.name = ""
        self.icon = ""
        self.lines = {}
        self.delays = {}
        
        for x in xrange(0,10):
            self.lines[x] = ""
            self.delays[x] = 0
        
        #inactive
        self.currentLine = -1
        
        self.skills = []
        self.spells = []
    
    
    def parseSkillsAndSpells(self):
        self.skills = []
        self.spells = []
        
        for line in self.lines.itervalues():
            line = line.upper()
            if line.startswith("/SKILL"):
                self.skills.append(line[7:])
            if line.startswith("/CAST"):
                self.spells.append(line[6:])
    
    
    def run(self,cindex):
        for index,command in self.lines.iteritems():
            if not command:
                continue
            
            try:
                #execute line
                mycindex = cindex
                if command[0] == "*":
                    cname,command = (command[1:]).split("* ",1)
                    from partyWnd import PARTYWND
                    for i,c in PARTYWND.charInfos.iteritems():
                        if c.NAME.upper() == cname.upper():
                            mycindex = i
                            break
                
                if len(command) and command[0]=='/':
                    PyDoCommand(['PyDoCommand',command],False,mycindex)
            except:
                from tomeGui import TOMEGUI
                print_exc()
                TOMEGUI.receiveGameText(RPG_MSG_GAME_DENIED,"Error in Custom Macro %s line %i\\n"%(self.name,index))
            
            #delay
            delay = float(self.delays[index])
            lasttime = time()
            while delay > 0:
                ctime = time()
                
                delay-=ctime-lasttime
                lasttime=ctime
                yield True
            
            yield True



class Macro:
    def __init__(self):
        self.text = ""
        self.cindex = -1
        self.controls = []
        self.commands = []
        
        self.index = -1
        self.hotKey = ""
        
        self.skill = None
        self.defaultCommand = None
        self.spellSlot = None
        self.invID = -1
        self.invSlot = -1
        
        self.customMacro = None
        self.customGenerator = None #for running custom macros
        
        self.enabled = True
        
        self.disableTime = time()
        
    def tick(self):
        if not self.customGenerator:
            return
        try:
            self.customGenerator.next()
        except StopIteration:
            self.customGenerator = None
        
        
    def setControls(self):
        from partyWnd import PARTYWND
        cinfo = PARTYWND.charInfos[self.cindex]
        for c in self.controls:
            c.index = self.index
            
            text = None
            if self.customMacro:
                
                text = self.customMacro.name
                icon = self.customMacro.icon
                
                c.tooltip = "XXX:"+text
                if icon:
            
                    if icon.startswith("SPELLICON_"):
                        split = icon.split("_")
                        index=int(split[2])
                        u0=(float(index%6)*40.0)/256.0
                        v0=(float(index/6)*40.0)/256.0
                        u1=(40.0/256.0)
                        v1=(40.0/256.0)
                        
                        c.setBitmapUV("~/data/ui/icons/spells0%s"%split[1],u0,v0,u1,v1)
                    else:
                        c.setBitmap("~/data/ui/icons/%s"%icon)

                    text = ""
                else:
                    c.SetBitmap("")
                    
                if text:
                    c.SetText(text)
                    
                else:
                    c.SetText("")
                    
                
            elif self.skill:
                sinfo = GetSkillInfo(self.skill)
                text = sinfo.name
                icon = sinfo.icon
                
                if icon:
                    if icon.startswith("SPELLICON_"):
                        split = icon.split("_")
                        index=int(split[2])
                        u0=(float(index%6)*40.0)/256.0
                        v0=(float(index/6)*40.0)/256.0
                        u1=(40.0/256.0)
                        v1=(40.0/256.0)
                        
                        c.setBitmapUV("~/data/ui/icons/spells0%s"%split[1],u0,v0,u1,v1)
                    else:
                        c.setBitmap("~/data/ui/icons/%s"%icon)
                if text:
                    c.SetText(text)
                    c.tooltip = "XXX:"+text
                
            elif self.invID != -1:
                c.SetBitmap("")
                for item in cinfo.ITEMS.itervalues():
                    if item.NAME == self.invID:
                        c.setBitmap("~/data/ui/items/"+item.BITMAP+"/0_0_0")
                        c.tooltip = "XXX:"+item.NAME
                        break
                    

            elif self.defaultCommand:
                text = str(self.defaultCommand.name)
                icon = self.defaultCommand.icon
                c.tooltip = self.defaultCommand.tooltip
                if icon:
                    if icon.startswith("SPELLICON_"):
                        split = icon.split("_")
                        index=int(split[2])
                        u0=(float(index%6)*40.0)/256.0
                        v0=(float(index/6)*40.0)/256.0
                        u1=(40.0/256.0)
                        v1=(40.0/256.0)
                        
                        c.setBitmapUV("~/data/ui/icons/spells0%s"%split[1],u0,v0,u1,v1)
                    else:
                        c.setBitmap("~/data/ui/icons/%s"%icon)

                    text = ""
                if text:
                    c.SetText(text)
                    
                    
            elif self.spellSlot != None:
                if cinfo.SPELLS.has_key(self.spellSlot):
                    sinfo = cinfo.SPELLS[self.spellSlot].SPELLINFO
                    c.tooltip = "XXX:"+sinfo.NAME
                    icon = sinfo.SPELLBOOKPIC
                    if icon.startswith("SPELLICON_"):
                        split = icon.split("_")
                        index=int(split[2])
                        u0=(float(index%6)*40.0)/256.0
                        v0=(float(index/6)*40.0)/256.0
                        u1=(40.0/256.0)
                        v1=(40.0/256.0)
                        
                        c.setBitmapUV("~/data/ui/icons/spells0%s"%split[1],u0,v0,u1,v1)
                    else:
                        c.setBitmap("~/data/ui/spellicons/%s"%icon)

                else:
                    c.SetBitmap("")
                
    
    def enable(self):
        
        if time() - self.disableTime < 3.5:
            return

        self.enabled = True
        for c in self.controls:
            c.SetValue(0)
            c.toggleLocked = False
            #c.SetActive(True)
            
            
    def disable(self):
        self.enabled = False

        for c in self.controls:
            c.SetValue(1)
            c.toggleLocked = True
            #c.SetActive(False)
            
    def activate(self,value=False):
        from partyWnd import PARTYWND
        
        if self.customGenerator:
            self.customGenerator = None
            self.enable()
            self.disableTime = time()-8
            return

        if not self.enabled:
            return
        
        cinfo = PARTYWND.charInfos[self.cindex]
        if cinfo.DEAD:
            return
        
        if self.customMacro and not self.customGenerator:
            self.customGenerator = self.customMacro.run(self.cindex)
            self.disable()
            self.disableTime = time()
            
            
        elif self.skill:
            self.disable()
            self.disableTime = time()

            PyDoCommand(['PyDoCommand','/SKILL %i %s'%(self.cindex,self.skill)],False)
            
        elif self.spellSlot != None:            
            self.disable()
            self.disableTime = time()

            PARTYWND.mind.onSpellSlot(PARTYWND.charInfos[self.cindex],self.spellSlot)
            
        elif self.invID != -1:
            cinfo = PARTYWND.charInfos[self.cindex]
            for slot,item in cinfo.ITEMS.iteritems():
                if self.invID == item.NAME:
                    PARTYWND.mind.onInvSlotUse(cinfo,slot)            
                    self.disable()
                    self.disableTime = time()
                    return
            
            
        elif self.defaultCommand:
            for c in self.controls:
                c.setValue(False)
            if self.defaultCommand.name == "Ranged Attack":
                self.disable()
                self.disableTime = time()
                
            command = (self.defaultCommand.makeCommand).replace(' ',' %i '%self.cindex,1)
            
            if self.defaultCommand.clientCommand:
                DoClientCommand(['DoClientCommand',command])
            else:
                PyDoCommand(['PyDoCommand',command],False)




def AttachMacroButtons():
    from partyWnd import PARTYWND
    from macroWnd import MACROWND
    
    #virtual page
    vpage = 0
    try:
        if int(TGEGetGlobal("$Py::Input::ShiftDown")):
            vpage = 1
    except:
        pass
    try:
        if int(TGEGetGlobal("$Py::Input::ControlDown")):
            vpage = 2
    except:
        pass
    
    for macros in CHARMACROS.itervalues():
        for macro in macros.itervalues():
            macro.enable()
            macro.controls = []
      
    for cindex,cinfo in PARTYWND.charInfos.iteritems():
        
        macroindex = vpage*10
        for x in xrange(0,10):
            control = MACROWND.macroButtons[cindex][x]
            control.setText("")
            control.SetBitmap("")
            control.hotKey = -1
            control.pulseGreen = False
            control.tooltip = "Macro Button (Press Ctrl or Shift to access more macro pages.  Double or Right Click to edit a custom macro.  Drag & Drop spells, items, and skills to create a default macro.)"
            
            if CURSORMACROTYPE and CURSORMACROCINDEX==cindex or PARTYWND.mind.cursorItem and PARTYWND.curIndex ==cindex:
                control.pulseGreen = True

            
            if CHARMACROS[cindex].has_key(macroindex):
                macro = CHARMACROS[cindex][macroindex]
                macro.controls.append(control)
            macroindex+=1
            
        if cinfo.DEAD:
            MACROWND.disableButtons(cindex)
        else:
            MACROWND.enableButtons(cindex)
                
            
    
    for macros in CHARMACROS.itervalues():
        for macro in macros.itervalues():
            if vpage == 0 and (10 > macro.index >= 0):
                macro.setControls()
            if vpage == 1 and (20 > macro.index >= 10):
                macro.setControls()
            if vpage == 2 and (30 > macro.index >= 20):
                macro.setControls()
    
    #handle skills
    
    for cindex,cinfo in PARTYWND.charInfos.iteritems():
        macros = CHARMACROS[cindex].values()
        
        for macro in macros:
            s = macro.invSlot
            id = macro.invID
            
            if macro.invSlot != -1 and macro.invID == -1:
                item = cinfo.ITEMS.get(macro.invSlot,None)
                if item:
                    macro.invID = item.NAME

            if macro.invSlot != -1 and macro.invID != -1:
                item = cinfo.ITEMS.get(macro.invSlot,None)
                if not item:
                    macro.invSlot = -1
                elif item.NAME != macro.invID:
                    macro.invSlot = -1
                    


            gotone = False
            if macro.invSlot == -1 and macro.invID != -1:
                item = None
                for i in cinfo.ITEMS.itervalues():
                    if i.NAME == macro.invID:
                        item  = i
                        break
                if item:
                    for k,v in cinfo.ITEMS.iteritems():
                        if v == item:
                            if k != RPG_SLOT_CURSOR:
                                gotone = True
                                macro.invSlot = k
                            break

            #if macro.invSlot != s or macro.invID != id:
            #    print "slot,id,newslot,newid",s,id,macro.invSlot,macro.invID
            if gotone:
                #print "Saving macros"
                #these saves should probably be moved to do once on exit or somehting
                SaveMacros()
                    
        if cinfo.DEAD:
            DisableAllMacros(cindex)
        else:
            for m in macros:
                for c in m.controls:
                    c.hotKey = m.hotKey
                if (m.defaultCommand and m.defaultCommand.name == "Attack") or (m.customMacro and m.customMacro.lines[0].lower().startswith("/attack")):
                    if cinfo.RAPIDMOBINFO.AUTOATTACK:
                        for c in m.controls:
                            c.SetValue(1)
                            c.pulseRed = True
                    else:
                        for c in m.controls:
                            c.SetValue(0)
                            c.pulseRed = False
                else:
                    for c in m.controls:
                        c.pulseRed = False
                containsRanged = False
                if (m.defaultCommand and m.defaultCommand.name == "Ranged Attack"):
                    containsRanged = True
                elif m.customMacro:
                    cmLines = m.customMacro.lines
                    for l in cmLines.itervalues():
                        if l.lower().startswith("/rangedattack"):
                            containsRanged = True
                if containsRanged:
                    if cinfo.RAPIDMOBINFO.RANGEDREUSE > 0:
                        m.disable()
                        
            
            EnableAllItemMacros(cindex)
            for itemInfo in cinfo.ITEMS.itervalues():
                if itemInfo.REUSETIMER:
                    for macro in macros:
                        if macro.invID == itemInfo.NAME:
                            macro.disable()

            EnableAllSkillMacros(cindex)
            for reuse in cinfo.SKILLREUSE.iterkeys():
                EnableSkillMacro(cindex,reuse,False)
            
            if cinfo.RAPIDMOBINFO.CASTING:
                DisableAllSpellMacros(cindex)
            else:
                EnableAllSpellMacros(cindex)
                for slot,sinfo in cinfo.SPELLS.iteritems():
                    if sinfo.RECASTTIMER:
                        for macro in macros:
                            if macro.spellSlot == slot:
                                macro.disable()
                            if macro.customMacro and len(macro.customMacro.spells) and sinfo.SPELLINFO.BASENAME.upper() in macro.customMacro.spells:
                                macro.disable()




def CreateMacro(cindex,mindex,mtype,value,value2 = None):
    m = Macro()
    m.cindex = cindex
    m.index = mindex
    m.hotKey = str((mindex+1)%10)
    
    if mtype == "CUSTOMMACRO":
        m.customMacro = value
        hk = TGEObject("CM_HOTKEY").getText()
        if hk == "None":
            m.hotKey = ""
        else:
            m.hotKey = hk
    
    elif mtype == "INV":
        m.invID = value
        m.invSlot = -1
    
    elif mtype == "SKILL":
        m.skill = value
    
    elif mtype == "SPELL":
        m.spellSlot = value
    
    elif mtype == "CMD":
        m.defaultCommand = value
    
    
    CHARMACROS[cindex][mindex] = m
    
    AttachMacroButtons()
    
    #clear it
    SetCursorMacro(None,None)
    
    #hm, here?
    SaveMacros()


def OnQuickButtonClick(args):
    from partyWnd import PARTYWND
    from commandWnd import COMMANDWND
    cindex = int(args[1])
    cmdindex = int(args[2])
    
    pane = COMMANDWND.panes[cindex]
    
    #virtual page
    vpage = 0
    try:
        if int(TGEGetGlobal("$Py::Input::ShiftDown")):
            vpage = 1
    except:
        pass
    try:
        if int(TGEGetGlobal("$Py::Input::ControlDown")):
            vpage = 2
    except:
        pass
    
    macroindex = vpage*10+cmdindex
    
    if CURSORMACROTYPE:
        #just to be sure though this shouldn't happen (we should clear on char switch)
        if CURSORMACROCINDEX != -1:
            if cindex != CURSORMACROCINDEX:
                mname = PARTYWND.charInfos[CURSORMACROCINDEX].NAME
                curname = PARTYWND.charInfos[cindex].NAME
                from tomeGui import TOMEGUI
                TOMEGUI.receiveGameText(RPG_MSG_GAME_DENIED,"%s's macro cannot be assigned to %s.\\n"%(mname,curname))
                return
        
        if cmdindex<=3:    
            TGEObject("CMDWND_CHAR%i_CMD%i"%(cindex+1,cmdindex)).SetValue(0) #when creating make sure it's up
        TGEObject("MINIWND_CHAR%i_CMD%i"%(cindex,cmdindex)).SetValue(0) #when creating make sure it's up
        
        CreateMacro(cindex,macroindex,CURSORMACROTYPE,CURSORMACROINFO)
    
    
    elif PARTYWND.mind.cursorItem:
        #macroing an item
        cursorItem = PARTYWND.mind.cursorItem
        
        # check for ranged macro
        if RPG_SLOT_RANGED in cursorItem.SLOTS:
            CreateMacro(cindex,macroindex,"CMD",GetDefaultCommand('Ranged Attack'))
        else:
            CreateMacro(cindex,macroindex,"INV",cursorItem.NAME,cursorItem.SLOT)
    
    else:
        if CHARMACROS[cindex].has_key(macroindex):
            macro = CHARMACROS[cindex][macroindex]            
            #if macro.defaultCommand:
            #    value = int(TGEObject("MINIWND_CHAR%i_CMD%i"%(cindex,cmdindex)).GetValue())
            #    for macro2 in CHARMACROS[cindex].values():
            #        if macro.defaultCommand == macro2.defaultCommand:
            #            macro2.activate(value) #sync
            #else:
            macro.activate()


def OnQuickButtonClickShift(args):
    from commandWnd import COMMANDWND
    #return #noooo
    cindex = int(args[1])
    cmdindex = int(args[2])
    pane = COMMANDWND.panes[cindex]    
    macroindex = pane.cmdPage*4+cmdindex
    if CHARMACROS[cindex].has_key(macroindex):
        CHARMACROS[cindex][macroindex].enable()
        del CHARMACROS[cindex][macroindex]
        AttachMacroButtons()
        SaveMacros()


def OnMacroButtonClickShift(args):
    #return #noooo
    from partyWnd import PARTYWND
    from macroWnd import MACROWND
    cindex = PARTYWND.curIndex
    mindex = int(args[1])
    if MACROWND.charPages.has_key(cindex):
        page = MACROWND.charPages[cindex]
    else:
        page = MACROWND.charPages[cindex] = 0
    
    macroindex = page*10+mindex
    
    if CHARMACROS[cindex].has_key(macroindex):
        CHARMACROS[cindex][macroindex].enable()
        del CHARMACROS[cindex][macroindex]
        AttachMacroButtons()
        SaveMacros()


def OnMacroButtonClick(args):
    from partyWnd import PARTYWND
    cindex = int(args[1])
    mindex = int(args[2])
    
    #if MACROWND.charPages.has_key(cindex):
    #    page = MACROWND.charPages[cindex]
    #else:
    #    page = MACROWND.charPages[cindex] = 0
    
    
    #virtual page
    vpage = 0
    try:
        if int(TGEGetGlobal("$Py::Input::ShiftDown")):
            vpage = 1
    except:
        pass
    try:
        if int(TGEGetGlobal("$Py::Input::ControlDown")):
            vpage = 2
    except:
        pass
    
    macroindex = vpage*10+mindex
    
    if CURSORMACROTYPE:
        #just to be sure though this shouldn't happen (we should clear on char switch)
        if CURSORMACROCINDEX != -1:
            if cindex != CURSORMACROCINDEX:
                mname = PARTYWND.charInfos[CURSORMACROCINDEX].NAME
                curname = PARTYWND.charInfos[cindex].NAME
                from tomeGui import TOMEGUI
                TOMEGUI.receiveGameText(RPG_MSG_GAME_DENIED,"%s's macro cannot be assigned to %s.\\n"%(mname,curname))
                return
        
        TGEObject("MACROWND_MACRO%i_%i"%(cindex,mindex)).SetValue(0) #when creating make sure it's up
        CreateMacro(cindex,macroindex,CURSORMACROTYPE,CURSORMACROINFO)
    
    elif PARTYWND.mind.cursorItem:
        #macroing an item
        cursorItem = PARTYWND.mind.cursorItem
        # check for ranged macro
        if RPG_SLOT_RANGED in cursorItem.SLOTS:
            CreateMacro(cindex,macroindex,"CMD",GetDefaultCommand('Ranged Attack'))
        else:
            CreateMacro(cindex,macroindex,"INV",cursorItem.NAME,cursorItem.SLOT)
    
    else:
        if CHARMACROS[cindex].has_key(macroindex):
            macro = CHARMACROS[cindex][macroindex]
            if macro.defaultCommand:
                value = int(TGEObject("MACROWND_MACRO%i_%i"%(cindex,mindex)).GetValue())
                for macro2 in CHARMACROS[cindex].itervalues():
                    if macro.defaultCommand == macro2.defaultCommand:
                        macro2.activate(value) #sync
            else:
                macro.activate()


def OnQuickButtonClickAlt(args):
    from commandWnd import COMMANDWND
    cindex = int(args[1])
    cmdindex = int(args[2])
    
    pane = COMMANDWND.panes[cindex]
    macroindex = pane.cmdPage*4+cmdindex
    
    OpenMacroEditor(cindex,macroindex)


def OnMacroButtonClickAlt(args):
    from macroWnd import MACROWND
    cindex = int(args[1])
    mindex = int(args[2])
    
    if MACROWND.charPages.has_key(cindex):
        page = MACROWND.charPages[cindex]
    else:
        page = MACROWND.charPages[cindex] = 0
    
    macroindex = page*10+mindex
    
    OpenMacroEditor(cindex,macroindex)


def OnHotKey(args):
    hk = args[1]
    #we are activating a macro
    for macros in CHARMACROS.itervalues():
        for macro in macros.itervalues():
            if macro.hotKey == hk:
                macro.activate()



TGEExport(OnHotKey,"Py","OnHotKey","desc",2,2)

TGEExport(OnQuickButtonClick,"Py","OnQuickButtonClick","desc",3,3)
#TGEExport(OnQuickButtonClickShift,"Py","OnQuickButtonClickShift","desc",3,3)

TGEExport(OnMacroButtonClick,"Py","OnMacroButtonClick","desc",3,3)
#TGEExport(OnMacroButtonClickShift,"Py","OnMacroButtonClickShift","desc",2,2)
TGEExport(OnMacroButtonClickAlt,"Py","OnMacroButtonClickAlt","desc",3,3)
TGEExport(OnQuickButtonClickAlt,"Py","OnQuickButtonClickAlt","desc",3,3)

TGEExport(CheckWindowPositions,"Py","CheckWindowPositions","desc",1,1)
