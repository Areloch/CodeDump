from tgenative import *
from mud.tgepython.console import TGEExport
from twisted.words.protocols import irc
from twisted.internet import reactor, protocol
from mud.world.defines import *
from mud.gamesettings import *
from cPickle import load,dump



#RPG_MSG_SPEECH_WORLD:"FFFFFF",
#RPG_MSG_SPEECH_ZONE:"B8C323",
#RPG_MSG_SPEECH_PARTY:"2896EA",
#RPG_MSG_SPEECH_SAY:"28EA44",
#RPG_MSG_SPEECH_AUCTION:"EA4828",
#RPG_MSG_SPEECH_GLOBAL:"06FFFC",
#RPG_MSG_SPEECH_NPC:"BAEA38",
#RPG_MSG_SPEECH_ALLIANCE:"2896EA",
#RPG_MSG_SPEECH_PET:"E0EA38",
#RPG_MSG_SPEECH_SYSTEM:"FFFF00",
#RPG_MSG_SPEECH_TELL:"BBBBFF",
#RPG_MSG_SPEECH_TOLD:"BBFFBB",
#RPG_MSG_SPEECH_EMOTE:"ECB3EB",
#RPG_MSG_SPEECH_OT:"E7E2EF",
#RPG_MSG_SPEECH_HELP:"79FF21",
#RPG_MSG_SPEECH_PLAYERJOINED:"E8EA38",

IGNORED = []
DISCONNECT = False
IRC = None
USERNAME = ""
MUTETIME = 0

GLOBAL_ON  = True
HELP_ON = True
OT_ON = True

def SetMuteTime(t):
    global MUTETIME
        
    if MUTETIME and not t:        
        ReceiveSpeechText(RPG_MSG_SPEECH_SYSTEM,r'You are no longer muted.\n')

    if not MUTETIME and t:
        m = t/60+1
        if m > 59:
            ReceiveSpeechText(RPG_MSG_SPEECH_ERROR,r'You have been muted.\n')
        else:
            ReceiveSpeechText(RPG_MSG_SPEECH_ERROR,r'You have been muted and will be able to speak in %i minutes.\n'%m)            
        
    MUTETIME = t
    
def CheckMuted():
    if MUTETIME:
        m = MUTETIME/60+1
        if m > 59:
            ReceiveSpeechText(RPG_MSG_SPEECH_ERROR,r'You have been muted.\n')
        else:
            ReceiveSpeechText(RPG_MSG_SPEECH_ERROR,r'You have been muted and will be able to speak in %i minutes.\n'%m)            
        return True
    return False
        

def ReceiveGameText(textCode,text):
    from gui.tomeGui import TOMEGUI
    #XXX todo, filter better!
    text = text.replace('\\"',"@$#") #valid quote
    text = text.replace('"','\\"') #invalid quote
    text = text.replace('@$#','\\"') #replace valid quotes
    
    TOMEGUI.receiveGameText(textCode,text)
    
def ReceiveSpeechText(textCode,text):
    from gui.tomeGui import TOMEGUI
    #XXX todo, filter better!
    text = text.replace('\\"',"@$#") #valid quote
    text = text.replace('"','\\"') #invalid quote
    text = text.replace('@$#','\\"') #replace valid quotes

    TOMEGUI.receiveSpeechText(textCode,text)


def FilterChannel(channel,value):
    global GLOBAL_ON,HELP_ON,OT_ON
    if channel == 'O':
        OT_ON = value
    if channel == 'H':
        HELP_ON = value
    if channel == 'M':
        GLOBAL_ON = value

class MyIRCClient(irc.IRCClient):
    
    def connectionMade(self):
        global IRC
        IRC = self
        self.nickname = self.factory.nickname
        irc.IRCClient.connectionMade(self)

    def connectionLost(self, reason):
        global IRC
        IRC = None
        irc.IRCClient.connectionLost(self, reason)


    def irc_ERR_NOSUCHNICK(self,prefix,params):
        mynick, their_nick, error = params
        
        ReceiveSpeechText(RPG_MSG_SPEECH_ERROR,r'%s is not currently logged in.  If you are messaging a monster, please replace any spaces in their name with underscores.\n'%their_nick)
        

    # callbacks for events
    
    def irc_RPL_NAMREPLY(self,prefix, params):
        pass #should remove this
        #if params[2]=="#prairiegames":
        #    ReceiveSpeechText(RPG_MSG_SPEECH_PLAYERJOINED,"Players in chat: %s \\n"%params[3])
        
    def userJoined(self, user, channel):
        """Called when I see another user joining a channel.
        """
        pass
        #if user.upper() in IGNORED:
        #    return

        #if channel == "#prairiegames":
        #    ReceiveSpeechText(RPG_MSG_SPEECH_PLAYERJOINED,r'%s has joined chat\n'%(user))

    def userLeft(self, user, channel):
        """Called when I see another user leaving a channel.
        """
        pass
        #if user.upper() in IGNORED:
        #    return

        #if channel == "#prairiegames":
        #    ReceiveSpeechText(RPG_MSG_SPEECH_PET,r'%s has left chat.\n'%(user))
            

    def userQuit(self, user, quitMessage):
        """Called when I see another user disconnect from the network.
        """
        #if user.upper() in IGNORED:
        #    return

        #ReceiveSpeechText(RPG_MSG_SPEECH_PET,r'%s has left chat.\n'%(user))

        pass

    def userKicked(self, kickee, channel, kicker, message):
        """Called when I observe someone else being kicked from a channel.
        """
        pass
        
        #if user.upper() in IGNORED:
        #    return

        #if channel == "#prairiegames":
        #    ReceiveSpeechText(RPG_MSG_SPEECH_PET,r'%s was kicked from chat by %s (%s)\n'%(kickee,kicker,message))

    def topicUpdated(self, user, channel, newTopic):
        pass
        #if channel == "#prairiegames":
        #ReceiveSpeechText(RPG_MSG_SPEECH_PET,r'%s has changed the  (%s)\n'%(kickee,kicker,message))

    def userRenamed(self, oldname, newname):  
        pass      
        #ReceiveSpeechText(RPG_MSG_SPEECH_PET,r'%s is now known as %s\n'%(oldname,newname))


    ### Information from the server.

    def receivedMOTD(self, motd):
        """I received a message-of-the-day banner from the server.

        motd is a list of strings, where each string was sent as a seperate
        message from the server. To display, you might want to use::

            '\\n'.join(motd)

        to get a nicely formatted string.
        """
        pass

    def signedOn(self):
        """Called when bot has succesfully signed on to server."""
        #self.join(self.factory.channel)
        self.join("#prairiegames") #off-topic
        self.join("#pg_global") #global
        self.join("#pg_help") #help

    def joined(self, channel):
        """This will get called when the bot joins the channel."""
        #self.logger.log("[I have joined %s]" % channel)
        self.live = True        
        if channel == "#prairiegames":
            ReceiveSpeechText(RPG_MSG_SPEECH_HELP,"You have joined chat.\\n")
            
            
        #self.player.irc = self

    def privmsg(self, user, channel, msg):
        """This will get called when the bot receives a message."""
        if not self.live:
            return
        
                
        if DISCONNECT:
            self.sendLine("QUIT :%s" % "Errant IRC connection closed")
            return

        #filters!
        if channel == "#prairiegames" and not OT_ON:
            return

        if channel == "#pg_global" and not GLOBAL_ON:
            return

        if channel == "#pg_help" and not HELP_ON:
            return
            
        
        user = user.split('!', 1)[0]
        user = user.replace("_"," ")
        
        msg = msg.replace("\\","")
        
        #ignores
        if user.upper() in IGNORED:
            return
        
        
        if channel.upper() == self.nickname.upper():
            TGESetGlobal("$Py::LastTell",user.replace(" ","_"))
            ReceiveSpeechText(RPG_MSG_SPEECH_TELL,r'%s tells you, \"%s\"\n'%(user,msg))
        else:
            if channel == "#pg_global":
                ReceiveSpeechText(RPG_MSG_SPEECH_GLOBAL,r'MoM: <%s> %s\n'%(user,msg))
            elif channel == "#pg_help":
                ReceiveSpeechText(RPG_MSG_SPEECH_HELP,r'Help: <%s> %s\n'%(user,msg))
            elif channel == "#prairiegames":
                ReceiveSpeechText(RPG_MSG_SPEECH_OT,r'OT: <%s> %s\n'%(user,msg))
            
            
        #
        #self.logger.log("<%s> %s" % (user, msg))
        
        # Check to see if they're sending me a private message
        #if channel == self.nickname:
        #    msg = "It isn't nice to whisper!  Play nice with the group."
        #    self.msg(user, msg)
        #    return

        # Otherwise check to see if it is a message directed at me
        #if msg.startswith(self.nickname + ":"):
        #    msg = "%s: I am a log bot" % user
        #    self.msg(channel, msg)
        #    self.logger.log("<%s> %s" % (self.nickname, msg))

    def action(self, user, channel, msg):
        """This will get called when the bot sees someone do an action."""
        user = user.split('!', 1)[0]
        user = user.replace("_"," ")
        #print user
        #self.logger.log("* %s %s" % (user, msg))
        
        #IGNORE!
        if user.upper() in IGNORED:
            return
        
        msg = msg.replace("\\","")
        ReceiveSpeechText(RPG_MSG_SPEECH_EMOTE,r'%s %s.\n'%(user,msg))
        


class IRCFactory(protocol.ClientFactory):
    def __init__(self, nickname,channel):
        self.nickname = nickname
        self.channel = channel
        self.protocol = MyIRCClient
    
    def buildProtocol(self,addr):
        print addr.host
        
        p = protocol.ClientFactory.buildProtocol(self,addr)        
        p.live = False
        p.nickname = self.nickname
        
        return p

#COMMANDS['ME']=CmdGlobalEmote
#COMMANDS['GE']=CmdGlobalEmote
#COMMANDS['GEMOTE']=CmdGlobalEmote
#COMMANDS['GWHO']=CmdGlobalWho

def ChangeNick(name):
    name = name.replace(" ","_")
    try:
        IRC.setNick(name)
    except:
        pass

def IRCConnect(name):
    LoadIgnoreList()
    global IRC
    if IRC:
        try:
            IRCDisconnect()
        except:
            pass
    IRC = None
    
    name = name.replace(" ","_")
    cf = IRCFactory(name,"#pg_global")
    reactor.connectTCP("irc.prairiegames.com", 6667, cf)
    ReceiveSpeechText(RPG_MSG_SPEECH_HELP,"Connecting to Prairie Games, Inc chat services.\\n")
    
def IRCDisconnect():
    global IRC
    if IRC:
        i = IRC
        IRC = None
        i.transport.loseConnection()

def GlobalMsg(msg):
    if CheckMuted():
        return

    if not IRC:
        return
    
    if not len(msg):
        return
    
    name = IRC.nickname
    name = name.replace("_"," ")
    ReceiveSpeechText(RPG_MSG_SPEECH_GLOBAL,r'MoM: <%s> %s\n'%(name,msg))
    IRC.msg("#pg_global", msg)

def OTMsg(msg):
    if CheckMuted():
        return

    if not IRC:
        return
    
    
    if not len(msg):
        return

    name = IRC.nickname
    name = name.replace("_"," ")
    
    ReceiveSpeechText(RPG_MSG_SPEECH_OT,r'OT: <%s> %s\n'%(name,msg))
    IRC.msg("#prairiegames", msg)
        
def HelpMsg(msg):
    if CheckMuted():
        return

    if not IRC:
        return
        
    if not len(msg):
        return
    
    name = IRC.nickname
    name = name.replace("_"," ")
    
    ReceiveSpeechText(RPG_MSG_SPEECH_HELP,r'Help: <%s> %s\n'%(name,msg))
    IRC.msg("#pg_help", msg)

def SendIRCMsg(channel,msg):
    if CheckMuted():
        return

    msg = msg.replace("\\","")

    if channel == 'O':
        OTMsg(msg)
    if channel == 'H':
        HelpMsg(msg)
    if channel == 'M':
        GlobalMsg(msg)
        



def LoadIgnoreList():
    global IGNORED
    try:
        f = file("%s/data/settings/ignore.dat"%GAMEROOT,'rb')
        IGNORED = load(f)
        f.close()
        if type(IGNORED) != type(list()):
            IGNORED = []        
    except:
        IGNORED = []

        
def SaveIgnoreList():
    try:
        f = file("%s/data/settings/ignore.dat"%GAMEROOT,'wb')
        dump(IGNORED,f)
        f.close()
    except:
        pass

    
        
def Ignore(nick):
    ReceiveGameText(RPG_MSG_GAME_GAINED,r'You are are now ignoring %s.\n'%nick)
    nick = nick.upper()
    if nick in IGNORED:
        return
    IGNORED.append(nick)
    SaveIgnoreList()
    
def Unignore(nick):
    ReceiveGameText(RPG_MSG_GAME_GAINED,r'You are are no longer ignoring %s.\n'%nick)
    nick = nick.upper()
    if nick not in IGNORED:
        return
    IGNORED.remove(nick)    
    SaveIgnoreList()

def IRCTell(nick,msg):
    if CheckMuted():
        return

    ReceiveSpeechText(RPG_MSG_SPEECH_TOLD,r'You tell %s, \"%s\"\n'%(nick,msg))
    IRC.msg(nick, msg)
    
def IRCEmote(lastchannel,emote):
    if CheckMuted():
        return
    
    channel = "#prairiegames"
    if lastchannel == 'M':
        channel = "#pg_global"
    if lastchannel == 'H':
        channel = "#pg_help"
    
    name = IRC.nickname
    name = name.replace("_"," ")
    ReceiveSpeechText(RPG_MSG_SPEECH_EMOTE,r'%s %s.\n'%(name,emote))
    IRC.ctcpMakeQuery(channel, [('ACTION', emote)])

