
from tgenative import *
from mud.tgepython.console import TGEExport

from sqlite3 import dbapi2 as sqlite

from twisted.spread import pb
from twisted.internet import reactor
from twisted.cred.credentials import UsernamePassword

LASTCHANNEL = 'M'
IRCCHANNELS = ('H','O','M')
CHATCHANNELS = ('H','O','M','W','Z','S','A','G')

#for jelly
from mud.world.shared.worlddata import ZoneConnectionInfo
from mud.world.shared.playdata import IsDirty

from mud.simulation.simmind import SimMind

from gui.clientcommands import DoClientCommand

from twisted.internet import defer

import types
from mud.world.defines import *
from mud.world.core import CoreSettings
from mud.gamesettings import *
from mud.client.sounds import SOUNDS
from mud.world.shared.vocals import *
import traceback,sys
import time

PLAYERMIND = None
DOQUITNAG = True


from gui.gamebreak import DisplayBreak

PAUSED_CALLBACK = DisplayBreak
def SetPausedCallback(cb):
    global PAUSED_CALLBACK
    PAUSED_CALLBACK = cb


CEREBRUM = None
def GetMoMClientDBConnection():
    global CEREBRUM
    if not CEREBRUM:
        CEREBRUM = sqlite.connect("./%s/data/worlds/multiplayer.baseline/world.db"%GAMEROOT)
        CEREBRUM.text_factory = sqlite.OptimizedUnicode
    return CEREBRUM


class PerspectiveWrapper:
    def __init__(self,perp):
        self.perspective = perp
        self.broker = perp.broker
        self.commands = []
        self.running = None
        self.lasttime=time.time()
        
    def commandDone(self,result):
        self.running = False
        return result
        
    def tick(self):
        if self.running or not len(self.commands):
            return
        delta = time.time()-self.lasttime
        if delta < .25:
            return
        self.lasttime = time.time()
        d,_name,args,kw = self.commands.pop(0)
        nd = self.perspective.callRemote(_name,*args,**kw)
        nd.chainDeferred(d)        
        self.running = True
        
        
        
    def callRemote(self,_name,*args, **kw):
        num = 25
        if PLAYERMIND and PLAYERMIND.charInfos and len(PLAYERMIND.charInfos):
            num = len(PLAYERMIND.charInfos)*8           
        if len(self.commands)<num:
            d = defer.Deferred()
            d.addCallback(self.commandDone)
            d.addErrback(self.commandDone)

            c = (d,_name,args,kw)
            self.commands.append(c)
            return d
        else:
            from gui.tomeGui import TOMEGUI
            TOMEGUI.receiveGameText(RPG_MSG_GAME_DENIED,"The command buffer is full.\\n")
            return None

            
    
class PlayerMind(pb.Root):
    directConnect = ""
    
    def __init__(self):
        global PLAYERMIND
        PLAYERMIND = self
        self.perspective = None
        self.simMind = None
        
        from gui.partyWnd import PARTYWND
        PARTYWND.mind = self
        self.cursor = TGEObject("DefaultCursor")
        self.cursorItem = None
        
        self.nagTime = 180
        
        self.running = True
        self.rootInfo = None
        
        #local so people don't spam trying to stop casting
        t = time.time()
        self.stopCastingTimers = {0:t,1:t,2:t,3:t,4:t,5:t}
        
        self.paused = False
        TGESetGlobal("$GamePaused",self.paused)
        self.lastAdTime = time.time()
        
        self.freeWorld = RPG_BUILD_DEMO
        self.party = None
        
        self.ircNick = None
        
        self.charInfos = {}
        
        self.pgserver = False
        
        self.initialFriendsSubmit = False
        
    
    def setPerspective(self,perp):
        self.perspective = PerspectiveWrapper(perp)
        
        
    #these are on the NEW MIND created in jumpserver
    def gotJumpServerResult(self,perspective):
        self.setPerspective(perspective)
        perspective.callRemote("PlayerAvatar","jumpIntoWorld",self.party[0])

    def gotJumpServerFailure(self,reason):
        print "jump failure",reason
        
    def remote_jumpServer(self,wip,wport,wpassword,zport,zpassword,party):
        
        from gui.macro import SaveWindowSettings
        if self.rootInfo:
            SaveWindowSettings()
        
        ip = wip
        if ip == None:
            ip = self.worldIP
            
        print "JumpServer",ip,wport
            
        mind = PlayerMind()
        mind.freeWorld = self.freeWorld
        mind.worldIP = self.worldIP
        mind.ircNick = self.ircNick
        mind.pgserver = self.pgserver
        self.running = False
        
        
        #hmmmm
        #try:
        #    self.perspective.broker.transport.loseConnection()
        #except:
        #    pass
            
        TGEEval("disconnect();Canvas.setContent(LoadingGui);")

        mind.party = party
        
        factory = pb.PBClientFactory()
        factory.unsafeTracebacks = PB_UNSAFE_TRACEBACKS
        reactor.connectTCP(ip,wport,factory)    
        
        #LAME!, role could be passed in instead
        MASTER_LOGIN_PLAYER = TGEObject("MASTER_LOGIN_PLAYER")
        MASTER_LOGIN_GUARDIAN = TGEObject("MASTER_LOGIN_GUARDIAN")
        MASTER_LOGIN_IMMORTAL = TGEObject("MASTER_LOGIN_IMMORTAL")

        role = "Player"
        if TGEGetGlobal("$pref::GM_LOGIN") == "1":
            TGESetGlobal("$pref::GM_LOGIN_ROLE","Player")
            if int(MASTER_LOGIN_GUARDIAN.getValue()):
                TGESetGlobal("$pref::GM_LOGIN_ROLE","Guardian")
                role = "Guardian"
            if int(MASTER_LOGIN_IMMORTAL.getValue()):
                TGESetGlobal("$pref::GM_LOGIN_ROLE","Immortal")
                role = "Immortal"
        
        from md5 import md5
        password = md5(wpassword).digest()

        d = factory.login(UsernamePassword("%s-%s"%(TGEGetGlobal("$pref::PublicName"),role), password),mind)
        d.addCallbacks(mind.gotJumpServerResult, mind.gotJumpServerFailure)
        return d

    def tick(self):
        
        #import time
        #tm = time.time()
        
        if self.perspective:
            if self.perspective.broker.disconnected:
                self.running = False
                from mud.client.irc import IRCDisconnect
                
                try:
                    IRCDisconnect()
                except:
                    traceback.print_exc()

                TGEEval("""
                if (PlayGui.isAwake())
                {
                    disconnect();
                    Canvas.setContent(MainMenuGui);
                    MessageBoxOK( "Disconnected", "You have been disconnected from the server." );    
                }
                """)
            else:
                self.perspective.tick()
            
            if not self.initialFriendsSubmit:
                self.initialFriendsSubmit = True
                from gui.friendsWnd import SubmitFriendsList
                SubmitFriendsList()
        
        if not self.running:
            return
            
            
        try:
            from gui.partyWnd import PARTYWND
            from gui.tacticalGui import TACTICALGUI
            from gui.itemInfoWnd import ITEMINFOWND            
            from gui.charMiniWnd import CHARMINIWND
            from gui.npcWnd import NPCWND
            from gui.allianceWnd import ALLIANCEWND
            from gui.leaderWnd import LEADERWND
            from gui.buffWnd import BUFFWND
            
            import gui.macroWnd
            
            itemInfo = self.cursorItem
            cursor = self.cursor
            
            #yagh (yet another gross hack)
            if not itemInfo and not cursor.bitmapName.startswith("%s/data/ui/icons/"%GAMEROOT) and not cursor.bitmapName.startswith("%s/data/ui/spellicons/"%GAMEROOT):
                cursor.bitmapName = "common/ui/CUR_3darrow"
                cursor.sizeX = -1
                cursor.sizeY = -1
                cursor.hotSpot = "0 0"
                cursor.number = -1
                cursor.u0=0
                cursor.v0=0
                cursor.u1=1
                cursor.v1=1
            elif itemInfo:
                cursor.bitmapName ="%s/data/ui/items/%s/0_0_0"%(GAMEROOT,itemInfo.BITMAP)
                cursor.sizeX = 50
                cursor.sizeY = 50
                cursor.u0=0
                cursor.v0=0
                cursor.u1=1
                cursor.v1=1
                cursor.hotSpot = "0 0"
                cursor.number = -1
                if itemInfo.STACKMAX > 1:
                    cursor.number = itemInfo.STACKCOUNT

            
            if self.rootInfo.bankDirty:
                NPCWND.bankPane.set(self.rootInfo.BANK)
                self.rootInfo.bankDirty = False
    
            
            cinfo = self.charInfos[PARTYWND.curIndex]
            TGESetGlobal("$Py::SelectionCharacterIndex",PARTYWND.curIndex)
    
        
            #character link targets
            if False:
                for x,c in self.charInfos.iteritems():
                    linktarget = c.clientSettings['LINKTARGET']
                    if linktarget:
                        for y,lt in self.charInfos.iteritems():
                            if lt.NAME == linktarget:
                                assert c != lt #make sure we aren't linked to ourself
                                if lt.RAPIDMOBINFO.TGTID:
                                    if lt.RAPIDMOBINFO.TGTID != c.RAPIDMOBINFO.TGTID:
                                        self.perspective.callRemote("PlayerAvatar","doCommand","TARGETID",[x,lt.RAPIDMOBINFO.TGTID,0])    
                                        break
                    defaulttarget = c.clientSettings['DEFAULTTARGET']
                    if defaulttarget and not c.RAPIDMOBINFO.TGTID:
                        for y,lt in self.charInfos.iteritems():
                            if lt.NAME == defaulttarget:
                                self.perspective.callRemote("PlayerAvatar","doCommand","TARGETID",[x,lt.MOBID,0])    
                                break
                    
                
            if self.pgserver and self.ircNick != self.charInfos[0].NAME:
                self.ircNick = self.charInfos[0].NAME
                from irc import ChangeNick
                ChangeNick(self.ircNick)
            
            PARTYWND.tick()
                
            
            CHARMINIWND.tick()
            #TACTICALGUI.tick(cinfo,self.rootInfo)  # instead of just return in the tick, take it out here
            NPCWND.tick()
            ALLIANCEWND.tick()
            #LEADERWND.tick()  # don't even call instead of just returning
            BUFFWND.tick()
            gui.macroWnd.SetFromCharacterInfos(self.charInfos)
            
            
            ITEMINFOWND.tick(cinfo)
            
            #tracking
            from gui.trackingWnd import TRACKINGWND
            if TRACKINGWND.trackingId or TRACKINGWND.trackInterest:
                frame = TGEGetTrackingFrame(TRACKINGWND.trackLocation)
                TRACKINGWND.trackingBitmap.setBitmap("~/data/ui/tracking/tracking%i"%frame)
            else:
                TRACKINGWND.trackingBitmap.setBitmap("")
            
            from gui.macro import CHARMACROS
            for v in CHARMACROS.itervalues():
                for m in v.itervalues():
                    if m.customGenerator:
                        m.tick()
                        m.disable()
                    #elif m.customMacro:
                    #    if not len(m.customMacro.skills) and not len(m.custom
                    #    m.enable()
        except:
            traceback.print_exc()
        

        if False:#self.freeWorld:
            if self.rootInfo.PAUSED:
                if not self.paused:                    
                    PAUSED_CALLBACK(True)
                self.paused=True
            else:
                PAUSED_CALLBACK(False)
                if self.paused:
                    self.lastAdTime = time.time()
                self.paused=False
                
            TGESetGlobal("$GamePaused",self.paused)
            
            t = time.time()-self.lastAdTime
            if t > 12*60:
                self.lastAdTime = time.time()
                t = 0
                
            TGEObject("SPONSORBREAK_BAR").SetValue(1.0 - float(t)/(12.0*60.0))

        
        
        t = TGEGetGlobal("$Gui::ToolTip")
        if t == "None" or t == None:
            #TGEObject("MOM_TOOLTIP").setText("")
            TGEObject("MOM_TOOLTIP_BORDER").visible = False
        else:
            tips = TGEGetGlobal("$pref::game::tooltips")
            if tips == None or tips == "None":
                tips = 1 
                TGESetGlobal("$pref::game::tooltips","1")
            tips = int(tips)
            if not tips and not t.startswith("XXX:"):
                TGEObject("MOM_TOOLTIP_BORDER").visible = False
            else:
            
                tt = TGEObject("MOM_TOOLTIP")
                
                if t.startswith("XXX:"):
                    t = t[4:]
            
                border = TGEObject("MOM_TOOLTIP_BORDER")
                tt.setText(t)
                extentx = int(tt.getTextWidth())
                border.visible = True
                border.setExtent(extentx+48,27)
            
        reactor.callLater(.1,self.tick)
        #print time.time()-tm,"client tick"

    def camp(self,result,quit=False):
        from mud.client.irc import IRCDisconnect
        
        try:
            IRCDisconnect()
        except:
            traceback.print_exc()

        self.running = False
        try:
            SPVal = TGEGetGlobal("$Py::ISSINGLEPLAYER")
            if SPVal and (int(SPVal)):
                from mud.worldserver.embedded import ShutdownEmbeddedWorld
                ShutdownEmbeddedWorld()
        except:
            pass
        
        try:
            self.perspective.broker.transport.loseConnection()
        except:
            pass
            
        if quit:
            TGEEval("Py::OnQuit();")
        else:
            TGEEval("disconnect();Canvas.setContent(MainMenuGui);")
    

    def campQuit(self):
        self.camp(None,True)
        return
        
    
    def doCommand(self,cmd,args):
        global DOQUITNAG,PREORDER_QUIT
        if RPG_BUILD_DEMO:
            if cmd.upper()=="QUIT":
                DOQUITNAG = False
                PREORDER_QUIT = True
                TGEObject("DEMOINFO_BITMAP").setBitmap("~/data/ui/demo/main")        
                TGEObject("DEMOINFOWIND_LATERBUTTON").command = "Py::OnCampQuit();"        
                TGEEval("canvas.pushDialog(DemoInfoWnd);")
                return

        

        if cmd.upper()=="QUIT" or cmd.upper()=="CAMP":
            self.running = False
            from gui.macro import SaveWindowSettings
            SaveWindowSettings()
        
            #TGEEval("Py::OnQuit();")
            self.camp(None,cmd.upper()=="QUIT")
            return
        try:
            if cmd.upper()=="STOPCAST":
                t = time.time()
                index = int(args[0])
                if t - self.stopCastingTimers[index] < 12:
                    from gui.tomeGui import TOMEGUI
                    TOMEGUI.receiveGameText(RPG_MSG_GAME_DENIED,"%s cannot stop casting at this time.\\n"%self.charInfos[index].NAME)
                    return
                self.stopCastingTimers[index]=t
        except:
            traceback.print_exc()
        
        
        d = self.perspective.callRemote("PlayerAvatar","doCommand",cmd,args)    
        #if cmd.upper()=="CAMP" and d:
        #    from gui.macro import SaveWindowSettings
        #    SaveWindowSettings()

        #    d.addCallback(self.camp)
        #    d.addErrback(self.camp)

        
            
            
        
    #INVENTORY

    #this is called when swapping inventory around, cursor item is called seperately
    
    def remote_setItemSlot(self,charId,itemInfo,slot):
        from gui.partyWnd import PARTYWND
        for index,cinfo in self.charInfos.iteritems():
            if cinfo.CHARID == charId:
                if itemInfo:
                    itemInfo.SLOT = slot
                    cinfo.ITEMS[slot]=itemInfo
                else:
                    if cinfo.ITEMS.has_key(slot):
                        del cinfo.ITEMS[slot]
                if index == PARTYWND.curIndex:
                    PARTYWND.invPane.setFromCharacterInfo(cinfo)
                return
            
    
    def onInvSlot(self,cinfo,slot):
        self.perspective.callRemote("PlayerAvatar","onInvSlot",cinfo.CHARID,slot)

    def onInvSlotAlt(self,cinfo,slot):
        self.perspective.callRemote("PlayerAvatar","onInvSlotAlt",cinfo.CHARID,slot)

    def onBankSlot(self,slot):
        self.perspective.callRemote("PlayerAvatar","onBankSlot",slot)

    def onInvSlotCtrl(self,cinfo,slot):
        self.perspective.callRemote("PlayerAvatar","onInvSlotCtrl",cinfo.CHARID,slot)

        
    def onSpellSlot(self,cinfo,slot):
        if cinfo.DEAD:
            return
        self.perspective.callRemote("PlayerAvatar","onSpellSlot",cinfo.CHARID,slot)

    def onSpellSlotSwap(self,cinfo,source,dest):
        self.perspective.callRemote("PlayerAvatar","onSpellSlotSwap",cinfo.CHARID,source,dest)

    def onInvSlotUse(self,cinfo,slot):
        if cinfo.DEAD:
            return
        self.perspective.callRemote("PlayerAvatar","onInvSlotUse",cinfo.CHARID,slot)
    
    def remote_setCursorItem(self,itemInfo):
        if itemInfo:
            itemInfo.SLOT = RPG_SLOT_CURSOR
        self.cursorItem = itemInfo
        from gui.partyWnd import PARTYWND
        PARTYWND.setCursorItem()
    
    def remote_checkIgnore(self,charName):
        from irc import IGNORED
        if charName and charName.upper() in IGNORED:
            return True
        return False
    
    def remote_receiveTextList(self,messages):
        from irc import IGNORED
        for t,textCode,text,src in messages:
            if src and src in IGNORED:
                continue  # messages is a list which may contain different sources
            if t == 0:
                self.remote_receiveGameText(textCode,text)
            elif t == 1:
                self.remote_receiveSpeechText(textCode,text)
            
    def remote_receiveGameText(self,textCode,text):
        from gui.tomeGui import TOMEGUI
        #XXX todo, filter better!
        text = text.replace('\\"',"@$#") #valid quote
        text = text.replace('"','\\"') #invalid quote
        text = text.replace('@$#','\\"') #replace valid qoutes
        
        TOMEGUI.receiveGameText(textCode,text)
        
    def remote_receiveSpeechText(self,textCode,text):
        from gui.tomeGui import TOMEGUI        
        #XXX todo, filter better!
        text = text.replace('\\"',"@$#") #valid quote
        text = text.replace('"','\\"') #invalid quote
        text = text.replace('@$#','\\"') #replace valid qoutes

        TOMEGUI.receiveSpeechText(textCode,text)
            
        
    #connection stuff
    def remote_createServer(self,zconnect):
        print "CreateServer"
        if self.simMind:
            self.simMind.destroyServer()
        
        self.simMind = SimMind(self.perspective,zconnect.instanceName)
        
        TGEEval("""
            LOAD_ZONEBITMAP.setBitmap("~/data/ui/loading/SPCreateZone");
            LoadingProgress.setValue(0);
            LOAD_MapDescription.setText("");
            LoadingProgressTxt.setText("... Populating Zone ... Please Wait ...");
            canvas.setcontent(LoadingGui);
            LOAD_MapName.setText("Traveling");
            canvas.repaint();""")
        
        TGEEval('CreateLocalMission("%s","%s");'%(zconnect.missionFile,zconnect.password))
        
    def remote_connect(self,zconnect,fantasyName=None):
        
        if fantasyName:
            TGESetGlobal("$pref::FantasyName",fantasyName)
            
        
        #TGECall("MessagePopup","Connecting to Zone...","Please wait...")
        TGEEval("Canvas.repaint();")
        #print zconnect.ip,zconnect.port,zconnect.password,zconnect.niceName,zconnect.missionFile
        from gui.pointsOfInterest import SetZoneName
        SetZoneName(zconnect.niceName)
        TGESetGlobal("$Py::RPG::ShowPlayers",1)
        TGESetGlobal("$Py::RPG::ShowNPCs",1)
        TGESetGlobal("$Py::RPG::ShowEnemies",1)
        TGESetGlobal("$Py::RPG::ShowPoints",1)
        
        
        
        
        #stash the zoneconnectpassword
        TGESetGlobal("$Py::playerZoneConnectPassword",zconnect.playerZoneConnectPassword)
        
        if SimMind.directConnect:
            zconnect.ip = SimMind.directConnect
            
        
        if int(TGEGetGlobal("$Py::ISSINGLEPLAYER")):
            print "CONNECT",zconnect.ip
            TGEEval('ConnectLocalMission();')            
        else:
            print "CONNECT",zconnect.ip
            connectstring = "%s:%i"%(zconnect.ip,zconnect.port)
            TGEEval('ConnectRemoteMission("%s","%s");'%(connectstring,""))
            
    #play stuff
    
    def remote_setRootInfo(self,rootInfo,pauseTime=None):
        
        #turn off autowalk (for zoning, ect)
        if int(TGEGetGlobal("$mvAutoForward")):
            TGESetGlobal("$mvAutoForward",2) #turn off
        
        doTick = False
        if not self.rootInfo:
            doTick = True
            
        if pauseTime:
            self.lastAdTime = time.time()-pauseTime

        self.rootInfo = rootInfo
        self.charInfos = rootInfo.CHARINFOS
        from gui.partyWnd import SetFromCharacterInfos
        SetFromCharacterInfos(self.charInfos)
        #from gui.charSelectGui import SetFromCharacterInfos
        #SetFromCharacterInfos(self.charInfos)
        
        from gui.macro import SetFromCharacterInfos
        SetFromCharacterInfos(self.charInfos)

        from gui.macroWnd import SetFromCharacterInfos
        SetFromCharacterInfos(self.charInfos)

        
        for x in xrange(0,6):
            TGEObject("PARTYWND_CHAR%i"%x).visible = False
        
        if len(self.charInfos) > 1:    
            for x in xrange(0,len(self.charInfos)):
                TGEObject("PARTYWND_CHAR%i"%x).visible = True
        
        from gui.allianceWnd import ALLIANCEWND
        ALLIANCEWND.setCharInfo(self.charInfos[0])
        
        from gui.charMiniWnd import CHARMINIWND
        CHARMINIWND.setCharInfos(self.charInfos)
        from gui.buffWnd import BUFFWND
        BUFFWND.setCharInfos(self.charInfos)

        
        TGEObject("MACROWND_CHAR0").performClick()
        TGEObject("INVPANE_PAGEBUTTON0").performClick()
        if doTick:
            self.tick()
        
    def remote_setCurCharIndex(self,index):
        from gui.partyWnd import PARTYWND
        PARTYWND.setFromCharacterInfo(index)


    def remote_openPetWindow(self):
        TGEEval("canvas.pushDialog(PetWnd);")
        
        
        
    def remote_clientCharCommand(self,index,cmd,args):
        DoClientCommand(self.charInfos[index],cmd,args)
        
    def charSetTarget(self,charIndex,mobId,cycle=False):
        self.perspective.callRemote("PlayerAvatar","doCommand","TARGETID",[charIndex,mobId,cycle])
        
        
    def remote_mouseSelect(self,charIndex,mobId):
        for x,cinfo in self.charInfos.iteritems():
            if x == charIndex:
                
                if cinfo.clientSettings['LINKTARGET']:
                    cinfo.clientSettings['LINKTARGET']=None # clear link target
                    from gui.partyWnd import PARTYWND
                    if PARTYWND.settingsPane.currentChar == cinfo:
                        PARTYWND.settingsPane.setFromCharacterInfo(cinfo,True)
                    
                continue #already set on server
            if cinfo.clientSettings['LINKMOUSETARGET']:
                self.perspective.callRemote("PlayerAvatar","doCommand","TARGETID",[x,mobId,0])
                
    #spell casting
    def remote_beginCasting(self,charIndex,time):
        
        from gui.charMiniWnd import CHARMINIWND
        from gui.allianceWnd import ALLIANCEWND
        
        CHARMINIWND.beginCasting(charIndex,time)
        ALLIANCEWND.beginCasting(time)
        
        
    #loot
    def remote_setLoot(self,loot):
        print loot,len(loot)
        from gui.lootWnd import LOOTWND
        lootwnd = TGEObject("LootWnd")
        if len(loot):
            if not int(lootwnd.isAwake()):
                eval = """
                canvas.pushDialog(LootWnd);
                """
                TGEEval(eval)
            LOOTWND.setLoot(loot)
        else:
            if int(lootwnd.isAwake()):
                eval = """
                canvas.popDialog(LootWnd);
                """
                TGEEval(eval)
                
    def loot(self,charIndex,slot):
        self.perspective.callRemote("PlayerAvatar","loot",charIndex,slot)
        
    def lootAlt(self,charIndex,slot):
        self.perspective.callRemote("PlayerAvatar","loot",charIndex,slot,True)

    def destroyCorpse(self):
        self.perspective.callRemote("PlayerAvatar","destroyCorpse")
    def expungeItem(self):
        self.perspective.callRemote("PlayerAvatar","expungeItem")

    def splitItem(self,newStackSize):
        self.perspective.callRemote("PlayerAvatar","splitItem",newStackSize)
        
    def closeLootWnd(self):
        self.perspective.callRemote("PlayerAvatar","endLooting")
        TGEEval("canvas.popDialog(LootWnd);")
        
        
    #inns
    
    def remote_getInnWnd(self):
        from gui.innWnd import INNWND
        return INNWND
            
    
        
    #zoning
    def remote_setZoneOptions(self,zoptions):
        print zoptions
        from gui.macro import SaveWindowSettings
        SaveWindowSettings()
        
        
        self.simMind = None
        TGEEval("disconnect();")
        
        #eventually this will bring up a dialog for us to either:
        #a) join a specific existing zone server
        #b) start our own, possible private zone server
        #for now, we just use the first one givem
        if not len(zoptions):
            #we HAVE to launch a new zone
            self.perspective.callRemote("PlayerAvatar","chooseZone","new")
            return
            
        self.perspective.callRemote("PlayerAvatar","chooseZone",zoptions[0].zoneInstanceName)
            
        
        
    def remote_syncTime(self,hour,minute):
        TGEEval(r'TGEDayNightSyncTime(%i,%i);'%(hour,minute))
        
    #INTERACTION
    def remote_openNPCWnd(self,title,banker=False):
        TGEObject("NPCWnd_Window").setText(title)
        from gui.npcWnd import NPCWND        
        NPCWND.openWindow(self.perspective, title,banker)
    def remote_closeNPCWnd(self):
        from gui.npcWnd import NPCWND
        NPCWND.closeWindow()
        
    def remote_setVendorStock(self,isVendor,stock,markup):
        from gui.npcWnd import NPCWND
        NPCWND.setStock(isVendor,stock,markup)
        
    def remote_setInitialInteraction(self,text,choices,journalEntryID=None,title=None):
        from gui.npcWnd import NPCWND
        NPCWND.setInitialInteraction(text,choices,journalEntryID,title)
        
        
    #Alliance
    
    def clearAllianceInfo(self):
        from gui.allianceWnd import ALLIANCEWND
        from gui.leaderWnd import LEADERWND
        ALLIANCEWND.clearAllianceInfo()
        LEADERWND.clearAllianceInfo()
        
    
    def remote_setAllianceInfo(self,ainfo):
        from gui.allianceWnd import ALLIANCEWND
        from gui.leaderWnd import LEADERWND
        ALLIANCEWND.setAllianceInfo(ainfo)
        LEADERWND.setAllianceInfo(ainfo)
        
    #this could go away
    def remote_setAllianceInvite(self,who):
        from gui.allianceWnd import ALLIANCEWND
        ALLIANCEWND.setInvite(who)
        if who:
            TGEEval("canvas.pushDialog(AllianceWnd);")
        
    #Player trading
    
    def remote_openTradeWindow(self,tradeInfo):
        from gui.tradeWnd import TRADEWND
        TRADEWND.open(tradeInfo)
        
    def remote_closeTradeWindow(self):
        from gui.tradeWnd import TRADEWND
        TRADEWND.close()
        
    #tracking
    def remote_setMuteTime(self,t):
        from irc import SetMuteTime
        SetMuteTime(t)
    
    def remote_setTracking(self,tracking):
        from gui.trackingWnd import TRACKINGWND
        TRACKINGWND.set(tracking)
        
    #conversation
    def remote_setTell(self,teller):
        teller = teller.replace(" ","_")
        TGESetGlobal("$Py::LastTell",teller)
        
    #sound effects
    
    def remote_vocalize(self,sexcode,set,vox,which):
        sex = "Male"
        if sexcode == 1:
            sex = "Female"
        if which < 10:
            num = "0%i"%which
        else:
            num = str(which)
        filename = "vocalsets/%s_LongSet_%s/%s_LS_%s_%s%s.ogg"%(
        sex,set,sex,set,VOCALFILENAMES[vox],num)
        
        
        self.remote_playSound(filename)
        
        
    
    def remote_playSound(self,sound):
        if type(sound) == types.IntType:
            eval = 'alxPlay(alxCreateSource(AudioMessage, "%s/data/sound/%s"));'%(GAMEROOT,SOUNDS[sound])
        else:
            eval = 'alxPlay(alxCreateSource(AudioMessage, "%s/data/sound/%s"));'%(GAMEROOT,sound)
        
       
        TGEEval(eval)
        
    #journal
    
    def remote_addJournalEntry(self,journalEntryID):
        from gui.journalWnd import JOURNALWND
        con = GetMoMClientDBConnection()
        journalTopic,journalEntry,text = con.execute("SELECT topic,entry,text FROM journal_entry WHERE id = %i LIMIT 1;"%journalEntryID).fetchone()
        JOURNALWND.addEntry(journalTopic,journalEntry,text)
        
        
    def remote_openDemoInfoWnd(self,screen):
        
        TGEObject("DEMOINFO_BITMAP").setBitmap("~/data/ui/demo/%s"%screen)
        TGEEval("canvas.pushDialog(DemoInfoWnd);")

        

    def remote_setResurrectNames(self,names):
        if len(names):
            from gui.resurrectionGui import RESURRECTIONWND
            RESURRECTIONWND.set(names)
            TGEEval('Canvas.pushDialog("ResurrectionGui");')
        else:
            TGEEval('Canvas.popDialog("ResurrectionGui");')
    
    def resurrect(self,cname):
        self.perspective.callRemote("PlayerAvatar","onResurrect",cname)
        
    def remote_resurrectionRequest(self,resurrector,xp):
        TGEEval('MessageBoxYesNo("Resurrection", "Would you like to be resurrected by %s with %i%% experience recovery?","Py::OnResurrectAccept();");'%(resurrector,int(xp*100.0)))
        
    def acceptResurrect(self):
        self.perspective.callRemote("PlayerAvatar","onAcceptResurrect")
        
    def chooseAdvancement(self,cname,advancement):
        self.perspective.callRemote("PlayerAvatar","chooseAdvancement",cname,advancement)
        
    def onCraft(self):
        from gui.partyWnd import PARTYWND
        self.perspective.callRemote("PlayerAvatar","onCraft",PARTYWND.curIndex)
    
  
    def remote_setFriendsInfo(self,finfo):
        from gui.friendsWnd import SetFriendsInfo
        SetFriendsInfo(finfo)
        
        
"""
      Con::setIntVariable("ServerInfo::Status",info.status);
      Con::setVariable("ServerInfo::Address",addrString);
      Con::setVariable("ServerInfo::Name",info.name);
      Con::setVariable("ServerInfo::GameType",info.gameType);
      Con::setVariable("ServerInfo::MissionName",info.missionName);
      Con::setVariable("ServerInfo::MissionType",info.missionType);
      Con::setVariable("ServerInfo::State",info.statusString);
      Con::setVariable("ServerInfo::Info",info.infoString);
      Con::setIntVariable("ServerInfo::PlayerCount",info.numPlayers);
      Con::setIntVariable("ServerInfo::MaxPlayers",info.maxPlayers);
      Con::setIntVariable("ServerInfo::BotCount",info.numBots);
      Con::setIntVariable("ServerInfo::Version",info.version);
      Con::setIntVariable("ServerInfo::Ping",info.ping);
      Con::setIntVariable("ServerInfo::CPUSpeed",info.cpuSpeed);
      Con::setBoolVariable("ServerInfo::Favorite",info.isFavorite);
      Con::setBoolVariable("ServerInfo::Dedicated",info.isDedicated());
      Con::setBoolVariable("ServerInfo::Password",info.isPassworded());
"""            

def OnReallyQuit():
    PyDoCommand(("PyDoCommand","/quit"))
    

def OnGameOptionsQuit():
    
    TGEEval('MessageBoxYesNo( "Quit?", "Do you really want to venture forth to reality?", "Py::OnReallyQuit();", "");')

def OnReallyCamp():
    PLAYERMIND.doCommand("CAMP",[0])
    

def OnGameOptionsCamp():
    TGEEval('MessageBoxYesNo("Camp?", "Do you really want to camp and return to the Main Menu?","Py::OnReallyCamp();");')


def formatChatString(sendString):
    # Don't bother with short strings
    if len(sendString) < 7:
        return sendString
    
    if sendString.isupper():
        sendString = sendString.lower()
    
    charList = list(sendString)
    charNum = len(set(charList))
    if charNum < 4:
        TGEEval("""MessageBoxOK("Message ignored", "The chat message you tried to send was filtered out, it didn't seem to make much sense.");""")
        return None
    
    prevChar = ''
    repeatCount = 0
    nonAlphanumCount = 0
    
    for i,char in enumerate(charList):
        # Not more than three non-text characters in a row
        if not char.isalpha() and not char.isdigit():
            nonAlphanumCount += 1
            if nonAlphanumCount > 3:
                charList[i] = ''
                continue
        else:
            nonAlphanumCount = 0
        
        # Don't allow repeating of a specific character more than thrice in a row
        if char == prevChar:
            repeatCount += 1
            if repeatCount > 3:
                charList[i] = ''
        else:
            repeatCount = 0
        prevChar = char
    
    sendString = ''.join(charList)
    
    sendString.replace(' u ', 'you')
    sendString.replace(' r ', 'are')
    
    return sendString


def PyDoCommand(myargs,insertCurChar=True, indexHack = None):
    global LASTCHANNEL
    from gui.partyWnd import PARTYWND
    from mud.client.irc import SendIRCMsg,IRCConnect,Ignore,Unignore,IRCTell, IRCEmote
    curIndex = PARTYWND.curIndex
    
    text = myargs[1]
    
    if text.startswith('/imm'):
        #immortal command
        text = text.split(' ')
        cmd = text[1].upper()
        args = text[2:]

        PLAYERMIND.perspective.callRemote("ImmortalAvatar","command",cmd,args)
        return

    if text.startswith('/gm'):
        #immortal command
        text = text.split(' ')
        cmd = text[1].upper()
        args = text[2:]

        PLAYERMIND.perspective.callRemote("GuardianAvatar","command",cmd,args)
        return
        
    
    if not text.startswith('/'):
        cmd = 'LC' #last channel
        args = [text]
        
    else:
        text = text.split(' ')
        cmd = text[0][1:].upper()
        args = text[1:]
        
    if cmd == "CHANNEL":
        if len(args)==2:
            if args[0].upper() in ("MOM","OFFTOPIC","HELP"):
                on = 0
                if args[1].upper()=="ON":
                    on = 1
                from gui.tomeGui import PyOnGlobalChannelToggle,PyOnOffTopicChannelToggle,PyOnHelpChannelToggle
                if args[0].upper()=="MOM":
                    PyOnGlobalChannelToggle(on)
                elif args[0].upper()=="OFFTOPIC":
                    PyOnOffTopicChannelToggle(on)
                else:
                    PyOnHelpChannelToggle(on)
                return
        
        
    #hack
    if cmd == "LOCALTIME":
        DoClientCommand((0,"/LOCALTIME"))
        return

    if cmd == "IGNORED":
        DoClientCommand((0,"/IGNORED"))
        return

    if cmd == "CLIENT":
        text = text[1:]
        if len(text):
            cmd = "/%s"%' '.join(text)
            DoClientCommand((0,cmd))
        return
    
    if cmd == 'FRIEND':
        if len(args)>=2:
            if args[0].lower()=="add":
                name = ' '.join(args[1:])
                from gui.friendsWnd import OnAddFriend
                OnAddFriend(name)
            elif args[0].lower()=="remove":
                name = ' '.join(args[1:])
                from gui.friendsWnd import OnRemoveFriend
                OnRemoveFriend(name)
    
    if cmd == 'LC':
        if LASTCHANNEL in IRCCHANNELS:
            cmd = LASTCHANNEL
        else:
            args = formatChatString(' '.join(args)).split(' ')
            if not args:
                return
    
    if cmd in CHATCHANNELS:
        LASTCHANNEL = cmd
        if cmd in IRCCHANNELS:
            msg = myargs[1]
            if msg.startswith("/"):
                msg = msg[3:]
            msg = formatChatString(msg)
            if msg:
                SendIRCMsg(cmd,msg)
            return
        else:
            args = formatChatString(' '.join(args)).split(' ')
            if not args:
                return
    
    if cmd == 'MCONNECT' and PLAYERMIND.ircNick:
        IRCConnect(PLAYERMIND.ircNick)
        return
    #elif cmd == 'MCONNECT' and len(args) and len(args[0]):
    #    IRCConnect(args[0])
    #    return
    
    elif cmd == 'T'or cmd == 'TELL':
        IRCTell(args[0], ' '.join(args[1:]))
        return
    elif cmd == 'GE'or cmd == 'GEMOTE':
        args = formatChatString(' '.join(args))
        if args:
            IRCEmote(LASTCHANNEL, args)
        return
    
    elif cmd == 'IGNORE':
        Ignore(' '.join(args))
        return
    elif cmd == 'UNIGNORE':
        Unignore(' '.join(args))
        return
        
    if insertCurChar:
        args.insert(0,curIndex)        
        
    elif indexHack!=None:
        args.insert(0,indexHack)        
        
        
                
    if cmd == "CAMP":
        TGEEval('MessageBoxYesNo("Camp?", "Do you really want to camp and return to the Main Menu?","Py::OnReallyCamp();");')
        return
    
    PLAYERMIND.doCommand(cmd, args)


def PyMissionDownloadComplete():
    from gui.macro import LoadWindowSettings
    
    LoadWindowSettings()
    TGEEval("""
    FadeWnd.fadeinTime = 2000;
    Canvas.pushDialog( FadeWnd );
    """)
    
    from gui.partyWnd import PyOnSendXPSliders
   

    PyOnSendXPSliders([0,1,2,3,4,5])
    
    
    

def PyClearCharTarget():
    try:
        from gui.partyWnd import PARTYWND
        curIndex = PARTYWND.curIndex

        PLAYERMIND.charSetTarget(curIndex,0)
    except:
        pass
    
def OnCharEffect(args):
    cindex,slot = int(args[1]),int(args[2])
    cinfo = PLAYERMIND.charInfos[cindex]
    sinfo = cinfo.SPELLEFFECTS[slot]
    PLAYERMIND.perspective.callRemote("PlayerAvatar","cancelProcess",cinfo.CHARID,sinfo.PID)

#DEMOINFOWIND_LATERBUTTON
#DEMOINFOWIND_PREORDERBUTTON


PREORDER_QUIT = False
def OnPreOrder():
    TGEEval('canvas.popDialog(DemoInfoWnd);')
    
    
    
    global PREORDER_QUIT
    if PREORDER_QUIT:
        TGEEval('gotoWebPage(\"http://www.prairiegames.com/index.php?option=com_content&task=view&id=25\");Py::OnUltimateQuit();')
    else:
        fs = int(TGEGetGlobal("$pref::video::fullscreen"))
        
        if not fs:
            TGEEval('gotoWebPage(\"http://www.prairiegames.com/index.php?option=com_content&task=view&id=25\");')
            return
        
        TGECall("MessageBoxYesNo","Thanks for ordering!","Do you want to exit the game and go to the ordering web page?",'gotoWebPage(\"http://www.prairiegames.com/index.php?option=com_content&task=view&id=25\");Py::OnUltimateQuit();',"")        
        
"""        
        #we're fullscreen, if we can go windowed, do so and go to web page... otherwise, launch brower and quit
        desktop = TGECall("GetDesktopResolution").split(" ")
        xres = int(desktop[0])
        bpp = int(desktop[2])
        
        
        neededx = 1024
        if sys.platform[:6] != 'darwin':
            neededx=1025 #need > 1024 on windows
        if xres >= neededx and bpp>=32:
            TGEEval('setScreenMode( 1024, 768, 32, 0 );')
            TGEEval('gotoWebPage(\"http://www.prairiegames.com/ordering.html\");')
        else:
            #must quit
            TGECall("MessageBoxOK","Thanks for pre-ordering!","The game will now exit and bring you to the pre-ordering web page.","'gotoWebPage(\"http://www.prairiegames.com/ordering.html\");Py::OnUltimateQuit();'")        
"""            

def OnUltimateQuit():
    #I guess one more
    try:
        SPVal = TGEGetGlobal("$Py::ISSINGLEPLAYER")
        if SPVal and (int(SPVal)):
            from mud.worldserver.embedded import ShutdownEmbeddedWorld
            ShutdownEmbeddedWorld()
    except:
        traceback.print_exc()
    
    TGEEval("quit();")

def OnQuit():
    global PREORDER_QUIT
    #HOW MANY QUIT FUNCTIONS DO WE NEED?!?!?!
    if RPG_BUILD_DEMO and DOQUITNAG:
        PREORDER_QUIT = True
        TGEObject("DEMOINFO_BITMAP").setBitmap("~/data/ui/demo/main")        
        TGEObject("DEMOINFOWIND_LATERBUTTON").command = "Py::OnUltimateQuit();"        
        TGEEval("canvas.pushDialog(DemoInfoWnd);")
    else:
        try:
            SPVal = TGEGetGlobal("$Py::ISSINGLEPLAYER")
            if SPVal and (int(SPVal)):
                from mud.worldserver.embedded import ShutdownEmbeddedWorld
                ShutdownEmbeddedWorld()
        except:
            traceback.print_exc()

        TGEEval("quit();")
    
def OnResurrectAccept():
    PLAYERMIND.acceptResurrect()
#"Py::OnCharEffect(5,11);";

def OnCampQuit():
    if not PLAYERMIND:
        return
    
    PLAYERMIND.campQuit()
    

TGEExport(PyMissionDownloadComplete,"Py","MissionDownloadComplete","desc",1,1)
TGEExport(PyDoCommand,"Py","DoCommand","desc",2,2)
TGEExport(OnGameOptionsCamp,"Py","OnGameOptionsCamp","desc",1,1)
TGEExport(OnGameOptionsQuit,"Py","OnGameOptionsQuit","desc",1,1)
TGEExport(OnCharEffect,"Py","OnCharEffect","desc",3,3)
TGEExport(OnReallyCamp,"Py","OnReallyCamp","desc",1,1)
TGEExport(OnReallyQuit,"Py","OnReallyQuit","desc",1,1)
TGEExport(OnQuit,"Py","OnQuit","desc",1,1)
TGEExport(OnUltimateQuit,"Py","OnUltimateQuit","desc",1,1)
TGEExport(OnPreOrder,"Py","OnPreOrder","desc",1,1)
TGEExport(OnCampQuit,"Py","OnCampQuit","desc",1,1)

TGEExport(OnResurrectAccept,"Py","OnResurrectAccept","desc",1,1)


TGEExport(PyClearCharTarget,"Py","ClearCharTarget","desc",1,1)