# Import smtplib for the actual sending function
import smtplib

# Import the email modules we'll need
from email.MIMEText import MIMEText

from mud.gamesettings import GAMEROOT

SUPPORTEMAIL_ADDRESS = ""
SUPPORTEMAIL_PASSWORD = ""

def ConfigureEmail(config):
    global SUPPORTEMAIL_ADDRESS,SUPPORTEMAIL_PASSWORD
    SUPPORTEMAIL_ADDRESS = config["Support Email Address"]
    SUPPORTEMAIL_PASSWORD = config["Support Email Password"]

def NewPlayerEmail(to,publicName,password, regkey,fromProduct):

    emailpw = SUPPORTEMAIL_PASSWORD
    me = SUPPORTEMAIL_ADDRESS
    
    if not fromProduct:
        body = FREE_BODY%(publicName,regkey,password)

    else:
        body = PREMIUM_BODY%(publicName,regkey,password)
    
    msg = MIMEText(body)
    
    if fromProduct:
        msg['Subject'] = PREMIUM_SUBJECT
    else:
        msg['Subject'] = FREE_SUBJECT
        
    msg['From'] = me
    msg['To'] = to

    #hrm this will block
    s = smtplib.SMTP()
    #s.set_debuglevel(1)
    s.connect('smtp.prairiegames.com',25)
    #XXX we must remove login information, it will be a command line option
    s.login("support@prairiegames.com",emailpw)
    s.sendmail(me, [to], msg.as_string())
    msg['To'] = "support@prairiegames.com"
    s.sendmail(me, "support@prairiegames.com", msg.as_string())
    s.close()


def LostPasswordEmail(to,publicName,password):

    emailpw = SUPPORTEMAIL_PASSWORD
    me = SUPPORTEMAIL_ADDRESS
    
    body = """Hello %s,

Your master account password is: %s (case sensitive)

Please do not share this password with anyone.

You are receiving this email because someone requested your password.  If this person wasn't you,
please email support@prairiegames.com with your public name.

Play Nice Policy
http://www.prairiegames.com/index.php?option=com_content&task=view&id=22&Itemid=38
 
Chat Channel Usage
http://www.prairiegames.com/phpBB2/viewtopic.php?t=2892
 
Online Terms of Use
http://www.prairiegames.com/index.php?option=com_content&task=view&id=35&Itemid=50

Have fun!!!,
The Team at Prairie Games
"""%(publicName,password)
    
    msg = MIMEText(body)
    
    msg['Subject'] = PASSWORD_SUBJECT
        
    msg['From'] = me
    msg['To'] = to

    #hrm this will block
    s = smtplib.SMTP()
    #s.set_debuglevel(1)
    s.connect('smtp.prairiegames.com',25)
    #XXX we must remove login information, it will be a command line option
    s.login("support@prairiegames.com",emailpw)
    s.sendmail(me, [to], msg.as_string())
    msg['To'] = "support@prairiegames.com"
    s.sendmail(me, "support@prairiegames.com", msg.as_string())
    s.close()


#break these out

if GAMEROOT == "minions.of.mirth":

    PASSWORD_SUBJECT = "Minions of Mirth: Password Request"

    FREE_SUBJECT = "Minions of Mirth: Free Edition Registration"

    PREMIUM_SUBJECT = "Minions of Mirth: Registration Information"

    FREE_BODY = """Hello,

    Thank you for playing the Minions of Mirth Free Edition!!!

    For ordering information, please see: http://www.prairiegames.com/ordering.html

    Please use the information below to login to your account.  

    Public Login Name: 
    %s (case sensitive)

    Registration Key:
    %s

    Password:
    %s (case sensitive)

    Email support@prairiegames.com if there are any problems with your account.

    Play Nice Policy
    http://www.prairiegames.com/index.php?option=com_content&task=view&id=22&Itemid=38
     
    Chat Channel Usage
    http://www.prairiegames.com/phpBB2/viewtopic.php?t=2892
     
    Online Terms of Use
    http://www.prairiegames.com/index.php?option=com_content&task=view&id=35&Itemid=50

    Have fun!!!,
    The Team at Prairie Games
    """

    PREMIUM_BODY="""Hello,

    Thank you for registering Minions of Mirth!!!

    Please use the information below to login to your account.

    Public Login Name: 
    %s (case sensitive)

    Registration Key:
    %s

    Password:
    %s (case sensitive)

    Email support@prairiegames.com if there are any problems with your account.

    Play Nice Policy
    http://www.prairiegames.com/index.php?option=com_content&task=view&id=22&Itemid=38
     
    Chat Channel Usage
    http://www.prairiegames.com/phpBB2/viewtopic.php?t=2892
     
    Online Terms of Use
    http://www.prairiegames.com/index.php?option=com_content&task=view&id=35&Itemid=50

    Have fun!!!,
    The Team at Prairie Games
    """
    
else:
    
    PASSWORD_SUBJECT = "MMO Technology (Preview): Password Request"

    FREE_SUBJECT = "MMO Technology (Preview): Registration Information"

    PREMIUM_SUBJECT = "MMO Technology (Preview): Registration Information"

    PREMIUM_BODY = FREE_BODY = """Hello,
    
    Please use the information below to login to your account.  

    Public Login Name: 
    %s (case sensitive)

    Registration Key:
    %s

    Password:
    %s (case sensitive)

    Email support@prairiegames.com if there are any problems with your account.

    Have fun!!!,
    Prairie Games and GarageGames
    """

