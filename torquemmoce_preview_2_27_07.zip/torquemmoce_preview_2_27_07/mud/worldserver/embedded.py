
#EMBEDDED world server, yargh!

import time
import traceback,sys
from tgenative import *
from mud.world.core import CoreSettings
from mud.gamesettings import *

from mud.tgepython.console import TGEExport


WORLDSERVER = None
MANHOLE = None


STARTZONE = "trinst"
STARTTRANSFORM = "17.699 -288.385 121.573 0 0 1 35.9607"

if GAMEROOT != "minions.of.mirth":
    if not USE_TGEA:
        STARTTRANSFORM = "-7.57105 -129.541 84 0 0 -1 59.0197"
    else:
        STARTTRANSFORM = "380.612 226.454 31.255 0 0 1 230.701"

DSTARTZONE = "kauldur"
DSTARTTRANSFORM = "-203.48 -395.96 150.1 0 0 1 38.92"

MSTARTZONE = "trinst"
MSTARTTRANSFORM = "-169.032 -315.986 150.9353 0 0 1 10.681"


def CreatePlayer():
    from mud.world.player import Player,PlayerXPCredit
    from mud.common.permission import User,Role
    
    try:
        Player.byPublicName("ThePlayer")
    except:
        traceback.print_exc()
        
        #move me
        global STARTZONE
        global STARTTRANSFORM
        from mud.world.zone import Zone
        zone = Zone.byName(STARTZONE)
        dzone = Zone.byName(DSTARTZONE)
        mzone = Zone.byName(MSTARTZONE)
        
        p = Player(publicName="ThePlayer",password="ThePlayer",fantasyName="ThePlayer",logZone=zone,bindZone=zone,darknessLogZone=dzone,darknessBindZone=dzone,
        monsterLogZone=mzone,monsterBindZone=mzone)
        #temp
        
        p.logTransformInternal= STARTTRANSFORM
        p.bindTransformInternal= STARTTRANSFORM
        p.darknessLogTransformInternal= DSTARTTRANSFORM
        p.darknessBindTransformInternal= DSTARTTRANSFORM
        p.monsterLogTransformInternal= MSTARTTRANSFORM
        p.monsterBindTransformInternal= MSTARTTRANSFORM
        
        user = User(name="ThePlayer",password="ThePlayer")
        user.addRole(Role.byName("Player"))
        user.addRole(Role.byName("Immortal"))
        
def ShutdownEmbeddedWorld():
    global WORLDSERVER,MANHOLE
    from mud.world.theworld import World
    from mud.common.dbconfig import SetDBConnection
    
    if not WORLDSERVER:
        return
    
    world = World.byName("TheWorld")
    world.shutdown()
    WORLDSERVER.shutdown()
    WORLDSERVER = None
    
    if MANHOLE:
        MANHOLE.stopListening()
    
    MANHOLE = None
    SetDBConnection(None)
    
        
def SetupEmbeddedWorld(worldname):
    
    global WORLDSERVER
    global MANHOLE
    
    #create a single player world
    import os
    from mud.common.dbconfig import SetDBConnection
    
    DATABASE = "sqlite:///"+os.getcwd()+("/%s/data/worlds/singleplayer/"%(GAMEROOT))+worldname+"/world.db"
        
    SetDBConnection(DATABASE,True)
    
    
    import mud.world.newplayeravatar
    import mud.world.playeravatar
    import mud.world.simavatar
    from   mud.common.avatar import RoleAvatar
    
    from mud.common.permission import User,Role
    
            
    #destroy the new player user, and recreate
    try:
        user = User.byName("NewPlayer")
        user.destroySelf()
    except:
        pass
        
    CreatePlayer()
    
    
    #--- Application
    
    from twisted.spread import pb
    from twisted.internet import reactor
    from twisted.cred.credentials import UsernamePassword
    
    from mud.server.app import Server
    
    
    WORLDSERVER = server = Server(3013)
    server.startServices()
    
    
            
    #kickstart the heart
    from mud.world.theworld import World
    world = World.byName("TheWorld")
    
    #TODO, single player backups
    #world.dbFile = os.getcwd()+"/minions.of.mirth/data/worlds/singleplayer/"+worldname+"/world.db"
    
    try:
        v = int(TGEGetGlobal("$pref::gameplay::difficulty"))
        
    except:
        v = 0
        TGESetGlobal("$pref::gameplay::difficulty",0)
    
    try:    
        respawn = float(TGEGetGlobal("$pref::gameplay::monsterrespawn"))
    except:
        TGESetGlobal("$pref::gameplay::monsterrespawn",0.0)
        respawn = 0.0
    
    
    if v ==1:
        CoreSettings.DIFFICULTY = 0
    elif v ==2:
        CoreSettings.DIFFICULTY = 2
    else:
        CoreSettings.DIFFICULTY = 1
        
    CoreSettings.RESPAWNTIME = respawn
    
    
        
    CoreSettings.SINGLEPLAYER = True
    world.launchTime = time.time()
    world.singlePlayer = True
    
    
    world.startup()
    world.transactionTick()
    
    world.tick()
    
    #fire up web access
    #from mud.worldweb.webserver import Start
    #Start()
    

    
    #telnet access
    #import telnet
    
    #try:
    #    from manhole import MakeFactory
    #    ips = ["127.0.0.1"]
    #    f= MakeFactory(ips,"me","me")
    #    MANHOLE = reactor.listenTCP(22, f)
    #except:
    #    print "Warning: Couldn't create single player manhole"

    
    
    
    
    
    
