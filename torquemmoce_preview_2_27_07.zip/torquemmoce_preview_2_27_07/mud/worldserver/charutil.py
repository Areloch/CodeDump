
#utilities for the character server's central store, this is located here primarily so it's not included in the
#world server sources (although, it could be and we could just provide pyc

import time
from mud.world.defines import *
from mud.common.dbconfig import GetDBURI
from twisted.internet import reactor
import traceback

from sqlite3 import dbapi2 as sqlite
import os,re,zlib

PLAYER_TABLES = ["player","player_monster_spawn","item","item_variant"]

CHARACTER_TABLES= ["character","character_spell","character_skill","character_advancement","character_dialog_choice","character_vault_item","character_faction",
"spawn","spawn_skill","spawn_resistance","spawn_spell","spawn_stat","item","item_variant","spell_store"]

TABLES = PLAYER_TABLES[:]
TABLES.extend(CHARACTER_TABLES)


TVALUES = {}

TATTR = {}

CREATE_PLAYER_TABLE_SQL = ""
CREATE_CHARACTER_TABLE_SQL = ""

PLAYER_BUFFERS = []

CLUSTER = -1

def SetClusterNum(cluster):
    global CLUSTER
    CLUSTER = cluster

def GenerateInsertValues(table,valuesIn,playerID=None,characterID=None,spawnID=None,itemID=None):
    valuesOut = []
    for valueIn in valuesIn:
        valueOut = []
        
        for col,v in zip(TATTR[table],valueIn):
            if col == 'id':
                valueOut.append(None)
            elif col == 'playerID':
                valueOut.append(playerID)
            elif col == 'characterID':
                valueOut.append(characterID)
            elif col == 'itemID':
                valueOut.append(itemID)
            elif col == 'spawnID':
                valueOut.append(spawnID)
            else:
                valueOut.append(v)
        
        valuesOut.append(valueOut)
    
    return valuesOut
    
def InstallCharacterBuffer(playerID,cname,buffer):
    from mud.world.player import Player
    tm = time.time()
    
    if not os.path.exists("data/tmp"):
        os.makedirs("data/tmp")
    
    try:
        dbuffer = zlib.decompress(buffer)
        f = file("data/tmp/character%i.db"%CLUSTER,"wb")
        f.write(dbuffer)
        f.close()
        
        dbconn = sqlite.connect("data/tmp/character%i.db"%CLUSTER)
        cursor = dbconn.cursor()
        dstConn = Player._connection.getConnection()    
        dstCursor = dstConn.cursor()
    except:
        traceback.print_exc()
        return True
    
    error = False
    
    dstCursor.execute("END TRANSACTION;")
    dstCursor.execute("BEGIN TRANSACTION;")
    
    try:
        #character tables

        #character name and spawn name in buffer can be at odds based on rename
        #in fact rename doesn't check spawn names and must
        cursor.execute("SELECT name FROM character;")
        name = cursor.fetchone()[0]
        if name!=cname:
            cursor.execute("UPDATE character SET name = '%s' WHERE name = '%s';"%(cname,name))

        cursor.execute("SELECT name FROM spawn;")
        name = cursor.fetchone()[0]
        if name!=cname:
            cursor.execute("UPDATE spawn SET name = '%s' WHERE name = '%s';"%(cname,name))

        
        cursor.execute("SELECT * FROM character where name = '%s';"%cname)
        cvalues = cursor.fetchone()
        cid = cvalues[0] #for look up        
        values = GenerateInsertValues('character',(cvalues,),playerID)
        sql = 'INSERT INTO character VALUES(%s)'%(TVALUES['character'])
        try:
            dstCursor.executemany(sql,values)
        except:
            traceback.print_exc()
            print sql,values
            raise "Error installing character",cname
        characterID = dstCursor.lastrowid
        #generate spawn
        cursor.execute("SELECT * FROM spawn WHERE character_id = %i;"%cid)
        svalues = cursor.fetchall()
        sid = svalues[0][0]
        values = GenerateInsertValues('spawn',svalues,playerID,characterID)
        dstCursor.executemany('INSERT INTO spawn VALUES(%s)'%(TVALUES['spawn']),values)
        spawnID = dstCursor.lastrowid
        #update character with spawnID now that we have it
        dstCursor.execute("UPDATE character SET spawn_id = %i WHERE id = %i;"%(spawnID,characterID))
        
        #character tables
        ctables = ["character_spell","character_skill","character_advancement","character_dialog_choice","spell_store","character_faction"]
        for t in ctables:
            cursor.execute("SELECT * FROM %s WHERE character_id = %i;"%(t,cid))
            values = GenerateInsertValues(t,cursor.fetchall(),playerID,characterID,spawnID)
            dstCursor.executemany('INSERT INTO %s VALUES(%s)'%(t,TVALUES[t]),values)
            
        #items
        cursor.execute("SELECT * FROM item WHERE character_id = %i;"%cid)
        
        for ivalues in cursor.fetchall():
            iid = ivalues[0] #for lookup
            values = GenerateInsertValues('item',(ivalues,),None,characterID,spawnID) #player_id is none for bank
            dstCursor.executemany('INSERT INTO item VALUES(%s)'%(TVALUES['item']),values)
            itemID = dstCursor.lastrowid
            #item variants
            cursor.execute("SELECT * FROM item_variant WHERE item_id = %i;"%iid)
            values = GenerateInsertValues('item_variant',cursor.fetchall(),playerID,characterID,spawnID,itemID)
            dstCursor.executemany('INSERT INTO item_variant VALUES(%s)'%(TVALUES['item_variant']),values)

        #character vault items
        cursor.execute("SELECT item_id FROM character_vault_item WHERE character_id = %i;"%cid)
        for itemid in cursor.fetchall():
            id = itemid[0]        
            cursor.execute("SELECT * FROM item WHERE id = %i;"%id)
            for ivalues in cursor.fetchall():
                iid = ivalues[0] #for lookup
                values = GenerateInsertValues('item',(ivalues,),None,None,spawnID) #player_id is none for bank
                dstCursor.executemany('INSERT INTO item VALUES(%s)'%(TVALUES['item']),values)
                itemID = dstCursor.lastrowid
                #item variants
                cursor.execute("SELECT * FROM item_variant WHERE item_id = %i;"%iid)
                values = GenerateInsertValues('item_variant',cursor.fetchall(),playerID,characterID,spawnID,itemID)
                dstCursor.executemany('INSERT INTO item_variant VALUES(%s)'%(TVALUES['item_variant']),values)
                
                cursor.execute("SELECT * FROM character_vault_item WHERE item_id = %i;"%iid)
                values = GenerateInsertValues('character_vault_item',cursor.fetchall(),playerID,characterID,spawnID,itemID)
                dstCursor.executemany('INSERT INTO character_vault_item VALUES(%s)'%(TVALUES['character_vault_item']),values)

            
        #spawn tables
        stables = ["spawn_skill","spawn_resistance","spawn_spell","spawn_stat"]
        
        for t in stables:
            cursor.execute("SELECT * FROM %s WHERE spawn_id = %i;"%(t,sid))
            values = GenerateInsertValues(t,cursor.fetchall(),playerID,characterID,spawnID)
            dstCursor.executemany('INSERT INTO %s VALUES(%s)'%(t,TVALUES[t]),values)
                
        #print "whee"
        dstCursor.execute('END TRANSACTION;')
    except:
        error = True
        traceback.print_exc()
        dstCursor.execute('ROLLBACK TRANSACTION;')
        
        
    dstCursor.execute('BEGIN TRANSACTION;')
    
    dstCursor.close()
    #dstConn.close()
    cursor.close()
    dbconn.close()
    
    print "Character intallation took %f seconds"%(time.time()-tm)
    
    return error


    

def InstallPlayerBuffer(buffer):
    global CREATE_PLAYER_TABLE_SQL
    if not CREATE_PLAYER_TABLE_SQL:
        Initialize()
    tm = time.time()
    from mud.world.player import Player
    
    if not os.path.exists("data/tmp"):
        os.makedirs("data/tmp")


    try:
        dbuffer = zlib.decompress(buffer)
        f = file("data/tmp/player%i.db"%CLUSTER,"wb")
        f.write(dbuffer)
        f.close()
        
        dbconn = sqlite.connect("data/tmp/player%i.db"%CLUSTER)
        cursor = dbconn.cursor()
        dstConn = Player._connection.getConnection()    
        dstCursor = dstConn.cursor()
    except:
        traceback.print_exc()
        return True
        
    error = False
    
    dstCursor.execute("END TRANSACTION;")
    dstCursor.execute("BEGIN TRANSACTION;")
    try:
        cursor.execute("SELECT * FROM player;")
        values = GenerateInsertValues('player',cursor.fetchall())
        print TVALUES['player'],values
        dstCursor.executemany('INSERT INTO player VALUES(%s)'%(TVALUES['player']),values)
        playerID = dstCursor.lastrowid
    
        #player tables
        ptables = ["player_monster_spawn"]
        for t in ptables:
            cursor.execute("SELECT * FROM %s;"%(t))
            values = GenerateInsertValues(t,cursor.fetchall(),playerID)
            dstCursor.executemany('INSERT INTO %s VALUES(%s)'%(t,TVALUES[t]),values)
            
        #bank items
        cursor.execute("SELECT * FROM item;")
        
        for ivalues in cursor.fetchall():
            iid = ivalues[0] #for lookup
            values = GenerateInsertValues('item',(ivalues,),playerID,None,None)
            dstCursor.executemany('INSERT INTO item VALUES(%s)'%(TVALUES['item']),values)
            itemID = dstCursor.lastrowid
            #item variants
            cursor.execute("SELECT * FROM item_variant WHERE item_id = %i;"%iid)
            values = GenerateInsertValues('item_variant',cursor.fetchall(),playerID,None,None,itemID)
            dstCursor.executemany('INSERT INTO item_variant VALUES(%s)'%(TVALUES['item_variant']),values)


    
        #character tables
        if 0:
            cursor.execute("SELECT * FROM character;")
            for cvalues in cursor.fetchall():
                cid = cvalues[0] #for look up        
                values = GenerateInsertValues('character',(cvalues,),playerID)
                dstCursor.executemany('INSERT INTO character VALUES(%s)'%(TVALUES['character']),values)
                characterID = dstCursor.lastrowid
                #generate spawn
                cursor.execute("SELECT * FROM spawn WHERE character_id = %i;"%cid)
                svalues = cursor.fetchall()
                sid = svalues[0][0]
                values = GenerateInsertValues('spawn',svalues,playerID,characterID)
                dstCursor.executemany('INSERT INTO spawn VALUES(%s)'%(TVALUES['spawn']),values)
                spawnID = dstCursor.lastrowid
                #update character with spawnID now that we have it
                dstCursor.execute("UPDATE character SET spawn_id = %i WHERE id = %i;"%(spawnID,characterID))
                
                #character tables
                ctables = ["character_spell","character_skill","character_advancement","character_dialog_choice","spell_store","character_faction"]
                for t in ctables:
                    cursor.execute("SELECT * FROM %s WHERE character_id = %i;"%(t,cid))
                    values = GenerateInsertValues(t,cursor.fetchall(),playerID,characterID,spawnID)
                    dstCursor.executemany('INSERT INTO %s VALUES(%s)'%(t,TVALUES[t]),values)
                    
                #items
                cursor.execute("SELECT * FROM item WHERE character_id = %i;"%cid)
                
                for ivalues in cursor.fetchall():
                    iid = ivalues[0] #for lookup
                    values = GenerateInsertValues('item',(ivalues,),playerID,characterID,spawnID)
                    dstCursor.executemany('INSERT INTO item VALUES(%s)'%(TVALUES['item']),values)
                    itemID = dstCursor.lastrowid
                    #item variants
                    cursor.execute("SELECT * FROM item_variant WHERE item_id = %i;"%iid)
                    values = GenerateInsertValues('item_variant',cursor.fetchall(),playerID,characterID,spawnID,itemID)
                    dstCursor.executemany('INSERT INTO item_variant VALUES(%s)'%(TVALUES['item_variant']),values)
                    
                #spawn tables
                stables = ["spawn_skill","spawn_resistance","spawn_spell","spawn_stat"]
                
                for t in stables:
                    cursor.execute("SELECT * FROM %s WHERE spawn_id = %i;"%(t,sid))
                    values = GenerateInsertValues(t,cursor.fetchall(),playerID,characterID,spawnID)
                    dstCursor.executemany('INSERT INTO %s VALUES(%s)'%(t,TVALUES[t]),values)
                
        #print "whee"
        dstCursor.execute('END TRANSACTION;')
    except:
        error = True
        traceback.print_exc()
        dstCursor.execute('ROLLBACK TRANSACTION;')
        
        
    dstCursor.execute('BEGIN TRANSACTION;')
    
    dstCursor.close()
    #dstConn.close()
    cursor.close()
    dbconn.close()
    
    print "Player intallation took %f seconds"%(time.time()-tm)
    
    return error


def Initialize():
    global CREATE_PLAYER_TABLE_SQL,CREATE_CHARACTER_TABLE_SQL
    
    dbconn = sqlite.connect(GetDBURI()[10:])#chars[0]._connection.getConnection()    
    cursor = dbconn.cursor()

    CREATE_PLAYER_TABLE_SQL = ""
    for t in PLAYER_TABLES:
        cursor.execute('PRAGMA table_info(%s);'%t)
        
        TATTR[t]=[]
    
        sql = "CREATE TABLE %s ("%t
        c = 0
        for col in cursor.fetchall():
            TATTR[t].append(UnderToMixed(col[1]))
            sql+="%s %s, "%(col[1],col[2])
            c+=1
        TVALUES[t] = ','.join('?'*c)  # lambda?
        sql=sql[:-2]+");"
        CREATE_PLAYER_TABLE_SQL += sql

    CREATE_CHARACTER_TABLE_SQL = ""
    for t in CHARACTER_TABLES:
        cursor.execute('PRAGMA table_info(%s);'%t)
        
        TATTR[t]=[]
    
        sql = "CREATE TABLE %s ("%t
        c = 0
        for col in cursor.fetchall():
            TATTR[t].append(UnderToMixed(col[1]))
            sql+="%s %s, "%(col[1],col[2])
            c+=1
        TVALUES[t] = ','.join('?'*c)  # lambda?
        sql=sql[:-2]+");"
        CREATE_CHARACTER_TABLE_SQL += sql
        
        
    cursor.close()
    dbconn.close()

def ExtractPlayer(publicName,pid,cid,append=True):
    from mud.world.player import Player
    #commit current transaction so we are current
    conn = Player._connection.getConnection()
    c = conn.cursor()
    c.execute("END TRANSACTION;")
    c.execute("BEGIN TRANSACTION;")
    c.close()
    return ExtractCharactersThread(publicName,pid,cid,append)

def ExtractCharactersThread(publicName,pid,cid,append=True):
    global CREATE_PLAYER_TABLE_SQL
    
    from mud.world.player import Player
    
    
    
    try:
        try:
            os.remove("export%i.db"%CLUSTER)
        except:
            pass
    
        #commit current transaction
        dbconn = sqlite.connect(GetDBURI()[10:])#chars[0]._connection.getConnection()    
        cursor = dbconn.cursor()
        exconn = sqlite.connect("export%i.db"%CLUSTER,isolation_level = None)
        excursor = exconn.cursor()
        excursor.execute("BEGIN TRANSACTION;")    
        
        if not CREATE_PLAYER_TABLE_SQL:
            Initialize()
        
        tm = time.time()
        excursor.executescript(CREATE_PLAYER_TABLE_SQL)
                
        #copy player information
        cursor.execute("SELECT * FROM player WHERE id = %i;"%pid)
        excursor.executemany('INSERT INTO player VALUES(%s)'%(TVALUES['player']),cursor.fetchall())
        
        #player tables
        ptables = ["player_monster_spawn","item"]
        for t in ptables:
            cursor.execute("SELECT * FROM %s WHERE player_id = %i;"%(t,pid))
            excursor.executemany('INSERT INTO %s VALUES(%s)'%(t,TVALUES[t]),cursor.fetchall())
            
        #rotten bank
        cursor.execute("SELECT id FROM item WHERE player_id = %i;"%pid)    
        
        itemIds = []
        for v in cursor.fetchall():
            itemIds.append(v[0])
            
        for id in itemIds:
            cursor.execute("SELECT * FROM item_variant WHERE item_id = %i;"%id)    
            excursor.executemany('INSERT INTO item_variant VALUES(%s)'%(TVALUES['item_variant']),cursor.fetchall())            

        
        excursor.execute("END;")
        
        excursor.close()
        exconn.close()
        
        
        f=file("export%i.db"%CLUSTER,"rb")
        buff = f.read()
        f.close()
        pbuffer = zlib.compress(buff)
        
        #character export
        
        try:
            os.remove("cexport%i.db"%CLUSTER)
        except:
            pass
    
        #commit current transaction
        exconn = sqlite.connect("cexport%i.db"%CLUSTER,isolation_level = None)
        excursor = exconn.cursor()
        excursor.execute("BEGIN TRANSACTION;")    
        
        tm = time.time()
        excursor.executescript(CREATE_CHARACTER_TABLE_SQL)
        
        
    
        cursor.execute("SELECT * FROM character WHERE id = %i;"%cid)
        excursor.executemany('INSERT INTO character VALUES(%s)'%(TVALUES['character']),cursor.fetchall())                
        
        
        ctables = ["character_spell","character_skill","character_advancement","character_dialog_choice","spell_store","character_faction"]
        for t in ctables:
            cursor.execute("SELECT * FROM %s WHERE character_id = %i;"%(t,cid))
            excursor.executemany('INSERT INTO %s VALUES(%s)'%(t,TVALUES[t]),cursor.fetchall())                
        #items
        cursor.execute("SELECT * FROM item WHERE character_id = %i;"%cid)    
        excursor.executemany('INSERT INTO item VALUES(%s)'%(TVALUES['item']),cursor.fetchall())
        
        cursor.execute("SELECT id FROM item WHERE character_id = %i;"%cid)    
        
        itemIds = []
        for v in cursor.fetchall():
            itemIds.append(v[0])
            
        for id in itemIds:
            cursor.execute("SELECT * FROM item_variant WHERE item_id = %i;"%id)    
            excursor.executemany('INSERT INTO item_variant VALUES(%s)'%(TVALUES['item_variant']),cursor.fetchall())            
            
        cursor.execute("SELECT * FROM character_vault_item WHERE character_id = %i;"%cid)    
        excursor.executemany('INSERT INTO character_vault_item VALUES(%s)'%(TVALUES['character_vault_item']),cursor.fetchall())   

        
        #vault items
        cursor.execute("SELECT item_id FROM character_vault_item WHERE character_id = %i;"%cid)
        for itemID in cursor.fetchall():
            itemID = itemID[0]
            cursor.execute("SELECT * FROM item WHERE id = %i;"%itemID)
            excursor.executemany('INSERT INTO item VALUES(%s)'%(TVALUES['item']),cursor.fetchall())   
            cursor.execute("SELECT * FROM item_variant WHERE item_id = %i;"%itemID)    
            excursor.executemany('INSERT INTO item_variant VALUES(%s)'%(TVALUES['item_variant']),cursor.fetchall())            
            
        
        
        
        #spawn info

        cursor.execute("SELECT name,race,pclass_internal,sclass_internal,tclass_internal,plevel,slevel,tlevel,realm FROM spawn WHERE character_id = '%i';"%cid)        
        cvalues = cursor.fetchone()
        
        cursor.execute("SELECT * FROM spawn WHERE character_id = %i;"%cid)    
        v = cursor.fetchone()
        sid = v[0]
        excursor.executemany('INSERT INTO spawn VALUES(%s)'%(TVALUES['spawn']),(v,))
        
        stables = ["spawn_skill","spawn_resistance","spawn_spell","spawn_stat"]
        
        for t in stables:
            cursor.execute("SELECT * FROM %s WHERE spawn_id = %i;"%(t,sid))
            excursor.executemany('INSERT INTO %s VALUES(%s)'%(t,TVALUES[t]),cursor.fetchall())                    
            
        excursor.execute("END;")
        
        excursor.close()
        exconn.close()
        
        
        f=file("cexport%i.db"%CLUSTER,"rb")
        buff = f.read()
        f.close()
        cbuffer = zlib.compress(buff)
        
        cursor.close()
    
        v = (publicName,pbuffer,cbuffer,cvalues)
        if append:
            PLAYER_BUFFERS.append(v)
        
        print "Character export took %f seconds"%(time.time()-tm)
        return v

    except:
        traceback.print_exc()
        return None
    
    

_UnderToMixedRE = re.compile('_.')
def UnderToMixed(name):
    if name.endswith('_id'):
        return UnderToMixed(name[:-3] + "ID")
    return _UnderToMixedRE.sub(lambda m: m.group(0)[1].upper(),
                               name)

