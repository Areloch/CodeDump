

def ConfigureServer(DBNAME):
    import sys,os
    
    options={"database":""}
    
    database = ""
    
    # String options
    for option in ['database']:
        for x in xrange(len(sys.argv)):
            if sys.argv[x].find(option) == 0:
                pos = sys.argv[x].find('=') + 1
                if pos > 0 and options.has_key(option):
                    options[option]=sys.argv[x][pos:]
                    sys.argv[x] = ''
    
    DATABASE=options['database']
    
    from mud.common.dbconfig import SetDBConnection
    
    if not os.path.exists(DATABASE):
        os.makedirs(DATABASE)
    SetDBConnection('sqlite:/%s/%s'%(DATABASE,DBNAME))

def LoadConfiguration(config):
    from ConfigParser import SafeConfigParser
    
    parser = SafeConfigParser()
    parser.read("./serverconfig/server.cfg")
    
    #Patch Server
    s = parser.get("Master Server","Patch Server Premium")
    up,address = s.split("@")
    user,password = up.split(":")
    
    config["Patch Server Premium"]=(address,user,password)
    
    s = parser.get("Master Server","Patch Server Demo")
    up,address = s.split("@")
    user,password = up.split(":")
    
    config["Patch Server Demo"]=(address,user,password)
    
    #Master Port
    config["Master IP"] = parser.get("Master Server","Master IP")
    config["Master Port"] = int(parser.get("Master Server","Master Port"))
    
    #World
    config["World Username"] = parser.get("Master Server","World Username")
    config["World Password"] = parser.get("Master Server","World Password")
    
    #Manhole
    config["Manhole Username"] = parser.get("Master Server","Manhole Username")
    config["Manhole Password"] = parser.get("Master Server","Manhole Password")
    config["Manhole Port"] = int(parser.get("Master Server","Manhole Port"))
    
    #Character Server
    config["Character Server Password"] = parser.get("Master Server","Character Server Password")

    #Support Email
    config["Support Email Address"] = parser.get("Master Server","Support Email Address")
    config["Support Email Password"] = parser.get("Master Server","Support Email Password")
    
