#master server services provided by world daemon

#we need to announce, etc