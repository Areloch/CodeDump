
#world daemon, log into world server, tell it to shutdown in 10 minutes
#world kills all zones

from twisted.cred.portal import Portal
from twisted.cred.checkers import InMemoryUsernamePasswordDatabaseDontUse
from twisted.internet import reactor
from zope.interface import implements
from twisted.spread import pb
from twisted.cred.portal import IRealm
import os,sys,imp
from twisted.python import components, failure, log
from twisted.cred.credentials import UsernamePassword


import math
import win32api,win32con,win32event
import time,traceback

from mud.gamesettings import *

ANNOUNCECALLBACK = None

#the first cluster is the announce server, where players will initially connect and should probably be low cpu usage

WORLDIMPS = {}

REMOTECLUSTERS = []

ZONECLUSTERS = []

WORLDNAME = None
PUBLICNAME = None
PASSWORD = None

for arg in sys.argv:
    if arg.startswith('-worldname='):
        WORLDNAME = arg[11:]
    if arg.startswith('-publicname='):
        PUBLICNAME = arg[12:]
    if arg.startswith('-password='):
        PASSWORD = arg[10:]

if not WORLDNAME or not PUBLICNAME or not PASSWORD:
    print "Usage: WorldDaemon -worldname=MYWORLD -publicname=MYPUBLICNAME -password=MYPASSWORD"
    raise "Incorrect Usage"

class BadConnectionError(Exception):
    def __str__(self):
        return "Bad Connection"

#military time!
REBOOT = True
REBOOT_HOUR = 3
REBOOT_MINUTE = 0
REBOOT_TIME = time.time()
ANNOUNCE_MINUTE = -1

FORCEKILL_TIME = None

KILLED = False

SPAWNED = False

def AnnounceShutdownReboot():
    for z in ZONECLUSTERS:
        try:
            if REBOOT:
                z.mind.callRemote("announceReboot",ANNOUNCE_MINUTE)
            else:
                z.mind.callRemote("announceShutdown",ANNOUNCE_MINUTE)
        except:
            pass
        

def Tick():
    global REBOOT_TIME, ANNOUNCE_MINUTE,FORCEKILL_TIME,ANNOUNCECALLBACK,KILLED,REBOOT,SPAWNED,ZONECLUSTERS
    from worldservices import ZoneClusterAvatar
    
    reactor.callLater(15,Tick)
    
    if KILLED and len(ZoneClusterAvatar.avatars):
        return
    elif KILLED and not REBOOT:
        reactor.stop()
        return
    elif KILLED and REBOOT:
        print "Rebooting"
        KILLED = False
        SpawnWorld()
        return
    
    #are we live?
    if SPAWNED:
        if not ANNOUNCECALLBACK and len(ZONECLUSTERS)==len(CLUSTERNAMES):
            ann = True
            for z in ZONECLUSTERS:
                if not z.live:
                    ann = False
                    break
            if ann:
                SPAWNED = False
                AnnounceWorld()
    
    if FORCEKILL_TIME != None:
        if ANNOUNCECALLBACK:
            ANNOUNCECALLBACK.cancel()
            ANNOUNCECALLBACK = None
            
        
        minutes = int(math.ceil((FORCEKILL_TIME - time.time())/60.0))
        if minutes<=0:
            FORCEKILL_TIME = None
            ANNOUNCE_MINUTE = -1
            REBOOT_TIME = time.time()
            
            KILLED = True
            from charservices import CServerAvatar
            CServerAvatar.worldCSAvatars = {}
            for z in ZONECLUSTERS:
                z.killWorld()
            ZONECLUSTERS = []

            
        else:
            if minutes < 11 and ANNOUNCE_MINUTE!=minutes:
                if REBOOT:
                    print "Reboot in %i minutes"%minutes
                else:
                    print "Shutdown in %i minutes"%minutes
                    
                ANNOUNCE_MINUTE = minutes
                
                AnnounceShutdownReboot()
                
            
        
    
    elif time.time()-REBOOT_TIME > 60*60*2: #if we haven't rebooted within the last 2 hours

        #automated reboot
        lt =  time.localtime()
        hour,minute =  lt[3],lt[4]
        
        nm = hour*60+minute
        rm = REBOOT_HOUR*60+REBOOT_MINUTE
        
        minutes = 0
        
        if rm > nm:
            minutes = rm-nm
        elif rm < nm:
            minutes = 24*60 - (nm-rm)
        
        if minutes < 0:
            minutes = 0
                        
        if minutes and minutes < 11 and ANNOUNCE_MINUTE != minutes:
            print "Reboot in %i minutes"%minutes
            ANNOUNCE_MINUTE = minutes
            if ANNOUNCECALLBACK:
                ANNOUNCECALLBACK.cancel()
                ANNOUNCECALLBACK = None
            AnnounceShutdownReboot()
            
        
        if hour == REBOOT_HOUR and minute >= REBOOT_MINUTE:
            ANNOUNCE_MINUTE = -1
            REBOOT_TIME = time.time()
            KILLED = True
            REBOOT = True
            from charservices import CServerAvatar
            CServerAvatar.worldCSAvatars = {}

            for z in ZONECLUSTERS:                
                z.killWorld()
            ZONECLUSTERS = []

    

def ShutdownWorld(minutes = 10):
    global FORCEKILL_TIME,REBOOT, ANNOUNCE_MINUTE
    REBOOT = False
    FORCEKILL_TIME = time.time()+minutes*60
    ANNOUNCE_MINUTE = minutes
    AnnounceShutdownReboot()

def RebootWorld(minutes = 10):
    global FORCEKILL_TIME,REBOOT, ANNOUNCE_MINUTE
    FORCEKILL_TIME = time.time()+minutes*60
    REBOOT = True
    ANNOUNCE_MINUTE = minutes
    AnnounceShutdownReboot()

    
    
def ZoneClusterSpawned(cluster=None):
    from worldservices import ZoneClusterAvatar
    if cluster:
        ZONECLUSTERS.append(cluster)
    else:
        znames = CLUSTERNAMES[0]
        cluster = ZoneClusterAvatar(0,znames,WORLDNAME,PUBLICNAME,PASSWORD)
        cluster.spawnWorldProcess(ZoneClusterSpawned)
        return
    
    
    cnum = cluster.clusterNum+1    
    
    #done? some of the announce stuff up in tick could probably be moved here
    if cnum == len(CLUSTERNAMES):
        return
    
    znames = CLUSTERNAMES[cnum]
    cluster = ZoneClusterAvatar(cnum,znames,WORLDNAME,PUBLICNAME,PASSWORD)
    
    if cnum not in REMOTECLUSTERS:
        cluster.spawnWorldProcess(ZoneClusterSpawned)
    else:
        cluster.spawnRemoteWorldProcess(WORLDIMPS[0],ZoneClusterSpawned)
    
    
    

def SpawnWorld():
    from worldservices import ZoneClusterAvatar
    global SPAWNED
    SPAWNED = True
    
    print "Spawning World Zone Clusters"
    ZoneClusterAvatar.clusterCount = len(CLUSTERNAMES)
    
    #start spawning
    ZoneClusterSpawned()
        
        
        
        
#announce stuff
def AnnounceSuccess(result,perspective):
    perspective.broker.transport.loseConnection()

def AnnounceConnected(perspective):
    from worldservices import ZoneClusterAvatar
    #we'll always connect on zone cluster 0 first
    wname = WORLDNAME.replace("_"," ")
    perspective.callRemote("WorldAvatar","announceWorld",wname,ZoneClusterAvatar.avatars[0].worldPort,False,[],(ZoneClusterAvatar.numPlayers,1024)).addCallbacks(AnnounceSuccess,AnnounceFailure,(perspective,))
    
def AnnounceFailure(error):
    print "ANNOUNCE FAILURE!!!!!",error

def AnnounceWorld():
    global ANNOUNCECALLBACK
    ANNOUNCECALLBACK = reactor.callLater(60,AnnounceWorld)
    
    username=PUBLICNAME+"-"+"World"
    password=PASSWORD
    from md5 import md5
    password = md5(password).digest()


    #print "Announcing World"
    
    factory = pb.PBClientFactory()
    reactor.connectTCP(MASTERIP,MASTERPORT,factory)
    #the pb.Root() is a bit of a hack, I don't know how to get host address on server without
    #sending it, and I don't want to take the time to figure it out at the moment
    factory.login(UsernamePassword(username, password),pb.Root()).addCallbacks(AnnounceConnected, AnnounceFailure)

def ImpConnected(imp):
    print "Imp %i connected... spawning world"%imp.id
    WORLDIMPS[imp.id]=imp
    #kickstart my heart
    reactor.callLater(0,SpawnWorld)
    reactor.callLater(0,Tick)

def main():
    from worldservices import StartServices
    from charservices import StartServices as CStartServices
    from worldimp import StartServices as ImpStartServices
    
    StartServices()
    CStartServices(PUBLICNAME,PASSWORD)
    #ImpStartServices(ImpConnected)
    reactor.callLater(0,SpawnWorld)
    reactor.callLater(0,Tick)


    #open up a manhole
    from telnetmanhole import MakeFactory
    FACTORY = MakeFactory("me","me",ShutdownWorld,RebootWorld)
    reactor.listenTCP(7002, FACTORY)
    #print "Waiting for Imp connections..."
    reactor.run()

 
