
USE_TGEA = False

GAMENAME = "Starter MMO"
GAMEROOT = "starter.mmo"

#GAMENAME = "Starter Advanced MMO"
#GAMEROOT = "starter_advanced.mmo"

#GAMENAME = "Minions of Mirth"
#GAMEROOT = "minions.of.mirth"

MASTERIP = '127.0.0.1'
MASTERPORT = 2007

if GAMEROOT == "minions.of.mirth":
    CLUSTERNAMES = [
    ("trinst","trinstsewer","temple","wasteland","field","hazerothkeep","arctic"),
    ("kauldur","mountain","anidaenforest","jakrethjungle","desertmohrum","swamp","talrimhills")
    ]
else:
    CLUSTERNAMES = [
    ("trinst",),
    ]
