
#MASTER_IP = 'minions.prairiegames.com'
#MASTER_IP = '127.0.0.1'
MASTER_IP = 'test.prairiegames.com'
MASTER_PORT = 2007
MASTER_PASSWORD = "^%$!^@%&uUUUuqjlkja--++"

GMSERVER_IP = MASTER_IP
GMSERVER_PORT = 2003
GMSERVER_PASSWORD = "&^!(*&@(*@jjjkkwiwiwu--++"