

class WorldConnection:
    def __init__(self):
        self.perspective = None
        