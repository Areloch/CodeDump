

from twisted.spread import pb
from mud.world.defines import *

#this will likely move, for now we are feeding spawnpoints off simulation server
class SpawnpointInfo(pb.Copyable,pb.RemoteCopy):
    def __init__(self):
        self.transform = [0,0,0,0,0,0,0]
        self.group = "easy"
    
pb.setUnjellyableForClass(SpawnpointInfo, SpawnpointInfo) 


class DialogTriggerInfo(pb.Copyable,pb.RemoteCopy):
    def __init__(self):
        self.position = (0,0,0)
        self.dialogTrigger = ""
        self.dialogRange = 0
    
pb.setUnjellyableForClass(DialogTriggerInfo, DialogTriggerInfo) 


#world -> simserver
#the bulk of the simulation state control for world mob-> simobject on simserver should 
#be changed to use this!
class SimMobInfo(pb.Cacheable):
    def __init__(self,mob):
        self.mob = mob
        self.state = {}
        self.observers = []
        
        self.state['NAME']=mob.name
        self.state['ID']=mob.id
        self.state['REALM']=mob.realm
        self.state['MOVE']=mob.move
        self.state['SIZE']=mob.size
        self.state['SEEINVISIBLE']=mob.seeInvisible
        self.state['VISIBILITY']=mob.visibility
        self.state['AGGRORANGE']=mob.spawn.aggroRange
        self.state['FEAR'] = mob.isFeared
        self.state['SLEEP'] = mob.sleep > 0 or mob.stun > 0
        self.state['FEIGNDEATH']=mob.feignDeath
        self.state['DETACHED']=mob.detached
        if mob.spawn.dialog and mob.spawn.dialog.greeting and mob.spawn.dialog.greeting.numChoices:
            self.state['VARNAME']="0"+mob.name
        elif mob.spawn.flags&RPG_SPAWN_UNIQUE or mob.spawn.name != mob.name:
            self.state['VARNAME']="1"+mob.name
        elif mob.spawn.difficultyMod > 1.0:
            self.state['VARNAME'] = "2%s %s"%(mob.variantName,mob.name)
        else:
            self.state['VARNAME'] = '%s %s'%(mob.variantName,mob.name)
            
        self.state['SEX']=mob.sex
        self.state['ATTACKING']=mob.attacking
        self.state['RANGEDATTACK']=False
        self.state['ZOMBIE']=mob.zombie
        self.state['TGTID']=0
        self.state['PLAYERPET']=False
        if mob.target:
            self.state['TGTID']=mob.target.simObject.id
        
        
        if not mob.player:
            self.state['ROLE'] = 'MOB'
            if mob.master and mob.master.player:
                masterPlayer = mob.master.player
                self.state['ENCOUNTERSETTING'] = masterPlayer.encounterSetting
                self.state['PRIMARYLEVEL'] = mob.master.level
                if masterPlayer.alliance:
                    self.state['ALLIANCELEADER'] = masterPlayer.alliance.leader.id
                else:
                    self.state['ALLIANCELEADER'] = masterPlayer.id
                self.state['GUILDNAME'] = masterPlayer.guildName
            else:
                self.state['ENCOUNTERSETTING'] = RPG_ENCOUNTER_PVE
                self.state['PRIMARYLEVEL'] = mob.level
                self.state['ALLIANCELEADER'] = 0
                self.state['GUILDNAME'] = ""
        else:
            player = mob.player
            self.state['ROLE'] = player.avatar.masterPerspective.role.name
            self.state['ENCOUNTERSETTING'] = player.encounterSetting
            self.state['PRIMARYLEVEL'] = mob.level
            if player.alliance:
                self.state['ALLIANCELEADER'] = player.alliance.leader.id
            else:
                self.state['ALLIANCELEADER'] = player.id
            self.state['GUILDNAME'] = player.guildName
        
        bestlight = mob.light
        for item in mob.worn.itervalues():
            if bestlight < item.light:
                bestlight = item.light
            
        self.state['LIGHT']=bestlight
        
        self.state['FLYING']=mob.flying
        
        self.state['MATBODY']=""
        self.state['MATARMS']=""
        self.state['MATFEET']=""
        self.state['MATLEGS']=""
        self.state['MATHANDS']=""
        
        
        if mob.worn.has_key(RPG_SLOT_CHEST):
            self.state['MATBODY']=mob.worn[RPG_SLOT_CHEST].material
        if mob.worn.has_key(RPG_SLOT_ARMS):
            self.state['MATARMS']=mob.worn[RPG_SLOT_ARMS].material
        if mob.worn.has_key(RPG_SLOT_FEET):
            self.state['MATFEET']=mob.worn[RPG_SLOT_FEET].material
        if mob.worn.has_key(RPG_SLOT_HANDS):
            self.state['MATHANDS']=mob.worn[RPG_SLOT_HANDS].material
        if mob.worn.has_key(RPG_SLOT_LEGS):
            self.state['MATLEGS']=mob.worn[RPG_SLOT_LEGS].material
        
        
        self.state['TWOHANDED']=False
        self.state['MOUNT3'] = self.state['MOUNT2'] = self.state['MOUNT1'] = self.state['MOUNT0'] = ""
        self.state['MOUNT3_MAT'] = ""
        
        if mob.worn.has_key(RPG_SLOT_SHIELD):
            self.state['MOUNT2']=mob.worn[RPG_SLOT_SHIELD].model

        if mob.worn.has_key(RPG_SLOT_HEAD):
            self.state['MOUNT3']=mob.worn[RPG_SLOT_HEAD].model
            self.state['MOUNT3_MAT']=mob.worn[RPG_SLOT_HEAD].material

        if mob.worn.has_key(RPG_SLOT_SECONDARY):
            self.state['MOUNT1']=mob.worn[RPG_SLOT_SECONDARY].model
        
        if mob.worn.has_key(RPG_SLOT_PRIMARY):
            item = mob.worn[RPG_SLOT_PRIMARY]
            self.state['MOUNT0']=item.model
            if '2H' in item.skill and (not mob.worn.get(RPG_SLOT_SECONDARY) or not mob.skillLevels.get("Power Wield")):
                self.state['MOUNT1'] = ""
                self.state['MOUNT2'] = ""
                self.state['TWOHANDED']=True

        
    def stoppedObserving(self, perspective, observer):
        #if observer in self.observers:
        self.observers.remove(observer)
        
    def getStateToCacheAndObserveFor(self, perspective, observer):
        self.observers.append(observer)
        mob = self.mob
        
                
        return self.state
        
    def refresh(self):
        mob = self.mob
        state = self.state
        changed = {}
        
        move = mob.move
        flying = mob.flying
        if mob.master:
            move = mob.master.move
            flying = mob.master.flying
            if mob.realm != self.state['REALM']:  # pets get their realm changed during assignment
                changed['REALM'] = state['REALM'] = mob.realm
        
        if mob.simObject:    
            if mob.simObject.waterCoverage >= .45:
                move = mob.swimMove
                if move > mob.move:
                    move = mob.move
            
            
        size = mob.size
        visibility = mob.visibility
        sleep = mob.sleep > 0 or mob.stun > 0
        seeinvisible = mob.seeInvisible
        fear = mob.isFeared
        
        feignDeath = mob.feignDeath
        
        playerpet = False
        if mob.master and mob.master.player:
            playerpet = True
        
        bestlight = mob.light
        for item in mob.worn.itervalues():
            if bestlight < item.light:
                bestlight = item.light
            
        

        
        #clamp
        if move < 0:
            move = 0
        if move > 4:
            move = 4
        if size < .1:
            size = .1
        if size > 3:
            size = 3
        if visibility < 0:
            visibility = 0
        if visibility > 1:
            visibility = 1
        if seeinvisible < 0:
            seeinvisible = 0
        if seeinvisible > 1:
            seeinvisible = 1
        
        if flying > 1:
            flying = 1
        if flying < 0:
            flying = 0
            
            
        attacking = mob.attacking
        if mob.player:
            player = mob.player
            if mob.casting and mob.casting.spellProto.skillname != "Singing":
                attacking = False
            encounterSetting = player.encounterSetting
            primaryLevel = mob.level
            if player.alliance:
                allianceLeader = player.alliance.leader.id
            else:
                allianceLeader = player.id
            guildName = player.guildName
        elif mob.master and mob.master.player:
            masterPlayer = mob.master.player
            encounterSetting = masterPlayer.encounterSetting
            primaryLevel = mob.master.level
            if masterPlayer.alliance:
                allianceLeader = masterPlayer.alliance.leader.id
            else:
                allianceLeader = masterPlayer.id
            guildName = masterPlayer.guildName
        else:
            encounterSetting = RPG_ENCOUNTER_PVE
            primaryLevel = mob.level
            allianceLeader = 0
            guildName = ""
        
        if encounterSetting != state['ENCOUNTERSETTING']:
            changed['ENCOUNTERSETTING'] = state['ENCOUNTERSETTING'] = encounterSetting
        if primaryLevel != state['PRIMARYLEVEL']:
            changed['PRIMARYLEVEL'] = state['PRIMARYLEVEL'] = primaryLevel
        if allianceLeader != state['ALLIANCELEADER']:
            changed['ALLIANCELEADER'] = state['ALLIANCELEADER'] = allianceLeader
        if guildName != state['GUILDNAME']:
            changed['GUILDNAME'] = state['GUILDNAME'] = guildName
        
        if playerpet != state['PLAYERPET']:
            changed['PLAYERPET']=state['PLAYERPET']=playerpet


        if attacking != state['ATTACKING']:
            changed['ATTACKING']=state['ATTACKING']=attacking
        if mob.simObject:
            if mob.simObject.rangedAttack != state['RANGEDATTACK']:
                changed['RANGEDATTACK'] = state['RANGEDATTACK'] = mob.simObject.rangedAttack
        
        if move != state['MOVE']:
            changed['MOVE']=state['MOVE']=move
        if size != state['SIZE']:
            changed['SIZE']=state['SIZE']=size
            
        if visibility != state['VISIBILITY']:
            changed['VISIBILITY']=state['VISIBILITY']=visibility

        if seeinvisible != state['SEEINVISIBLE']:
            changed['SEEINVISIBLE']=state['SEEINVISIBLE']=seeinvisible

        if fear != state['FEAR']:
            changed['FEAR']=state['FEAR']=fear

        if bestlight != state['LIGHT']:
            changed['LIGHT']=state['LIGHT']=bestlight

        if sleep != state['SLEEP']:
            changed['SLEEP']=state['SLEEP']=sleep

        if flying != state['FLYING']:
            changed['FLYING']=state['FLYING']=flying

        if feignDeath != state['FEIGNDEATH']:
            changed['FEIGNDEATH']=state['FEIGNDEATH']=feignDeath

        if mob.detached != state['DETACHED']:
            changed['DETACHED']=state['DETACHED']=mob.detached

        if mob.zombie != state['ZOMBIE']:
            changed['ZOMBIE']=state['ZOMBIE']=mob.zombie
            
        if not mob.target and state['TGTID']:
            changed['TGTID']=state['TGTID']=0
        elif mob.target:
            if mob.target.simObject.id != state['TGTID']:
                state['TGTID']=changed['TGTID']=mob.target.simObject.id

        
        twohanded = False
        mount3 = mount2 = mount1 = mount0 = mount3_material = ""
        
        if mob.worn.has_key(RPG_SLOT_SHIELD):
            mount2=mob.worn[RPG_SLOT_SHIELD].model


        if mob.worn.has_key(RPG_SLOT_HEAD):
            mount3=mob.worn[RPG_SLOT_HEAD].model
            mount3_material=mob.worn[RPG_SLOT_HEAD].material
        
        if not state['RANGEDATTACK'] or not mob.worn.has_key(RPG_SLOT_RANGED):
            if mob.worn.has_key(RPG_SLOT_SECONDARY):
                mount1=mob.worn[RPG_SLOT_SECONDARY].model
        
            if mob.worn.has_key(RPG_SLOT_PRIMARY):
                item = mob.worn[RPG_SLOT_PRIMARY]
                mount0=item.model
                if '2H' in item.skill and (not mob.worn.get(RPG_SLOT_SECONDARY) or not mob.skillLevels.get("Power Wield")):
                    mount1 = ""
                    mount2 = ""
                    twohanded = True
        else:
            mount0 = mob.worn[RPG_SLOT_RANGED].model
            mount1 = ""
                
        if mount0 != state['MOUNT0']:
            changed['MOUNT0']=state['MOUNT0']=mount0
        
        if mount1 != state['MOUNT1']:
            changed['MOUNT1']=state['MOUNT1']=mount1

        if mount2 != state['MOUNT2']:
            changed['MOUNT2']=state['MOUNT2']=mount2

        if mount3 != state['MOUNT3']:
            changed['MOUNT3']=state['MOUNT3']=mount3
            
        if mount3_material != state['MOUNT3_MAT']:
            changed['MOUNT3_MAT']=state['MOUNT3_MAT']=mount3_material

            
        if twohanded != state['TWOHANDED']:
            changed['TWOHANDED']=state['TWOHANDED']=twohanded
            
        #materials
        mbody=""
        marms = ""
        mfeet = ""
        mlegs = ""
        mhands = ""
        
        if mob.worn.has_key(RPG_SLOT_CHEST):
            mbody=mob.worn[RPG_SLOT_CHEST].material
        if mob.worn.has_key(RPG_SLOT_ARMS):
            marms=mob.worn[RPG_SLOT_ARMS].material
        if mob.worn.has_key(RPG_SLOT_FEET):
            mfeet=mob.worn[RPG_SLOT_FEET].material
        if mob.worn.has_key(RPG_SLOT_HANDS):
            mhands=mob.worn[RPG_SLOT_HANDS].material
        if mob.worn.has_key(RPG_SLOT_LEGS):
            mlegs=mob.worn[RPG_SLOT_LEGS].material
            
        if mbody != state['MATBODY']:
            changed['MATBODY']=state['MATBODY']=mbody
        if mfeet != state['MATFEET']:
            changed['MATFEET']=state['MATFEET']=mfeet
        if marms != state['MATARMS']:
            changed['MATARMS']=state['MATARMS']=marms
        if mlegs != state['MATLEGS']:
            changed['MATLEGS']=state['MATLEGS']=mlegs
        if mhands != state['MATHANDS']:
            changed['MATHANDS']=state['MATHANDS']=mhands

            
        if not len(changed):
            return
            
        for o in self.observers: o.callRemote('updateChanged', changed)
            
        
class SimMobInfoGhost(pb.RemoteCache):
    
    def __init__(self):
        self.dirty = True

    
    def setCopyableState(self, state):
        self.dirty = True
        for k,v in state.iteritems():
            self.__dict__[k]=v
            
    def observe_updateChanged(self,changed):
        
        self.dirty = True
        for k,v in changed.iteritems():
            setattr(self,k,v)
            
pb.setUnjellyableForClass(SimMobInfo, SimMobInfoGhost) 

