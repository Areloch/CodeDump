
#simserver -> world

from twisted.spread import pb
import math
import random
import time
import traceback
from math import fabs

try:
    #sim server side
    from tgenative import *
    from mud.tgepython.console import TGEExport
except:
    #world side
    pass 
   
ANIM_IDLE = 0
ANIM_WALK = 1
ANIM_RUN = 1


class Brain:
    """
    IDLE = 0 #idle animation
    SEEKING_TARGET = 1 #run animation 
    SEEKING_POSITION = 2 #walk animation
    ONPATH = 3 #walk animation
    EVADING_TARGET = 4 #run animation
    IMMOBALIZED = 5 #die, cast, idle
    
    PHYSICS_WALK = 0
    PHYSICS_SWIM = 1
    PHYSICS_LEVITATE = 2
    """
        
    def __init__(self,simObject):
        self.simObject = simObject
        self.reset()
        
    def reset(self):
        self.target = None
        self.followTarget = None
        self.targetPos = None
        self.attacking = False
        self.rangedAttack = False
        self.iscasting = 0
        
        self.dead = False
        
        self.anim = -1
        self.death = 0
        self.feignDeath = 0
        
        self.noanim = True
        
        self.twohanded = False
        
        tge = self.simObject.tgeObject
        
        if int(tge.isSwimming()):
            tge.playThread(0,"idle")
        if int(tge.isFlying()):
            tge.playThread(0,"flyidle")
        else:
            tge.playThread(0,"swimidle")
            
        self.returnHomeTimer = 0
        
    def returnHome(self):
        hp = self.simObject.homePosition
        hr = self.simObject.homeRotation
        self.simObject.tgeObject.setVelocity("0 0 0")
        self.simObject.tgeObject.setTransform("%s %s %s %s %s %s %s"%(hp[0],hp[1],hp[2],hr[0],hr[1],hr[2],hr[3]))
        
            
        
    def setTarget(self,tgt):
        if tgt == self.target:
            return
        if self.simObject.wanderGroup <= 0:
            if not tgt and not self.simObject.isPlayer and not self.returnHomeTimer and not self.death:
                self.returnHomeTimer = 10*60 #1 minute
            elif tgt:
                self.returnHomeTimer = 0            
        self.target = tgt
        
    def setFollowTarget(self,tgt):            
        self.followTarget = tgt
        
    def casting(self,casting):
        self.iscasting = casting
        if casting and not self.death and self.noanim and not self.attacking and not self.rangedAttack:
            self.simObject.tgeObject.playThread(0,"spellprepare")
                
            
        
        
    def cast(self,projectile=False):
        
        self.iscasting = False
        so = self.simObject
        tge = so.tgeObject
        
        if self.death:
            return
        
        if int(tge.isFlying()) or self.attacking or self.rangedAttack:
            return
        
        if projectile:
            tge.playThread(0,"spellcast")
        else:
            tge.playThread(0,"spellcast2")
        
    def playAnimation(self,anim):
        if anim == "bowattack":
            return
            self.rangedAttack = True
            if self.simObject.observer:
                self.simObject.observer.callRemote('updateRangedAttack', self.rangedAttack)
        self.noanim = False
        self.simObject.tgeObject.playThread(0,anim)
        
    def pain(self):
        if self.death:
            print "WARNING: mob pain after death"
            return

        so = self.simObject
        tge = so.tgeObject

        
        if int(tge.isFlying()):
            return


        self.noanim = False
        if not random.randint(0,1):
            self.simObject.tgeObject.playThread(0,"pain1")
        else:
            self.simObject.tgeObject.playThread(0,"pain2")
            
        
        
    def tick(self):
        so = self.simObject
        tge = so.tgeObject
        
        if self.returnHomeTimer:
            self.returnHomeTimer -= 1
            if not self.returnHomeTimer:
                self.returnHome()
        
        #handle animation
        vel = tge.getVelocity()
        spd = 0
        if math.fabs(vel[0]) > .1 or math.fabs(vel[1]) > .1:
            spd = 1
        
        dist = 1000000
        

        #if we want to do autofollow we need to change the player class cpp side to 
        #have this stuff
        if not self.simObject.isPlayer:
            if self.target:
                tge.setFollowObject(self.target.id)
            elif self.followTarget:
                tge.setFollowObject(self.followTarget.id)
            else:
                tge.setFollowObject(0)
                
            if so.mobInfo.FEAR:
                tge.setAvoidFollowObject(True)
            else:
                tge.setAvoidFollowObject(False)
            
        if not self.feignDeath and so.mobInfo.FEIGNDEATH:
            self.doFeignDeath()
        elif not so.mobInfo.FEIGNDEATH:
            self.feignDeath = 0
        
        if self.noanim and not self.death and not self.feignDeath:
            cansee = False
            
            if self.target:
                x = self.target.position[0] - so.position[0]
                y = self.target.position[1] - so.position[1]
                z = self.target.position[2] - so.position[2]
                dist = math.sqrt(x*x+y*y+z*z)
                dist-=self.target.spawnInfo.radius*self.target.spawnInfo.scale
                
                if self.target.id in so.canSee:
                    cansee = True
                    
            if so.mobInfo.SLEEP:
                
                tge.playThread(0,"idle")
                    
                if not self.simObject.isPlayer:
                    tge.setMoveSpeed(0.0)
            else:
                if not self.simObject.isPlayer:
                    tge.setMoveSpeed(1.0)
                if spd:
                    if self.target or self.followTarget or self.simObject.isPlayer:
                        if not self.simObject.isPlayer:
                            tge.setMoveSpeed(1.0)
                            
                        if int(tge.isSwimming()):
                            tge.playThread(0,"swim")
                        elif int(tge.isFlying()) and int(tge.hasFlyingAnimation()):
                            tge.playThread(0,"fly")                            
                        else:
                            if self.twohanded:
                                tge.playThread(0,"2hrun")
                            else:
                                tge.playThread(0,"1hrun")
                            
                    else:
                        swimming = int(tge.isSwimming())
                        if swimming:
                            tge.playThread(0,"swim")
                        elif int(tge.isFlying()) and int(tge.hasFlyingAnimation()):
                            tge.playThread(0,"fly")
                        else:
                            if self.twohanded:
                                tge.playThread(0,"2hwalk")
                            else:
                                tge.playThread(0,"1hwalk")
                                
                        if not self.simObject.isPlayer and not swimming:
                            tge.setMoveSpeed(0.5)
                        else:
                            tge.setMoveSpeed(1.0)
                            
                        
                else:
                    if self.target and self.attacking:
                        if self.twohanded and not self.rangedAttack:
                            tge.playThread(0,"cready2h")
                        else:
                            tge.playThread(0,"cready1h")
                            
                    else:
                        if self.iscasting:
                            tge.playThread(0,"spellprepare")
                        elif int(tge.isSwimming()):
                            tge.playThread(0,"swimidle")
                        elif int(tge.isFlying()):
                            tge.playThread(0,"flyidle")
                        else:
                            tge.playThread(0,"idle")
                            
                    
            #print dist,so.spawnInfo.radius
                
            if (not random.randint(0,3)) and (not spd) and self.target and cansee and self.attacking and not self.rangedAttack and dist < (so.spawnInfo.radius*so.spawnInfo.scale) and not so.mobInfo.SLEEP and not so.mobInfo.FEAR:
    
                twohandedanims = (
                "2hslash","2hslash2","2hslash3","2hthrust",
                )
                
                if so.mobInfo.MOUNT0 and so.mobInfo.MOUNT1:
                    onehandedanims = (
                    "1hslashleft","1hslashright",
                    "1hslash2left","1hslash2right",
                    "1hslash3left","1hslash3right",
                    "1hthrustleft","1hthrustright",
                    )

                elif so.mobInfo.MOUNT0 and not so.mobInfo.MOUNT1:
                    onehandedanims = (
                    "1hslashright","1hslash2right","1hslash3right","1hthrustright","unarmedleft"
                    )

                elif not so.mobInfo.MOUNT0 and so.mobInfo.MOUNT1:
                    onehandedanims = (
                    "1hslashleft","1hslash2left","1hslash3left","1hthrustleft","unarmedright"
                    )
                
                else:
                    onehandedanims = ("unarmedleft","unarmedright")
                    
                anims = onehandedanims
                
                if self.twohanded:
                    anims = twohandedanims
                
                
                a = random.randint(0,len(anims)-1)
                self.simObject.tgeObject.playThread(0,anims[a])
                
                    
                self.noanim = False
     
     
    def doFeignDeath(self):
        self.feignDeath = 1
        self.noanim = False           
        self.simObject.tgeObject.playThread(0,"death")
    def die(self):
        self.returnHomeTimer =0
        self.death = 1
        self.noanim = False
        self.simObject.tgeObject.playThread(0,"death")
        
            
    def onEndSequence(self):
        tge =self.simObject.tgeObject
        self.noanim = True
        if self.rangedAttack:
            self.rangedAttack = False
            if self.simObject.observer:
                self.simObject.observer.callRemote('updateRangedAttack', self.rangedAttack)
        if not self.death and not self.feignDeath:
            if self.iscasting:
                tge.playThread(0,"spellcast2")
            elif self.target and self.attacking:
                if self.twohanded:
                    tge.playThread(0,"cready2h")
                else:
                    tge.playThread(0,"cready1h")
            else:
                if int(tge.isSwimming()):
                    tge.playThread(0,"swimidle")
                if int(tge.isFlying()):
                    tge.playThread(0,"flyidle")
                else:
                    tge.playThread(0,"idle")

                
                
                
                    
                
                
 

#simulation server side
class SimObject(pb.Cacheable):
    def __init__(self,id,spawnInfo,mobInfo,transform=[0,0,0,0,0,0,0],wanderGroup = -1,isPlayer = False):
        self.observer = None
        self.id = id
        self.wanderGroup = wanderGroup
        self.tgeObject = TGEObject(id)
        self.tgeObject.wanderGroup = wanderGroup
        self.isPlayer = isPlayer
        self.spawnInfo = spawnInfo
        self.mobInfo = mobInfo
        self.position = (transform[0],transform[1],transform[2])
        self.rotation = (transform[3],transform[4],transform[5],transform[6])
        self.canSee = []
        self.simZombie = False
        
        self.waypoint = -1
        
        
        self.homePosition = self.position
        self.homeRotation = self.rotation
        
        self.brain = Brain(self)
        self.canKite = False
        
        
    def getStateToCacheAndObserveFor(self, perspective, observer):
        self.observer = observer
        state = {}
        state['id']=self.id
        state['position']=self.position
        state['rotation']=self.rotation
        state['cansee']=self.canSee
        state['simZombie']=self.simZombie
        return state
        
    def stoppedObserving(self, perspective, observer):
        self.observer = None
        self.mobInfo = None
        self.brain = None
        self.canSee = []
        
    def updateCanSee(self,cansee):
        if not self.observer:
            return
        if cansee != self.canSee:
            self.canSee = cansee
            self.observer.callRemote('updateCanSee', cansee)
            
        
    def updateTransform(self):
        if not self.observer:
            return None

        if self.isPlayer:
            
            waterCoverage = float(self.tgeObject.waterCoverage)
            
            pos = self.tgeObject.getPosition()
            #pos =  (transform[0],transform[1],transform[2])
            #rot = (transform[3],transform[4],transform[5],transform[6])
            
            if pos == self.position:# and self.rotation == rot:
                return None# no need to send
            
            if fabs(pos[0]-self.position[0]) < 1.0:
                if fabs(pos[1]-self.position[1]) < 1.0:
                    if fabs(pos[2]-self.position[2]) < 1.0:
                        return None
                
            
            self.position = pos
            #self.rotation = rot
        
            #self.observer.callRemote('updateTransform', pos,rot,waterCoverage)
            return (self.id,pos,waterCoverage)
            
        else:
            #mobs only do position
            canKite = self.tgeObject.canKite
            pos = self.tgeObject.getPosition()
            if pos == self.position and canKite == self.canKite:
                return None
            if fabs(pos[0]-self.position[0]) < 1.0:
                if fabs(pos[1]-self.position[1]) < 1.0:
                    if fabs(pos[2]-self.position[2]) < 1.0:
                        return None
            self.canKite = canKite
            self.position = pos
            #self.observer.callRemote('updatePosition', pos,canKite)
            return (self.id,pos,canKite)
            
    def remote_mountImage(self,rpgslot,model):
        print rpgslot,model     
            
    
    
#world side    
class SimGhost(pb.RemoteCache):
    def __init__(self):
        self.canKite = False
        self.waterCoverage = 0.0
        self.rangedAttack = False
        
        
    def setCopyableState(self, state):
        self.id = state['id']
        self.position = state['position']
        self.rotation = state['rotation']
        self.canSee = state['cansee']
        self.simZombie = state['simZombie']

    def observe_updatePosition(self,position,canKite):
        self.position=position
        self.canKite = canKite
        
    def observe_updateTransform(self,position,rotation,waterCoverage):
        self.position=position
        self.rotation=rotation
        self.waterCoverage = waterCoverage
        
    def observe_updateCanSee(self,canSee):
        self.canSee = canSee
        
    def observe_updateSimZombie(self,zombie):
        self.simZombie = zombie
    
    def observe_updateRangedAttack(self,rangedAttack):
        self.rangedAttack = rangedAttack
        
        
    
pb.setUnjellyableForClass(SimObject, SimGhost) 
