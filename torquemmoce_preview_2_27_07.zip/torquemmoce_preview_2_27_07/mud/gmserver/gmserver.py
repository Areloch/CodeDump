import sys,os
sys.path.append(os.getcwd())

if sys.platform == "win32":
    from twisted.internet.iocpreactor import install
else:
    from twisted.internet.pollreactor import install
install()

from twisted.internet import reactor
from mud.server.app import Server
from mud.server.config import ConfigureServer
from mud.common.permission import Role,User
from mud.common.avatar import Avatar,RoleAvatar


from gmcommands import DoGMCommand

#Always drop tables for now
DROPTABLES = True

sys.argv.append('database=data/gmserver')
ConfigureServer("gmserver.db",DROPTABLES)

#Character Server
CHARSERVER_MIND = None
class CharacterAvatar(Avatar):
    def __init__(self,username,role,mind):
        global CHARSERVER_MIND
        Avatar.__init__(self,username,role,mind)
        self.username = username
        self.role = role
        self.mind = mind
        CHARSERVER_MIND = mind
        
        from gmcommands import SetCharServerMind
        SetCharServerMind(CHARSERVER_MIND)

    def perspective_sayHi(self):
        print "yup"
                
    def logout(self):
        global CHARSERVER_MIND
        CHARSERVER_MIND = None


class GMAvatar(Avatar):
    def __init__(self,username,role,mind):
        Avatar.__init__(self,username,role,mind)
        self.username = username
        self.role = role
        self.mind = mind

    def perspective_command(self,command):
        DoGMCommand(self,command)
        
                
    def logout(self):
        pass

def ConfigureRoles():

    admin = Role(name="Administrator")
    RoleAvatar(name="AdminAvatar",role=admin)
    
    
    gm = Role(name="GM")
    RoleAvatar(name="GMAvatar",role=gm)

    character = Role(name="CharacterServer")
    RoleAvatar(name="CharacterAvatar",role=character)

def ConfigureUsers():
    
    cserver = User(name="CharacterServer",password="&^!(*&@(*@jjjkkwiwiwu--++")
    cserver.addRole(Role.byName("CharacterServer"))
    
    from userpasswords import USERS
    for name,info in USERS.iteritems():
        password,roles = info
        user = User(name=name,password=password)
        for role in roles:
            user.addRole(Role.byName(role))
            
     
print "Prairie Games GM Server"
print "->Initializing"

ConfigureRoles()
ConfigureUsers()
    
server = Server(2003,True)    # True to use md5 hashing for passwords
server.startServices()

print "->GM Server is up"
reactor.run()



