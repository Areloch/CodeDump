
#ability to remotely GM without being in the game
#monitoring some chat

import wx
import  wx.lib.anchors as anchors
from twisted.internet import wxreactor
wxreactor.install()
from twisted.spread import pb
from twisted.internet import reactor
from twisted.cred.credentials import UsernamePassword
import traceback

VERSION = "v1.0"
#GMSERVER_IP = "minions.prairiegames.com"
#GMSERVER_IP = "127.0.0.1"
GMSERVER_IP = "test.prairiegames.com"
GMSERVER_PORT = 2003

USERNAME = ""
PASSWORD = ""
ROLE = ""

HISTORY=[]
HISTORY_POSITION = -1
def DoCommand(command):
    global HISTORY, HISTORY_POSITION
    HISTORY.append(command)
    HISTORY_POSITION = len(HISTORY)
    LogText("\n>>> %s\n"%command)
    if not GMCONNECTION:
        LogText("\nYou are not connected to the GM Server.\n")
        return
    
    if command.startswith('/adm') and " " in command:
        pass
        
    if command.startswith('/gm') and " " in command:
        GMCONNECTION.doGMCommand(command)
        

    

class LoginDialog(wx.Dialog):
    def __init__(
            self, parent, ID, title, size=wx.DefaultSize, pos=wx.DefaultPosition, 
            style=wx.DEFAULT_DIALOG_STYLE
            ):
        global USERNAME,PASSWORD

        pre = wx.PreDialog()
        pre.Create(parent, ID, title, pos, size, style)

        self.PostCreate(pre)

        sizer = wx.BoxSizer(wx.VERTICAL)

        label = wx.StaticText(self, -1, "GM Server Login")
        sizer.Add(label, 0, wx.ALIGN_CENTRE|wx.ALL, 5)

        box = wx.BoxSizer(wx.HORIZONTAL)

        label = wx.StaticText(self, -1, "Username:")        
        box.Add(label, 0, wx.ALIGN_CENTRE|wx.ALL, 5)

        self.userTextCtrl = text = wx.TextCtrl(self, -1, USERNAME, size=(80,-1))        
        box.Add(text, 1, wx.ALIGN_CENTRE|wx.ALL, 5)

        sizer.Add(box, 0, wx.GROW|wx.ALIGN_CENTER_VERTICAL|wx.ALL, 5)

        box = wx.BoxSizer(wx.HORIZONTAL)

        label = wx.StaticText(self, -1, "Password:")
        
        box.Add(label, 0, wx.ALIGN_CENTRE|wx.ALL, 5)

        self.passwordTextCtrl = text = wx.TextCtrl(self, -1, PASSWORD, size=(80,-1),style=wx.TE_PASSWORD)        
        box.Add(text, 1, wx.ALIGN_CENTRE|wx.ALL, 5)

        sizer.Add(box, 0, wx.GROW|wx.ALIGN_CENTER_VERTICAL|wx.ALL, 5)

        line = wx.StaticLine(self, -1, size=(20,-1), style=wx.LI_HORIZONTAL)
        sizer.Add(line, 0, wx.GROW|wx.ALIGN_CENTER_VERTICAL|wx.RIGHT|wx.TOP, 5)

        btnsizer = wx.StdDialogButtonSizer()
        
        btn = wx.Button(self, wx.ID_OK)
        btn.SetDefault()
        btnsizer.AddButton(btn)

        btn = wx.Button(self, wx.ID_CANCEL)        
        btnsizer.AddButton(btn)
        btnsizer.Realize()

        sizer.Add(btnsizer, 0, wx.ALIGN_CENTER_VERTICAL|wx.ALL, 5)

        self.SetSizer(sizer)
        sizer.Fit(self)
        

class GMFactory(pb.PBClientFactory):
    reconnect = False
    
    def clientConnectionMade(self,broker):
        self.reconnect = False
        pb.PBClientFactory.clientConnectionMade(self,broker)
    
    def clientConnectionFailed(self,connector,reason):
        LogText("\nConnection to GM Server failed, %s\n"%reason.getErrorMessage().split(':',1)[0])
    
    def clientConnectionLost(self,connector,reason):
        self.reconnect = True    # reconnect on command input
    #    LogText("\nConnection to GM Server lost, %s\nTrying to reconnect...\n"%reason.getErrorMessage().split(':',1)[0])
    #    if not self.serverUnreachable:
    #        connector.connect()
    
    def checkConnectionForCommand(self):
        if self.reconnect:
            global GMCONNECTION
            GMCONNECTION.connect()
            return False
        return True


GMCONNECTION = None
class GMConnection(pb.Root):
    factory = None
    command = None
    
    def doGMCommand(self,command):
        if self.factory.checkConnectionForCommand():
            self.perspective.callRemote("GM","command",command)
        else:
            self.command = command
        
    def connect(self):
        global GMCONNECTION,USERNAME,PASSWORD,ROLE
        GMCONNECTION = None

        if not self.factory:
            self.factory = GMFactory()
        reactor.connectTCP(GMSERVER_IP,GMSERVER_PORT,self.factory)
        from md5 import md5
        self.factory.login(UsernamePassword("%s-%s"%(USERNAME,ROLE), md5(PASSWORD).digest()),self).addCallbacks(self.connected)
        LogText("\nConnecting to GM Server as User: %s Role: %s\n"%(USERNAME,ROLE))
        
        
    def connected(self,perspective):
        global GMCONNECTION        
        GMCONNECTION = self
        
        self.perspective = perspective
        LogText("\nConnected to GM Server.\n")
        if self.command:
            self.perspective.callRemote("GM","command",self.command)
            self.command = None
        
    def failure(self,reason):
        LogText("Error: %s\n"%reason.getErrorMessage().split(':',1)[0])
        
    def remote_logText(self,text):
        LogText(text)
       

def ShowLoginDialog(parent):
    dlg = LoginDialog(parent, -1, "GM Login", size=(350, 200),
                     #style = wxCAPTION | wxSYSTEM_MENU | wxTHICK_FRAME
                     style = wx.DEFAULT_DIALOG_STYLE
                     )
    dlg.CenterOnScreen()

    # this does not return until the dialog is closed.
    val = dlg.ShowModal()

    if val == wx.ID_OK:
        pass
    else:
        dlg.Destroy()
        return
    
    global USERNAME,PASSWORD,ROLE
        
    USERNAME = dlg.userTextCtrl.GetValue()
    PASSWORD = dlg.passwordTextCtrl.GetValue()
    ROLE = "GM" #todo, add admin
    
    dlg.Destroy()
    
    
    
    gm = GMConnection()
    gm.connect()
    
    
OUTPUTWINDOW = None
EDITCONTROL = None

def LogText(text):
    OUTPUTWINDOW.AppendText(text)

class CommandPanel(wx.Panel):
    def __init__(self,parent):
        global OUTPUTWINDOW,EDITCONTROL
        
        wx.Panel.__init__(self,parent)
        
        sizer = wx.BoxSizer(wx.VERTICAL)
        
        OUTPUTWINDOW = output = wx.TextCtrl(self, -1,"",size=(900, 600), style=wx.TE_MULTILINE|wx.TE_READONLY)
        
        self.edit = EDITCONTROL = edit = wx.TextCtrl(self, -1,"",size=(900, -1),style=wx.TE_PROCESS_ENTER)
        
        
        
        self.edit.Bind(wx.EVT_TEXT_ENTER, self.EvtTextEnter)
        
        self.edit.Bind(wx.EVT_CHAR, self.EvtChar)
        
        
        sizer.Add(output, 0, wx.ALIGN_CENTRE|wx.ALL|wx.EXPAND, 5)
        sizer.Add(edit,0, wx.ALIGN_CENTRE|wx.ALL|wx.EXPAND, 5)
        self.SetSizer(sizer)
        sizer.Fit(self)
        
        
    def EvtTextEnter(self, event):
        
        command = self.edit.GetValue()
        self.edit.SetValue("")
        if len(command):
            DoCommand(command)
        
    def EvtChar(self, event):
        global HISTORY,HISTORY_POSITION
        k = event.GetKeyCode()
        #317 up and 319 down
        #LogText('EvtChar: %d\n' % k)
        #up
        if k == 317 and HISTORY_POSITION>0:
            HISTORY_POSITION-=1
            EDITCONTROL.SetValue(HISTORY[HISTORY_POSITION])

        elif k == 319 and HISTORY_POSITION<len(HISTORY)-1:
            HISTORY_POSITION+=1
            EDITCONTROL.SetValue(HISTORY[HISTORY_POSITION])
            
        elif k == 319:
            EDITCONTROL.SetValue("")
            
            
        event.Skip()

        


class MyMainPanel(wx.Panel):
    def __init__(self,parent,id):
        wx.Panel.__init__(self,parent,id)
        
        sizer = wx.BoxSizer(wx.VERTICAL)

        p1 = CommandPanel(self)

        sizer.Add(p1, 0, wx.ALIGN_CENTRE|wx.ALL|wx.EXPAND, 5)
        
        self.SetSizer(sizer)
        sizer.Fit(self)




class MainFrame(wx.Frame):
    def __init__(self, parent, id, title):
        wx.Frame.__init__(self, parent, -1, title,size=wx.Size(800, 600),style=wx.CAPTION|wx.MINIMIZE_BOX| wx.SYSTEM_MENU|wx.TAB_TRAVERSAL| wx.CLOSE_BOX)
                        
        menu = wx.Menu()
        menu.Append(1000, "Login", "Login to GM Server")
        menu.Append(wx.ID_EXIT, "E&xit", "Terminate the program")        
        menuBar = wx.MenuBar()
        menuBar.Append(menu, "&File")
        self.SetMenuBar(menuBar)
        wx.EVT_MENU(self, wx.ID_EXIT,  self.DoExit)
        wx.EVT_MENU(self, 1000,  self.DoLogin)
        
        sizer = wx.BoxSizer(wx.VERTICAL)
        
        try:
            mmp = MyMainPanel(self,-1)
        except:
            traceback.print_exc()
            
            
        sizer.Add(mmp, 0, wx.ALIGN_CENTRE|wx.ALL|wx.EXPAND, 0)
        
        self.SetSizer(sizer)
        sizer.Fit(self)

    def DoLogin(self,event):
        ShowLoginDialog(self)
        
    def DoExit(self, event):        
        reactor.stop()


class GMApp(wx.App):
    def OnInit(self):
        wx.InitAllImageHandlers()
        
        

        frame = MainFrame(None, -1, "GM Tool")
        frame.Centre()
        #frame.Maximize()
        frame.Show(1)
        
        
        self.mainFrame = frame
            
        LogText("GM Tool %s Initialized.\nSelect File->Login to connect to GM Server\n"%VERSION)
        EDITCONTROL.SetFocus()
        
        return True


def main():
    app = GMApp()
    reactor.registerWxApp(app)
    
    #reactor.callLater(.1,ShowLoginDialog,app.mainFrame)
        
    
    try:
    	reactor.run()
    except:
        traceback.print_exc()


main()