
from mud.world.zone import Zone
from mud.world.defines import *
from utils import *
from mud.world.loot import ZONE_ENCHANTINGITEMS

ENCHANT_FocusPowersNice = {
'Health':'Max Health',
'Ether':'Max Mana',
'Endurance':'Max Stamina',
'Strength':'Strength',
"Constitution":'Body',
"Instinct":'Reflex',
"Nimbleness":'Agility',
"Quickness":'Dexterity',
"Insight":'Mind',
'Clarity':'Wisdom',
"the Arcane":'Mysticism',
'Defense':'Armor',
'Physical Protection':'Physical Resistance',
'Magic Protection':'Magical Resistance',
'Fiery Protection':'Fire Resistance',
'Cold Protection':'Cold Resistance',
'Electrical Resistance':'Electrical Resistance',
'Acidity':'Acid Resistance',
'Poison Resist':'Poison Resistance',
'Disease Resist':'Disease Resistance',
'the Sphinx':'Cast Time',
'the Dwarven King':'Health Regeneration',
'Volsh':'Melee Haste',
'Speed':'Movement Speed',
'Lightning':'Spell Damage',
'the Warling Cleric':'Healing Spell Modifier',
'Aelieas':'Mana Regeneration',
'the Cavebear':'Stamina Regeneration',
'the Ghoul Slayer':'Undead Bane'
}

ZonePage = """
---+ ^^ZONENAME^^

*Quick Links:* [[#MySpawns][Spawns]],[[#MyLoot][Loot]]

---++ Description

^^DESCTEXT^^
#MyLoot
---++ Loot
^^LOOTTEXT^^
#MySpawns
---++ Spawns
^^SPAWNTEXT^^
    
"""

def SpawnSort(a,b):
    if a.name < b.name:
        return -1
    if a.name > b.name:
        return 1
    return 0


def GenLootText(zone):
    items = []
    spawns = []
    
    for sg in zone.spawnGroups:
        for si in sg.spawninfos:
            if si.spawn not in spawns:
                spawns.append(si.spawn)
    
    for s in spawns:
        if s.lootProto:
            for lootitem in s.lootProto.lootItems:
                if lootitem.itemProto not in items:
                    items.append(lootitem.itemProto)
    
    items.sort(SpawnSort)
    
    loottext = ', '.join('[[Item%s][%s]]'%(GetTWikiName(item.name),item.name) for item in items)
    return loottext


def GenSpawnText(zone):
    spawns = []
    for sg in zone.spawnGroups:
        for si in sg.spawninfos:
            if si.spawn not in spawns:
                spawns.append(si.spawn)
                
    #generate twiki names
    twiki = dict((s,'Spawn'+GetTWikiName(s.name)) for s in spawns)
    
    vendors  = []
    npc      = []
    monsters = []
    dialog   = []
    uniques  = []
    inns     = []
    
    spawns.sort(SpawnSort)
    
    for s in spawns:
        if s.vendorProto:
            vendors.append(s)
        if s.flags&RPG_SPAWN_UNIQUE:
            uniques.append(s)
        if s.realm == RPG_REALM_MONSTER:
            monsters.append(s)
        else:
            npc.append(s)
        if s.dialog:
            dialog.append(s)
        if s.flags&RPG_SPAWN_INN:
            inns.append(s)
    
    stext = ""
    if len(dialog):
        stext += "\n\n*Quests, Trainers, Dialog:* %s"%', '.join('[[%s][%s]]'%(twiki[s],s.name) for s in dialog)
    
    if len(inns):
        stext += "\n\n*Innkeepers:* %s"%', '.join('[[%s][%s]]'%(twiki[s],s.name) for s in inns)
    
    if len(vendors):
        stext += "\n\n*Vendors:* %s"%', '.join('[[%s][%s]]'%(twiki[s],s.name) for s in vendors)
    
    if len(uniques):
        stext += "\n\n*Uniques:* %s"%', '.join('[[%s][%s]]'%(twiki[s],s.name) for s in uniques)
    
    if len(npc):
        stext += "\n\n*NPC:* %s"%', '.join('[[%s][%s]]'%(twiki[s],s.name) for s in npc)
    
    if len(monsters):
        stext += "\n\n*Monsters:* %s"%', '.join('[[%s][%s]]'%(twiki[s],s.name) for s in monsters)
    
    return stext


def CreateZonePages():
    climate = {}
    climate[RPG_CLIMATE_POLAR]="Polar"
    climate[RPG_CLIMATE_TROPICAL]="Tropical"
    climate[RPG_CLIMATE_TEMPERATE]="Temperate"
    climate[RPG_CLIMATE_DRY]="Dry"
    climate[RPG_CLIMATE_COLD]="Cold"
    
    indexPage = '%META:TOPICINFO{author="JoshRitter" date="1121799107" format="1.0" version="1.1"}%\n'
    indexPage += "---+ Zone Index\n\n"
    
    FocusLootDetailPage = """
---+ Enchanting Focus Loot Details

In every zone that allows for focus drops there is a slight chance to get a focus from all mobs living in that zone. The special zone focii are especially rare.
The dropped focii have a random variety in quality [[FocusMergingDetails][(Focus Merging Details)]]. Higher quality is significantly rarer. The special zone focii always come at maximum quality.
Raw focus types are never dropped and can only be gained through disenchanting.


---++ Zones in which to find Focii
"""
    
    
    #ZONES
    for zone in Zone.select(orderBy = "niceName"):
        page = ZonePage
        addToFocusPage = False
        if zone.name in ZONE_ENCHANTINGITEMS:
            addToFocusPage = True
        
        TWIKINAME = "Zone"+GetTWikiName(zone.niceName)
        indexPage+="\t* [[%s][%s]]\n"%(TWIKINAME,zone.niceName)
        if addToFocusPage:
            FocusLootDetailPage += "\n\n---++++ [[%s][%s]]\n \t*Raw Type:* %s <br> \t*Random Focii:* <br>"%(TWIKINAME,zone.niceName,ZONE_ENCHANTINGITEMS[zone.name][0].split(' of ',1)[0])
            for focusName in ZONE_ENCHANTINGITEMS[zone.name][:-1]:
                FocusLootDetailPage += "\t\t    %s (%s) <br>"%(focusName,ENCHANT_FocusPowersNice[focusName.split(' of ',1)[1]])
            specialFocus = ZONE_ENCHANTINGITEMS[zone.name][-1]
            FocusLootDetailPage += " \t*Special Focus:* %s (%s) <br>"%(specialFocus,ENCHANT_FocusPowersNice[specialFocus.split(' of ',1)[1]])
        
        DESCTEXT = "*Climate:* "+climate[zone.climate]+"<br>\n"
        b = (int(zone.xpMod*100)-100)
        if b:
            DESCTEXT += "*Experience Bonus:* %i%%<br>"%b
        
        SPAWNTEXT = GenSpawnText(zone)
        LOOTTEXT = GenLootText(zone)
        
        page = page.replace("^^DESCTEXT^^",DESCTEXT)
        page = page.replace("^^ZONENAME^^",zone.niceName)
        page = page.replace("^^SPAWNTEXT^^",SPAWNTEXT)
        page = page.replace("^^LOOTTEXT^^",LOOTTEXT)
        
        f = file("./distrib/twiki/data/MoMWorld/%s.txt"%TWIKINAME,"w")
        f.write(page)
        f.close()
    
    
    f = file("./distrib/twiki/data/MoMWorld/ZoneIndex.txt","w")
    f.write(indexPage)
    f.close()
    f = file("./distrib/twiki/data/MoMWorld/FocusLootDetails.txt","w")
    f.write(FocusLootDetailPage)
    f.close()
        
        
 