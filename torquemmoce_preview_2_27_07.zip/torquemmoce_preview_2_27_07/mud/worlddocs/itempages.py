from mud.world.vendor import VendorProto
from mud.world.loot import LootProto
from mud.world.spell import SpellProto
from mud.world.dialog import Dialog
from mud.world.crafting import Recipe

from mud.world.defines import *
from utils import *

ItemPage = """
---+ ^^ITEMNAME^^

---++ Description

^^DESCTEXT^^

---++ Stats

---+++++ ^^FLAGTEXT^^

^^STATTEXT^^

---++ Procurement
^^PROCUREMENTTEXT^^

---++ Quests
^^QUESTTEXT^^
"""


#we'll only document items that actually drop, can be bought, can be summoned, or are the results of a quest

def ItemSort(a,b):
    if a.name < b.name:
        return -1
    if a.name > b.name:
        return 1
    return 0

def ItemLevelSort(a,b):
    if a.level < b.level:
        return -1
    if a.level > b.level:
        return 1
    return 0

LOOTITEMS = []
VENDORITEMS = []
SUMMONEDITEMS = []
QUESTITEMS = []

CRAFTITEMS = []
WEAPONCRAFTITEMS = []
ARMORCRAFTITEMS = []
ARCHERYITEMS = []
POISONITEMS = []
ALCHEMYITEMS = []
INGREDIENTS = {} #itemproto -> list of recipes
RECIPES = {} #itemproto->list of recipes


#[itemproto]->spawns
LOOT = {}

#[item]->dialog
QUESTSGIVE = {}
QUESTSTAKE = {}
QUESTSCHECK = {}

#[item]->spells
SUMMONED = {}

#item->spawns
VENDORS = {}

# sub indexes, syntax: [file name, title, associated item list]
ItemSubIndexes = []
ItemSubIndexes.append(("ItemWeaponCraftIndex","Weapon Crafts and Ingredients",WEAPONCRAFTITEMS))
ItemSubIndexes.append(("ItemArmorCraftIndex","Armor Crafts and Ingredients",ARMORCRAFTITEMS))
ItemSubIndexes.append(("ItemArcheryCraftIndex","Archery Crafts and Ingredients",ARCHERYITEMS))
ItemSubIndexes.append(("ItemPoisonCraftIndex","Poisons and Ingredients",POISONITEMS))
ItemSubIndexes.append(("ItemAlchemyCraftIndex","Alchemy Crafts and Ingredients",ALCHEMYITEMS))
ItemSubIndexes.append(("ItemSummonedIndex","Summoned Items",SUMMONEDITEMS))
ItemSubIndexes.append(("ItemQuestIndex","Quest Items",QUESTITEMS))


def GetItemList(spellSummonItems,questItems):
    
    items = []
    
    #CRAFTED
    for rproto in Recipe.select():
        iproto = rproto.craftedItemProto
        craftskill = rproto.skillname
        if iproto:
            if craftskill == "Weapon Craft":
                if iproto not in WEAPONCRAFTITEMS:
                    WEAPONCRAFTITEMS.append(iproto)
            elif craftskill == "Armor Craft":
                if iproto not in ARMORCRAFTITEMS:
                    ARMORCRAFTITEMS.append(iproto)
            elif craftskill == "Archery":
                if iproto not in ARCHERYITEMS:
                    ARCHERYITEMS.append(iproto)
            elif craftskill == "Poisons":
                if iproto not in POISONITEMS:
                    POISONITEMS.append(iproto)
            elif craftskill == "Alchemy":
                if iproto not in ALCHEMYITEMS:
                    ALCHEMYITEMS.append(iproto)
            
            if iproto not in items:
                items.append(iproto)
            if iproto not in CRAFTITEMS:
                CRAFTITEMS.append(iproto)
            if not RECIPES.has_key(iproto):
                RECIPES[iproto]=[]
            if rproto not in RECIPES[iproto]:
                RECIPES[iproto].append(rproto)
                
            for ing in rproto.ingredients:
                iproto = ing.itemProto
                if craftskill == "Weapon Craft":
                    if iproto not in WEAPONCRAFTITEMS:
                        WEAPONCRAFTITEMS.append(iproto)
                elif craftskill == "Armor Craft":
                    if iproto not in ARMORCRAFTITEMS:
                        ARMORCRAFTITEMS.append(iproto)
                elif craftskill == "Archery":
                    if iproto not in ARCHERYITEMS:
                        ARCHERYITEMS.append(iproto)
                elif craftskill == "Poisons":
                    if iproto not in POISONITEMS:
                        POISONITEMS.append(iproto)
                elif craftskill == "Alchemy":
                    if iproto not in ALCHEMYITEMS:
                        ALCHEMYITEMS.append(iproto)
                
                if iproto not in items:
                    items.append(iproto)
                
                if not INGREDIENTS.has_key(iproto):
                    INGREDIENTS[iproto]=[]
                if rproto not in INGREDIENTS[iproto]:
                    INGREDIENTS[iproto].append(rproto)
                
                
    
    
    #LOOT
    for proto in LootProto.select():
        for lootitem in proto.lootItems:
            if lootitem.itemProto not in items:
                items.append(lootitem.itemProto)
            if lootitem.itemProto not in LOOTITEMS:
                LOOTITEMS.append(lootitem.itemProto)
                
            if not LOOT.has_key(lootitem.itemProto):
                LOOT[lootitem.itemProto]=[]
            
            for spawn in proto.spawns:
                if not spawn in LOOT[lootitem.itemProto]:
                    LOOT[lootitem.itemProto].append(spawn)
                
                
    #VENDORS
    for proto in VendorProto.select():
        for vitem in proto.vendorItems:
            if vitem.itemProto not in items:
                items.append(vitem.itemProto)
        
            if vitem.itemProto not in VENDORITEMS:
                VENDORITEMS.append(vitem.itemProto)
                
            if not VENDORS.has_key(vitem.itemProto):
                VENDORS[vitem.itemProto]=[]
                
            for spawn in proto.spawns:
                if not spawn in VENDORS[vitem.itemProto]:
                    VENDORS[vitem.itemProto].append(spawn)
            

    #SUMMONED
    for summonItem in spellSummonItems.iterkeys():
        if summonItem not in items:
            items.append(summonItem)
        if summonItem not in SUMMONEDITEMS:
            SUMMONEDITEMS.append(summonItem)
        if not SUMMONED.has_key(summonItem):
            SUMMONED[summonItem]=[]
        for proto in spellSummonItems[summonItem]:
            if proto not in SUMMONED[summonItem]:
                SUMMONED[summonItem].append(proto)

        
    #QUEST
    # first come the items taken
    for qitem in questItems[0].iterkeys():
        if qitem not in items:
            items.append(qitem)
        if qitem not in QUESTITEMS:
            QUESTITEMS.append(qitem)
        if not QUESTSTAKE.has_key(qitem):
            QUESTSTAKE[qitem] = []
        for dialog in questItems[0][qitem]:
            if dialog not in QUESTSTAKE[qitem]:
                QUESTSTAKE[qitem].append(dialog)
    # then items checked
    for qitem in questItems[1].iterkeys():
        if qitem not in items:
            items.append(qitem)
        if qitem not in QUESTITEMS:
            QUESTITEMS.append(qitem)
        if not QUESTSCHECK.has_key(qitem):
            QUESTSCHECK[qitem] = []
        for dialog in questItems[1][qitem]:
            if dialog not in QUESTSCHECK[qitem]:
                QUESTSCHECK[qitem].append(dialog)
    # then items given
    for qitem in questItems[2].iterkeys():
        if qitem not in items:
            items.append(qitem)
        if qitem not in QUESTITEMS:
            QUESTITEMS.append(qitem)
        if not QUESTSGIVE.has_key(qitem):
            QUESTSGIVE[qitem] = []
        for dialog in questItems[2][qitem]:
            if dialog not in QUESTSGIVE[qitem]:
                QUESTSGIVE[qitem].append(dialog)
        
            
    items.sort(ItemSort)
    WEAPONCRAFTITEMS.sort(ItemSort)
    ARMORCRAFTITEMS.sort(ItemSort)
    ARCHERYITEMS.sort(ItemSort)
    POISONITEMS.sort(ItemSort)
    ALCHEMYITEMS.sort(ItemSort)
    SUMMONEDITEMS.sort(ItemSort)
    QUESTITEMS.sort(ItemSort)
    
    return items


def GenProcurementText(item):
    
    ptext = []
    
    #crafted
    recipes = RECIPES.get(item)
    if recipes and len(recipes):
        ptext.append("<br> *Recipe:* ")
        ptext.append(', '.join("[[%s][%s]]"%("Recipe%s"%GetTWikiName(r.name),r.name) for r in recipes))

    #craft ingredient
    recipes = INGREDIENTS.get(item)
    if recipes and len(recipes):
        ptext.append("<br> *Craft Ingredient:* ")
        ptext.append(', '.join("[[%s][%s]]"%("Recipe%s"%GetTWikiName(r.name),r.name) for r in recipes))
    
    #vendors
    vendors = VENDORS.get(item)
    if vendors and len(vendors):
        ptext.append("<br> *Vendors:* ")
        ptext.append(', '.join("[[%s][%s]]"%("Spawn%s"%GetTWikiName(v.name),v.name) for v in vendors))
    
    #spawns    
    spawns = LOOT.get(item)
    if spawns and len(spawns):
        ptext.append("<br> *Spawns:* ")
        ptext.append(', '.join("[[%s][%s]]"%("Spawn%s"%GetTWikiName(s.name),s.name) for s in spawns))
    
    #quests    
    quests = QUESTSGIVE.get(item)
    if quests and len(quests):
        ptext.append("<br> *Quests:* ")
        ptext.append(', '.join("[[%s][%s]]"%("Quest%s"%GetTWikiName(q.name),q.name) for q in quests))
    
    #summoned
    spells = SUMMONED.get(item)
    if spells and len(spells):
        ptext.append("<br> *Summoning Spells:* ")
        ptext.append(', '.join("[[%s][%s]]"%("Spell%s"%GetTWikiName(s.name),s.name) for s in spells))
    
    return ''.join(ptext)

def GenQuestText(item):
    ptext = []
    
    #quests    
    quests = QUESTSGIVE.get(item)
    if quests and len(quests):
        ptext.append("<br> *Rewarded By:* ")
        ptext.append(', '.join("[[%s][%s]]"%("Quest%s"%GetTWikiName(q.name),q.name) for q in quests))

    quests = QUESTSTAKE.get(item)
    if quests and len(quests):
        ptext.append("<br> *Taken By:* ")
        ptext.append(', '.join("[[%s][%s]]"%("Quest%s"%GetTWikiName(q.name),q.name) for q in quests))

    quests = QUESTSCHECK.get(item)
    if quests and len(quests):
        ptext.append("<br> *Checked By:* ")
        ptext.append(', '.join("[[%s][%s]]"%("Quest%s"%GetTWikiName(q.name),q.name) for q in quests))

    return ''.join(ptext)
        
def GenFlagText(item):
    ftext = []
    #FLAGS
    for f,t in RPG_ITEM_FLAG_TEXT.iteritems():
        if item.flags&f:
            ftext.append(t)
            
    return ' '.join(ftext)
    
def GenStatText(item):
    stext = []
    
    #races
    
    if item.level > 1:
        stext.append("*Recommended Level:* %i<br> "%item.level)
    
    
    races = item.races
    if len(races):
        stext.append("*Races:* ")
        stext.append(', '.join("[[%s][%s]]"%("Race%s"%GetTWikiName(race),race) for race in races))
        stext.append(' ')
    
    #classes
    classes = list(item.classes)
    if len(classes):
        stext.append("*Classes:* ")
        stext.append(', '.join("[[%s][%s]] (%i)"%("Class%s"%GetTWikiName(klass.classname),klass.classname,klass.level) for klass in classes))
        stext.append(' ')
    
    #slots
    if len(item.slots):
        stext.append("*Slots:* ")
        stext.append(', '.join(RPG_SLOT_TEXT[slot] for slot in item.slots))
        stext.append(' ')
    
    #skill
    if item.skill:
        stext.append("*Skill:* %s "%item.skill)

    #weapon
    if item.wpnDamage:
        stext.append("*Weapon:* %i/%i/%i "%(int(item.wpnDamage),int(item.wpnRate),int(item.wpnRange)))

    #armor
    if item.armor:
        stext.append("*Armor:* %i "%(item.armor))

    #light
    if item.light:
        stext.append("*Light:* %i "%(int(item.light)))
        
        
    #stats
    stats = list(item.stats)
    if len(stats):
        stext.append("<br> *Special:* ")
        for st in stats:
            name = st.statname
            value = st.value
            
            if name=="haste":
                stext.append("%%GREEN%%HASTE %i%% %%ENDCOLOR%%, "%int(value*100.0))
            elif name.lower()=="casthaste":
                stext.append("%%GREEN%%CASTING HASTE %i%% %%ENDCOLOR%%, "%int(value*100.0))
            elif name=="regenHealth":
                stext.append("%%GREEN%%HEALTH REGEN %i %%ENDCOLOR%%, "%int(value))
            elif name=="regenMana":
                stext.append("%%BLUE%%MANA REGEN %i %%ENDCOLOR%%, "%int(value))
            elif name=="regenStamina":
                stext.append("%%YELLOW%%STAMINA REGEN %i %%ENDCOLOR%%, "%int(value))
            elif name=="move":
                stext.append("%%GREEN%%MOVE +%i%% %%ENDCOLOR%%, "%int(value*100.0))
            elif value != round(value):
                if value > 0:
                    stext.append("%%GREEN%%%s %i%% %%ENDCOLOR%%, "%(name.upper(),int(value*100.0)))
                else:
                    stext.append("%%RED%%%s %i%% %%ENDCOLOR%%, "%(name.upper(),int(value*100.0)))
            else:
                if value > 0:
                    stext.append("%%GREEN%%%s %i %%ENDCOLOR%%, "%(name.upper(),int(value)))
                else:
                    stext.append("%%RED%%%s %i %%ENDCOLOR%%, "%(name.upper(),int(value)))
                
            
        stext[-1] = stext[-1][:-2]+" "
        
    #procs
    

    trigger = {}
    trigger[RPG_ITEM_TRIGGER_WORN]="Worn"
    trigger[RPG_ITEM_TRIGGER_MELEE]="Melee"
    trigger[RPG_ITEM_TRIGGER_DAMAGED]="Damaged"
    trigger[RPG_ITEM_TRIGGER_USE]="Use"
    trigger[RPG_ITEM_TRIGGER_POISON]="Poison"

    spells = list(item.spells)
    if len(spells):
        stext.append("<br> *Procs:* ")
        stext.append(', '.join("[[%s][%s]] (%s)"%("Spell%s"%GetTWikiName(s.spellProto.name),s.spellProto.name,trigger[s.trigger]) for s in spells))
        stext.append(' ')
    
    
    return ''.join(stext)

def CreateItemSubIndex(indexFile,indexTitle,itemList):
    subpage = "---+ %s\n\n"%indexTitle
    subpage += ''.join("\t* [[%s][%s]]\n"%("Item%s"%GetTWikiName(item.name),item.name) for item in itemList)
    f = file("./distrib/twiki/data/MoMWorld/%s.txt"%indexFile,"w")
    f.write(subpage)
    f.close()

def CreateItemIndex(items):

    # top index
    indexPage = '%META:TOPICINFO{author="JoshRitter" date="1121799107" format="1.0" version="1.1"}%\n'
    indexPage += "---+ Item Index\n\n"
    indexPage += "\t* [[ItemAllIndex][Index of all Items]]\n"
    items.sort(ItemLevelSort)
    indexPage += "\t* [[ItemAllLevelIndex][Index of all Items by Level]]\n\n"
    
    subpage = "---+ Index of all Items by Level\n\n"
    level = 0
    for item in items:
        # filter out all uninteresting items
        if not len(item.slots):
            if not len(item.spells):
                if item.level <= 1:
                    continue
        if item.level != level:
            level = item.level
            subpage+="---+++ Level %i<br>\n"%level
        TWIKINAME = "Item"+GetTWikiName(item.name)
        subpage+="\t* [[%s][%s]]\n"%(TWIKINAME,item.name)
    f = file("./distrib/twiki/data/MoMWorld/ItemAllLevelIndex.txt","w")
    f.write(subpage)
    f.close()
    
    for index in ItemSubIndexes:
        indexPage += "\t* [[%s][%s]]\n"%(index[0],index[1])
        CreateItemSubIndex(index[0],index[1],index[2])
    # the table for spell scrolls will be generated in spellpages.py
    # since we go through all scrolls there anyway
    indexPage += "\t* [[ItemSpellScrollsIndex][Spell Scrolls]]\n"
    
    f = file("./distrib/twiki/data/MoMWorld/ItemIndex.txt","w")
    f.write(indexPage)
    f.close()

        
def CreateItemPages(spellSummonItems,questItems):
    
    items = GetItemList(spellSummonItems,questItems)
    
    allPage = "---+ Index of all Items\n\n"
    
    for item in items:
        
        page = ItemPage
        
        TWIKINAME = "Item"+GetTWikiName(item.name)
        allPage += "\t* [[%s][%s]]\n"%(TWIKINAME,item.name)
        
        PROCUREMENTTEXT = GenProcurementText(item)
        FLAGTEXT = GenFlagText(item)
        STATTEXT = GenStatText(item)
        QUESTTEXT = GenQuestText(item)
        
        page=page.replace("^^ITEMNAME^^",item.name)
        if item.desc:
            page=page.replace("^^DESCTEXT^^",item.desc)
        else:
            page=page.replace("^^DESCTEXT^^","None")
            
        page=page.replace("^^PROCUREMENTTEXT^^",PROCUREMENTTEXT)
        page=page.replace("^^FLAGTEXT^^",FLAGTEXT)
        page=page.replace("^^STATTEXT^^",STATTEXT)
        page=page.replace("^^QUESTTEXT^^",QUESTTEXT)
        
        f = file("./distrib/twiki/data/MoMWorld/%s.txt"%TWIKINAME,"w")
        f.write(page)
        f.close()
    
    f = file("./distrib/twiki/data/MoMWorld/ItemAllIndex.txt","w")
    f.write(allPage)
    f.close()
    CreateItemIndex(items)
        
        
    


    

 