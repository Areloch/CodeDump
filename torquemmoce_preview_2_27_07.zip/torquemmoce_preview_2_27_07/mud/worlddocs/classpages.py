#Quest Pages

from mud.world.defines import *
from utils import *
from mud.world.career import ClassProto
from mud.world.spell import SpellProto
from mud.world.advancement import *

ClassPage = """
---+ ^^CLASSNAME^^

---++ Skills
^^SKILLTEXT^^

---++ Spells
^^SPELLTEXT^^

---++ Advancement
^^ADVANCEMENTTEXT^^

"""

CLASSSKILLS = {}

def SortSkill(a,b):
    if a.levelGained < b.levelGained:
        return -1
    if a.levelGained > b.levelGained:
        return 1
    return 0

def SortAdvancement(a,b):
    classes1 = list(a.classes)
    classes2 = list(b.classes)
    
    
    level1 = a.level
    
    for c in classes1:
        if c.classname == a.klass.name:
            if c.level > level1:
                level1 = c.level
            break

    
    level2 = b.level
    
    for c in classes2:
        if c.classname == b.klass.name:
            if c.level > level2:
                level2 = c.level
            break
            
    if level1 < level2:
        return -1
    
    if level1 > level2:
        return 1
    
    return 0
    
    

def GenAdvancementText(c):
    
    advances = []
    
    for advance in AdvancementProto.select():
        
        advance.myLevel = advance.level
        q = True
        
        classes = list(advance.classes)
        races = list(advance.races)
        if len(races) and not len(classes):
            continue #racial
        
        if len(classes):
            q = False
            for cl in classes:
                if cl.classname == c.name:
                    if cl.level > advance.myLevel:
                        advance.myLevel = cl.level #stash
                    q = True
                    break
                
        if not q:
            continue
        advance.klass = c #stash for sort
        advances.append(advance)
        
        
    if not len(advances):
        return ""
    
    advances.sort(SortAdvancement)
    
    atable = "| *Advancement* | *Level* | *Cost* | *Max Rank* | *Description*| *Requirements* | *Exclusion* |\n"
    
    for a in advances:
        reqtext = []
        races = list(a.races)
        for r in a.requirements:
            if r.rank > 1:
                reqtext.append("%s (%i)"%(r.require,r.rank))
            else:
                reqtext.append(r.require)
        
        reqtext.append(', '.join('(Race) %s'%r.racename for r in races))
        
        atable+="| %s | %i | %i | %i | %s | %s | %s |\n"%(a.name,a.myLevel,a.cost,a.maxRank,a.desc,', '.join(reqtext),', '.join(ex.exclude for ex in a.exclusions))
        
    return atable
        
        
        
    
    

def GenSkillText(c):
    stext = "| *Skill* | *Level Gained* | *Level Capped* | *Max* | *Trained* |\n"
    skills = list(c.skills)
    skills.sort(SortSkill)
    for s in skills:
        skillname = s.skillname
        twiki = "Skill"+GetTWikiName(skillname)
        trained = "No"
        if s.trained:
            trained = "Yes"
        
        # pretty big sorting...
        if skillname in CLASSSKILLS:
            CLASSSKILLS[skillname][0].append(c.name)
            if CLASSSKILLS[skillname][1].has_key(s.levelGained):
                CLASSSKILLS[skillname][1][s.levelGained].append(c.name)
            else:
                CLASSSKILLS[skillname][1][s.levelGained] = [c.name]
            if CLASSSKILLS[skillname][2].has_key(s.levelCapped):
                CLASSSKILLS[skillname][2][s.levelCapped].append(c.name)
            else:
                CLASSSKILLS[skillname][2][s.levelCapped] = [c.name]
            if CLASSSKILLS[skillname][3].has_key(s.minReuseTime):
                CLASSSKILLS[skillname][3][s.minReuseTime].append(c.name)
            else:
                CLASSSKILLS[skillname][3][s.minReuseTime] = [c.name]
            if CLASSSKILLS[skillname][4].has_key(s.maxReuseTime):
                CLASSSKILLS[skillname][4][s.maxReuseTime].append(c.name)
            else:
                CLASSSKILLS[skillname][4][s.maxReuseTime] = [c.name]
            if CLASSSKILLS[skillname][5].has_key(s.maxValue):
                CLASSSKILLS[skillname][5][s.maxValue].append(c.name)
            else:
                CLASSSKILLS[skillname][5][s.maxValue] = [c.name]
            if CLASSSKILLS[skillname][6].has_key(trained):
                CLASSSKILLS[skillname][6][trained].append(c.name)
            else:
                CLASSSKILLS[skillname][6][trained] = [c.name]
            raceReq = s.raceRequirementsInternal[:]
            if len(raceReq):
                racenames = [req.race for req in raceReq]
                existing = False
                if not len(CLASSSKILLS[skillname][7]):
                    CLASSSKILLS[skillname][7] = [[],[]]
                for i in xrange(len(CLASSSKILLS[skillname][7][0])):
                    if CLASSSKILLS[skillname][7][0][i] == racenames:
                        CLASSSKILLS[skillname][7][1][i].append(c.name)
                        existing = True
                        break
                if not existing:
                    CLASSSKILLS[skillname][7][0].append(racenames)
                    CLASSSKILLS[skillname][7][1].append([c.name])
            if s.spellProto:
                protoname = s.spellProto.name
                if CLASSSKILLS[skillname][8].has_key(protoname):
                    CLASSSKILLS[skillname][8][protoname].append(c.name)
                else:
                    CLASSSKILLS[skillname][8][protoname] = [c.name]
        else:
            CLASSSKILLS[skillname] = [[c.name],{s.levelGained:[c.name]},{s.levelCapped:[c.name]},{s.minReuseTime:[c.name]},{s.maxReuseTime:[c.name]},{s.maxValue:[c.name]},{trained:[c.name]},[],{}]
            raceReq = s.raceRequirementsInternal[:]
            if len(raceReq):
                racenames = [req.race for req in raceReq]
                CLASSSKILLS[skillname][7] = [[racenames],[[c.name]]]
            if s.spellProto:
                CLASSSKILLS[skillname][8] = {s.spellProto.name:[c.name]}
        
        stext+="| [[%s][%s]] | %i | %i | %i | %s |\n"%(twiki,skillname,s.levelGained,s.levelCapped,s.maxValue,trained)
    
    return stext

def SortSpell(a,b):
    spell1,value1 = a[0],a[1]
    spell2,value2 = b[0],b[1]
    
    if value1 < value2:
        return -1
    if value2 > value1:
        return 1
    
    return 0


def GenSpellText(c,spellClasses):
    stext = ""
    stable = "| *Spell* | *Level Gained* |\n"
    
    # better do this here, class spells by level need a special sort
    spellPage = "---+ %s Spells\n\n"%c.name
    
    spells = []
    
    if spellClasses.has_key(c.name):
        spells = spellClasses[c.name]
    
    spells.sort(SortSpell)
    
    for sname,level in spells:
        twiki = "Spell"+GetTWikiName(sname)
        stable+="| [[%s][%s]] | %i |\n"%(twiki,sname,level)
        spellPage+="\t* (%i)\t [[%s][%s]]\n"%(level,twiki,sname)
    
    f = file("./distrib/twiki/data/MoMWorld/Spell%sIndex.txt"%GetTWikiName(c.name),"w")
    f.write(spellPage)
    f.close()
    stext+=stable
    return stext


def CreateClassPages(spellClasses):
    
    indexPage = '%META:TOPICINFO{author="JoshRitter" date="1121799107" format="1.0" version="1.1"}%\n'
    indexPage += "---+ Class Index\n\n"
    
    for c in ClassProto.select(orderBy="name"):
        page = ClassPage
        
        TWIKINAME = "Class"+GetTWikiName(c.name)
        indexPage+="\t* [[%s][%s]]\n"%(TWIKINAME,c.name)
        SKILLTEXT = GenSkillText(c)
        ADVANCEMENTTEXT = GenAdvancementText(c)
        SPELLTEXT = GenSpellText(c,spellClasses)
        page=page.replace("^^CLASSNAME^^",c.name)
        page=page.replace("^^SKILLTEXT^^",SKILLTEXT)
        page=page.replace("^^SPELLTEXT^^",SPELLTEXT)
        page=page.replace("^^ADVANCEMENTTEXT^^",ADVANCEMENTTEXT)
        
        f = file("./distrib/twiki/data/MoMWorld/%s.txt"%TWIKINAME,"w")
        f.write(page)
        f.close()
    
    f = file("./distrib/twiki/data/MoMWorld/ClassIndex.txt","w")
    f.write(indexPage)
    f.close()
    
    return CLASSSKILLS
        
    

 