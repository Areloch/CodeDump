

def GetTWikiName(name):
    if not name:
        return ""
    # special characters can't be removed with strip()
    for spchar in [".",";",":",",","'","/"]:
        name = name.replace(spchar,"")
    listname = name.split(" ")
    tname = ""
    for n in listname:
        tname+=n[0].upper()+n[1:]
    
    return tname
 