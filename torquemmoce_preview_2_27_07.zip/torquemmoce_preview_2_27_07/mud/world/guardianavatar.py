from mud.common.permission import User,Role
from mud.common.avatar import Avatar
from mud.world.player import Player
from guardiancommand import DoGuardianCommand

class GuardianAvatar(Avatar):
    def __init__(self,username,role,mind):
        Avatar.__init__(self,username,role,mind)
        self.username = username
        self.mind = mind
        self.player = Player.byPublicName(username)
        from mud.world.theworld import World
        self.world = World.byName("TheWorld")

        
    def perspective_command(self,cmd,args):
        DoGuardianCommand(self.player,cmd,args)
        
        
        
 