
from math import floor
from messages import GameMessage
from defines import *
import time
from shared.vocals import *
import random
from core import *
import random
from random import randint

import math

class ExtraDamageInfo:
    def __init__(self):
        self.clear()
    def clear(self):
        self.resistDebuff = None
        self.resistDebuffMod = 0

class XPDamage:
    def __init__(self):
        self.lastTime = time.time()
        self.amount = 0
        
    def addDamage(self,amount):
        self.amount+=amount
        self.lastTime = time.time()


DAMAGETEXT = {}
DAMAGETEXT[RPG_DMG_FIRE]="burns"
DAMAGETEXT[RPG_DMG_COLD]="freezes"
DAMAGETEXT[RPG_DMG_POISON]="poisons"
DAMAGETEXT[RPG_DMG_DISEASE]="diseases"
DAMAGETEXT[RPG_DMG_ACID]="corrodes"
DAMAGETEXT[RPG_DMG_ELECTRICAL]="zaps"
DAMAGETEXT[RPG_DMG_MAGICAL]="oppresses"
DAMAGETEXT[RPG_DMG_SLASHING]="slashes"
DAMAGETEXT[RPG_DMG_IMPACT]="crushes"
DAMAGETEXT[RPG_DMG_CLEAVE]="cleaves"
DAMAGETEXT[RPG_DMG_PIERCING]="pierces"
DAMAGETEXT[RPG_DMG_PHYSICAL]="damages"
DAMAGETEXT[RPG_DMG_PUMMEL]="pummels"
DAMAGETEXT[RPG_DMG_CLAWS]="claws"
DAMAGETEXT[RPG_DMG_CRITICAL]="critically wounds"
DAMAGETEXT[RPG_DMG_DRAIN]="drains"

DAMAGETEXTNOINFLICTOR = {}
DAMAGETEXTNOINFLICTOR[RPG_DMG_FIRE]="burned"
DAMAGETEXTNOINFLICTOR[RPG_DMG_COLD]="frozen"
DAMAGETEXTNOINFLICTOR[RPG_DMG_POISON]="poisoned"
DAMAGETEXTNOINFLICTOR[RPG_DMG_DISEASE]="diseased"
DAMAGETEXTNOINFLICTOR[RPG_DMG_ACID]="corroded"
DAMAGETEXTNOINFLICTOR[RPG_DMG_ELECTRICAL]="zapped"
DAMAGETEXTNOINFLICTOR[RPG_DMG_MAGICAL]="oppressed"
DAMAGETEXTNOINFLICTOR[RPG_DMG_SLASHING]="slashed"
DAMAGETEXTNOINFLICTOR[RPG_DMG_IMPACT]="crushed"
DAMAGETEXTNOINFLICTOR[RPG_DMG_CLEAVE]="cleaved"
DAMAGETEXTNOINFLICTOR[RPG_DMG_PUMMEL]="pummeled"
DAMAGETEXTNOINFLICTOR[RPG_DMG_PIERCING]="pierced"
DAMAGETEXTNOINFLICTOR[RPG_DMG_CLAWS]="clawed"
DAMAGETEXTNOINFLICTOR[RPG_DMG_CRITICAL]="critically wounded"
DAMAGETEXTNOINFLICTOR[RPG_DMG_DRAIN]="drains"
DAMAGETEXTNOINFLICTOR[RPG_DMG_PHYSICAL]="damaged"


def Heal(mob,healer,amount,isRegen=False):
    if mob.health >= mob.maxHealth:
        return
    
    gap = mob.maxHealth - mob.health
    if amount > gap:
        amount = gap
    
    mob.health += amount
    
    if mob != healer and not isRegen:
        if healer.player and amount>1:
            for m in mob.zone.activeMobs:
                if m.player:
                    continue
                try:
                    if m.aggro[mob]>0:
                        m.addAggro(healer,amount/2)
                except KeyError:
                    pass
    
    if mob.player and not isRegen:
        mob.player.sendGameText(RPG_MSG_GAME_GOOD,"%s has been healed for %i points!\\n"%(mob.name,amount))



def Damage(mob,inflictor,amount,dmgType, textDesc = None,doThorns = True,outputText=True,isDrain=False):
    
    from spell import Spell
    
    #when you take damage your regen is halted 
    mob.regenTimer = 36
    
    if not mob.player:
        if not mob.mobInitialized:
            mob.initMob()
    
    if amount <= 0:
        amount = 1
    
    if inflictor and inflictor.character:
        if inflictor.character.invulnerable:
            inflictor.character.invulnerable = 0
            inflictor.player.sendGameText(RPG_MSG_GAME_YELLOW,r'%s is no longer protected from death.\n'%inflictor.name)
    
    if not AllowHarmful(inflictor,mob):
        return 0
    
    if inflictor and inflictor.difficultyMod != 1.0 and doThorns:
        amount += amount * (inflictor.difficultyMod/4.0)
        amount = math.ceil(amount)
        
    
    #resists
    resist = 0
    if not isDrain:
        rtype = RESISTFORDAMAGE[dmgType]
        resist = mob.resists.get(rtype,0)
    
    #only do debuff on mobs that are resistant in the first place, and never go below zero
    if resist>0 and mob.extraDamageInfo.resistDebuffMod and rtype==mob.extraDamageInfo.resistDebuff:
        resist-=mob.extraDamageInfo.resistDebuffMod
        if resist<0:
            resist = 0
            
    if resist:
        if resist < 0:
            a = amount+(-resist*3)
            if a > amount*2:
                a = amount*2
            amount = a
            
        else:            
            a=amount-(resist*2)
            if a/amount < .5:
                amount*=.5
            else:
                amount = a
    
    amount = floor(amount)
    if amount < 1:
        amount = 1
        
    if inflictor and inflictor.player:
        for c in inflictor.player.party.members:
            if c.mob.detached:
                continue
            hate = amount
            m = c.mob
            if m == inflictor:
                hate*=2
                
            mob.addAggro(m,hate)
            
    elif inflictor:# and IsKOS(inflictor,mob):
        mob.addAggro(inflictor,amount*2)
      
    if inflictor:  
        if not mob.xpDamage.has_key(inflictor):
            mob.xpDamage[inflictor]=XPDamage()
            
        mob.xpDamage[inflictor].addDamage(amount)
        
    if mob.player and inflictor and not isDrain:
        for item in mob.worn.itervalues():
            if item.slot == RPG_SLOT_PRIMARY or item.slot == RPG_SLOT_SECONDARY or item.slot==RPG_SLOT_RANGED or item.slot == RPG_SLOT_AMMO:
                continue
            if item.repairMax and item.repair and not randint(0,20):
                item.repair-=1
                repairRatio = float(item.repair)/float(item.repairMax)
                if not repairRatio:
                    mob.player.sendGameText(RPG_MSG_GAME_RED,"%s's %s has broken! (%i/%i)\\n"%(mob.name,item.name,item.repair,item.repairMax))
                    mob.playSound("sfx/Shatter_IceBlock1.ogg")
                elif repairRatio < .2:
                    mob.player.sendGameText(RPG_MSG_GAME_YELLOW,"%s's %s is severely damaged! (%i/%i)\\n"%(mob.name,item.name,item.repair,item.repairMax))
                    mob.playSound("sfx/Menu_Horror24.ogg")
                
            
                item.setCharacter(mob.character,True)

    
    mob.health-=amount
    DAMAGEAMOUNT = amount
    mob.cancelStatProcess("feignDeath","$tgt is obviously not dead!\\n")
    mob.tookDamage = True
    mob.cancelSleep()
    
    if mob.player and mob.casting and not mob.combatCasting:
        cancel = True
        conc = mob.skillLevels.get("Concentration",0)
        if conc:
            r = random.randint(0,amount)
            if r <= conc*2:
                cancel = False
                mob.character.checkSkillRaise("Concentration",2,10)
        if cancel:
            t =mob.casting.spellProto.recastTime/5
            if t:
                mob.recastTimers[mob.casting.spellProto]=t

            mob.casting.cancel()
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,"%s's casting has been interrupted!\\n"%(mob.name))

    
    #handle thorns
    if doThorns and inflictor and len(mob.processesIn) and not isDrain:
        bestp = 0
        bestmax = 0
        
        tdmgtype = DAMAGEFORRESIST[RESISTFORDAMAGE[dmgType]]
        processes = []
        for p in mob.processesIn:
            if isinstance(p,Spell):
                for e in p.effects:
                    effectProto = e.effectProto
                    if effectProto.dmgReflectionType != tdmgtype:
                        continue
                    
                    if effectProto.dmgReflectionPercent > bestp:
                        bestp = effectProto.dmgReflectionPercent
                    if effectProto.dmgReflectionMax > bestmax:
                        bestmax = effectProto.dmgReflectionMax
                        
        if bestp and bestmax:
            #thorns
            tamount = math.ceil(amount*bestp)
            if tamount > bestmax:
                tamount = bestmax
            try:
                if inflictor and outputText:
                    if inflictor.player or mob.player:
                        dmgText = DAMAGETEXTNOINFLICTOR[tdmgtype]
                        text = r'%s is %s for %i damage!\n'%(inflictor.name,dmgText,tamount)            
                        GameMessage(RPG_MSG_GAME_COMBAT,mob.zone,mob,inflictor,text,mob.simObject.position,20)

            except:
                pass
                
            Damage(inflictor,None,tamount,tdmgtype,False)    
            
        
                     
                
    
    
    #count into damage
    
    
    """
    if mob.health <= 0:
        if not mob.player:
            mob.die()
        else:
            mob.disable()
    """
    
    
    if not isDrain:
        if (inflictor and inflictor.battle) and (mob and mob.battle):
            text = ""
        else:
            dmgText = textDesc
            if not dmgText:
                if inflictor:
                    dmgText = DAMAGETEXT[dmgType]
                else:
                    dmgText = DAMAGETEXTNOINFLICTOR[dmgType]
                
            text = ""
            if inflictor:
                text = r'%s %s %s for %i damage!\n'%(inflictor.name,dmgText,mob.name,amount)
            else:
                text = r'%s is %s for %i damage!\n'%(mob.name,dmgText,amount)
            
        
    #def GameMessage(msgType,zone,src,tgt,msg,position,range=0):
    
    
    
    mob.extraDamageInfo.clear()

    if not mob.battle or not (inflictor and inflictor.battle) and not isDrain:
        mob.zone.simAvatar.mind.callRemote("pain",mob.simObject.id)
        i = inflictor
        if not inflictor:
            i = mob
            
        if outputText:    
            GameMessage(RPG_MSG_GAME_COMBAT,mob.zone,i,mob,text,mob.simObject.position,20)
    
        snd = mob.spawn.getSound("sndPain")
        if snd:
             if not random.randint(0,1):
                mob.playSound(snd)
        else:
            if not random.randint(0,2):
                mob.vocalize(VOX_HURTGRUNT)
            else:
                mob.vocalize(VOX_HURTPUNCH)
                    
    return DAMAGEAMOUNT
        
