    
import math
from mud.world.defines import *
from mud.world.damage import Damage
import random


from core import *

class Projectile:
    id = 1L
    def __init__(self,src,dst,level=1):
        self.src = src
        self.dst = dst #can be dynamically changed based on who is hit
        self.weapon = None
        self.ammoDamage = 0
        self.ammoSpells = []
        self.spellProto = None #spell payload
        self.speed = 1
        self.level = level
        
        self.projectile = None
        
        self.id = Projectile.id        
        Projectile.id+=1
        
    def onCollision(self,hitPos):
        src = self.src
        dst = self.dst
        
        if dst.player and src.target.player == dst.player:
            dst = src.target
        
        if dst.detached or src.detached:
            return

        
        if  self.spellProto:
            if self.spellProto.spellType&RPG_SPELL_HARMFUL and not src.character and dst != src.target:
                return
            from spell import SpawnSpell
            mod = 1.0
            if self.level != 1.0:
                mod+=self.level/10.0
            
            SpawnSpell(self.spellProto,src,dst,hitPos,mod)
        else:
            #this is an arrow (move this)
            
            if not AllowHarmful(src,dst):
                return
            
            if src.character and src.character.invulnerable:
                src.character.invulnerable = 0
                src.player.sendGameText(RPG_MSG_GAME_YELLOW,r'%s is no longer protected from death.\n'%src.name)
            
            if not dst.aggro.get(src):
                dst.addAggro(src,10)
            
            askill = src.skillLevels.get("Archery")
            if not askill:
                return
            
            missed = False
            if dst.plevel - src.plevel > 30:
                missed = True
            else:
                base = 4 - int((float(dst.plevel) - float(src.plevel))/10.0)
                if base > 4:
                    base = 4
                mod = int(float(askill)*2.0/float(dst.plevel))
                resistance = dst.resists.get(RPG_RESIST_PHYSICAL,0)
                mod -= int(float(resistance)/float(askill))
                if mod > 20:
                    mod = 20
                base += mod
                if base < 1:
                    base = 1
                if not random.randint(0,base):
                    missed = True
            if missed:
                if src.character:
                    if GetRange(src,dst) > 20:
                        src.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s completely misses the target.\n'%src.name)
                    else:
                        src.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s easily deflects %s\'s ranged attack.\n'%(dst.name,src.name))
                return
            elif src.target != self.dst:
                if src.character:
                    src.player.sendGameText(RPG_MSG_GAME_YELLOW,r'%s misses the target and hits %s instead.\n'%(src.name,self.dst.name))
                else:
                    return
            
            dmg = askill
            wdmg=(self.weapon.wpnDamage + self.ammoDamage)*10
            wdmg*=askill/1000.0
            
            dmg+=wdmg
            
            if dmg < 20:
                dmg = 20
            
            dmg = random.randint(int(dmg/2),int(dmg))
            
            critical = False
            try:
                icrit = src.skillLevels["Precise Shot"]
            except:
                icrit = 0
                
            if icrit:
                ps = src.advancements.get("preciseShot",0.0)
                chance = float(math.ceil(15/src.critical))
                chance *= 1.0 - ps
                chance = int(chance)
                if not random.randint(0,chance):
                    if src.character:
                        src.character.checkSkillRaise("Precise Shot",5)
                    icrit /= 200.0
                    if icrit < 2:
                        icrit = 2.0
                    if icrit > 5:
                        icrit = 5.0
                    dmg *= icrit*(1.0 + ps)
                    dmg *= src.critical
                    dmg = int(dmg)
                    critical = True
            
            if dmg:
                if not critical:
                    Damage(self.dst,self.src,dmg,RPG_DMG_PIERCING)
                else:
                    Damage(self.dst,self.src,dmg,RPG_DMG_PIERCING,"precisely wounds")
                    
                #procs
                spells = self.weapon.spells[:]
                spells.extend(self.ammoSpells)
                from spell import SpawnSpell
                
                
                for ispell in spells:
                    if ispell.trigger == RPG_ITEM_TRIGGER_MELEE:
                        if ispell.frequency <= 1 or not random.randint(0,ispell.frequency):
                            proto = ispell.spellProto
                        
                            tgt = self.dst
                            if proto.target == RPG_TARGET_SELF:
                                tgt = src
                            if proto.target == RPG_TARGET_PARTY:
                                tgt = src
                            if proto.target == RPG_TARGET_ALLIANCE:
                                tgt = src
                            if proto.target == RPG_TARGET_PET:
                                tgt = src.pet                                
                            if tgt:
                                SpawnSpell(proto,self.src,tgt,tgt.simObject.position,1.0)
                
                    
                if src.character:
                    src.character.checkSkillRaise("Archery")
                    
                
        
    def launch(self):
        
        #if self.wpnDamage:
            #self.projectile = self.ammo.projectile
            #self.speed = self.ammo.speed
        if self.spellProto:
            self.projectile = self.spellProto.projectile
            self.speed = self.spellProto.projectileSpeed

        
        self.src.zone.launchProjectile(self)
        
        
        
    
        