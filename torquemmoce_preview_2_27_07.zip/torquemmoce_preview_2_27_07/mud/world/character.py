

from sqlobject import *
from mud.common.persistent import Persistent
from datetime import datetime
from item import ItemProto,Item,ItemInstance
from defines import *
import math
import random
from core import *
from advancement import AdvancementProto

from mud.world.shared.playdata import CharacterInfo
from mud.world.shared.sounddefs import *
import traceback,time


class StartingGear(Persistent):
    racename = StringCol(default="")
    classname = StringCol(default="")
    sex = StringCol(default="")
    realm = IntCol()
    
    #, delimited item names
    items = StringCol(default="")
    
    def qualify(self,spawn):
        if self.racename and self.racename != spawn.race:
            return False
        if self.classname:
            if spawn.pclass.name != self.classname:
                return False
        if self.sex and self.sex != spawn.sex:
            return False
        if self.realm and self.realm != spawn.realm:
            return False
            
        #todo faith
        return True
            
class CharacterSpell(Persistent):
    character = ForeignKey('Character')
    spellProto = ForeignKey('SpellProto')
    slot = IntCol(default=0) #150 spell slots
    recast = IntCol(default=0) 
    level = IntCol(default=1)
    
    def _init(self,*args,**kw):
        Persistent._init(self, *args, **kw)
        self.spellInfo = None
        
class CharacterSkill(Persistent):
    character = ForeignKey('Character')
    skillname = StringCol()
    level = IntCol(default = 1)
    
class CharacterDialogChoice(Persistent):
    character = ForeignKey('Character')
    identifier = StringCol()
    count = IntCol(default=1)
    
    
class CharacterAdvancement(Persistent):
    advancementProto = ForeignKey('AdvancementProto')
    character = ForeignKey('Character')
    rank = IntCol(default = 1)
    
    def apply(self):
        pass
    
    def remove(self):
        pass


class CharacterVaultItem(Persistent):
    character = ForeignKey('Character')
    item = ForeignKey('Item')
    name = StringCol()
    stackCount = IntCol()


#spells
#class CharacterEffect(Persistent):
#    character = ForeignKey('Character')
#    faction = ForeignKey('EffectProto')
#    points = IntCol(default=0)

class CharacterFaction(Persistent):
    character = ForeignKey('Character')
    faction = ForeignKey('Faction')
    points = IntCol(default = 0)



class Character(Persistent):    
    
    name = StringCol(alternateID = True,default="")
    lastName = StringCol(default="")
    player = ForeignKey('Player')
    spawn = ForeignKey('Spawn')
    creationTime = DateTimeCol(default = datetime.now)
    
    spellsInternal = MultipleJoin('CharacterSpell')
    
    itemsInternal = MultipleJoin('Item')
    vaultItemsInternal = MultipleJoin('CharacterVaultItem')
    
    advancements = MultipleJoin('CharacterAdvancement')
    
    
    skills = MultipleJoin('CharacterSkill')
    
    characterDialogChoices = MultipleJoin('CharacterDialogChoice')
    
    characterFactions = MultipleJoin('CharacterFaction')
    
    spellStore = MultipleJoin('SpellStore')
    
    xpPrimary = IntCol(default = 0)
    xpSecondary = IntCol(default = 0)
    xpTertiary = IntCol(default = 0)
    
    xpDeathPrimary = IntCol(default=0)
    xpDeathSecondary = IntCol(default=0)
    xpDeathTertiary = IntCol(default=0)
    
    advancementPoints = IntCol(default=0)
    advancementLevelPrimary = IntCol(default=1)
    advancementLevelSecondary = IntCol(default=1)
    advancementLevelTertiary = IntCol(default=1)
    
    portraitPic = StringCol()
    
    dead = BoolCol(default = False)
    
    #by potions
    strRaise = IntCol(default=300)
    bdyRaise = IntCol(default=300)
    dexRaise = IntCol(default=300)
    mndRaise = IntCol(default=300)
    wisRaise = IntCol(default=300)
    agiRaise = IntCol(default=300)
    refRaise = IntCol(default=300)
    mysRaise = IntCol(default=300)
    
    health = IntCol(default=-999999)
    mana = IntCol(default=-999999)
    stamina = IntCol(default=-999999)
    
    #allow /classchange command?
    pchange = BoolCol(default=False)
    schange = BoolCol(default=False)
    tchange = BoolCol(default=False)
    
    deathTransformInternal = StringCol(default="0 0 0 1 0 0 0") 
    deathZone = ForeignKey('Zone',default=None)
    
    def _init(self,*args,**kw):
        Persistent._init(self, *args, **kw)        
    
        self.mob = None
        self.setXPMods()
        self.calcXPPercents()
    
        #user adjustable XP gains, per character... serialized client side
        self.xpGainPrimary = 1.0
        self.xpGainSecondary = 0
        self.xpGainTertiary = 0
        
        self.itemList = None
        
        self.vaultItemsDirty = True
        self.vaultItemList = None

        self.spellsDirty = True
        self.spellList = None
        
        self.invulnerable = 0
        
        # store former pets health, need to do this here because of zoning
        self.petHealthBackup = 0
        self.petHealthTimer = -9999
        
        #check for newly exluding advancements, etc
        self.checkAdvancements()
        
    def _get_deathTransform(self):
        return map(float, self.deathTransformInternal.split(" "))

    def _set_deathTransform(self,transform):
        self.deathTransformInternal = ' '.join(map(str,transform))
    
    def _get_items(self):
        if not self.itemList:
            self.itemList = []
            for item in self.itemsInternal:
                flags = item.itemProto.flags
                if flags & RPG_ITEM_ETHEREAL:
                    item.destroySelf()
                    continue
                self.itemList.append(ItemInstance(item))
        return self.itemList
    
    def _get_vaultItems(self):
        if self.vaultItemsDirty:
            self.vaultItemList = self.vaultItemsInternal
        self.vaultItemsDirty = False
        return self.vaultItemList


    def _get_spells(self):
        if self.spellsDirty:
            self.spellList = self.spellsInternal
        self.spellsDirty = False
        return self.spellList
    
    
    def refreshItems(self):
        for item in self.items:
            if not (RPG_SLOT_PET_END > item.slot >= RPG_SLOT_PET_BEGIN):
                item.refreshFromProto()
        self.refreshPetItems()
        self.player.cinfoDirty = True
    
    def backupItems(self):
        for item in self.items:
            item.storeToItem()
    
    
    def trainClass(self,klass):
        spawn = self.spawn
        if not spawn.slevel:
            spawn.slevel = 1
            spawn.sclassInternal = klass
        else:
            spawn.tlevel = 1
            spawn.tclassInternal = klass
            
        self.setXPMods()
        self.calcXPPercents()
        self.mob.levelChanged()
        
         
    def setXPGain(self,pgain,sgain,tgain):
        #these no longer need to be persistent, hrm
        self.xpGainPrimary = pgain
        self.xpGainSecondary = sgain
        self.xpGainTertiary = tgain
        
        #paranoia
        if not self.spawn.sclassInternal:
            self.xpGainSecondary = 0.0
            
        if not self.spawn.tclassInternal:
            self.xpGainTertiary = 0.0
        
        
    def setXPMods(self):
        from race import GetRace
        from archetype import GetClass
        
        self.pxpMod = 1.0
        self.sxpMod = 1.0
        self.txpMod = 1.0

        spawn = self.spawn
        race = GetRace(self.spawn.race)
        pclass = GetClass(spawn.pclassInternal)
        sclass = None
        tclass = None
        
        if spawn.sclassInternal:
            sclass = GetClass(spawn.sclassInternal)
        if spawn.tclassInternal:
            tclass = GetClass(spawn.tclassInternal)
            
        xpmod = race.getXPMod() - 1.0
        self.pxpMod = 1.0 + xpmod + (pclass.getXPMod()-1.0)
        if sclass:
            self.sxpMod = 1.0 + xpmod + (sclass.getXPMod()-1.0)
        if tclass:
            self.txpMod = 1.0 + xpmod + (tclass.getXPMod()-1.0)
    
    def calcXPPercents(self):
        spawn = self.spawn
        self.pxpPercent = 0
        self.sxpPercent = 0
        self.txpPercent = 0

        #this happened on the server when I was doing an update, odd
        if spawn.plevel == None:
            spawn.plevel = 1        
        if spawn.slevel == None:
            spawn.slevel = 0
        if spawn.tlevel == None:
            spawn.tlevel = 0
            

        pneeded = spawn.plevel*spawn.plevel*100L*self.pxpMod
        sneeded = spawn.slevel*spawn.slevel*100L*self.sxpMod
        tneeded = spawn.tlevel*spawn.tlevel*100L*self.txpMod
        
        pprevneeded = ((spawn.plevel-1)*(spawn.plevel-1)*100L*self.pxpMod)
        sprevneeded = ((spawn.slevel-1)*(spawn.slevel-1)*100L*self.sxpMod)
        tprevneeded = ((spawn.tlevel-1)*(spawn.tlevel-1)*100L*self.txpMod)
        
        pgap = pneeded - pprevneeded
        sgap = sneeded - sprevneeded
        tgap = tneeded - tprevneeded
        
        pxp = self.xpPrimary
        sxp = self.xpSecondary
        txp = self.xpTertiary
        
        self.pxpPercent = (pxp-pprevneeded)/pgap
        if self.spawn.slevel:
            self.sxpPercent = (sxp-sprevneeded)/sgap
        if self.spawn.tlevel:
            self.txpPercent = (txp-tprevneeded)/tgap
            
    def gainLevel(self,which):
        spawn = self.spawn
        
        if RPG_BUILD_DEMO and spawn.plevel >= RPG_DEMO_PLEVEL_LIMIT and not self.player.premium and which==0:
            return

        if RPG_BUILD_DEMO and spawn.slevel >= RPG_DEMO_SLEVEL_LIMIT and not self.player.premium and which==1:
            return

        if RPG_BUILD_DEMO and not self.player.premium and which == 2:
            return
        
        pneeded = spawn.plevel*spawn.plevel*100L*self.pxpMod
        sneeded = spawn.slevel*spawn.slevel*100L*self.sxpMod
        tneeded = spawn.tlevel*spawn.tlevel*100L*self.txpMod
        
        if which == 0:
            self.xpPrimary = int(pneeded+1)
        if which == 1:
            self.xpSecondary = int(sneeded+1)
        if which == 2:
            self.xpTertiary = int(tneeded+1)
            
        self.gainXP(10)
    
    def gainXP(self,amount,clamp=True,rez=None):
        
        spawn = self.spawn
        mob = self.mob
        
        total = 1.0 
          
        pgain = self.xpGainPrimary
        total-=pgain        
        if total < 0.0:
            total = 0.0 #shouldn't happen
        
        sgain = self.xpGainSecondary
        if sgain > total:
            sgain = total
        total-=sgain
        if total < 0.0:
            total = 0.0 
        
        tgain = self.xpGainTertiary
        if tgain > total:
            tgain = total
        total-=tgain
        if total < 0.0:
            total = 0.0
            
        #add any remainder
        
        if total:
            if self.xpGainPrimary >= self.xpGainSecondary and self.xpGainPrimary >= self.xpGainTertiary:
                pgain+=total
            elif self.xpGainSecondary >= self.xpGainPrimary and self.xpGainSecondary >= self.xpGainTertiary:
                sgain+=total
            elif self.xpGainTertiary >= self.xpGainPrimary and self.xpGainTertiary >= self.xpGainSecondary:
                tgain+=total
            else:
                pgain+=total

        if not spawn.slevel:
            sgain = 0.0
            
        if not spawn.tlevel:
            tgain = 0.0

        
        msg = False
        if RPG_BUILD_DEMO and spawn.plevel >= RPG_DEMO_PLEVEL_LIMIT and not self.player.premium and pgain:
            if spawn.slevel > 0 and spawn.slevel < RPG_DEMO_SLEVEL_LIMIT:
                sgain+=pgain
                if sgain > 1.0:
                    sgain = 1.0
            pgain = 0
            msg = True
            self.player.sendGameText(RPG_MSG_GAME_DENIED,"\\n%s has reached primary level %i and can gain more experience by training in a secondary class or purchasing the Minions of Mirth: Premium Edition.  The Premium Edition will also allow %s to use premium gear and multiclass in a third class to level 100!  Please see www.prairiegames.com for more information.\\n\\n"%(self.spawn.name, RPG_DEMO_PLEVEL_LIMIT, self.spawn.name))
            
        
        if RPG_BUILD_DEMO and spawn.slevel >= RPG_DEMO_SLEVEL_LIMIT and not self.player.premium and sgain:
            if spawn.plevel < RPG_DEMO_PLEVEL_LIMIT:
                pgain+=sgain
                if pgain > 1.0:
                    pgain = 1.0
            sgain = 0
            if not msg:
                self.player.sendGameText(RPG_MSG_GAME_DENIED,"\\n%s has reached secondary level %i and can gain more experience by purchasing the Minions of Mirth: Premium Edition.  The Premium Edition will also allow %s to use premium gear and multiclass in a third class to level 100!  Please see www.prairiegames.com for more information.\\n\\n"%(self.spawn.name, RPG_DEMO_SLEVEL_LIMIT, self.spawn.name))
            
        if RPG_BUILD_DEMO and not self.player.premium and (not sgain and not pgain):
            return
                    
        if spawn.sclass and spawn.slevel >= spawn.plevel and spawn.plevel != 100:
            pgain+=sgain 
            sgain = 0
        if spawn.tclass and spawn.tlevel >= spawn.slevel and spawn.slevel != 100:
            pgain+=tgain 
            tgain = 0
        
        xpp = amount*pgain
        xps = (amount*sgain)/2
        xpt = (amount*tgain)/3
        
        xpp*=mob.xpScalar
        xps*=mob.xpScalar
        xpt*=mob.xpScalar
        
        if rez:
            xpp,xps,xpt = rez
        
        pneeded = spawn.plevel*spawn.plevel*100L*self.pxpMod
        sneeded = spawn.slevel*spawn.slevel*100L*self.sxpMod
        tneeded = spawn.tlevel*spawn.tlevel*100L*self.txpMod
        
        pgap = pneeded - ((spawn.plevel-1)*(spawn.plevel-1)*100L*self.pxpMod)
        sgap = sneeded - ((spawn.slevel-1)*(spawn.slevel-1)*100L*self.sxpMod)
        tgap = tneeded - ((spawn.tlevel-1)*(spawn.tlevel-1)*100L*self.txpMod)
                
        if xpp < 1:
            xpp = 0
        if xps < 1:
            xps = 0
        if xpt < 1:
            xpt = 0
            
        #no single XP event will reward more than 1/level*5 of a level!
        
        if clamp:
            pdiv = 10#spawn.plevel
            sdiv = 10#spawn.slevel
            tdiv = 10#spawn.tlevel
    
            
            if xpp > pgap/pdiv:
                xpp = pgap/pdiv
                
            if sdiv:
                if xps > sgap/sdiv:
                    xps = sgap/sdiv
            if tdiv:
                if xpt > tgap/tdiv:
                    xpt = tgap/tdiv

        xpp = int(math.ceil(xpp))
        xps = int(math.ceil(xps))
        xpt = int(math.ceil(xpt))
        
        calc = False
        if spawn.plevel == 100 and self.xpPrimary + xpp >= pneeded:
            self.xpPrimary = int(pneeded)-1
            xpp = 0
            calc = True
        if spawn.slevel == 100 and self.xpSecondary + xps >= sneeded:
            self.xpSecondary = int(sneeded)-1
            xps = 0
            calc = True

        if spawn.tlevel == 100 and self.xpTertiary + xpt >= tneeded:
            self.xpTertiary = int(tneeded)-1
            xpt = 0
            calc = True
            
        if xpp < 1:
            xpp = 0
        if xps < 1:
            xps = 0
        if xpt < 1:
            xpt = 0

        
        if not xpp and not xps and not xpt:
            if calc:
                self.calcXPPercents()
            return

        if xpp < 1:
            xpp = 0
        if xps < 1:
            xps = 0
        if xpt < 1:
            xpt = 0

        
        if not xpp and not xps and not xpt:
            return
        
        self.xpPrimary += xpp 
        self.xpSecondary += xps
        self.xpTertiary += xpt
        
        #check for level gains
        if xpp:
            text = "%i primary, "%xpp
        if xps:
            text = "%i secondary, "%xps
        if xpt:
            text = "%i tertiary, "%xpt
        
        text = "%s gained %s xp!\\n"%(self.name, text[:-2])
        
        self.player.sendGameText(RPG_MSG_GAME_GAINED,text)
                
        gained = False
        
        if spawn.plevel < 100:
            if self.xpPrimary >= pneeded:
                #we have gained a level
                spawn.plevel+=1
                mob.plevel+=1
                gained = True
                
                advance = False
                points = 0
                if self.advancementLevelPrimary < spawn.plevel:
                    advance = True
                    self.advancementLevelPrimary+=1
                    points = int(float(spawn.plevel)/2.0)
                    if points < 5:
                        points = 5                    
                    self.advancementPoints+=points
                
                
                self.player.mind.callRemote("playSound","sfx/Pickup_Magic02.ogg")
                if advance:
                    self.player.sendGameText(RPG_MSG_GAME_LEVELGAINED,"%s is now a level %i %s!!!\\n"%(self.name,spawn.plevel,spawn.pclassInternal.lower()))
                    self.player.sendGameText(RPG_MSG_GAME_LEVELGAINED,"%s has gained %i advancement points!!!\\n"%(self.name,points))
                    
                    #
                    # Check if the player has unlocked the ability to multiclass.  If so, display a message
                    # to the player.
                    #
                    if RPG_MULTICLASS_SECONDARY_LEVEL_REQUIREMENT == spawn.plevel and not spawn.slevel:
                        self.player.sendGameText(RPG_MSG_GAME_GAINED,"%s can now train in a secondary class.\\n"%(self.name))
                    elif RPG_MULTICLASS_TERTIARY_LEVEL_REQUIREMENT == spawn.plevel and not spawn.tlevel:
                        self.player.sendGameText(RPG_MSG_GAME_GAINED,"%s can now train in a tertiary class.\\n"%(self.name))
                else:
                    self.player.sendGameText(RPG_MSG_GAME_LEVELGAINED,"%s has regained a primary level!!! (%s, %i)\\n"%(self.name,spawn.pclassInternal.lower(),spawn.plevel))
        
        
        if spawn.sclass and spawn.slevel < spawn.plevel:
            if self.xpSecondary >= sneeded:
                #we have gained a secondary level
                spawn.slevel+=1
                mob.slevel+=1
                gained = True
                
                advance = False
                points = 0
                if self.advancementLevelSecondary < spawn.slevel:
                    advance = True
                    self.advancementLevelSecondary+=1
                    points = int(float(spawn.slevel)/2.0)
                    if points < 3:
                        points = 3                    
                    self.advancementPoints+=points
                    

                
                
                self.player.mind.callRemote("playSound","sfx/Pickup_Magic02.ogg")
                if advance:
                    self.player.sendGameText(RPG_MSG_GAME_LEVELGAINED,"%s's secondary class of %s is now level %i!!\\n"%(self.name,spawn.sclassInternal.lower(),spawn.slevel))
                    self.player.sendGameText(RPG_MSG_GAME_LEVELGAINED,"%s has gained %i advancement points!!!\\n"%(self.name,points))
                else:
                    self.player.sendGameText(RPG_MSG_GAME_LEVELGAINED,"%s has regained a secondary class level! (%s, %i)!!\\n"%(self.name,spawn.sclassInternal.lower(),spawn.slevel))
                    
                    
                

                    
            
        if spawn.tclass and spawn.tlevel < spawn.slevel:
            if self.xpTertiary >= tneeded:
                #we have gained a tertiary level
                spawn.tlevel+=1
                mob.tlevel+=1
                gained = True
                
                advance = False
                points = 0
                if self.advancementLevelTertiary < spawn.tlevel:
                    advance = True
                    self.advancementLevelTertiary+=1
                    points = int(float(spawn.tlevel)/2.0)
                    if points < 1:
                        points = 1
                    self.advancementPoints+=points
                    

                
                self.player.mind.callRemote("playSound","sfx/Pickup_Magic02.ogg")
                if advance:
                    self.player.sendGameText(RPG_MSG_GAME_LEVELGAINED,"%s's tertiary class of %s is now level %i!!\\n"%(self.name,spawn.tclassInternal.lower(),spawn.tlevel))
                    self.player.sendGameText(RPG_MSG_GAME_LEVELGAINED,"%s has gained %i advancement points!!!\\n"%(self.name,points))
                else:
                    self.player.sendGameText(RPG_MSG_GAME_LEVELGAINED,"%s has regained a tertiary level!!! (%s, %i)\\n"%(self.name,spawn.tclassInternal.lower(),spawn.tlevel))
                    
                
        self.calcXPPercents()
                
        if gained:
            
            #monster automagically gain new spells on level up
            if False:#self.player.monster:
                
                def SpellSort(a,b):
                    if a.level < b.level:
                        return -1
                    if a.level > b.level:
                        return 1
                    return 0

                spawn = self.spawn
                from spell import SpellClass
                qspells = list(SpellClass.select(OR(AND(SpellClass.q.classname == spawn.pclassInternal,SpellClass.q.level <= spawn.plevel),AND(SpellClass.q.classname == spawn.sclassInternal,SpellClass.q.level <= spawn.slevel),AND(SpellClass.q.classname == spawn.tclassInternal,SpellClass.q.level <= spawn.tlevel))))
                qspells.sort(SpellSort)
                
                usedslots=[]
                myspells = []
                for s in self.spells:
                    myspells.append(s.spellProto)
                    usedslots.append(s.slot)
                sprotos = frozenset([sc.spellProto for sc in qspells if sc.spellProto not in myspells])
                
                slot = 0
                for sproto in sprotos:
                    while slot in usedslots:
                        slot+=1
                    self.spellsDirty = True
                    CharacterSpell(character=self,spellProto=sproto,slot=slot,recast=0)
                    self.player.sendGameText(RPG_MSG_GAME_GAINED,"%s has learned the %s spell!!\\n"%(self.name,sproto.name))
                    
            
            mob.levelChanged()
            
    
    def onSpellSlotSwap(self,srcslot,dstslot):
        
        srcspell = None
        for spell in self.spells:
            if spell.slot == srcslot:
                srcspell = spell
                break
                
        dstspell = None
        for spell in self.spells:
            if spell.slot == dstslot:
                dstspell = spell
                break
            
        if srcspell:
            srcspell.slot = dstslot
            
        if dstspell:
            dstspell.slot = srcslot
            
        
        
            
        
    def onSpellSlot(self,slot,item=None):
        fspell = None
        for spell in self.spells:
            if spell.slot == slot:
                fspell = spell
                break
                
        if fspell:
            self.mob.cast(fspell.spellProto,fspell.level)
            return #cast!
        
        if not item:
            item = self.player.cursorItem
        
        
        if not item or not item.itemProto.spellProto:
            print "Warning: no cursor item (or no spell on cursor item) on spell slot server side, should be caught on client"
            return
        
        #no tomes please
        if item and item.spellEnhanceLevel:
            return
            
            
        #trying to learn spell
        proto = item.itemProto.spellProto
        
        
        #do we already know this spell?
        for cspell in self.spells:
            if proto == cspell.spellProto:
                self.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s already knows this spell!\n'%self.name)
                return
                
        #can we learn this spell?
        if not proto.qualify(self.mob):
            self.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s cannot learn %s at this time.\n'%(self.name,proto.name))
            return
                
        
        CharacterSpell(character=self,spellProto=proto,slot=slot,recast=0)
        
        item.stackCount -= 1
        if item.stackCount <= 0:
            if item == self.player.cursorItem:
                self.player.cursorItem = None
            self.player.takeItem(item)
        else:
            item.itemInfo.refreshDict({'STACKCOUNT':item.stackCount})

            
        
        #item.character = None
        #item.slot = -1
        #item.destroySelf()
        self.spellsDirty = True
        
        
        
        
        self.player.mind.callRemote("playSound","sfx/Pencil_WriteOnPaper2.ogg")
        self.player.sendGameText(RPG_MSG_GAME_GOOD,r'%s learns %s.\n'%(self.name,proto.name))
    
    
    def equipItems(self,printSets=True):
        for item in self.items:
            if RPG_SLOT_WORN_END > item.slot >= RPG_SLOT_WORN_BEGIN:
                self.mob.equipItem(item.slot, item, printSets)
    
    def unequipItems(self):
        for item in self.items:
            if RPG_SLOT_WORN_END > item.slot >= RPG_SLOT_WORN_BEGIN:
                self.mob.unequipItem(item.slot)
    
    
    def onTradeSlot(self,slot):
        player = self.player
        trade = player.trade
        if not trade:
            return
        
        if trade.p0Accepted or trade.p1Accepted:
            return #can't alter trade
        
        if trade.p0 == player:
            titems = trade.p0Items
        else:
            titems = trade.p1Items
        
        cursorItem = player.cursorItem
        
        if not cursorItem and not titems.has_key(slot-RPG_SLOT_TRADE0):
            return
        
        if cursorItem:
            if cursorItem.flags & RPG_ITEM_SOULBOUND and player.role.name != "Immortal":
                self.player.sendGameText(RPG_MSG_GAME_DENIED,r'This item cannot be traded.\n')
                return #cannot trade!
        
        previtem = None
        if titems.has_key(slot-RPG_SLOT_TRADE0):
            previtem = titems[slot-RPG_SLOT_TRADE0]
            del titems[slot-RPG_SLOT_TRADE0]
        
        if cursorItem:
            #find first free trade slot
            gotone = False
            for tslot in xrange(RPG_SLOT_TRADE_BEGIN,RPG_SLOT_TRADE_END):
                found = False
                for item in self.items:
                    if item.slot == tslot:
                        found = True
                        break
                if not found:
                    gotone = True
                    cursorItem.slot = tslot
                    break
            
            if not gotone:
                titems[slot-RPG_SLOT_TRADE0] = previtem
                return
            
            titems[slot-RPG_SLOT_TRADE0] = cursorItem
        
        if previtem:
            previtem.slot = RPG_SLOT_CURSOR
            previtem.setCharacter(self)
        
        player.cursorItem = previtem
        
        trade.refresh()
    
    
    def equipItem(self,item):
        mob = self.mob
        #if not item.isUseable(self.mob):
        #    self.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s cannot use this item!\n'%self.name)
        #    return #should be caught on client
        proto = item.itemProto
        
        useslot = None
        
        dualwield = self.mob.skillLevels.get("Dual Wield")
        powerwield = False
        if RPG_SLOT_PRIMARY in proto.slots and "2H" in item.skill and self.mob.skillLevels.get("Power Wield"):
            powerwield = True
        
        #find first slot that isn't used that item can go into
        slots = list(proto.slots)
        if powerwield and RPG_SLOT_SECONDARY not in slots:
            slots.append(RPG_SLOT_SECONDARY)
        
        for slot in slots:
            found = False
            for citem in self.items:
                if citem.slot == slot:
                    found = True
                    break
            if not found:
                useslot = slot
                break
        
        unequip = None
        if useslot == None and len(slots):
            unequip = item
            useslot = slots[0]
        
        try:
            pitem = self.mob.worn[RPG_SLOT_PRIMARY]
        except KeyError:
            pitem = None
        
        if useslot == RPG_SLOT_SECONDARY and (not (dualwield or powerwield) or pitem and "2H" in pitem.skill and not powerwield):
            #self.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s does not know how to dual wield.\n'%self.name)
            unequip = None
            if RPG_SLOT_PRIMARY in slots:
                useslot = RPG_SLOT_PRIMARY
                for citem in self.items:
                    if citem.slot == RPG_SLOT_PRIMARY:
                        unequip = citem
                        break
        
        if item.flags & RPG_ITEM_UNIQUE:
            for iitem in self.mob.worn.itervalues():
                if item.itemProto == iitem.itemProto and iitem.slot != useslot:
                    self.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s can only use one of these at a time!\n'%self.name)
                    return
        
        if unequip and not self.unequipItem(useslot,item.slot):
            return
        
        item.slot = useslot
        self.mob.equipItem(useslot,item)
        
        snd = SND_ITEMEQUIP
        if item.sndProfile and item.sndProfile.sndEquip:
            snd = item.sndProfile.sndEquip
        self.player.mind.callRemote("playSound",snd)
    
    
    def unequipItem(self,slot,putslot=None):
        for item in self.items:
            if item.slot == slot:
                free = self.getFreeCarrySlots()
                if putslot == None and not len(free):
                    return False
                if putslot != None:
                    item.slot = putslot
                else:
                    item.slot = free[0]
                
                self.mob.unequipItem(slot)
                return True
        
        return False
    
    
    def onInvSlotCtrl(self,slot):
        if (RPG_SLOT_WORN_END > slot >= RPG_SLOT_WORN_BEGIN) or (RPG_SLOT_CARRY_END > slot >= RPG_SLOT_CARRY_BEGIN):
            for item in self.items:
                if item.slot == slot:
                    spellProto = item.itemProto.spellProto
                    if spellProto:
                        #enhance
                        if item.spellEnhanceLevel:
                            for s in self.spells:
                                if s.spellProto == spellProto:
                                    if s.level >=item.spellEnhanceLevel:
                                        self.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s already understands the knowledge contained in this tome.\n'%self.name)
                                    else:
                                        self.player.sendGameText(RPG_MSG_GAME_GAINED,r'$src has increased $srchis knowledge of the %s spell!\n'%spellProto.name,self.mob)
                                        item.stackCount-=1
                                        if item.stackCount<=0:
                                            self.player.takeItem(item)
                                        else:
                                            item.itemInfo.refreshDict({'STACKCOUNT':item.stackCount})
                                        s.level+=1
                                        s.spellInfo.fullRefresh()
                                        
                                    return
                                
                            self.player.sendGameText(RPG_MSG_GAME_DENIED,"%s doesn't know the %s spell.\\n"%(self.name,spellProto.name))
                            return
                            
                        else:
                            #scribe
                            sslots = [s.slot for s in self.spells]
                            
                            for sslot in xrange(0,256):
                                if not sslot in sslots:
                                    self.onSpellSlot(sslot,item)
                                    return
                            return
                    else:
                        if self.dead or not self.mob:
                            return
                        item.use(self.mob)
                        return
                    
                    break
    
    
    
    def onInvSlotAlt(self,slot):
        if RPG_SLOT_WORN_END > slot >= RPG_SLOT_WORN_BEGIN:
            #click on a worn item, try and take it off
            self.unequipItem(slot)
            if self.player.cursorItem:
                oldcur = self.player.cursorItem
                self.onInvSlot(slot)
                if oldcur != self.player.cursorItem:
                    self.player.updateCursorItem(oldcur)
                
            return

        if RPG_SLOT_CARRY_END > slot >= RPG_SLOT_CARRY_BEGIN:
            #trying to equip or use a scroll, or stack items
            for item in self.items:
                proto = item.itemProto
                if item.slot == slot:
                    cursor = self.player.cursorItem
                    if proto.stackMax > 1:
                        if not cursor or cursor.name==item.name:
                            if not item.stackCount:
                                item.stackCount = 1
                            if not cursor:
                                if item.stackCount == 1:
                                    self.onInvSlot(slot)
                                    self.player.cursorItem =item
                                    self.player.updateCursorItem(None)
                                    return
                                nitem = item.clone()
                                nitem.setCharacter(self,False)
                                nitem.stackCount = 1
                                item.stackCount-=1
                                item.itemInfo.refreshDict({'STACKCOUNT':item.stackCount})
                                self.player.cursorItem = nitem
                                self.player.updateCursorItem(None)
                                                          
                                return
                            
                            #we have a stackable item in cursor
                            if cursor.stackCount < cursor.itemProto.stackMax:
                                useMax = proto.useMax
                                useStack = False
                                refreshUse = False
                                if useMax > 0 and item.useCharges < useMax:
                                    amt = useMax - cursor.useCharges
                                    refreshUse = True
                                    if amt >= item.useCharges:
                                        cursor.useCharges += item.useCharges
                                        useStack = True
                                    else:
                                        cursor.useCharges = item.useCharges - amt
                                    item.useCharges = useMax
                                if not useStack:
                                    cursor.stackCount+=1
                                if refreshUse and useStack:
                                    cursor.itemInfo.refreshDict({'USECHARGES':cursor.useCharges})
                                elif refreshUse:
                                    cursor.itemInfo.refreshDict({'STACKCOUNT':cursor.stackCount,'USECHARGES':cursor.useCharges})
                                else:
                                    cursor.itemInfo.refreshDict({'STACKCOUNT':cursor.stackCount})
                                if item.stackCount > 1:
                                    item.stackCount-=1
                                    if refreshUse:
                                        item.itemInfo.refreshDict({'STACKCOUNT':item.stackCount,'USECHARGES':item.useCharges})
                                    else:
                                        item.itemInfo.refreshDict({'STACKCOUNT':item.stackCount})
                                    return
                                #item is going away
                                self.player.takeItem(item)
                                
                        #stackable return
                        return
                    
                    
                    if len(proto.slots):
                        #it can be worn
                        canUse = item.isUseable(self.mob)
                        if not canUse:
                            if RPG_BUILD_DEMO and not self.player.premium:
                                if item.level>=50 or item.itemProto.flags&RPG_ITEM_PREMIUM:
                                    self.player.sendGameText(RPG_MSG_GAME_DENIED,"\\nThis item requires the Minions of Mirth: Premium Edition.  Please see www.prairiegames.com for more information.\\n\\n")

                            self.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s cannot use this item!\n'%self.name)
                            return #should be caught on client

                        self.equipItem(item)
                        
                        return
                    break
    
    
    def setPetEquipment(self):
        if not self.mob or not self.mob.pet or self.mob.pet.detached or self.mob.pet.charmEffect:
            return
        pet = self.mob.pet
        self.refreshPetItems()
        pet.mobInfo.refresh()
    
    
    def refreshPetItems(self):
        pet = self.mob.pet
        petSlots = range(RPG_SLOT_PET_BEGIN,RPG_SLOT_PET_END)
        if not pet:    # pet died, unsummoned, whatever, need to reassign stats for master
            for item in self.items:
                if item.slot in petSlots:
                    item.setCharacter(self,True)
            return
        
        for slot in petSlots:
            pet.unequipItem(slot-RPG_SLOT_PET_BEGIN)
        
        for item in self.items:
            if item.slot not in petSlots:
                continue
            proto = item.itemProto
            
            if RPG_BUILD_DEMO and not self.player.premium:
                if item.level>=50 or proto.flags&RPG_ITEM_PREMIUM:
                    pet.equipItem(item.slot-RPG_SLOT_PET_BEGIN,item)
                    continue    # just use masters 100% penalty
            if len(proto.realms):
                found = False
                for r in proto.realms:
                    if self.mob.spawn.realm == r.realmname:
                        found = True
                        break
                if not found:
                    pet.equipItem(item.slot-RPG_SLOT_PET_BEGIN,item)
                    continue    # just use masters 100% penalty, have to check nonetheless
            
            item.penalty = item.getPenalty(pet,True)
            item.refreshFromProto(True)
            pet.equipItem(item.slot-RPG_SLOT_PET_BEGIN,item)
    
    
    def onPetSlot(self,slot):
        cursorItem = self.player.cursorItem
        
        previtem = None
        for item in self.items:
            if item.slot == slot:
                previtem = item
                break

        shouldEquip = False
        if cursorItem:        
            
            if (slot-RPG_SLOT_PET_BEGIN) not in cursorItem.itemProto.slots:
                self.player.sendGameText(RPG_MSG_GAME_DENIED,r'This item cannot be equipped here.\n')
                return

            cursorItem.setCharacter(self)
            cursorItem.slot = slot
            self.player.cursorItem = None
            
            self.player.mind.callRemote("setItemSlot",self.id,cursorItem.itemInfo,slot)
        else:
            if previtem:
                self.player.mind.callRemote("setItemSlot",self.id,None,slot)
                
            
        if previtem:
            previtem.slot = RPG_SLOT_CURSOR
            self.player.cursorItem = previtem
            previtem.setCharacter(self,True)
        
        if previtem or cursorItem:
            self.player.mind.callRemote("playSound",SND_INVENTORY)
            
            self.setPetEquipment()
    
    
    def eat(self,tick=True):
        if not self.player:
            return
        items = []
        for m in self.player.party.members:
            items.extend(m.items)
        for item in items:
            if item.food:
                item.food -= 1
                self.mob.hungry = False
                if item.food <= 0:
                    # no need to check for stackMax
                    item.stackCount -= 1
                    if item.stackCount <= 0:
                        self.player.takeItem(item)
                    else:
                        item.food = item.itemProto.food
                        item.itemInfo.refreshDict({'STACKCOUNT':item.stackCount})
                return
        if tick:
            self.mob.hungry = True  
            self.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s is starving.\n'%self.name)
    
    def drink(self,tick=True):
        if not self.player:
            return
        items = []
        for m in self.player.party.members:
            items.extend(m.items)
        for item in items:
            if item.drink:
                item.drink -= 1
                self.mob.thirsty = False  
                if item.drink <= 0:
                    # no need to check for stackMax
                    item.stackCount -= 1
                    if item.stackCount <= 0:
                        self.player.takeItem(item)
                    else:
                        item.drink = item.itemProto.drink
                        item.itemInfo.refreshDict({'STACKCOUNT':item.stackCount})
                return
        if tick:
            self.mob.thirsty = True    
            self.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s is thirsty.\n'%self.name)
    
    
    def onInvSlot(self,slot):
        if RPG_SLOT_TRADE_END > slot >= RPG_SLOT_TRADE_BEGIN:
            self.onTradeSlot(slot)
            return


        if RPG_SLOT_PET_END > slot >= RPG_SLOT_PET_BEGIN:
            self.onPetSlot(slot)
            return
            
        
        cursorItem = self.player.cursorItem
        
        previtem = None
        for item in self.items:
            if item.slot == slot:
                previtem = item
                break
            
        if cursorItem and previtem:
            if cursorItem.name == previtem.name and cursorItem.itemProto.stackMax > 1:
                prevProto = previtem.itemProto
                if previtem.stackCount < prevProto.stackMax:
                    amt = prevProto.stackMax - previtem.stackCount
                    if amt > cursorItem.stackCount:
                        amt = cursorItem.stackCount
                    cursorItem.stackCount-=amt
                    previtem.stackCount+=amt
                    
                    useMax = prevProto.useMax
                    refreshUse = False
                    if useMax > 0 and cursorItem.useCharges < useMax:
                        refreshUse = True
                        amt = useMax - previtem.useCharges
                        if amt >= cursorItem.useCharges:
                            previtem.useCharges += cursorItem.useCharges
                            previtem.stackCount -= 1
                        else:
                            previtem.useCharges = cursorItem.useCharges - amt
                        cursorItem.useCharges = useMax
                    
                    if cursorItem.stackCount<=0:
                        self.player.takeItem(cursorItem)
                        cursorItem = None
                    
                    if refreshUse:
                        previtem.itemInfo.refreshDict({'STACKCOUNT':previtem.stackCount,'USECHARGES':previtem.useCharges})
                    else:
                        previtem.itemInfo.refreshDict({'STACKCOUNT':previtem.stackCount})
                    if cursorItem:
                        if refreshUse:
                            cursorItem.itemInfo.refreshDict({'STACKCOUNT':cursorItem.stackCount,'USECHARGES':cursorItem.useCharges})
                        else:
                            cursorItem.itemInfo.refreshDict({'STACKCOUNT':cursorItem.stackCount})
                    return
                        
                    
                

        shouldEquip = False
        if cursorItem:        

            if RPG_SLOT_WORN_END > slot >= RPG_SLOT_WORN_BEGIN:
                #we're trying to use this item
                canUse = cursorItem.isUseable(self.mob)
                if not canUse:
                    if RPG_BUILD_DEMO and not self.player.premium:
                        if cursorItem.level>=50 or cursorItem.itemProto.flags&RPG_ITEM_PREMIUM:
                            self.player.sendGameText(RPG_MSG_GAME_DENIED,"\\nThis item requires the Minions of Mirth: Premium Edition.  Please see www.prairiegames.com for more information.\\n\\n")

                    self.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s cannot use this item!\n'%self.name)
                    return #should be caught on client
                
                if cursorItem.flags & RPG_ITEM_UNIQUE:
                    for iitem in self.mob.worn.itervalues():
                        if cursorItem.itemProto == iitem.itemProto and slot != iitem.slot:
                            self.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s can only use one of these at a time!\n'%self.name)
                            return
                        
                if slot == RPG_SLOT_SECONDARY and not self.mob.skillLevels.get("Dual Wield"):
                    self.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s does not know how to dual wield.\n'%self.name)
                    return
                
                if slot == RPG_SLOT_SECONDARY and "2H" in cursorItem.skill and not self.mob.skillLevels.get("Power Wield"):
                    self.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s does not know how to power wield.\n'%self.name)
                    return
                
                if slot not in cursorItem.itemProto.slots and not ("2H" in cursorItem.skill and slot == RPG_SLOT_SECONDARY):
                    self.player.sendGameText(RPG_MSG_GAME_DENIED,r'This item cannot be equipped here.\n')
                    return

                
                shouldEquip = True
                    
            
            cursorItem.setCharacter(self)
            cursorItem.slot = slot
            self.player.cursorItem = None
            self.player.mind.callRemote("setCursorItem",None)
            self.player.mind.callRemote("setItemSlot",self.id,cursorItem.itemInfo,slot)
        else:
            if previtem:
                self.player.mind.callRemote("setItemSlot",self.id,None,slot)
                
            
        if previtem:
            if RPG_SLOT_WORN_END > slot >= RPG_SLOT_WORN_BEGIN:            
                self.mob.unequipItem(slot)
            previtem.slot = RPG_SLOT_CURSOR
            self.player.cursorItem = previtem
            self.player.mind.callRemote("setCursorItem",previtem.itemInfo)
            
        if shouldEquip:
            self.mob.equipItem(slot,cursorItem)
            snd = SND_ITEMEQUIP
            if cursorItem.sndProfile and cursorItem.sndProfile.sndEquip:
                snd = cursorItem.sndProfile.sndEquip
            self.player.mind.callRemote("playSound",snd)
        else:
            self.player.mind.callRemote("playSound",SND_INVENTORY)
            
    def stackItem(self,sitem):
        if not self.checkStackable(sitem):
            print "WARNING: Attempting to stack %s without enough stack room!"%sitem.name
            return
        
        amt = sitem.stackCount
        useMax = sitem.itemProto.useMax
        for item in self.items:
            if sitem==item:
                continue
            if sitem.name != item.name:
                continue
            
            add = item.itemProto.stackMax - item.stackCount
            if add <= 0:
                continue
            
            if useMax > 0 and sitem.useCharges < useMax:
                diff = useMax - item.useCharges
                if diff >= sitem.useCharges:
                    item.useCharges += sitem.useCharges
                    amt -= 1
                else:
                    item.useCharges = sitem.useCharges - diff
                sitem.useCharges = useMax
                item.itemInfo.refreshDict({'USECHARGES':item.useCharges})
            
            if add > amt:
                add = amt
            
            item.stackCount+=add
            item.itemInfo.refreshDict({'STACKCOUNT':item.stackCount})
            
            amt-=add
            if amt <= 0:                
                return
            
    
    def checkStackable(self,sitem):
        if not sitem.itemProto.stackMax > 1:
            return False
        
        amt = sitem.stackCount
        for item in self.items:
            if sitem==item:
                continue
            if sitem.name != item.name:
                continue
            
            add = item.itemProto.stackMax - item.stackCount
            if add <= 0:
                continue
            
            amt-=add
            if amt <= 0:
                return True #we have room
            
        return False
            
        
                
        
    def onLoot(self,mob,slot,alt=False):
        if not mob.loot or len(mob.loot.items) <= slot:
            traceback.print_stack()
            print "AssertionError: looting whackiness!"
            return
        
        item = mob.loot.items[slot]
        mslot = item.slot
        
        stackable = False
        
        if alt:
            stackable = self.checkStackable(item) 
            
            #first see if it stacks
            if not stackable:
                if not self.player.giveItemInstance(item):
                    self.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s has no free inventory slots!\n'%self.name)
                    return
                
                if not isinstance(item,ItemInstance) or item.character != self or item.slot == -1:
                    traceback.print_stack()
                    print "AssertionError: item owner whackiness!"
                    return
        
        else:
            for citem in self.items:
                if citem.slot == RPG_SLOT_CURSOR:
                    self.player.sendGameText(RPG_MSG_GAME_DENIED,r'Put down the item in %s\'s cursor first!\n'%self.name)
                    return
            
            item.setCharacter(self)
            item.slot = RPG_SLOT_CURSOR
            self.player.cursorItem = item
            self.player.mind.callRemote("setCursorItem",self.player.cursorItem.itemInfo)
        
        if mslot != -1:
            mob.unequipItem(mslot)
            #only refresh is mob has more items, otherwise corpse is going to pop anyway
            if len(mob.loot.items) > 1:
                mob.mobInfo.refresh()
        
        mob.loot.items.remove(item)
        lootitem = item
        
        # handle items unique to the world
        if item.itemProto.flags&RPG_ITEM_WORLDUNIQUE:
            for p in self.player.world.activePlayers:
                p.sendGameText(RPG_MSG_GAME_BLUE,r'%s has looted the sought-after %s.\n'%(item.character.name,item.name))
        else:
            # inform alliance members
            self.player.alliance.lootMessage(self.player,lootitem)
        
        if not len(mob.loot.items):
            self.player.sendGameText(RPG_MSG_GAME_LOOT,r'As %s takes the last item, the corpse crumbles to dust!\n'%self.name)
            mob.zone.removeMob(mob)
        else:
            loot = dict((x,item.itemInfo) for x,item in enumerate(mob.loot.items))
            self.player.mind.callRemote("setLoot",loot)
            
        if stackable:
            self.stackItem(lootitem)
            lootitem.destroySelf()
    
    def recoverDeathXP(self,xpRecover):
        pxp = int(self.xpDeathPrimary*xpRecover)
        sxp = int(self.xpDeathSecondary*xpRecover)
        txp = int(self.xpDeathTertiary*xpRecover)
        
        if pxp or sxp or txp:
            rez = (pxp,sxp,txp)
            self.gainXP(1,False,rez)
        
        self.xpDeathPrimary = 0
        self.xpDeathSecondary = 0
        self.xpDeathTertiary = 0
        
        if not pxp and not sxp and not txp:
            self.player.sendGameText(RPG_MSG_GAME_GOOD,"%s has been resurrected!\\n"%self.name)
            return
            
        self.player.sendGameText(RPG_MSG_GAME_GOOD,"%s has been resurrected and regained some lost XP!\\n"%self.name)
        
    
    def playerResurrect(self,xpRecover):
        self.player.world.clearDeathMarker(self.player)
        self.recoverDeathXP(xpRecover)
        dz = self.deathZone
        self.deathZone = None
        
        self.dead = False
        self.mob.health = 1
        self.mob.mana = 1
        self.mob.stamina = 1

        
        #teleport
        #are we in the same zone?
        if dz == self.player.zone.zone:
            #we just need to respawn player, whew
            self.player.zone.respawnPlayer(self.player,self.deathTransformInternal)
        else:
            from zone import TempZoneLink            
            zlink = TempZoneLink(dz.name,self.deathTransformInternal)
            self.player.world.onZoneTrigger(self.player,zlink)

        
            
    def resurrect(self, xpRecover):
        if not self.dead:
            return
            
        self.mob.autoAttack = False
            
        self.dead = False
        self.mob.health = 1
        self.mob.mana = 1
        self.mob.stamina = 1
        self.mob.zone.reattachMob(self.mob)
        
        self.recoverDeathXP(xpRecover)
    
    
    def loseXP(self,factor=1.0,death=True):
        #oh no! 
        player = self.player
        
        spawn = self.spawn
        
        #lose xp
        pneeded = spawn.plevel*spawn.plevel*100L*self.pxpMod
        sneeded = spawn.slevel*spawn.slevel*100L*self.sxpMod
        tneeded = spawn.tlevel*spawn.tlevel*100L*self.txpMod
        
        pprevneeded = ((spawn.plevel-1)*(spawn.plevel-1)*100L*self.pxpMod)
        sprevneeded = ((spawn.slevel-1)*(spawn.slevel-1)*100L*self.sxpMod)
        tprevneeded = ((spawn.tlevel-1)*(spawn.tlevel-1)*100L*self.txpMod)

        pgap = pneeded - pprevneeded
        sgap = sneeded - sprevneeded
        tgap = tneeded - tprevneeded
        
        pxploss = pgap/(spawn.plevel*2)
        sxploss = 0
        txploss = 0
        
        if spawn.slevel:
            sxploss = sgap/(spawn.slevel*2)
        if spawn.tlevel:
            txploss = tgap/(spawn.tlevel*2)
            
        pxploss = int(pxploss*.8*factor)
        sxploss = int(sxploss*.8*factor)
        txploss = int(txploss*.8*factor)
        
        if self.spawn.plevel < 5:
            pxploss = sxploss = txploss = 0
            
        
            
        pxp = int(self.xpPrimary - pxploss)
        sxp = int(self.xpSecondary - sxploss)
        txp = int(self.xpTertiary - txploss)
        
        if death:
            if (self.xpPrimary and pxploss) or (self.xpSecondary and sxploss) or (self.xpTertiary and txploss):
                player.sendGameText(RPG_MSG_GAME_CHARDEATH,"%s has died and lost experience!!\\n"%self.name)
            else:
                player.sendGameText(RPG_MSG_GAME_CHARDEATH,"%s has died!!\\n"%self.name)
        else:
            player.sendGameText(RPG_MSG_GAME_CHARDEATH,"%s has lost experience!!\\n"%self.name)
            

        
        if pxp < 0:
            pxploss = self.xpPrimary
            pxp = 0
        if sxp < 0:
            sxploss = self.xpSecondary
            sxp = 0
        if txp < 0:
            txploss = self.xpTertiary
            txp = 0
            
        self.xpDeathPrimary = pxploss
        self.xpDeathSecondary = sxploss
        self.xpDeathTertiary = txploss
            
        self.xpPrimary = int(pxp)
        self.xpSecondary = int(sxp)
        self.xpTertiary = int(txp)

        lost = False
        if pxp < pprevneeded and spawn.plevel > 1:
            lost = True
            self.player.sendGameText(RPG_MSG_GAME_LEVELLOST,"%s has lost a primary level in the %s class.\\n"%(self.name,spawn.pclassInternal))
            spawn.level-=1
            spawn.plevel-=1
            
        if sxp < sprevneeded and spawn.slevel > 1:
            lost = True
            self.player.sendGameText(RPG_MSG_GAME_LEVELLOST,"%s has lost a secondary level in the %s class.\\n"%(self.name,spawn.sclassInternal))
            spawn.slevel-=1
            
        if txp < tprevneeded and spawn.tlevel > 1:
            lost = True
            self.player.sendGameText(RPG_MSG_GAME_LEVELLOST,"%s has lost a tertiary level in the %s class.\\n"%(self.name,spawn.tclassInternal))
            spawn.tlevel-=1
            
        self.calcXPPercents()
            
        if lost:
            self.mob.levelChanged()
    
    
    def die(self):
        #store death for marker
        if CoreSettings.MAXPARTY == 1:
            so = self.player.simObject
            if so:
                transform = [v for v in so.position]
                for v in so.rotation:
                    transform.append(v)
                
                transform[6] = math.degrees(transform[6])
                
                self.player.world.clearDeathMarker(self.player)
                
                self.deathZone = self.player.zone.zone
                self.deathTransform = transform
                
                self.player.world.setDeathMarker(self.player,self)
        
        self.invulnerable = 360 #one minute
        self.mob.zone.detachMob(self.mob)
        
        self.health = 1
        self.mana = 1
        self.stamina = 1
        
        #find who did the most damage
        most = 0
        king = None
        for damager,xpdmg in self.mob.xpDamage.iteritems():
            if xpdmg.amount > most:
                most = xpdmg.amount
                king = damager
        
        if king:
            if king.master:
                king = king.master
            if king and king.player:
                if king.player.alliance.rewardKillXP(king.player,self.mob):
                    for p in self.mob.zone.players:
                        p.sendGameText(RPG_MSG_GAME_YELLOW,r'%s has killed %s\'s character, %s!!!\n'%(king.character.name,self.player.name,self.name))
        
        self.mob.xpDamage = {}
        self.mob.aggro = {}
        self.mob.playerAggro = {}
        if not king or not king.player:
            factor = float(self.mob.plevel) / 50.0
            if factor < 1.0:
                factor = 1.0
            self.loseXP(factor)
        player = self.player
        
        self.dead = True
        
        #check if all of player's party is dead
        #if so, it's back to the bindpoint
        alldead = True
        for c in self.player.party.members:
            if not c.dead:
                alldead = False
                break
        
        if alldead:
            self.player.world.onPlayerDeath(self.player)
        else:
            #set to first non-dead character
            if player.curChar == self:
                for x,c in enumerate(self.player.party.members):
                    if not c.dead:
                        player.curChar = c
                        player.mind.callRemote("setCurCharIndex",x)
                        player.sendGameText(RPG_MSG_GAME_EVENT,"%s is now your active character.\\n"%c.name)
                        break
    
    
    def addStartingGear(self):
        #optimize with a proper select if gets too crazy
        slot = RPG_SLOT_CARRY0
        usedslots = []
        sgear = list(StartingGear.select())
        
        for sg in sgear:
            #do we qualify
            if sg.qualify(self.spawn):
                inames = sg.items.split(',')
                for iname in inames:
                    iproto = ItemProto.byName(iname)
                    item = iproto.createInstance()
                    
                    item.slot = -1
                    for islot in iproto.slots:
                        if islot not in usedslots:
                            item.slot = islot
                            usedslots.append(islot)
                            break
                    
                    if item.slot == -1:
                        item.slot = slot
                        slot += 1
                    
                    item.setCharacter(self)
        
        credits = list(self.player.xpCredits)
        if len(credits):
            iproto=ItemProto.byName("Certificate of Experience")
            for cr in credits:
                
                credit = iproto.createInstance()
                credit.descOverride = "This certificate grants it's user %i experience points."%cr.xp
                credit.xpCoupon = cr.xp
                credit.setCharacter(self)
                credit.slot = slot
                slot+=1
                cr.destroySelf()
                
                if slot == RPG_SLOT_CARRY_END:
                    break
                
                

                    
                    
#ITEM MANAGEMENT
    def checkGiveItems(self,numItems):
        player = self.player
        if numItems:
            #get amount of free inventory space
            usedslots = 0
            for item in self.items:
                if RPG_SLOT_CARRY_END > item.slot >= RPG_SLOT_CARRY_BEGIN:
                    usedslots+=1
                    
            freeslots = (RPG_SLOT_CARRY_END-RPG_SLOT_CARRY_BEGIN)-usedslots
            
            if freeslots < numItems:
                player.sendGameText(RPG_MSG_GAME_DENIED,"%s needs %i free inventory spaces.\\n"%(self.name,numItems))
                return False
                    
        return True
        
                                
        
    
    def giveItemProtos(self,itemProtos,counts):
        player = self.player
        for proto,count in zip(itemProtos,counts):
            for c in xrange(0,count): #to do, handle stacking
                item = proto.createInstance()
                
                #find slot
                
                slot = None
                for x in xrange(RPG_SLOT_CARRY_BEGIN,RPG_SLOT_CARRY_END):
                    found = False
                    for sitem in self.items:
                        if x == sitem.slot:
                            found = True
                    if not found:
                        slot = x
                        break
                    
                if not slot:
                    traceback.print_stack()
                    print "AssertionError: no slot found!"
                    return
                
                item.slot = slot
                item.setCharacter(self)
                
                player.sendGameText(RPG_MSG_GAME_GAINED,"%s has gained %s!\\n"%(self.name,item.name))
                
                
                
        
        
        
        
    def takeItems(self,itemProtos,counts,silent=False):
        player = self.player
        index = 0
        for takeItem,countneeded in zip(itemProtos,counts):
            if not countneeded:
                index+=1
                continue #already satisfied
            count = 0
            for item in self.items:
                #if item.slot < RPG_SLOT_CARRY_BEGIN or item.slot>=RPG_SLOT_CARRY_END:
                #    continue
                
                if RPG_SLOT_TRADE_END > item.slot >= RPG_SLOT_TRADE_BEGIN:
                    continue
                if RPG_SLOT_LOOT_END > item.slot >= RPG_SLOT_LOOT_BEGIN:
                    continue


                if item.itemProto == takeItem:
                    sc = item.stackCount
                    if not sc:
                        sc = 1
                    if sc > counts[index]:
                        sc = counts[index]
                    count+=sc
                    counts[index]-=sc
                    
                    item.stackCount-=sc
                    
                    if not silent:
                        for x in xrange(0,sc):
                            player.sendGameText(RPG_MSG_GAME_LOST,"%s lost %s.\\n"%(self.name,item.name))
  
                    
                    if item.stackCount <=0:
                        if item == player.cursorItem:
                            player.cursorItem = None
                            item.slot = -1
                            player.updateCursorItem(item)
                            
                        if RPG_SLOT_WORN_END > item.slot >= RPG_SLOT_WORN_BEGIN:
                            self.mob.unequipItem(item.slot)
                
                        if self.mob.pet and RPG_SLOT_PET_END > item.slot >= RPG_SLOT_PET_BEGIN:
                            self.mob.pet.unequipItem(item.slot)
    
                        item.destroySelf()
                    else:
                        item.itemInfo.refreshDict({'STACKCOUNT':item.stackCount})
                        
                    
                    if count >= countneeded:
                        break
                    
            index+=1
                        
                    
        


    def restoreTradeItem(self,item):
        proto = item.itemProto
        
                
        #first, find a free carry slot if any
        for slot in xrange(RPG_SLOT_CARRY_BEGIN,RPG_SLOT_CARRY_END):
            found = False
            for hitem in self.items:
                if slot == hitem.slot:
                    found = True
                    break
            if not found:
                item.slot = slot
                item.setCharacter(self)
                return True #got it
            
        #next look to see if we can equip the item
        for slot in proto.slots:
            found = False
            for hitem in self.items:
                if slot == hitem.slot:
                    found = True
            if not found:
                item.slot = slot
                item.setCharacter(self)
                self.mob.equipItem(slot,item)
                return True #got it

                
        return False #blarg, the rotten player was moving stuff around
    
    
    def giveItemInstance(self,item):
        # Attempt to place item in free carry slot.
        freeSlots = self.getFreeCarrySlots()
        if len(freeSlots):
            item.slot = freeSlots[0]
            item.setCharacter(self)
            return True
        
        # Attempt to have the player equip the item.
        if item.isUseable(self.mob):
            item.slot = None
            self.equipItem(item)
            # If the item was equipped, the slot has been updated.
            if item.slot:
                item.setCharacter(self)
                return True
        
        # Attempt to place the item on the player's cursor.
        for ownedItems in self.items:
            if ownedItems.slot == RPG_SLOT_CURSOR:
                break
        # If the for loop exits normally, no item is on the cursor.
        else:
            item.slot = RPG_SLOT_CURSOR
            item.setCharacter(self)
            self.player.cursorItem = item
            self.player.mind.callRemote("setCursorItem", self.player.cursorItem.itemInfo)
            return True
        
        return False
    
    
    def getFreeCarrySlots(self):
        freeSlots = range(RPG_SLOT_CARRY_BEGIN, RPG_SLOT_CARRY_END)
        for item in self.items:
            try:    # try - except faster than a check if in list
                freeSlots.remove(item.slot)
            except:
                continue
        
        return freeSlots
    
    
    def checkSkillRaise(self,skillname,min=3,max=8,playSound = True,silent=False):
        mob = self.mob
        reuseTime = 0
        try:
            slevel    = mob.skillLevels[skillname]
            mlevel    = mob.mobSkillProfiles[skillname].maxValue
            reuseTime = mob.mobSkillProfiles[skillname].reuseTime
            questReq  = mob.mobSkillProfiles[skillname].questRequirements
        except KeyError:
            return
            
        if slevel >= mlevel:
            return
        
        for qreq in questReq:
            if slevel >= qreq[1]:
                dcs = list(CharacterDialogChoice.select(AND(CharacterDialogChoice.q.identifier==qreq[0],CharacterDialogChoice.q.characterID==self.id)))
                if not dcs or not len(dcs) or not dcs[0].count:
                    return
            
        i = int (slevel/10)
        if i < min:
            i = min


        if i > max:
            i = max
            
        #non passive skills are that much easier
        if reuseTime:
            i/=2
            if i < min:
                i = min
        
        if random.randint(0,i):
            return
        
        for skill in self.skills:
            if skill.skillname == skillname:
                skill.level += 1
                mob.skillLevels[skillname] = skill.level
                mob.updateClassStats()
                if not silent:
                    self.player.sendGameText(RPG_MSG_GAME_GAINED,"%s has become better at %s! (%i)\\n"%(self.name,skillname,skill.level))
                if playSound:
                    self.player.mind.callRemote("playSound","sfx/Pickup_Secret02.ogg")
                return
            
    
    def removeAdvancementStats(self):
        try:
            if not self.mob:
                return
            self.mob.derivedDirty = True
            self.mob.advancements = {}
            self.mob.advancementStats = []
            for adv in self.advancements:
                for stat in adv.advancementProto.stats:
                    if stat.statname.startswith("advance_"):
                        continue
                    v = float(adv.rank)*stat.value
                    if stat.statname in RPG_RESISTSTATS:
                        self.mob.resists[RPG_RESISTLOOKUP[stat.statname]]-=v
                    else:
                        setattr(self.mob,stat.statname,getattr(self.mob,stat.statname)-v)
        except:
            traceback.print_exc()


    def applyAdvancementStats(self):
        try:
            if not self.mob:
                return
            self.mob.derivedDirty = True
            self.mob.advancementStats = []
            advancements = self.mob.advancements = {}
            for adv in self.advancements:
                for stat in adv.advancementProto.stats:
                    v = float(adv.rank)*stat.value
                    if stat.statname.startswith("advance_"):
                        st = stat.statname[8:]
                        if advancements.has_key(st):
                            advancements[st]+=v
                        else:
                            advancements[st]=v
                    elif stat.statname in RPG_RESISTSTATS:
                        try:
                            self.mob.resists[RPG_RESISTLOOKUP[stat.statname]]+=v
                        except KeyError:
                            self.mob.resists[RPG_RESISTLOOKUP[stat.statname]]=v
                    else:                        
                        setattr(self.mob,stat.statname,getattr(self.mob,stat.statname)+v)
                        self.mob.advancementStats.append((stat.statname,v))
        except:
            traceback.print_exc()
    
    def checkAdvancements(self):
        advancements = list(self.advancements)
        
        for a in advancements:
            if hasattr(a,"hasBeenDestroyed"):
                continue
            adv = list(self.advancements)
            for b in adv:
                if a == b:
                    continue
                for ex in a.advancementProto.exclusions:
                    if ex.exclude == b.advancementProto.name:
                        b.hasBeenDestroyed = True
                        b.destroySelf()
                
        self.advancementsCache = self.advancements
                            
    def chooseAdvancement(self,advance):
        spawn = self.spawn
        try:
            a = AdvancementProto.byName(advance)
        except:
            print "WARNING: Unknown Advancement %s"%advance
            return
        thisAdv = None
        existingAdv = {}
        for adv in self.advancements:
            proto = adv.advancementProto
            existingAdv[proto.name] = adv.rank
            if proto == a:
                thisAdv = adv
        
        passed = True
        if spawn.plevel < a.level or self.advancementPoints < a.cost or (thisAdv and thisAdv.rank >= a.maxRank):
            passed = False
        elif len(a.classes):
            passed = False
            for cl in a.classes:
                if (cl.classname == spawn.pclassInternal and cl.level <= spawn.plevel) or (cl.classname == spawn.sclassInternal and cl.level <= spawn.slevel) or (cl.classname == spawn.tclassInternal and cl.level <= spawn.tlevel):
                    passed = True
                    break
        if passed and len(a.races):
            passed = False
            for rc in a.races:
                if rc.racename == spawn.race and rc.level <= spawn.plevel:
                    passed = True
                    break
        if passed:
            for req in a.requirements:
                if req.require not in existingAdv or req.rank > existingAdv[req.require]:
                    passed = False
                    break
        
        if not passed:
            print "WARNING: %s attempted unqualified advancement %s"%(self.name,advance)
            return
        
        self.removeAdvancementStats()
        
        if thisAdv:
            thisAdv.rank += 1
            self.advancementPoints -= a.cost
            self.applyAdvancementStats()
            self.player.sendGameText(RPG_MSG_GAME_GAINED,"%s has gained a rank in %s! (%i)\\n"%(self.name,advance,thisAdv.rank))
            return
        
        CharacterAdvancement(advancementProto=a,character=self)
        self.advancementPoints -= a.cost
        self.checkAdvancements()
        self.applyAdvancementStats()
        self.player.sendGameText(RPG_MSG_GAME_GAINED,"%s has advanced in %s!\\n"%(self.name,advance))
        
        self.advancementsCache = self.advancements
    
    
    def onCraft(self):
        if self.dead:
            self.player.sendGameText(RPG_MSG_GAME_DENIED,"%s is dead and cannot craft!\\n"%(self.name))
            return
        
        from crafting import Craft
        Craft(self.mob)
        
    def splitItem(self,item,newStackSize):
        
        if newStackSize >= item.stackCount or newStackSize < 1:
            return
        
        needed = 1
        #cursorItem = self.player.cursorItem
        #if cursorItem != item:
        #    needed+=1
        
        if len(self.getFreeCarrySlots())<needed:
            self.player.sendGameText(RPG_MSG_GAME_DENIED,"%s doesn't have enough free carry slots for item split!\\n"%(self.name))
            return
        
        nitem = item.clone()
        nitem.stackCount = item.stackCount-newStackSize 
        item.stackCount = newStackSize
        item.itemInfo.refreshDict({'STACKCOUNT':item.stackCount})
        
        
        if not self.giveItemInstance(nitem):
            nitem.destroySelf()
            raise "Unable to give item instance on split!"
        
            
    def destroySelf(self):
        
        for o in self.spellsInternal:
            o.destroySelf()
        
        for o in self.itemsInternal:
            o.destroySelf()
        
        for o in self.advancements:
            o.destroySelf()
                
        for o in self.skills:
            o.destroySelf()
        
        for o in self.characterDialogChoices:
            o.destroySelf()
        
        
        for o in self.spellStore:
            o.destroySelf()
            
        for o in self.vaultItems:
            o.destroySelf()
        
        for o in self.characterFactions:
            o.destroySelf()
            
        self.spawn.destroySelf()
 
        
        Persistent.destroySelf(self)
           
            
        
        
            
        
