
from twisted.spread import pb
import math
from mud.world.defines import *
from mud.world.core import *
import traceback


ROMAN = ("I","II","III","IV","V","VI","VII","VIII","IX","X")

DIRTY = False
def IsDirty():
    global DIRTY
    if DIRTY:
        DIRTY = False
        return True
    return False

ADVANCEMENTS_DIRTY = False
def AdvancementsDirty():
    global ADVANCEMENTS_DIRTY
    if ADVANCEMENTS_DIRTY:
        ADVANCEMENTS_DIRTY = False
        return True
    return False

TACTICAL_DIRTY = False
def IsTacticalDirty():
    global TACTICAL_DIRTY
    if TACTICAL_DIRTY:
        TACTICAL_DIRTY = False
        return True
    return False

SKILLS_DIRTY = []
def AreSkillsDirty(cinfo):
    global SKILLS_DIRTY
    d = cinfo in SKILLS_DIRTY
    SKILLS_DIRTY = []
    return d
    
class RootInfo(pb.Cacheable):
    def __init__(self,player,charInfos):
        self.player = player
        self.observers = []
        self.charInfos = charInfos
        self.state = None
        self.forceBankUpdate = False
        
        
    def stoppedObserving(self, perspective, observer):
        #if observer in self.observers:
        self.observers.remove(observer)

        
    def getStateToCacheAndObserveFor(self, perspective, observer):
        self.observers.append(observer)
        
        state = self.state = {}
        
        state['PLAYERNAME']=self.player.name
        state['CHARINFOS']=self.charInfos
        #state['TACTICAL']=self.tactical
        player = self.player
        tin = long(player.tin)
        tin += player.copper * 100L
        tin += player.silver * 10000L
        tin += player.gold * 1000000L
        tin += player.platinum * 100000000L
        state['TIN'] = tin
        state['PAUSED']=False
        state['GUILDNAME']=player.guildName
        
        
        bank = {}
        for b in player.bankItems:
            if b.slot < RPG_SLOT_BANK_BEGIN or b.slot >= RPG_SLOT_BANK_END:
                print "WARNING: INVALID BANK ITEM SLOT, ITEM DELETED: %s"%b.name
                b.destroySelf()
                continue
                
            bank[b.slot]=b.itemInfo
        state['BANK']=bank
        
        return state
        
    def tick(self):
        if not self.state:
            return
        #self.tactical.tick(self.player)
        for c in self.charInfos.itervalues():
            c.rapidMobInfo.tick()
            
        changed = {}
        state = self.state
        player = self.player
        
        if player.world.paused != state['PAUSED']:
            changed['PAUSED']=state['PAUSED']=player.world.paused
        
            
        if state['GUILDNAME'] !=player.guildName:
            changed['GUILDNAME']=state['GUILDNAME']=player.guildName
        
        tin = long(player.tin)
        tin += player.copper * 100L
        tin += player.silver * 10000L
        tin += player.gold * 1000000L
        tin += player.platinum * 100000000L
        if state['TIN'] != tin:
            changed['TIN'] = state['TIN'] = tin
        
        bank = {}
        for b in player.bankItems:
            if b.slot < RPG_SLOT_BANK_BEGIN or b.slot >= RPG_SLOT_BANK_END:
                print "WARNING: INVALID BANK ITEM SLOT, ITEM DELETED: %s"%b.name
                b.destroySelf()
                continue

            bank[b.slot]=b.itemInfo
        
        if self.forceBankUpdate or state['BANK']!=bank:
            changed['BANK']=state['BANK']=bank
            self.forceBankUpdate = False
        
        if len(changed):    
            for o in self.observers: o.callRemote('updateChanged', changed)
        
class RootInfoGhost(pb.RemoteCache):
    def setCopyableState(self, state):
        self.bankDirty = True
        for k,v in state.iteritems():
            if k == "GUILDNAME":
                from tgenative import TGEObject
                if v:
                    TGEObject("TomeGui_Window").setText("< %s >"%v)
                else:
                    TGEObject("TomeGui_Window").setText("Tome")

            self.__dict__[k]=v
            
    def observe_updateChanged(self,changed):
        for k,v in changed.iteritems():
            if k == 'BANK':
                self.bankDirty = True
            if k == "GUILDNAME":
                from tgenative import TGEObject
                if v:
                    TGEObject("TomeGui_Window").setText("< %s >"%v)
                else:
                    TGEObject("TomeGui_Window").setText("Tome")
            setattr(self,k,v)
    
    def checkMoney(self,worth):
        if not worth:
            return True
        
        if self.TIN < 0:
            traceback.print_stack()
            print "AssertionError: player %s wealth whackiness!"%self.PLAYERNAME
            return
        
        if self.TIN >= worth:
            return True
        return False

pb.setUnjellyableForClass(RootInfo, RootInfoGhost)             


class RapidMobInfo(pb.Cacheable):
    def __init__(self,mob):
        self.observers = []
        self.mob = mob
        self.state = None
        
    def stoppedObserving(self, perspective, observer):
        #if observer in self.observers:
        self.observers.remove(observer)

    def getStateToCacheAndObserveFor(self, perspective, observer):
        self.observers.append(observer)
        mob = self.mob
        state = {}
        if not self.state:
            self.state = state
        state['HEALTH']=float(mob.health)
        state['MAXHEALTH']=float(mob.maxHealth)
        if mob.maxMana:
            state['MANA']=float(mob.mana)/float(mob.maxMana)
        else:
            state['MANA']=0.0
            
        state['MANA']=float(mob.mana)
        state['MAXMANA']=float(mob.maxMana)
        
        state['STAMINA']=float(mob.stamina)
        state['MAXSTAMINA']=float(mob.maxStamina)
        if mob.target:
            state['TGT']=mob.target.name
            state['TGTID']=mob.target.id
            state['TGTHEALTH']=float(mob.target.health)/float(mob.target.maxHealth)
        else:
            state['TGT']=None
            state['TGTID']=0
            state['TGTHEALTH']=-1

        if mob.pet:
            state['PETNAME'] = mob.pet.name
            state['PETHEALTH'] = float(mob.pet.health)/float(mob.pet.maxHealth)
            state['PETAGGRESSIVE'] = mob.pet.attacking
        else:
            state['PETNAME'] = None
            state['PETHEALTH'] = -1
            state['PETAGGRESSIVE'] = False

            
        state['AUTOATTACK']=mob.autoAttack
        state['RANGEDREUSE']=mob.rangedReuse
        if mob.casting:
            state['CASTING']=True
        else:
            state['CASTING']=False
        
        return state
        
    def tick(self):
        mob = self.mob
        state = self.state
        changed = {}
        
        health = float(mob.health)
        if state['HEALTH'] != health:
            changed['HEALTH'] = state['HEALTH'] = health
        maxHealth = float(mob.maxHealth)
        if state['MAXHEALTH'] != maxHealth:
            changed['MAXHEALTH'] = state['MAXHEALTH'] = maxHealth
        
        mana = mob.mana
        if state['MANA'] != mana:
            changed['MANA'] = state['MANA'] = mana
        maxMana = mob.maxMana
        if state['MAXMANA'] != maxMana:
            changed['MAXMANA'] = state['MAXMANA'] = maxMana
        
        stamina = float(mob.stamina)
        if state['STAMINA'] != stamina:
            changed['STAMINA'] = state['STAMINA'] = stamina
        maxStamina = float(mob.maxStamina)
        if state['MAXSTAMINA'] != maxStamina:
            changed['MAXSTAMINA'] = state['MAXSTAMINA'] = maxStamina
        
        if mob.target:
            tgt=mob.target.name
            tgtid = mob.target.id
            tgthealth=float(mob.target.health)/float(mob.target.maxHealth)
        else:
            tgt=None
            tgtid = 0
            tgthealth = -1
            
        if mob.pet:
            petname = mob.pet.name
            pethealth = float(mob.pet.health)/float(mob.pet.maxHealth)
            petAggressive = mob.pet.attacking
        else:
            petname = None
            pethealth = -1
            petAggressive = False
        
        if state['TGT'] != tgt:
            changed['TGT'] = state['TGT'] = tgt
        if state['TGTID'] != tgtid:
            changed['TGTID'] = state['TGTID'] = tgtid
        if state['TGTHEALTH'] != tgthealth:
            changed['TGTHEALTH'] = state['TGTHEALTH'] = tgthealth

        if state['PETNAME'] != petname:
            changed['PETNAME'] = state['PETNAME'] = petname
        if state['PETHEALTH'] != pethealth:
            changed['PETHEALTH'] = state['PETHEALTH'] = pethealth
        if state['PETAGGRESSIVE'] != petAggressive:
            changed['PETAGGRESSIVE'] = state['PETAGGRESSIVE'] = petAggressive
            
        if state['AUTOATTACK'] != mob.autoAttack:
            changed['AUTOATTACK'] = state['AUTOATTACK'] = mob.autoAttack
        if state['RANGEDREUSE'] != mob.rangedReuse:
            changed['RANGEDREUSE'] = state['RANGEDREUSE'] = mob.rangedReuse
        
        casting = False
        if mob.casting:
            casting = True
        if state['CASTING'] != casting:
            changed['CASTING'] = state['CASTING'] = casting
        
        if not len(changed):
            return
        
        for o in self.observers: o.callRemote('updateChanged', changed)


class RapidMobInfoGhost(pb.RemoteCache):
    def setCopyableState(self, state):
        for k,v in state.iteritems():
            self.__dict__[k]=v
    
    def observe_updateChanged(self,changed):
        from mud.client.gui.partyWnd import PARTYWND
        if 'CASTING' in changed:
            PARTYWND.spellPane.setFromCharacterInfo(PARTYWND.charInfos[PARTYWND.curIndex])
            PARTYWND.encounterSettingDisturbed()
            if changed['CASTING']:
                PARTYWND.encounterBlock += 1
            else:
                PARTYWND.encounterBlock -= 1
        if 'AUTOATTACK' in changed:
            PARTYWND.encounterSettingDisturbed()
            if changed['AUTOATTACK']:
                PARTYWND.encounterBlock += 1
            else:
                PARTYWND.encounterBlock -= 1
        if 'PETAGGRESSIVE' in changed:
            PARTYWND.encounterSettingDisturbed()
            if changed['PETAGGRESSIVE']:
                PARTYWND.encounterBlock += 1
            else:
                PARTYWND.encounterBlock -= 1
        for k,v in changed.iteritems():
            setattr(self,k,v)


pb.setUnjellyableForClass(RapidMobInfo, RapidMobInfoGhost) 



#we could save a little bandwidth here by sending itemprotos only once
class ItemInfo(pb.Cacheable):
    #dynamic stats only!
    keys = {'PENALTY':'penalty','SLOT':'slot','REPAIR':'repair','REUSETIMER':'reuseTimer',"USECHARGES":"useCharges","ARMOR":"armor",'STACKCOUNT':'stackCount'}
    resists = [RPG_RESIST_COLD,RPG_RESIST_FIRE,RPG_RESIST_DISEASE,RPG_RESIST_MAGICAL,RPG_RESIST_PHYSICAL,RPG_RESIST_POISON,RPG_RESIST_ELECTRICAL,RPG_RESIST_ACID]
    
    def __init__(self, item):
        self.item = item
        self.state = {}
        self.observers = []
        self.initialized = False
    
    def getFullState(self):
        self.initialized = True
        self.state = {}
        state = self.state
        item = self.item
        
        for k,attr in ItemInfo.keys.iteritems():
            state[k] = getattr(self.item,attr)
        
        if item.character:
            state['OWNERCHARID'] = item.character.id
        else:
            state['OWNERCHARID'] = 0
        
        state['PROTOID'] = item.itemProto.id
        state['NAME'] = item.name
        
        state['REPAIRMAX'] = item.repairMax
        state['BITMAP'] = item.bitmap
        state['FLAGS'] = item.flags
        state['LEVEL'] = item.level
        
        state['STATS'] = item.stats
        state['WPNDAMAGE'] = item.wpnDamage
        state['WPNRATE'] = item.wpnRate
        state['WPNRANGE'] = item.wpnRange
        state['LIGHT'] = item.light
        
        state['QUALITY'] = item.quality
        state['WORTHINCREASETIN'] = item.worthIncreaseTin
        state['DESC'] = item.descOverride    # just send descoverride, which can be None
        
        #debuffs
        state['RACEBANE'] = item.wpnRaceBane
        state['RACEMOD'] = item.wpnRaceBaneMod
        state['RESISTDEBUFF'] = item.wpnResistDebuff
        state['RESISTDEBUFFMOD'] = item.wpnResistDebuffMod
        state['POISONS'] = []
        state['ENCHANTMENTS'] = []
        for proc,details in item.procs.iteritems():
            if details[1] == RPG_ITEMPROC_POISON:
                state['POISONS'].append(proc.spellProto.name)
            else:
                state['ENCHANTMENTS'].append(proc.spellProto.name)
    
    def getStateToCacheAndObserveFor(self, perspective, observer):
        self.observers.append(observer)
        self.getFullState()
        return self.state
    
    def stoppedObserving(self, perspective, observer):
        #if observer in self.observers:
        self.observers.remove(observer)
    
    def reset(self):
        self.getFullState()
        for o in self.observers: o.callRemote('updateChanged', self.state)
    
    def refresh(self):
        if not self.initialized:
            self.getFullState()
        
        state = self.state
        changed = {}
        
        for k,attr in ItemInfo.keys.iteritems():
            v = getattr(self.item,attr)
            if state[k] != v:
                state[k] = changed[k] = v
        
        ownerid = 0
        if self.item.character:
            ownerid = self.item.character.id
        if ownerid != state['OWNERCHARID']:
            state['OWNERCHARID']=changed['OWNERCHARID']=ownerid
        
        poisons = []
        enchantments = []
        for proc,details in self.item.procs.iteritems():
            if details[1] == RPG_ITEMPROC_POISON:
                poisons.append(proc.spellProto.name)
            else:
                enchantments.append(proc.spellProto.name)
        if poisons != state['POISONS']:
            state['POISONS'] = changed['POISONS'] = poisons
        if enchantments != state['ENCHANTMENTS']:
            state['ENCHANTMENTS'] = changed['ENCHANTMENTS'] = enchantments
        
        if len(changed):
            for o in self.observers: o.callRemote('updateChanged', changed)
    
    def refreshDict(self,dict):
        rm = []
        for k,v in dict.iteritems():
            try:
                if self.state[k] != v:
                    self.state[k] = v
                else:
                    rm.append(k)
            except:
                rm.append(k)
                traceback.print_exc()
        
        for k in rm:
            del dict[k]
            
        if len(dict):
            for o in self.observers: o.callRemote('updateChanged', dict)
    
    def refreshProcs(self):
        poisons = []
        enchantments = []
        for proc,details in self.item.procs.iteritems():
            if details[1] == RPG_ITEMPROC_POISON:
                poisons.append(proc.spellProto.name)
            else:
                enchantments.append(proc.spellProto.name)
        
        changed = {}
        if poisons != self.state['POISONS']:
            self.state['POISONS'] = changed['POISONS'] = poisons
        if enchantments != self.state['ENCHANTMENTS']:
            self.state['ENCHANTMENTS'] = changed['ENCHANTMENTS'] = enchantments
        if len(changed):
            for o in self.observers: o.callRemote('updateChanged', changed)

class ItemInfoGhost(pb.RemoteCache):
    
    def __init__(self):
        self.text = ""
        self.infoDirty = True
    
    def generateItemText(self):
        # Prepare stats
        stattext = []
        rtext = [r'\c3Resists: ']
        wpntext = []
        gotResist = False
        for st,value in self.STATS:
            stChanged = False
            if not value:
                continue
            
            stupper = st.upper()
            if stupper in RPG_STATS:
                stChanged = True
                st = stupper
            
            elif st == "dmgBonusOffhand":
                wpntext.append(r'\c3%s \c2%i '%("Dmg Bonus(Offhand)",value))
            elif st == "dmgBonusPrimary":
                wpntext.append(r'\c3%s \c2%i '%("Dmg Bonus",value))
            
            elif st == "maxHealth":
                stChanged = True
                st = "Health"
            elif st == "maxStamina":
                stChanged = True
                st = "Stamina"
            elif st == "maxMana":
                stChanged = True
                st = "Mana"
            
            elif st == "pre":
                stChanged = True
                st = "Presence"
            
            elif st == "haste":
                stattext.append(r'\c2Melee Haste ')
            elif st == "castHaste":
                stattext.append(r'\c2Casting Haste ')
            elif st == "move":
                stattext.append(r'\c2%s +%i%% '%(st,value*100.0))
            
            elif st == "regenHealth":
                stattext.append(r'\c2Regeneration ')
            elif st == "regenStamina":
                stattext.append(r'\c2Revitalization ')
            elif st == "regenMana":
                stattext.append(r'\c2Mana Regen ')
            
            elif RPG_RESISTLOOKUP.has_key(st):
                gotResist = True
                if value > 0:
                    rtext.append(r'\c3%s \c2%i '%(RPG_RESIST_TEXT[RPG_RESISTLOOKUP[st]],value))
                else:
                    rtext.append(r'\c3%s \c1%i '%(RPG_RESIST_TEXT[RPG_RESISTLOOKUP[st]],value))
            
            else:
                stChanged = True
            
            if stChanged:
                if value > 0:
                    stattext.append(r'\c3%s \c2%i '%(st,value))
                else:
                    stattext.append(r'\c3%s \c1%i '%(st,value))
        if gotResist:
            stattext.extend(rtext)
        
        # Name <--- get's centered above, quality is part of the name
        text = []
        
        # Level Recommendation
        if self.LEVEL > 1:
            text.append(r'\c3Recommended Level: \c0%i \n'%self.LEVEL)
        
        setNewline = False
        # Races
        if len(self.RACES):
            setNewline = True
            text.append(r'\c3Races: \c2%s'%' '.join(self.RACES))
        
        # Realms
        if len(self.REALMS):
            setNewline = True
            text.append(r'\c3Realms: ')
            for r,level in self.REALMS:
                if r == RPG_REALM_LIGHT and level <= 1:
                    text.append(r'\c0FoL\c3 ')
                elif r == RPG_REALM_DARKNESS and level <= 1:
                    text.append(r'\c0MoD\c3 ')
                elif r == RPG_REALM_MONSTER and level <= 1:
                    text.append(r'\c0Monsters\c3 ')
                else:
                    if r == RPG_REALM_LIGHT and level > 1:
                        text.append(r'\c0FoL\c3(\c0%i\c3) '%level)
                    elif r == RPG_REALM_DARKNESS and level > 1:
                        text.append(r'\c0MoD\c3(\c0%i\c3) '%level)
                    elif r == RPG_REALM_MONSTER and level > 1:
                        text.append(r'\c0Monsters\c3(\c0%i\c3) '%level)
        
        # Classes
        if len(self.CLASSES):
            setNewline = True
            text.append(r'\c3Classes: ')
            for cl,level in self.CLASSES:
                text.append(r'\c0%s\c3(\c0%i\c3) '%(cl,level))
        
        if setNewline:
            text.append(r'\n')
        
        # Penalty
        if self.PENALTY:
            text.append(r'\c3Penalty: \c1%i%% '%(int(self.PENALTY*100.0)))
        
        # Skill
        if self.SKILL:
            text.append(r'\c3Skill: \c2%s '%self.SKILL)
        
        # Slots
        if len(self.SLOTS):
            text.append(r'\c3Slots: \c2%s '%((r' \c2').join(RPG_SLOT_TEXT[slot] for slot in self.SLOTS)))
        
        # Charges
        if self.USEMAX and self.USECHARGES:
            text.append(r'\c3Charges: \c2%i'%(self.USECHARGES))
        
        # Bane
        if self.RACEBANE:
            text.append(r'\n\c3Bane: Attack \c2+%i%%  \c3Damage \c2+%i%% \c3vs \c0%s'%(int(RPG_BANEWEAPON_OFFENSE[self.RACEMOD]*100.0),
            int(RPG_BANEWEAPON_DAMAGE[self.RACEMOD]*100.0),self.RACEBANE))
        
        # Debuff
        if self.RESISTDEBUFFMOD:
            r = RPG_RESIST_TEXT[self.RESISTDEBUFF]
            text.append(r'\n\c3Enemy Resists: \c0%s \c1-%i \n'%(r,self.RESISTDEBUFFMOD))
        
        # Weapon Desc
        if self.WPNDAMAGE:
            text.append(r'\n\c3Wpn Dmg/Delay: \c3(\c0%i\c3/\c0%i\c3)\n'%(self.WPNDAMAGE,self.WPNRATE))
            text.extend(wpntext)
        
        # Range
        if self.WPNRANGE:
            text.append(r'\c3Range: \c0%i '%self.WPNRANGE)
        
        # Stats
        if stattext:
            text.append(r'\n%s '%(''.join(stattext)))
        
        # Armor
        if self.ARMOR:
            text.append(r'\c3Armor: \c0%i '%self.ARMOR)
        
        # Light
        if self.LIGHT:
            text.append(r'\c3Radiance: \c0%i '%math.ceil(self.LIGHT))
        
        # Repair
        if self.REPAIRMAX:
            text.append(r'\c3Repair:  ')
            if self.REPAIR < self.REPAIRMAX:
                text.append(r'\c1%i\c3/\c0%i '%(self.REPAIR,self.REPAIRMAX))
            else:
                text.append(r'\c0%i\c3/\c0%i '%(self.REPAIR,self.REPAIRMAX))
        
        setNewline = False
        # Effect Desc
        if self.EFFECTDESC:
            setNewline = True
            if text:
                text.append("\\n\\n")
            text.append(r'\c3Effect: \c0%s\n'%self.EFFECTDESC)
        
        # Desc
        if self.DESC:
            if setNewline:
                text.append("\\n")
            elif text:
                text.append("\\n\\n")
            text.append(r'\c0%s'%self.DESC)
            setNewline = True
        
        # Poisons
        if len(self.POISONS):
            if setNewline:
                text.append("\\n")
            elif text:
                text.append("\\n\\n")
            text.append(r'\c3Active Poisons: \c0%s'%(', '.join(self.POISONS)))
            setNewline = True
        # Enchantments
        if len(self.ENCHANTMENTS):
            if setNewline:
                text.append("\\n")
            elif text:
                text.append("\\n\\n")
            text.append(r'\c3Active Enchantments: \c0%s'%(', '.join(self.ENCHANTMENTS)))
        
        
        self.text = r'\cp%s'%(''.join(text))
    
    def setCopyableState(self, state):
        global DIRTY
        DIRTY = True
        self.infoDirty = True
        from mud.client.playermind import GetMoMClientDBConnection
        con = GetMoMClientDBConnection()
        
        for k,v in state.iteritems():
            self.__dict__[k] = v
        
        self.SKILL,self.WEIGHT,self.STACKMAX,self.USEMAX,self.EFFECTDESC,basedesc,spID,self.STACKDEFAULT,self.WORTHTIN = con.execute('SELECT skill,weight,stack_max,use_max,effect_desc,desc,spell_proto_id,stack_default,worth_tin FROM item_proto WHERE id = %i LIMIT 1;'%self.PROTOID).fetchone()
        
        self.SLOTS = tuple(s[0] for s in con.execute('SELECT slot FROM item_slot WHERE item_proto_id = %i;'%self.PROTOID))
        
        if not self.FLAGS and self.QUALITY != RPG_QUALITY_NORMAL and not spID and len(self.SLOTS) and not self.STACKMAX > 1:
            self.NAME = ' '.join((RPG_QUALITY_TEXT[self.QUALITY],self.NAME))
        
        self.SPELLINFO = None
        if spID:
            self.SPELLINFO = SpellInfoGhost(spID)
            if not self.DESC:
                self.DESC = self.SPELLINFO.DESC
        elif not self.DESC:
            self.DESC = basedesc
        
        self.CLASSES = [(classname,level) for classname,level in con.execute('SELECT classname,level FROM item_class WHERE item_proto_id = %i;'%self.PROTOID)]
        if spID:
            self.CLASSES.extend(self.SPELLINFO.CLASSES)
        self.CLASSES = tuple(self.CLASSES)
        self.RACES = tuple(item[0] for item in con.execute('SELECT racename FROM item_race WHERE item_proto_id = %i;'%self.PROTOID))
        self.REALMS = tuple((realmname,level) for realmname,level in con.execute('SELECT realmname,level FROM item_realm WHERE item_proto_id = %i;'%self.PROTOID))
        
        self.generateItemText()
    
    def getWorth(self,valueMod = 1.0):
        #todo, repair
        tin = self.WORTHTIN
        tin += self.WORTHINCREASETIN
        
        tin = math.floor(tin*RPG_QUALITY_MODS[self.QUALITY])
        tin = math.ceil(tin*valueMod)
        
        mod = 1.0
        if self.STACKCOUNT:
            if not self.STACKDEFAULT:
                mod = float(self.STACKCOUNT)
            else:
                mod = float(self.STACKCOUNT)/float(self.STACKDEFAULT)
        tin = math.ceil(tin*mod)
        
        return long(tin)
    
    def isUseable(self,cinfo):
        
        if self.SKILL:
            if not cinfo.SKILLS.get(self.SKILL):
                return False
        
        if len(self.RACES):
            if cinfo.RACE not in self.RACES:
                return False
        
        if len(self.REALMS):
            found = False
            for r in self.REALMS:
                if cinfo.REALM == r[0]:
                    found = True
                    break
            if not found:
                return False
        
        if len(self.CLASSES):
            found = False
            for cl,level in self.CLASSES:
                if cinfo.PCLASS == cl:
                    if self.SPELLINFO:
                        if cinfo.PLEVEL < level:
                            continue
                    found = True
                    break
                elif cinfo.SCLASS == cl:
                    if self.SPELLINFO:
                        if cinfo.SLEVEL < level:
                            continue
                    found = True
                    break
                elif cinfo.TCLASS == cl:
                    if self.SPELLINFO:
                        if cinfo.TLEVEL < level:
                            continue
                    found = True
                    break
                    
            if not found:
                return False
            
        return True
    
    def observe_setState(self,state):
        self.infoDirty = True
        self.setCopyableState(state)
    
    def observe_updateChanged(self,changed):
        global DIRTY
        DIRTY = True
        self.infoDirty = True
        
        for k,v in changed.iteritems():
            if k == 'DESC' and not v:
                continue
            setattr(self,k,v)
        
        self.generateItemText()

pb.setUnjellyableForClass(ItemInfo, ItemInfoGhost)


#this is shared for src and dst mob
class SpellEffectInfo(pb.Copyable,pb.RemoteCopy):
    def __init__(self,spell=None):
        if spell:
            
            proto = spell.spellProto
            
            if not spell.skill:
                try:
                    self.NAME=proto.name+" "+ROMAN[spell.level-1]
                except:
                    self.NAME=proto.name
                    
            else:
                self.NAME=proto.name
                
            self.HARMFUL = proto.spellType&RPG_SPELL_HARMFUL
            
            self.ICONSRC=proto.iconSrc
            self.ICONDST=proto.iconDst
            self.SRCMOBID=spell.src.id
            self.DSTMOBID=spell.dst.id
            self.PID=spell.pid
            self.TIME = float(proto.duration)/6.0 - float(spell.time)/6.0

pb.setUnjellyableForClass(SpellEffectInfo, SpellEffectInfo)     
            
        
    
        

class CharacterInfo(pb.Cacheable):
    spawnkeys = {'NAME':'name','RACE':'race','SEX':'sex','REALM':'realm'}
    mobkeys = {'STRBASE':'strBase','DEXBASE':'dexBase','BDYBASE':'bdyBase','MNDBASE':'mndBase','WISBASE':'wisBase','AGIBASE':'agiBase',
    'REFBASE':'refBase','MYSBASE':'mysBase',
    'STR':'str','DEX':'dex','BDY':'bdy','MND':'mnd','WIS':'wis','AGI':'agi','REF':'ref','MYS':'mys','PRE':'pre',
    'OFFENSE':'offense','DEFENSE':'defense','HEALTH':'health',"ARMOR":'armor'}
    
    def __init__(self,character):
        self.character = character
        self.state = {}
        self.observers = []
    
        
    def stoppedObserving(self, perspective, observer):
        
        #if observer in self.observers:
        self.observers.remove(observer)

        
    
    def getStateToCacheAndObserveFor(self, perspective, observer):
        
        self.observers.append(observer)
        state = self.state
        mob = self.character.mob
        spawn = mob.spawn
        
        for k,attr in CharacterInfo.spawnkeys.iteritems():
            state[k]=getattr(spawn,attr)
        for k,attr in CharacterInfo.mobkeys.iteritems():
            state[k]=getattr(mob,attr)
            
        
        self.rapidMobInfo = state['RAPIDMOBINFO']= RapidMobInfo(mob)
        
        
        
        #current advancements
        state['ADVANCEMENTS'] = [(a.advancementProto.name,a.rank) for a in self.character.advancements]
        
        
        
        #todo - zip this info up and generate real info!
        
        
        #just clean some stuff up for the dictionary dump isn't too crazy
        
        
        
        #state['TEXTINFO']=self.getContextText(mob.context)
        
        state['PCLASS']=spawn.pclassInternal
        state['SCLASS']=spawn.sclassInternal
        state['TCLASS']=spawn.tclassInternal
        state['PLEVEL']=spawn.plevel
        state['SLEVEL']=spawn.slevel
        state['TLEVEL']=spawn.tlevel
        
        state['UNDERWATERRATIO']=mob.underWaterRatio
        
        
        character = self.character
        
        state['SPAWNID']=mob.spawn.id
        state['CHARID']=character.id
        state['ADVANCE']=character.advancementPoints
        state['MOBID']=mob.id
        
        state['ITEMS'] = dict((item.slot,item.itemInfo) for item in character.items)
        
        spells = {}
        for cspell in character.spells:
            if not cspell.spellInfo:
                cspell.spellInfo = CharSpellInfo(character,cspell)
            spells[cspell.slot] = cspell.spellInfo
            
        #spellproto id -> spellinfo
        state['SPELLS']=spells
        
        #skills
        state['SKILLS']=mob.skillLevels.copy()
        
        state['SKILLREUSE'] = dict((key,1) for key in mob.skillReuse.iterkeys())
        
        #leveling
        state['PXPPERCENT']=character.pxpPercent
        state['SXPPERCENT']=character.sxpPercent
        state['TXPPERCENT']=character.txpPercent
        
        state['PORTRAITPIC']=character.portraitPic
        
        state['DEAD']=character.dead
        
        #spelleffects
        if state.has_key('SPELLEFFECTS'): #<--- we are using this solely to cache to player if this changes, change this
            traceback.print_stack()
            print "AssertionError: CharacterInfo state got spell effects in dictionary and shouldn't!"
            return
        spelleffects = []
        from mud.world.spell import Spell
        processes = []
        processes.extend(mob.processesIn)
        processes.extend(mob.processesOut)
        for p in processes:
            if isinstance(p,Spell):
                if not p.spellProto.duration:
                    continue
                    
                if not p.spellEffectInfo:
                    p.spellEffectInfo = SpellEffectInfo(p)
                    
                if p.spellEffectInfo not in spelleffects:
                    spelleffects.append(p.spellEffectInfo)
                    
        state['SPELLEFFECTS']=spelleffects
        
        state['RESISTS'] = resists = []
        for resist in RPG_RESISTVALUES:
            r = mob.resists.get(resist)
            if r:
                resists.append((resist,r))
                    
        #vaultitems
        state['VAULTITEMS'] = [(v.id,v.name,v.stackCount) for v in self.character.vaultItems]
        
        return state
    
    def refreshLite(self,send=False):
        state = self.state
        mob = self.character.mob
        spawn = mob.spawn
        character = self.character

        changed = {}
        
        for k,attr in CharacterInfo.spawnkeys.iteritems():
            v = getattr(spawn,attr)
            if state[k] != v:
                
                changed[k] = v
                state[k]=v
                
        for k,attr in CharacterInfo.mobkeys.iteritems():
            v = getattr(mob,attr)
            if state[k] != v:
                
                changed[k] = v
                state[k]=v
                
        if state['UNDERWATERRATIO']!=mob.underWaterRatio:
            state['UNDERWATERRATIO']=changed['UNDERWATERRATIO']=mob.underWaterRatio
            
        #leveling
        if state['PXPPERCENT']!=character.pxpPercent:
            changed['PXPPERCENT'] = state['PXPPERCENT'] = character.pxpPercent
        if state['SXPPERCENT']!=character.sxpPercent:
            changed['SXPPERCENT'] = state['SXPPERCENT'] = character.sxpPercent
        if state['TXPPERCENT']!=character.txpPercent:
            changed['TXPPERCENT'] = state['TXPPERCENT'] = character.txpPercent

        resists = []
        for resist in RPG_RESISTVALUES:
            r = mob.resists.get(resist)
            if r:
                resists.append((resist,r))
    
        if state['RESISTS'] != resists:
            changed['RESISTS']=state['RESISTS']=resists
            
        if send:
            if len(changed):
                for o in self.observers: o.callRemote('updateChanged', changed)

            
        return changed

        
    def refresh(self):
        state = self.state
        character = self.character
        mob = character.mob
        spawn = mob.spawn

        changed = self.refreshLite()
        
        if mob.skillLevels != state['SKILLS']:
            changed['SKILLS'] = state['SKILLS'] = mob.skillLevels.copy()
            
        skillReuse = dict((key,1) for key in mob.skillReuse.iterkeys())
        if skillReuse != state['SKILLREUSE']:
            changed['SKILLREUSE'] = state['SKILLREUSE'] = skillReuse
        
        items = dict((item.slot,item.itemInfo) for item in character.items)
        #could this be leaking?
        if state['ITEMS']!=items:
            state['ITEMS']=changed['ITEMS']=items
        
        if state['PCLASS']!=spawn.pclassInternal:
            state['PCLASS']=changed['PCLASS']=spawn.pclassInternal
        if state['SCLASS']!=spawn.sclassInternal:
            state['SCLASS']=changed['SCLASS']=spawn.sclassInternal
        if state['TCLASS']!=spawn.tclassInternal:
            state['TCLASS']=changed['TCLASS']=spawn.tclassInternal
        
        if state['PLEVEL']!=spawn.plevel:
            state['PLEVEL']=changed['PLEVEL']=spawn.plevel
        if state['SLEVEL']!=spawn.slevel:
            state['SLEVEL']=changed['SLEVEL']=spawn.slevel
        if state['TLEVEL']!=spawn.tlevel:
            state['TLEVEL']=changed['TLEVEL']=spawn.tlevel

        if state['DEAD'] != character.dead:
            state['DEAD']=changed['DEAD']=character.dead
            
        if state['ADVANCE']!=character.advancementPoints:
            state['ADVANCE']=changed['ADVANCE']=character.advancementPoints
            

        #current advancements
        cadvance = [(a.advancementProto.name,a.rank) for a in self.character.advancementsCache]
            
        if state['ADVANCEMENTS'] != cadvance:
            state['ADVANCEMENTS'] = changed['ADVANCEMENTS']=cadvance
            
        
        spells = {}
        for cspell in character.spells:
            if not cspell.spellInfo:
                cspell.spellInfo = CharSpellInfo(character,cspell)
            else:
                cspell.spellInfo.refresh()
            
            spells[cspell.slot]=cspell.spellInfo
        
        if state['SPELLS']!=spells:
            changed['SPELLS']=state['SPELLS']=spells
        
        if len(mob.processesIn):# or len(mob.processesOut):
            spelleffects = []
            from mud.world.spell import Spell
            processes = []
            processes.extend(mob.processesIn)
            #processes.extend(mob.processesOut)
            for p in processes:
                if isinstance(p,Spell):
                    if not p.spellProto.duration:
                        continue
    
                    if not p.spellEffectInfo:
                        p.spellEffectInfo = SpellEffectInfo(p)
                    else:
                        p.spellEffectInfo.TIME = float(p.spellProto.duration)/6.0 - float(p.time)/6.0
                        
                    if p.spellEffectInfo not in spelleffects:
                        spelleffects.append(p.spellEffectInfo)
                     
            if spelleffects != state['SPELLEFFECTS']:
                changed['SPELLEFFECTS']=state['SPELLEFFECTS']=spelleffects
        else:
            if len(state['SPELLEFFECTS']):
                changed['SPELLEFFECTS']=state['SPELLEFFECTS']=[]
                
            

        
        if state['PORTRAITPIC']!=character.portraitPic:
            changed['PORTRAITPIC']=state['PORTRAITPIC']=character.portraitPic
            

        #vaultitems
        vitems = [(v.id,v.name,v.stackCount) for v in self.character.vaultItems]
        if state['VAULTITEMS']!=vitems:
            changed['VAULTITEMS']=state['VAULTITEMS']=vitems
            
        if len(changed):
            for o in self.observers: o.callRemote('updateChanged', changed)

        character.player.cinfoDirty = False

class CharacterInfoGhost(pb.RemoteCache):
    
    def __init__(self):
        self.clientSettings = {}
        self.clientSettings['LINKMOUSETARGET'] = 1
        self.clientSettings['LINKTARGET'] = None
        self.clientSettings['DEFAULTTARGET'] = None
        self.clientSettings['PXPGAIN'] = 1
        self.clientSettings['SXPGAIN'] = 0
        self.clientSettings['TXPGAIN'] = 0
        self.wasDead = False
    
    def setCopyableState(self, state):
        global DIRTY,SKILLS_DIRTY
        DIRTY = True
        SKILLS_DIRTY.append(self)
        
        for k,v in state.iteritems():
            self.__dict__[k]=v
    
    def observe_updateChanged(self,changed):
        global DIRTY,SKILLS_DIRTY,ADVANCEMENTS_DIRTY
        DIRTY = True
        if changed.has_key('SKILLS') or changed.has_key('SKILLREUSE'):
            SKILLS_DIRTY.append(self)
        
        if changed.has_key('ADVANCE') or changed.has_key('ADVANCEMENTS') or changed.has_key('PLEVEL') or changed.has_key('SLEVEL') or changed.has_key('TLEVEL') or changed.has_key('TCLASS') or changed.has_key('SCLASS') or changed.has_key('PCLASS'):
            ADVANCEMENTS_DIRTY = True
        
        for k,v in changed.iteritems():
            setattr(self,k,v)

pb.setUnjellyableForClass(CharacterInfo, CharacterInfoGhost) 


class EffectProtoInfo(pb.Copyable,pb.RemoteCopy):
    def __init__(self,eproto = None):
        if eproto: #server side
            pass
            
pb.setUnjellyableForClass(EffectProtoInfo, EffectProtoInfo) 


class CharSpellInfo(pb.Cacheable):
    def __init__(self,character,charSpell):
        self.observers = []
        self.char = character
        self.charSpell = charSpell
        self.state = None
        
    def stoppedObserving(self, perspective, observer):
        #if observer in self.observers:
        self.observers.remove(observer)

    def getFullState(self):
        state = self.state = {}
        
        proto = self.charSpell.spellProto
                
        state['ID']=proto.id
        state['SLOT']=self.charSpell.slot
        state['RECASTTIMER']=0
        state['SPELLINFO']=SpellInfo(proto,self.charSpell.level)
        
            
        if self.char.mob.recastTimers.has_key(proto):
            state['RECASTTIMER']=self.char.mob.recastTimers[proto]
            
        
        return state
        
        
    def getStateToCacheAndObserveFor(self, perspective, observer):
        self.observers.append(observer)
        return self.getFullState()
        
    
    def fullRefresh(self):
        r = self.getFullState()
        for o in self.observers: o.callRemote('updateChanged', r)
        
        
    def refresh(self):
        
        state = self.state
        if state == None:
            return
        changed = {}
        proto = self.charSpell.spellProto
        
        slot=self.charSpell.slot
        if slot != state['SLOT']:
            state['SLOT']=changed['SLOT']=slot
            
        recast = 0
        if self.char.mob.recastTimers.has_key(proto):
            recast=self.char.mob.recastTimers[proto]
            
        if recast != state['RECASTTIMER']:
            state['RECASTTIMER']=changed['RECASTTIMER']=recast
        
        if not len(changed):
            return
        
        for o in self.observers: o.callRemote('updateChanged', changed)
        
        
class CharSpellInfoGhost(pb.RemoteCache):
    
    
    def setCopyableState(self, state):
        for k,v in state.iteritems():
            self.__dict__[k]=v
            
            
    def observe_updateChanged(self,changed):
        for k,v in changed.iteritems():
            setattr(self,k,v)

pb.setUnjellyableForClass(CharSpellInfo, CharSpellInfoGhost)     



#this is used for "Character spells" which need to be split out... so we canuse  this for vendor... yargh
class SpellInfo(pb.Cacheable):
    def __init__(self,proto,level=0):
        self.observers = []
        self.proto = proto
        self.level = level
        
    def stoppedObserving(self, perspective, observer):
        #if observer in self.observers:
        self.observers.remove(observer)

    def getFullState(self):
        state = self.state = {}
        
        state['ID'] = self.proto.id
        state['LEVEL'] = self.level #this is a character spell info if > 0
        
        return state
        
    def getStateToCacheAndObserveFor(self, perspective, observer):
        self.observers.append(observer)
        return self.getFullState()
        
    
    def fullRefresh(self):
        for o in self.observers: o.callRemote('updateChanged', self.getFullState())

            
class SpellInfoGhost(pb.RemoteCache):
    def __init__(self,spID = None):
        self.text = ""
        self.ID = spID
        if spID:
            self.LEVEL = 0
            self.generateItemText()
    
    def generateItemText(self):
        from mud.client.playermind import GetMoMClientDBConnection
        con = GetMoMClientDBConnection()
        self.BASENAME,self.SPELLBOOKPIC,self.DESC,self.TARGET,self.CASTTIME,self.RECASTTIME,self.DURATION,self.CASTRANGE,self.AOERANGE,self.MANACOST,self.SKILLNAME,self.SPELLTYPE = con.execute('SELECT name,spellbook_pic,desc,target,cast_time,recast_time,duration,cast_range,aoe_range,mana_cost,skillname,spell_type FROM spell_proto WHERE id = %i LIMIT 1;'%self.ID).fetchone()
        self.CLASSES = tuple((classname,level) for classname,level in con.execute('SELECT classname,level FROM spell_class WHERE spell_proto_id = %i;'%self.ID))
        self.COMPONENTS = []
        for protoID,count in con.execute('SELECT item_proto_id,count FROM spell_component WHERE spell_proto_id = %i;'%self.ID):
            self.COMPONENTS.append((con.execute('SELECT name FROM item_proto WHERE id = %i LIMIT 1;'%protoID).fetchone()[0],count))
        negate = negatemax = 0
        for neg,negMax in con.execute('SELECT negate,negate_max_level FROM effect_proto WHERE id in (SELECT effect_proto_id FROM effect_proto_spell_proto WHERE spell_proto_id = %i);'%self.ID):
            if neg > negate:
                negate = neg
            if negMax > negatemax:
                negatemax = negMax
        self.NEGATE = negate
        self.NEGATEMAXLEVEL = negatemax
        
        text = []
        
        if self.LEVEL:
            self.NAME = ' '.join([self.BASENAME,ROMAN[self.LEVEL-1]])
            text.append(r'\cp\c3Casting Level: \c0%s\n'%ROMAN[self.LEVEL-1])
        
        # Skill
        if self.SKILLNAME:
            text.append(r'\c3Skill: \c0%s '%self.SKILLNAME)
        
        # Target
        if self.SPELLTYPE&RPG_SPELL_HARMFUL:
            text.append(r'\c3Target: \c1%s '%RPG_TARGET_TEXT[self.TARGET])
        else:
            text.append(r'\c3Target: \c2%s '%RPG_TARGET_TEXT[self.TARGET])
        
        # Range
        if self.TARGET != RPG_TARGET_SELF:
            text.append(r'\c3Range: \c0%im '%self.CASTRANGE)
        
        # AOE Range
        if self.AOERANGE:
            text.append(r'\c3AoE Range: \c0%im '%self.AOERANGE)
        
        # Duration
        if not self.DURATION:
            text.append(r'\c3Duration: \c0Instant ')
        else:
            d = self.DURATION/6
            if d > 60:
                m,s = divmod(d,60)
                text.append(r'\c3Duration: \c0%im %is '%(m,s))
            else:
                text.append(r'\c3Duration: \c0%is '%d)
        
        # Casting Time
        if not self.CASTTIME:
            text.append(r'\c3Cast Time: \c0Instant ')
        else:
            d = self.CASTTIME/6
            if d > 60:
                m,s = divmod(d,60)
                text.append(r'\c3Cast Time: \c0%im %is '%(m,s))
            else:
                text.append(r'\c3Cast Time: \c0%is '%d)
        
        # Mana Cost
        text.append(r'\c3Mana: \c0%i '%self.MANACOST)
        
        # Negate
        if self.NEGATE and self.NEGATEMAXLEVEL:
            text.append(r'\n\c3Negate: \c0%i \c3of max level \c0%i \n'%(self.NEGATE,self.NEGATEMAXLEVEL))
        
        # Classes
        classtext = ' '.join(r'\c0%s\c3(\c0%i\c3)'%(cl,level) for cl,level in self.CLASSES)
        if classtext:
            text.append(r'\c3Classes: %s '%classtext)
        
        # Components
        comptext = ' '.join(r'\c0%s\c3(\c0%i\c3)'%(c,count) for c,count in self.COMPONENTS)
        if comptext:
            text.append(r'\c3Components: %s '%comptext)
        
        desctext = self.DESC
        if desctext:
            if len(text):
                text.append(r'\n\n%s'%desctext)
            else:
                text.append(desctext)
        
        self.text = ''.join(text)
    
    
    def setCopyableState(self, state):
        for k,v in state.iteritems():
            self.__dict__[k]=v
        
        self.generateItemText()
    
    
    def observe_updateChanged(self,changed):
        for k,v in changed.iteritems():
            setattr(self,k,v)
        
        if self.LEVEL:
            self.NAME = ' '.join([self.BASENAME,ROMAN[self.LEVEL-1]])


pb.setUnjellyableForClass(SpellInfo, SpellInfoGhost)     


class AllianceInfo(pb.Cacheable):
    def __init__(self,alliance):
        self.alliance = alliance
        #each member of the alliance -> [cnames,]
        self.cnames = {}
        #each member of the alliance -> [chealthpercentages,]
        self.chealth = {}

        self.observers = []
        
        self.state = None
        
        
        #perspective -> 
        #self.observerLookup = {}
        
    def getStateDict(self,state):
        from mud.world.alliance import Alliance
        state['PNAMES']=[]
        state['NAMES']={}
        state['HEALTHS']={}
        state['MOBIDS']={}
        alliance = self.alliance

        a = None
        try:
            a = Alliance.masterAllianceInfo[alliance.remoteLeaderName]
        except KeyError:
            pass
        if a:
            remote = dict((x,(pname,cname)) for x,(pname,cname) in enumerate(a))
                
            local = {}
            
            for m in alliance.members:
                if not m.party:
                    continue #when does this happen?
                c = m.party.members[0]
                if c.mob:
                    h = round(float(c.mob.health)/float(c.mob.maxHealth),1)
                    local[m.name]=(c.name,h,c.mob.id)
                else:
                    local[m.name]=(c.name,1.0,-1)
                
            for x in xrange(0,len(remote)):
                pname,cname = remote[x]
                state['PNAMES'].append(pname)
                state['NAMES'][x]=[]
                state['HEALTHS'][x]=[]
                state['MOBIDS'][x] = []
                if pname in local:
                    cname,health,id = local[pname]
                    state['NAMES'][x].append(cname)
                    state['HEALTHS'][x].append(health)
                    state['MOBIDS'][x].append(id)
                else:
                    state['NAMES'][x].append(cname)
                    state['HEALTHS'][x].append(1.0)
                    state['MOBIDS'][x].append(-1)
        else:
            x = 0
            if alliance and alliance.members:
                for m in alliance.members:
                    state['PNAMES'].append(m.name)
                    state['NAMES'][x]=[]
                    state['HEALTHS'][x]=[]
                    state['MOBIDS'][x] = []
                    if m.party:
                        for c in m.party.members:
                            if not c.mob:    # zoning
                                break
                            state['NAMES'][x].append(c.name)
                            h = round(float(c.mob.health)/float(c.mob.maxHealth),1)
                            state['HEALTHS'][x].append(h)
                            state['MOBIDS'][x].append(c.mob.id)
                        x+=1

        
        
        
    def getStateToCacheAndObserveFor(self, perspective, observer):
        self.observers.append(observer)
        
        state = {}
        
        if not self.state:
            self.state = state
        
        alliance = self.alliance
        
        state['LEADER']=alliance.remoteLeaderName #leader never changes
        
        self.getStateDict(state)
        
        return state

        

    def stoppedObserving(self, perspective, observer):
        #if observer in self.observers:
        self.observers.remove(observer)
        
        
    def refresh(self):
        changed = {}
        state = {}

        self.getStateDict(state)
        
        if self.state['PNAMES'] != state['PNAMES']:
            changed['PNAMES']=self.state['PNAMES']=state['PNAMES']

        if self.state['NAMES'] != state['NAMES']:
            changed['NAMES']=self.state['NAMES']=state['NAMES']
            
        if self.state['HEALTHS'] != state['HEALTHS']:
            changed['HEALTHS']=self.state['HEALTHS']=state['HEALTHS']

        if self.state['MOBIDS'] != state['MOBIDS']:
            changed['MOBIDS']=self.state['MOBIDS']=state['MOBIDS']
            
        if len(changed):
            for o in self.observers: o.callRemote('updateChanged', changed)

      
class AllianceInfoGhost(pb.RemoteCache):
    
    def setCopyableState(self, state):
        for k,v in state.iteritems():
            self.__dict__[k]=v
            
    def observe_updateChanged(self,changed):
        for k,v in changed.iteritems():
            setattr(self,k,v)
            
        #breakin' the law, breakin' the law
        from mud.client.gui.allianceWnd import ALLIANCEWND
        from mud.client.gui.leaderWnd import LEADERWND
        ALLIANCEWND.setAllianceInfo(self)
        LEADERWND.setAllianceInfo(self)


pb.setUnjellyableForClass(AllianceInfo, AllianceInfoGhost)     


class TradeInfo(pb.Cacheable):
    def __init__(self,trade):
        self.trade = trade
        self.observers = []
        self.state = None
        
    def stoppedObserving(self, perspective, observer):
        #if observer in self.observers:
        self.observers.remove(observer)

        
    def getStateToCacheAndObserveFor(self, perspective, observer):
        self.observers.append(observer)
        
        state = {}
        
        trade = self.trade
        
        if not self.state:
            self.state = state
            
        state['P0NAME']=trade.p0.name
        state['P1NAME']=trade.p1.name

        state['C0NAME']=trade.p0.charName
        state['C1NAME']=trade.p1.charName


        state['P0ACCEPTED']=trade.p0Accepted
        state['P1ACCEPTED']=trade.p1Accepted
        
        state['P0TIN'] = trade.p0Tin
        state['P1TIN'] = trade.p1Tin
        
        state['P0ITEMS'] = dict((slot,item.itemInfo) for slot,item in trade.p0Items.iteritems())
        state['P1ITEMS'] = dict((slot,item.itemInfo) for slot,item in trade.p1Items.iteritems())
        
        return state


    def refresh(self):
        changed = {}
        
        trade = self.trade
        
        p0Items = dict((slot,item.itemInfo) for slot,item in trade.p0Items.iteritems())
        p1Items = dict((slot,item.itemInfo) for slot,item in trade.p1Items.iteritems())
        
        if self.state['P0ACCEPTED'] != trade.p0Accepted:
            self.state['P0ACCEPTED']=changed['P0ACCEPTED']=trade.p0Accepted
        if self.state['P1ACCEPTED'] != trade.p1Accepted:
            self.state['P1ACCEPTED']=changed['P1ACCEPTED']=trade.p1Accepted

        if self.state['P0TIN'] != trade.p0Tin:
            self.state['P0TIN'] = changed['P0TIN'] = trade.p0Tin
        if self.state['P1TIN'] != trade.p1Tin:
            self.state['P1TIN'] = changed['P1TIN'] = trade.p1Tin

        if self.state['P0ITEMS'] != p0Items:
            self.state['P0ITEMS']=changed['P0ITEMS']=p0Items
        if self.state['P1ITEMS'] != p1Items:
            self.state['P1ITEMS']=changed['P1ITEMS']=p1Items

        if len(changed):
            for o in self.observers: o.callRemote('updateChanged', changed)
    
    
    def refreshDict(self,dict):
        for k,v in dict.iteritems():
            try:
                if self.state[k] != v:
                    self.state[k] = v
                else:
                    del dict[k]
            except:
                del dict[k]
                traceback.print_exc()
        
        if len(dict):
            for o in self.observers: o.callRemote('updateChanged', dict)

class TradeInfoGhost(pb.RemoteCache):
    
    def setCopyableState(self, state):
        for k,v in state.iteritems():
            self.__dict__[k]=v
            
    def observe_updateChanged(self,changed):
        for k,v in changed.iteritems():
            setattr(self,k,v)
            
        from mud.client.gui.tradeWnd import TRADEWND
        TRADEWND.setFromTradeInfo(self)

pb.setUnjellyableForClass(TradeInfo, TradeInfoGhost)     
        

