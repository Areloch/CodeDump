
import math
from core import *
from mud.world.shared.vocals import *
from faction import KOS



class Tactical:
    def __init__(self,mob):
        self.mob = mob
        
    def doMob(self,otherMob):
        mob = self.mob

        #if otherMob.aggro.has_key(mob):
            #new enemy! he hates me so I hate him, just as much!
        #    mob.aggro[otherMob]=otherMob.aggro[mob]
        #    continue

        #todo factions
        
        if otherMob.aggroOff:
            return
        

            
        #already an enemy?
        if not mob.aggro.has_key(otherMob):
            
            range = GetRange(mob,otherMob)
            aggroRange = mob.aggroRange*mob.zone.zone.aggroMod
            
            vis = otherMob.visibility + mob.seeInvisible
            if vis < 0:
                vis = 0
            if vis > 1:
                vis = 1
            
            aggroRange*=vis
            
            
            if range < aggroRange:
                #new enemy!
                if otherMob.sneak:
                    #sneaking
                    sn = otherMob.skillLevels.get("Sneak",0)
                    if sn+100 < mob.plevel*10 or mob.plevel>=90:
                        otherMob.cancelStatProcess("sneak","$tgt has been noticed!\\n")
                    else:
                        return
                
                mob.addAggro(otherMob,10)
                    
        else:
            if otherMob.sneak:
                otherMob.cancelStatProcess("sneak","$tgt has been noticed!\\n")
            
        
    def tick(self):
        mob = self.mob
        if mob.player or mob.detached:
            return 
                
        if not mob.zone.world.aggroOn:
            return
        
        zone = mob.zone
        simAvatar = zone.simAvatar
        
        doNewAggro = not mob.target
                
        #build up the tactical map
        #canKite = mob.simObject.canKite
        for id in mob.simObject.canSee:
            
            try:
                otherMob = zone.mobLookup[simAvatar.simLookup[id]]
            except KeyError:
                continue #not spawned yet, though in cansee
            
            #try:
            #    if otherMob.simObject.canKite != canKite:
            #        continue
            #except:
            #    continue
                
            if not otherMob.player and otherMob.detached:
                #detached but still in cansee
                continue
                
            if mob == otherMob:
                continue
            
            if mob.plevel < 50:
                if mob.plevel < otherMob.plevel-20:
                    continue
            
            if not mob.aggroRange or not otherMob.aggroRange:
                continue
            
            if otherMob.character and otherMob.character.invulnerable:
                continue
                
            #player mobs don't initiate
            if mob.master and mob.master.player:
                if not mob.aggro.get(otherMob):
                    continue

                        
            if mob.battle or otherMob.battle:
                continue
            
            initial = False
            if otherMob.player and not mob.aggro.get(otherMob):
                initial = True
            
            kos = IsKOS(mob,otherMob)
                
            if not otherMob.player and otherMob.assists:
                if mob.realm==otherMob.realm and not kos:
                    if not mob.master and not otherMob.master:
                        for m in mob.aggro.iterkeys(): 
                            if not otherMob.aggro.get(m,0):
                                if GetRange(mob,otherMob)<=(otherMob.spawn.aggroRange*m.zone.zone.aggroMod)*.65:
                                    otherMob.addAggro(m,5)
            
            # mob assisting player of same realm
            if not kos:
                if otherMob.player and not mob.master and mob.assists and mob.realm == otherMob.realm:
                    for c in otherMob.player.party.members:
                        otherMob = c.mob
                        for m in otherMob.aggro.iterkeys(): 
                            if not m.player or m.detached:
                                continue
                            if not mob.aggro.get(m,0):
                                #if m.simObject.canKite == canKite:
                                if m.realm != mob.realm and AllowHarmful(m,otherMob) and m.simObject.id in mob.simObject.canSee and GetRange(m,mob) <= mob.spawn.aggroRange*m.zone.zone.aggroMod:
                                    mob.addAggro(m,5)
                continue
            
            if doNewAggro:
                if otherMob.player:
                    #we have to run thru all the players mobs
                    for c in otherMob.player.party.members:
                        if c.mob.detached:
                            continue
                        self.doMob(c.mob)
                else:
                    self.doMob(otherMob)
                
                if initial and mob.aggro.get(otherMob):
                    a = 10
                    for member in otherMob.player.party.members:
                        if not member.mob.detached and not member.mob.sneak:
                            if member.mob.pet:
                                mob.addAggro(member.mob.pet,a)
                            else:
                                mob.addAggro(member.mob,a)
                            a-=1

                    
        if len(mob.aggro):
            mostHated = None
            best = -999999
            
            thate = 0
            if mob.target:
                range = GetRange(mob,mob.target)
                if range <= mob.followRange or mob.battle:
                    thate = mob.aggro.get(mob.target,0)
                    if thate:
                        mostHated = mob.target
                
            for m,hate in mob.aggro.iteritems():
                if m.feignDeath:
                    continue
                
                if hate <= thate:
                    continue
                
                if hate >= best: #XXX: do a hate falloff on distance
                    range = GetRange(mob,m)
                
                    if range <= mob.followRange or mob.battle:
                        
                        best = hate
                        mostHated = m
            
           
            if mostHated:
                
                if mostHated != mob.target:
                    #alert and vocalization
                    snd = mob.spawn.getSound("sndAlert")
                    if snd:
                        mob.playSound(snd)
                        
                    else:
                        mob.vocalize(VOX_MADSCREAM)
                        
                    zone.setTarget(mob,mostHated)
            else:
                mob.aggro={}
                if mob.target:
                    zone.setTarget(mob,None)
                    
        else:
            zone.setTarget(mob,None)
                
                
                
                
                
                
