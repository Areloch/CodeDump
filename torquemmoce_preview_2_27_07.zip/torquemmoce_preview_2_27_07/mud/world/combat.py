

from defines import *
from core import *
import math
from random import randint
from process import Process
from damage import Damage
from spell import SpawnSpell

class UnarmedSoundProfile:
    def __init__(self):
        self.sndAttack1 = "character/Boxing_FemalePunchBreath06.ogg"
        self.sndAttack2 = "character/Boxing_FemalePunchBreath07.ogg"
        self.sndAttack3 = "character/Boxing_FemalePunchBreath09.ogg"
        self.sndAttack4 = "character/Boxing_MalePunchGrunt01.ogg"
        self.sndAttack5 = "character/Boxing_MalePunchGrunt02.ogg"
        self.sndAttack6 = "character/Boxing_MalePunchGrunt05.ogg"
        self.sndAttack7 = "character/Boxing_MalePunchGrunt03.ogg"
        self.sndAttack8 = "character/Boxing_MalePunchBreath02.ogg"
        self.numSndAttack = 8
        
        self.sndHit1 = "character/Punch_Boxing_BodyHit01.ogg"
        self.sndHit2 = "character/Punch_Boxing_BodyHit02.ogg"
        self.sndHit3 = "character/Punch_Boxing_BodyHit03.ogg"
        self.sndHit4 = "character/Punch_Boxing_BodyHit04.ogg"

        self.sndHit5 = "character/Punch_Boxing_FaceHit1.ogg"
        self.sndHit6 = "character/Punch_Boxing_FaceHit2.ogg"
        self.sndHit7 = "character/Punch_Boxing_FaceHit3.ogg"
        self.sndHit8 = "character/Punch_Boxing_FaceHit4.ogg"
        
        self.numSndHit = 8
        
    def getSound(self,snd):
        if snd == "sndAttack":
            return getattr(self,"sndAttack%i"%randint(1,8))
        return getattr(self,"sndHit%i"%randint(1,8))
        
        
UNARMEDSOUNDPROFILE = UnarmedSoundProfile()        

def SuccessfulAttack(mob, offhand = False):
    #a player successfully attacked so we need to check a few skills for raise
    char = mob.character
    skill = "Fists"
    wpn = None
    if offhand:
        if mob.worn.has_key(RPG_SLOT_SECONDARY):
            wpn = mob.worn[RPG_SLOT_SECONDARY]
    else:
        if mob.worn.has_key(RPG_SLOT_PRIMARY):
            wpn = mob.worn[RPG_SLOT_PRIMARY]
            
    if wpn and wpn.skill:
        skill = wpn.skill
        
    char.checkSkillRaise(skill,1,8)
    
    char.checkSkillRaise("Tactics Offense",1,8)
    
    if offhand:
        pweapon = mob.worn.get(RPG_SLOT_PRIMARY)
        sweapon = mob.worn.get(RPG_SLOT_SECONDARY)
        if pweapon and sweapon:
            if "2H" in pweapon.skill or "2H" in sweapon.skill and mob.skillLevels.get("Power Wield"):
                char.checkSkillRaise("Power Wield",1,8)
            else:
                char.checkSkillRaise("Dual Wield",1,8)
        else:
            char.checkSkillRaise("Dual Wield",1,8)
                
    
def SuccessfulDefense(mob):
    char = mob.character
    char.checkSkillRaise("Tactics Defense",1,5)

class CombatProcess(Process):
    def __init__(self,src,dst):
        Process.__init__(self,src,dst)

        self.type = "Combat"
        
        self.dmgType = 0
        
        self.attacker = src
        self.defender = dst
        
        src.primaryAttackTimer = 0
        src.secondaryAttackTimer = 0
        
        
        
        #if not dst.player:
        #    if not dst.aggro.has_key(src):
        #        dst.addAggro(src,10)
                

    def getPrimaryDamage(self):
        
        dmg = self.attacker.level*3+10
        ratio = float(self.damage)/100.0
        if "2H" in self.skill:
            ratio+=.66
        dmg+=self.attacker.pre/3
        return dmg*ratio+dmg*ratio


    def getSecondaryDamage(self):        
        dmg = self.attacker.level*2+10
        ratio = float(self.damage)/100.0
        if "2H" in self.skill:
            ratio+=.66
            
        dmg+=self.attacker.pre/5
        
        return dmg*ratio+dmg*ratio
            
        
    def getPrimaryAttackRate(self):
        
        mob = self.attacker
        base = float(mob.primaryAttackRate)
        
        wpnRate = 16.0
            
        
        
        pweapon = mob.worn.get(RPG_SLOT_PRIMARY)
        sweapon = mob.worn.get(RPG_SLOT_SECONDARY)

        if (not pweapon or not pweapon.skill or "Fists" == pweapon.skill) and mob.player:
            monkfists = mob.advancements.get("monkFists",0.0)
            if monkfists:
                if monkfists == 1:
                    wpnRate=14
                elif monkfists == 2:
                    wpnRate=13
                elif monkfists == 3:
                    wpnRate=12
                else:
                    wpnRate = 10

        
        slow = 0
        if pweapon and sweapon:
            #we are dual/power wielding
            if '2H' in pweapon.skill:
                slow+=.15
            if '2H' in sweapon.skill:
                slow+=.15
                
                
        if slow == .3:
            #we are powerwielding
            improve = mob.advancements.get("powerWield",0.0)
            if improve:
                slow*=(1.0-improve)
                
        
        if pweapon:
            wpnRate = float(pweapon.wpnRate)
                
        base+=wpnRate
        
        e,effectHaste = mob.effectHaste
        haste = mob.itemHaste+mob.innateHaste+float(effectHaste)
        haste -= mob.slow
        haste -= slow
        if not mob.stamina:
            haste-=.2
        
        if haste<0:
            #we are slowed!
            base += math.floor(base*-haste)
        else:
            base -= math.floor(base*haste)

        base+=4
        
        if base < 8:
            base = 8
            
        return math.ceil(base)
        
        
        
    def getSecondaryAttackRate(self):
        m = self.attacker
        base = float(m.secondaryAttackRate)

        wpnRate = 20.0
        

        
        mob = self.attacker
        pweapon = mob.worn.get(RPG_SLOT_PRIMARY)
        sweapon = mob.worn.get(RPG_SLOT_SECONDARY)
        
        if (not sweapon or not sweapon.skill or "Fists" == sweapon.skill) and m.player:
            monkfists = mob.advancements.get("monkFists",0.0)
            if monkfists:
                if monkfists == 1:
                    wpnRate=14
                elif monkfists == 2:
                    wpnRate=13
                elif monkfists == 3:
                    wpnRate=12
                else:
                    wpnRate = 10

        
        slow = 0
        if pweapon and sweapon:
            #we are dual/power wielding
            if '2H' in pweapon.skill:
                slow+=.15
            if '2H' in sweapon.skill:
                slow+=.15
                
        
        if sweapon:
            wpnRate = float(sweapon.wpnRate)
                
        base+=wpnRate
        e,effectHaste = mob.effectHaste
        haste = mob.itemHaste+mob.innateHaste+float(effectHaste)
        haste -= mob.slow
        haste -= slow
        if not mob.stamina:
            haste-=.2

        if haste<0:
            #we are slowed!
            base += math.floor(base*-haste)
        else:
            base -= math.floor(base*haste)

        base+=6
        
        if base < 11:
            base = 11
        
        return math.ceil(base)
        
    def clearSrc(self):
        self.cancel()
        self.src = None
        
        
    def clearDst(self):
        self.cancel()
        self.dst = None
        
    def begin(self):
        Process.begin(self)
        
    def end(self):
        Process.end(self)
        
                
    def tick(self):
        src = self.src
        dst = self.dst

        while src.target == dst and dst.health:
            
            if not src.player and dst.feignDeath:
                src.zone.setTarget(src,None)
                break
                
            
            inhibit = False
            
            attacker = self.attacker
            defender = self.defender
            
            player = attacker.player
            
            if player and attacker.casting:
                if attacker.casting.spellProto.skillname != "Singing" and not attacker.combatCasting:
                    yield True
                    continue

            
            inhibitPrimary = False
            inhibitSecondary = False
            if src.primaryAttackTimer<=3 or src.secondaryAttackTimer<=3:
                if defender.simObject.id not in attacker.simObject.canSee:
                    attacker.combatInhibited+=3
                    if player and not player.msgCombatCantSee: #this should be on client
                        player.msgCombatCantSee = 20 #ten seconds
                        player.sendGameText(RPG_MSG_GAME_DENIED,"%s's adversary is obstructed!\\n"%attacker.character.name)
                    inhibit = True
                
                crange = GetRangeMin(attacker,defender)
                wpnRange = 0
                # take highest weapon range
                pweapon = attacker.worn.get(RPG_SLOT_PRIMARY)
                sweapon = attacker.worn.get(RPG_SLOT_SECONDARY)
                if pweapon and pweapon.wpnRange > wpnRange:
                    wpnRange = pweapon.wpnRange / 5.0
                if sweapon:
                    if sweapon.wpnRange > wpnRange:
                        wpnRange = sweapon.wpnRange / 5.0
                        if pweapon and crange > pweapon.wpnRange / 5.0:
                            inhibitPrimary = True
                    elif crange > sweapon.wpnRange / 5.0:
                        inhibitSecondary = True
                if crange > wpnRange:
                    attacker.combatInhibited+=3
                    if player and not player.msgCombatNotCloseEnough: #this should be on client
                        player.msgCombatNotCloseEnough = 20 #ten seconds
                        player.sendGameText(RPG_MSG_GAME_DENIED,"%s's adversary is out of melee range!\\n"%attacker.character.name)
                    inhibit = True

                        
            if src.sleep <= 0 and src.stun <= 0 and not src.isFeared and not inhibit:
                src.primaryAttackTimer -= 3
                if src.primaryAttackTimer <= 0:
                    src.primaryAttackTimer = self.getPrimaryAttackRate()
                    if not inhibitPrimary:
                        attacks = 1
                        da = src.skillLevels.get('Double Attack',0)
                        if da:
                            da = 1000-da
                            da/=40
                        
                            da+=dst.plevel/10
                        
                            if da<10:
                                da = 10
                            if not randint(0,int(da)):
                                attacks=2
                                if src.character:
                                    src.character.checkSkillRaise("Double Attack")

                        ta = src.skillLevels.get('Triple Attack',0)
                        if ta:
                            ta = 1000-ta
                            ta/=15
                        
                            ta+=dst.plevel/10
                        
                            if ta<10:
                                ta = 10
                            if not randint(0,int(ta)):
                                attacks=3
                                if src.character:
                                    src.character.checkSkillRaise("Triple Attack")

                        if attacks == 2 and src.player:
                            src.player.sendGameText(RPG_MSG_GAME_YELLOW,"%s double attacks!\\n"%src.name)
                        if attacks == 3 and src.player:
                            src.player.sendGameText(RPG_MSG_GAME_YELLOW,"%s triple attacks!\\n"%src.name)
                        
                        self.skill = "Fists"
                        self.dmgType = RPG_DMG_PUMMEL
                        self.weapon = None
                        if not src.player:
                            self.damage = src.plevel/2
                            #if src.difficultyMod > 1.0:
                            #    self.damage += int(self.damage*(src.difficultyMod/3.0))
                        else:
                            self.damage = 4
                        if src.worn.has_key(RPG_SLOT_PRIMARY):
                            self.weapon = src.worn[RPG_SLOT_PRIMARY]
                            self.dmgType = self.weapon.dmgType
                            self.damage = int(self.weapon.wpnDamage*15)
                                                        
                            if self.weapon.skill:
                                self.skill = self.weapon.skill
                            
                        if self.skill == "Fists" and src.player:
                            monkfists = attacker.advancements.get("monkFists",0.0)
                            if monkfists:
                                if monkfists == 1:
                                    self.damage=15*15
                                elif monkfists == 2:
                                    self.damage=20*15
                                elif monkfists == 3:
                                    self.damage=30*15
                                else:
                                    self.damage = 40*15

                            
                        self.damage += int(src.skillLevels[self.skill]*1.5) #up to 1500
                    
                        for a in xrange(0,attacks):
                            dmg = self.doAttack(self.getPrimaryDamage(),False)
                            if dmg:
                                if src.player:
                                    SuccessfulAttack(src)
                            
                if src.skillLevels.has_key("Dual Wield") or src.skillLevels.has_key("Power Wield"):
                    skip = False
                    
                    w = src.worn.get(RPG_SLOT_PRIMARY)
                    s = src.worn.get(RPG_SLOT_SECONDARY)
                    
                    twohanded = 0
                    if w and "2H" in w.skill:
                        twohanded+=1
                    if s and "2H" in s.skill:
                        twohanded+=1
                        
                    if twohanded and (not w or not s or not src.skillLevels.get("Power Wield")):
                        skip = True #powerwield is weapon only    

                            
                    if src.secondaryAttackRate > 0 and not skip:
                        src.secondaryAttackTimer-=3
                        if src.secondaryAttackTimer <=0:
                            if not inhibitSecondary:
                            
                                src.secondaryAttackTimer = self.getSecondaryAttackRate()
                                self.skill = "Fists"
                                self.dmgType = RPG_DMG_PUMMEL
                                self.weapon = None
                                if not src.player:
                                    self.damage = src.plevel/2
                                    #if src.difficultyMod > 1.0:
                                        #self.damage += int(self.damage*(src.difficultyMod/3.0))

                                else:
                                    self.damage = 4
                                
                                if src.worn.has_key(RPG_SLOT_SECONDARY):
                                    self.weapon = src.worn[RPG_SLOT_SECONDARY]
                                    self.dmgType = self.weapon.dmgType
                                    self.damage = int(self.weapon.wpnDamage*15)
                                    if self.weapon.skill:
                                        self.skill = self.weapon.skill
                                    
                                if self.skill == "Fists" and src.player:
                                    monkfists = attacker.advancements.get("monkFists",0.0)
                                    if monkfists:
                                        if monkfists == 1:
                                            self.damage=15*10
                                        elif monkfists == 2:
                                            self.damage=20*10
                                        elif monkfists == 3:
                                            self.damage=30*10
                                        else:
                                            self.damage = 40*10

    
                                self.damage += int(src.skillLevels[self.skill]) #up to 1000
    
                                dmg = self.doAttack(self.getSecondaryDamage(),True)
                                if dmg:
                                    if src.player:
                                        SuccessfulAttack(src,True)
                            
                        
            yield True                
            
        
                    
    def calcDamageActual(self, MAXDMG):
    
        #This function takes the MAXDMG (adjusted) and returns a random damage
        
        attacker = self.attacker
        defender = self.defender
      
        spread = GetLevelSpread(attacker, defender)
      
        #a curve of sorts... average the damage out into the middle range
        R = randint(0,99)
        
        if self.wpnAdvanceMod:
            MAXDMG+=MAXDMG*self.wpnAdvanceMod
                  
        #Middle 33%
        d = MAXDMG / 3.0
      
        additive = MAXDMG / 3.0
      
        #upper 33%
        #if R >= 75:
        #    additive = (MAXDMG / 3.0) * 2.0
      
          
        #lower 33%
        if R <= 10:  
            additive = 0;
          
        if d < 1.0:
            d = 1.0;
      
        
        R = math.ceil(d/spread)
        if not R:
            R = 1
    
        damage = randint(0,R-1) + 1
      
        damage = damage + additive
      
        if damage > MAXDMG:
            damage = MAXDMG
            
        if not attacker.player:
            if attacker.plevel < 30:
                damage = int(math.ceil(damage*.65))
                if damage < attacker.plevel:
                    damage = attacker.plevel
            elif attacker.plevel < 60:
                if damage < attacker.plevel*5:
                    damage = attacker.plevel*5
            elif attacker.plevel < 80:                
                if damage < attacker.plevel*10:
                    damage = attacker.plevel*10
            elif attacker.plevel < 90:                
                if damage < attacker.plevel*20:
                    damage = attacker.plevel*20
            else:                
                if damage < attacker.plevel*30:
                    damage = attacker.plevel*30
            
            if attacker.zone.zone.name == 'field':
                damage = int(math.ceil(damage*attacker.difficultyMod))
                
            #reduction for pets
            if attacker.master:
                damage*=.5
                if damage < 10:
                    damage = 10
                
      
        return int(damage)
    
    
    
    
    def calcDamageAdjustedMax(self,damage):
        attacker = self.attacker
        defender = self.defender
        
        if attacker.player:
            plevel = attacker.skillLevels[self.skill]/10
            if plevel < 1:
                plevel = 1
        else:
            plevel = attacker.plevel
    
    
        DFDLEVEL = defender.level
        ATTLEVEL = attacker.level
        DFDDEFENSE = defender.defense
        
        #Clamp DFDLEVEL to 100 for these calculations
        #Will we allow AI mobs to exceed 100?
        if DFDLEVEL > 100:
            DFDLEVEL = 100
            
        spread = defender.plevel - plevel
  
        if plevel < defender.plevel:
            spread = spread + ((defender.plevel - plevel) ** 2)
    
        LS = ((spread + 100.0) * 10.0) / 1000.0

        
        #LS = GetLevelSpread(attacker, defender)
        R=LS*.5
        
        ADJUSTEDMAX = damage / R
        
        
        
        #now figure in Damage  Absorption
      
        ADJUSTEDMAX = ADJUSTEDMAX - (DFDDEFENSE / 100) * (DFDLEVEL * 4 / 100)
        
        #damage mitigation for armor
        a = defender.armor/LS
        if a > defender.armor:
            a = defender.armor
        a*=(defender.plevel/100.0)
        a*=.5
        a = int(a)
        
        rand = randint(0,9)        
        if rand < 4:
            a = a/3
        elif rand <=7:
            a = a/2
            
        
        if a > ADJUSTEDMAX:
            a = ADJUSTEDMAX
            
        a = ADJUSTEDMAX-a
        
        if not a:
            a = 1
            
        if ADJUSTEDMAX/a < ADJUSTEDMAX/3:
            ADJUSTEDMAX/=3
        else:
            ADJUSTEDMAX/=a
            
            
        ADJUSTEDMAX*=1.3333
        
        s = 0
        d = 5.0-(plevel/20.0)
        if d < 2:
            d = 2
        s = (attacker.str/d)
            
        ADJUSTEDMAX+=s
        
        if ADJUSTEDMAX < plevel*3.5:
            ADJUSTEDMAX =  plevel*3.5
            
        ADJUSTEDMAX+=plevel*2
           
            
        if ADJUSTEDMAX > damage/2:
            ADJUSTEDMAX = damage/2
        

        if ADJUSTEDMAX < 6:
            ADJUSTEDMAX = 6
            
        if ADJUSTEDMAX > 6500:
            ADJUSTEDMAX = 6500

          
        return int(ADJUSTEDMAX)
    
    
    
        #1 - 99%
    def calcBaseHitPercentage(self,attoffense, defdefense):
    
        attacker = self.attacker
        defender = self.defender

        R = GetLevelSpread(attacker, defender)
        R*=.5
        
        # R = .01 to .99   at  MYLEVEL = 100 DFDLEVEL = 1 (best)
        # R= 1.0  at  MYLEVEL = 100 DFDLEVEL = 100
        # R = 1.0 to 100 at MYLEVEL = 1 DFDLEVEL = 100 (worst)
        
        d = defdefense * (R * R)
    
        if not d:
            d=1
        
        base = (attoffense * 60) / d
        
        if base > 99:
            base = 99;
        if base < 1:
            base = 1
               
        #at level 100 worst is 25%
        lc = attacker.plevel/4

        if base < lc:
            base = lc
        
        
            
        return base
    
    
    def doAttack(self,dmg,offhand = False):
        
        attacker = self.attacker
        defender = self.defender
        
        if attacker.player:
            stm = attacker.plevel*3
            if offhand:
                stm=int(stm*.6)
            if stm < 1:
                stm = 1
            attacker.stamina-=stm
            if attacker.stamina<0:
                attacker.stamina = 0
                
            if attacker.character.invulnerable:
                attacker.character.invulnerable = 0
                attacker.player.sendGameText(RPG_MSG_GAME_YELLOW,r'%s is no longer protected from death.\n'%attacker.name)

        defender.regenTimer = 72    # suspend regen for two ticks (12 seconds)
        
        #block
        block = defender.skillLevels.get("Block",0)
        if block and defender.plevel+5>=attacker.plevel:
            if attacker.plevel > defender.plevel:
                block-=(attacker.plevel-defender.plevel)*2 #subtract out level difference*2
            block/=2
            if block < 1:
                block = 1
            x = defender.plevel*15
            if x < block*10:
                x = block*10
                
            if randint(0,x) < block:
                if attacker.player:
                    attacker.player.sendGameText(RPG_MSG_GAME_YELLOW,"%s blocks %s's attack!\\n"%(defender.name,attacker.name))
                if defender.player:
                    defender.player.sendGameText(RPG_MSG_GAME_YELLOW,"%s blocks %s's attack!\\n"%(defender.name,attacker.name))
                if defender.character and attacker.plevel>=defender.plevel-10:
                    defender.character.checkSkillRaise("Block",1,1)
                return 0
            
        #Dodge
        block = defender.skillLevels.get("Dodge",0)
        if block and defender.plevel+5>=attacker.plevel:
            if attacker.plevel > defender.plevel:
                block-=(attacker.plevel-defender.plevel)*2 #subtract out level difference*2
            block/=2
            if block < 1:
                block = 1
            x = defender.plevel*15
            if x < block*10:
                x = block*10

            if randint(0,x) < block:
                if attacker.player:
                    attacker.player.sendGameText(RPG_MSG_GAME_YELLOW,"%s dodges %s's attack!\\n"%(defender.name,attacker.name))
                if defender.player:
                    defender.player.sendGameText(RPG_MSG_GAME_YELLOW,"%s dodges %s's attack!\\n"%(defender.name,attacker.name))
                if defender.character and attacker.plevel>=defender.plevel-10:
                    defender.character.checkSkillRaise("Dodge",1,1)
                return 0
            
        #Shields
        block = defender.skillLevels.get("Shields",0)
        if block and defender.worn.has_key(RPG_SLOT_SHIELD):
            skip = False
            wpn = defender.worn.get(RPG_SLOT_PRIMARY,None)
            wpn2 = defender.worn.get(RPG_SLOT_SECONDARY,None)
            if wpn and "2H" in wpn.skill:
                skip = True
            elif wpn2 and "2H" in wpn2.skill:
                skip = True
                
            if not skip:                
                if block and defender.plevel+5>=attacker.plevel:
                    if attacker.plevel > defender.plevel:
                        block-=(attacker.plevel-defender.plevel)*2 #subtract out level difference*2
                    block/=2
                    if block < 1:
                        block = 1
                        
                    x = defender.plevel*15
                    if x < block*10:
                        x = block*10

                    if randint(0,x) < block:
                        sex = "itself"
                        if defender.spawn.sex == "Male":
                            sex = "himself"
                        elif defender.spawn.sex == "Female":
                            sex = "herself"

                        if attacker.player:
                            attacker.player.sendGameText(RPG_MSG_GAME_YELLOW,"%s shields %s from %s's attack!\\n"%(defender.name,sex,attacker.name))
                        if defender.player:
                            defender.player.sendGameText(RPG_MSG_GAME_YELLOW,"%s shields %s from %s's attack!\\n"%(defender.name,sex,attacker.name))
                        if defender.character and attacker.plevel>=defender.plevel-10:
                            defender.character.checkSkillRaise("Shields",1,1)
                            
                        defender.zone.simAvatar.mind.callRemote("playAnimation",defender.simObject.id,"shieldblock")
                        return 0
        
        
        
        slot = RPG_SLOT_PRIMARY
        wpn = None
        if offhand:
            slot = RPG_SLOT_SECONDARY
        if attacker.worn.has_key(slot):
            wpn = attacker.worn[slot]
        
        if attacker.visibility <= 0:        
            attacker.cancelInvisibility()
            

            
        if attacker.flying > 0:
            attacker.cancelFlying()
        if attacker.feignDeath > 0:
            attacker.cancelStatProcess("feignDeath","$tgt is obviously not dead!\\n")
        
        #msgCombatNotCloseEnough = 0
        #msgCombatCantSee = 0
        
        player = attacker.player
            
        attacker.combatInhibited = 0
    
        actualdmg = 0
        offense = attacker.offense
        defense = defender.defense
        try:
            offense+=attacker.skillLevels['Tactics Offense']*2
        except KeyError:
            pass

        try:
            defense+=defender.skillLevels['Tactics Defense']
        except KeyError:
            pass
            
        offense += attacker.skillLevels[self.skill]
        defense += defender.armor*(defender.plevel/15) 
        
        offense += offense*(attacker.difficultyMod/5.0)
        defense += defense*(defender.difficultyMod/5.0)
        
        self.wpnAdvanceMod = attacker.advancements.get(self.skill,0.0)
        if self.wpnAdvanceMod:
            offense += offense*self.wpnAdvanceMod
        
        
        #BANE WEAPONS
        bane = -1
        
        twohanded = False
        if wpn:
            if wpn.wpnRaceBane == defender.spawn.race:
                bane = wpn.wpnRaceBaneMod
                
            if wpn.wpnResistDebuffMod:
                defender.extraDamageInfo.resistDebuff = wpn.wpnResistDebuff
                defender.extraDamageInfo.resistDebuffMod = wpn.wpnResistDebuffMod
                
            if "2H" in wpn.skill:
                twohanded=True
                
        
        if bane != -1:  
            offense += offense*RPG_BANEWEAPON_OFFENSE[bane]
        
        if attacker.player and CoreSettings.DIFFICULTY != RPG_DIFFICULTY_HARDCORE:
            offense = int(offense*1.20)

        if attacker.player and CoreSettings.DIFFICULTY == RPG_DIFFICULTY_EASY:
            offense += int(offense*1.10)
        
        offense = int(offense)
        defense = int(defense)
        hitp = self.calcBaseHitPercentage(offense,defense)
        
        if attacker.player and CoreSettings.DIFFICULTY == RPG_DIFFICULTY_EASY:
            hitp+=int(hitp*.30)

        if attacker.player and CoreSettings.DIFFICULTY != RPG_DIFFICULTY_HARDCORE and defender.plevel < 5:
            hitp+=int(hitp)
        if not attacker.player and attacker.plevel < 5 and hitp > 4:
            hitp/=2
            

        actualdmg = 0
        if randint(0,100) < hitp: #includes 100 intentionally
            maxdmg = self.calcDamageAdjustedMax(dmg)
            actualdmg = self.calcDamageActual(maxdmg)
            
            actualdmg*=attacker.meleeDmgMod
            
            if bane != -1:  
                actualdmg+=actualdmg*RPG_BANEWEAPON_DAMAGE[bane]

            
            if actualdmg:
                if defender.player and CoreSettings.DIFFICULTY == RPG_DIFFICULTY_EASY:
                    actualdmg/=3
                    if actualdmg < 1:
                        actualdmg = 1
                elif defender.player and CoreSettings.DIFFICULTY != RPG_DIFFICULTY_HARDCORE and attacker.plevel < 5:
                    actualdmg = int(actualdmg*.5)
                    if actualdmg < 1:
                        actualdmg = 1
                        
                if not attacker.stamina:
                    actualdmg = int(actualdmg*.75)
                    if actualdmg < 1:
                        actualdmg = 1
                    
                
                #criticals
                critical = False
                if not offhand and attacker.stamina:
                    #criticals on primary only
                    try:
                        icrit = attacker.skillLevels["Inflict Critical"]
                    except:
                        icrit = 0
                        
                    if icrit:
                        c = 20.0/attacker.critical
                        c-=icrit/200
                        if c < 10:
                            c = 10
                        chance = int(math.ceil(c))
                        if not randint(0,chance): 
                            if attacker.character:
                                attacker.character.checkSkillRaise("Inflict Critical",8)
                                
                            c = randint(0,8)
                            if c == 8:
                                icrit = 4
                            elif c >= 5:
                                icrit = 3
                            else:
                                icrit = 2
                                
                            if not attacker.player:
                                actualdmg*=2.0
                            else:
                                actualdmg*=attacker.critical
                                actualdmg*=icrit
                                
                                
                            critical = True
                            
                            try:
                                gwnd = attacker.skillLevels["Grievous Wound"]
                            except:
                                gwnd = 0
                            
                            # able to land Grievous Wound on opponent of up to level + 5, skill depending
                            if attacker.plevel + int(math.floor(gwnd/45.0)) < defender.plevel:
                                gwnd = 0
                            
                            if not attacker.player:
                                gwnd /= 3
                            
                            # possibility for Grievous Wound ranges from 5% - 25% depending on skill level
                            if gwnd and not randint(0,int(20.0 - float(gwnd)/15.0)):
                                if attacker.character:
                                    attacker.character.checkSkillRaise("Grievous Wound",3)
                                # additional damage in the range +20% to +100%
                                actualdmg *= 1.1967 + 0.0033*gwnd
                                # Here, so dmgBonus doesn't get factored by critical
                                # As criticals only happen on primary, just take it
                                if attacker.dmgBonusPrimary:
                                    actualdmg += attacker.dmgBonusPrimary
                                Damage(defender,attacker,actualdmg,RPG_DMG_CRITICAL,"grievously wounds")
                            else:
                                # Here, so dmgBonus doesn't get factored by critical
                                # As criticals only happen on primary, just take it
                                if attacker.dmgBonusPrimary:
                                    actualdmg += attacker.dmgBonusPrimary
                                Damage(defender,attacker,actualdmg,RPG_DMG_CRITICAL)
                                
 
                if not critical:
                    

                        
                    #RIPOSTE possible on "normal" attacks
                    r = defender.skillLevels.get('Riposte',0)
                    if r:
                        r = 1000-r
                        r/=50
                        
                        r+=attacker.plevel/10
                        
                        if r<10:
                            r = 10
                        if not randint(0,int(r)):
                            if defender.character:
                                defender.character.checkSkillRaise("Riposte",10)
                            Damage(attacker,defender,actualdmg/2,RPG_DMG_PHYSICAL,"ripostes",False)
                        
                    #apply damage bonus after riposte
                    if attacker.dmgBonusPrimary and not offhand:
                        actualdmg+=attacker.dmgBonusPrimary
                    elif attacker.dmgBonusOffhand and offhand:
                        actualdmg+=attacker.dmgBonusOffhand
                    
                    Damage(defender,attacker,actualdmg,self.dmgType)
                    
        elif defender.player and defender.plevel-attacker.plevel<5:
            SuccessfulDefense(defender)
            

       
        sndProfile = UNARMEDSOUNDPROFILE
        if wpn and wpn.sndProfile:
            sndProfile = wpn.sndProfile
                
        #spawn attack sound
        snd = attacker.spawn.getSound("sndAttack")
        if snd:
            attacker.playSound(snd)

        #weapon attack sound
        if not actualdmg:
            snd = sndProfile.getSound("sndAttack")
            if snd:
                attacker.playSound(snd)
                
        else:
            snd = sndProfile.getSound("sndHit")
            if snd:
                attacker.playSound(snd)
   
        #procs
        
        #rings
        if self.skill == "Fists" and actualdmg:
            item = None
            if offhand:
                item = attacker.worn.get(RPG_SLOT_LFINGER,None)
            else:
                item = attacker.worn.get(RPG_SLOT_RFINGER,None)
                
            if item and item.skill == "Fists":
                for ispell in item.spells:
                    if ispell.trigger == RPG_ITEM_TRIGGER_MELEE:
                        if ispell.frequency <= 1 or not randint(0,ispell.frequency):
                            proto = ispell.spellProto
                        
                            tgt = defender
                            if proto.target == RPG_TARGET_SELF:
                                tgt = attacker
                            if proto.target == RPG_TARGET_PARTY:
                                tgt = attacker
                            if proto.target == RPG_TARGET_ALLIANCE:
                                tgt = attacker
                            if proto.target == RPG_TARGET_PET:
                                tgt = attacker.pet
                                
                            if tgt:
                                SpawnSpell(proto,attacker,tgt,tgt.simObject.position,1.0)

            
        
        damagedProcs = defender.damagedProcs
        if defender.itemSetSpells.has_key(RPG_ITEM_TRIGGER_DAMAGED):
            damagedProcs.extend(defender.itemSetSpells[RPG_ITEM_TRIGGER_DAMAGED])
        if actualdmg and len(damagedProcs):# and not randint(0,2):
            for item in damagedProcs:
                for ispell in item.spells:
                    if ispell.trigger == RPG_ITEM_TRIGGER_DAMAGED:
                        if ispell.frequency <= 1 or not randint(0,ispell.frequency):
                            proto = ispell.spellProto
                        
                            tgt = attacker
                            if proto.target == RPG_TARGET_SELF:
                                tgt = defender
                            if proto.target == RPG_TARGET_PARTY:
                                tgt = defender
                            if proto.target == RPG_TARGET_ALLIANCE:
                                tgt = defender
                            if proto.target == RPG_TARGET_PET:
                                tgt = defender.pet
                                
                            if tgt:
                                SpawnSpell(proto,defender,tgt,tgt.simObject.position,1.0)
                    
        
        
        if actualdmg and wpn:
            
            if attacker.player and wpn.repairMax and wpn.repair and not randint(0,20):
                wpn.repair-=1
                repairRatio = float(wpn.repair)/float(wpn.repairMax)
                if not repairRatio:
                    attacker.player.sendGameText(RPG_MSG_GAME_RED,"%s's %s has broken! (%i/%i)\\n"%(attacker.name,wpn.name,wpn.repair,wpn.repairMax))
                    attacker.playSound("sfx/Shatter_IceBlock1.ogg")
                elif repairRatio < .2:
                    attacker.player.sendGameText(RPG_MSG_GAME_YELLOW,"%s's %s is severely damaged! (%i/%i)\\n"%(attacker.name,wpn.name,wpn.repair,wpn.repairMax))
                    attacker.playSound("sfx/Menu_Horror24.ogg")
                    
                #refresh
                wpn.setCharacter(attacker.character,True)
                
            
            if attacker.itemSetSpells.has_key(RPG_ITEM_TRIGGER_MELEE):
                setProcs = attacker.itemSetSpells[RPG_ITEM_TRIGGER_MELEE]
            else:
                setProcs = []
            if len(wpn.spells) or len(wpn.procs) or len(setProcs):
                if wpn.penalty:
                    spells = [] # no proc when penalty
                else:
                    spells = wpn.spells[:]
                    
                spells.extend(wpn.procs.keys())
                spells.extend(setProcs)
                refreshProcs = False
                for ispell in spells:
                    if ispell.trigger == RPG_ITEM_TRIGGER_MELEE or ispell.trigger == RPG_ITEM_TRIGGER_POISON:
                        #first do a dex check
                        dex = int(30-attacker.dex/50)
                        if dex < 10:
                            dex = 10
                        if dex > ispell.frequency:
                            if dex < 1:
                                dex = 1
                            dex = randint(0,dex)
                        
                        if not dex or ispell.frequency <= 1 or not randint(0,ispell.frequency):
                            proto = ispell.spellProto
                        
                            tgt = defender
                            if proto.target == RPG_TARGET_SELF:
                                tgt = attacker
                            if proto.target == RPG_TARGET_PARTY:
                                tgt = attacker
                            if proto.target == RPG_TARGET_ALLIANCE:
                                tgt = attacker
                            if proto.target == RPG_TARGET_PET:
                                tgt = attacker.pet
                                
                            if tgt:
                                if ispell.trigger == RPG_ITEM_TRIGGER_POISON:
                                    wpn.procs[ispell][0] -= 1
                                    if wpn.procs[ispell][0] <= 0:
                                        del wpn.procs[ispell]
                                        if attacker.player:
                                            attacker.player.sendGameText(RPG_MSG_GAME_SPELLEND,"The %s on %s's %s has worn off.\\n"%(ispell.spellProto.name,attacker.name,wpn.name))
                                        # only need to update for description,
                                        # so only do if attacker is a player or a player pet
                                        if attacker.player or attacker.master.player:
                                            refreshProcs = True
                                            
                                        
                                    
                                SpawnSpell(proto,attacker,tgt,tgt.simObject.position,1.0)
                
                if refreshProcs:
                    wpn.itemInfo.refreshProcs()
        

        defender.extraDamageInfo.clear()    
            
        return actualdmg
            
    
    
        
    

