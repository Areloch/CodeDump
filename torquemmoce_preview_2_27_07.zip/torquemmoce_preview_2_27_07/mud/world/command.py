

from skill import UseSkill
from defines import *
from pet import *
from messages import GameMessage
import math
from core import *
from inn import Inn
from shared.vocals import *
import random
from character import Character
from loot import Loot
import time
import traceback



(SUB_MALE, SUB_FEMALE, SUB_OTHER) = range(3)
SUBSTITUTION_SUBJECTIVE = ["he" , "she", "it" ]
SUBSTITUTION_OBJECTIVE  = ["him", "her", "it" ]
SUBSTITUTION_POSSESSIVE = ["his", "her", "its"]

def contextSubstitution(mob,args):
    
    #
    # For each word in the argument list, check if it is a context
    # specific substitution character.  Note: the context specific
    # substitution variables are case-sensitive.  upper() or lower() are
    # not used so that capitalization preservation can occur.
    # \n = newline is stripped
    # %t = target name
    # %g = taget's gender
    # %s = target in third-person pronoun subjective
    # %o = target in third-person pronoun objective
    # %p = target in third-person pronoun possessive
    #
    
    for index in xrange(len(args)):
        
        #
        # Strip bad character combinations.
        #
        args[index] = args[index].replace("\\n", "")
        # Allow normal backslash after all, but reformat.
        args[index] = args[index].replace("\\", "\\\\")
        
        #
        # All other substitutions require a valid.mob.target
        #
        if mob.target:
            args[index] = args[index].replace("%t", mob.target.name)
            args[index] = args[index].replace("%r", mob.target.spawn.race)
            args[index] = args[index].replace("%g", mob.target.sex)
            
            #
            # Determine the sex of the mob, all personal pronouns cases are dependent
            # on the target's sex/gender.
            #
            sexIndex = 0
            if RPG_SEXES[SUB_MALE] == mob.target.sex:
                sexIndex = SUB_MALE
            elif RPG_SEXES[SUB_FEMALE] == mob.target.sex:
                sexIndex = SUB_FEMALE
            else:
                sexIndex = SUB_OTHER
            args[index] = args[index].replace("%s", SUBSTITUTION_SUBJECTIVE[sexIndex])
            args[index] = args[index].replace("%o", SUBSTITUTION_OBJECTIVE[sexIndex])
            args[index] = args[index].replace("%p", SUBSTITUTION_POSSESSIVE[sexIndex])



MUTEDPLAYERS = {}

def CheckMuted(mob):
    player = mob.player
    if player.world.mutedPlayers.has_key(player.publicName):
        mt = player.world.mutedPlayers[player.publicName]
        m = mt/60+1
        if m > 59:
            player.sendSpeechText(RPG_MSG_SPEECH_ERROR,r'You have been muted.\n')            
        else:
            player.sendSpeechText(RPG_MSG_SPEECH_ERROR,r'You have been muted and will be able to speak in %i minutes.\n'%m)            
        return True

    return False
            
#get top 10 players
def CmdLadder(mob,args):
    from newplayeravatar import NewPlayerAvatar
    
    mob.player.sendGameText(RPG_MSG_GAME_EVENT,"The ladder command is currently inactive.\\n")
    return
    
    text= r'\n------------------------------------\n'
    text+= r'Most Experienced Characters\n'
    text+=r'------------------------------------\n'
    
    chars = {}
    players = {}
    
    cursor = mob.spawn.__class__._connection.getConnection().cursor()
    try:
        cursor.execute("select name,xp_primary,xp_secondary,xp_tertiary,player_id from character;")
        for r in cursor.fetchall():
            name,xpPrimary,xpSecondary,xpTertiary,playerID=r
    
            c2 = mob.spawn.__class__._connection.getConnection().cursor()
            c2.execute("select public_name from player where id = %i;"%playerID)
            if c2.fetchone()[0]==NewPlayerAvatar.ownerPublicName:
                c2.close()
                continue
            c2.close()

            
            c2 = mob.spawn.__class__._connection.getConnection().cursor()
            c2.execute("select realm from spawn where name = '%s';"%name)
            if c2.fetchone()[0]==RPG_REALM_MONSTER:
                c2.close()
                continue
            c2.close()
            
            xp = xpPrimary + xpSecondary + xpTertiary
            chars[name]=xp
            players[name]=playerID
        
        
        v = chars.values()
        v.sort()
        v.reverse()
        v=v[:9]
        
        x = 1
        for xp in v:
            if x > 20:
                break
            for c,cxp in chars.iteritems():
                if cxp == xp:
                    cursor.execute("select pclass_internal,plevel,sclass_internal,slevel,tclass_internal,tlevel from spawn where name = '%s';"%c)
                    pclassInternal,plevel,sclassInternal,slevel,tclassInternal,tlevel = cursor.fetchone()
                    
                    text+="%i.  <%s> %s (%i) "%(x,c,pclassInternal,plevel)
                    if slevel:
                        text+="%s (%i) "%(sclassInternal,slevel)
                    if tlevel:
                        text+="%s (%i) "%(tclassInternal,tlevel)
                        
                    cursor.execute("select fantasy_name from player where id = %i;"%players[c])
                    pname = cursor.fetchone()[0]
                    text+=r'- %s\n'%pname
                    
                    x+=1        
        text = str(text) #remove unicode
        mob.player.sendGameText(RPG_MSG_GAME_EVENT,text)
    except:
        traceback.print_exc()
    cursor.close()
    
def CmdSuicide(mob,args):
    
    for c in mob.player.party.members:
        if not c.dead:
            c.mob.health = -100

def CmdUnstick(mob,args):
    
    for c in mob.player.party.members:
        if c.mob.unstickReuse:
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,"You must wait a short time before trying to unstick again.\\n")
            return

    
    mob.player.sendGameText(RPG_MSG_GAME_GAINED,"Please try and unstick yourself.\\n")
    for c in mob.player.party.members:
        if not c.mob.unstick:
            c.mob.unstickReuse = 6*45
            c.mob.unstick = 18
            c.mob.flying+=1.0
            
            


def CmdAvatar(mob,args):
    if not len(args):
        return
        
    name = args[0].upper()
    index = 0
    for m in mob.player.party.members:
        if m.name.upper() == name:
            if mob.player.modelChar == m:
                return
            mob.player.modelChar = m
            mob.player.modelIndex = index
            mob.player.avatarCharName = m.name
            
            mob.player.zone.simAvatar.mind.callRemote("setPlayerSpawnInfo",mob.player.simObject.id,m.spawn.name)
            mob.player.sendGameText(RPG_MSG_GAME_GAINED,"Your avatar has been set to %s.\\n"%m.name)
            return
        index+=1

def CmdWho(mob,args):
    if not CoreSettings.PGSERVER:
        CmdWhoOld(mob, args)
        return
    
    if len(args):
        original = ' '.join(args)
        filter = original.upper()
        for pname,info in mob.player.world.characterInfos.iteritems():        
            prefix,cname,realm,pclass,sclass,tclass,plevel,slevel,tlevel,zone,guild = info
            if cname.upper() == filter:
                #MAKE THIS BETTER /who needs total redo!
                classes = (pclass,sclass,tclass)
                levels = (plevel,slevel,tlevel)
                
                text = r'%s (%s %s)\n'%(' '.join([prefix, cname]),
                            '/'.join(RPG_CLASS_ABBR[klass] for klass in classes if klass),
                            '/'.join('%i'%level for level in levels if level))
                mob.player.sendGameText(RPG_MSG_GAME_EVENT, text)
                return
        
        try:
            charname,wname,zname = mob.player.world.globalPlayers[filter]
            mob.player.sendGameText(RPG_MSG_GAME_EVENT, r'%s is on %s\n'%(charname, wname))
        except KeyError:
            mob.player.sendGameText(RPG_MSG_GAME_DENIED, r'%s is not currently logged in.\n'%original)
        return
    
    text = ""
    for pname,info in mob.player.world.characterInfos.iteritems():
        prefix,cname,realm,pclass,sclass,tclass,plevel,slevel,tlevel,zone,guild = info
        classes = (pclass,sclass,tclass)
        levels = (plevel,slevel,tlevel)
        
        text += r'%s (%s %s)\n'%(' '.join([prefix, cname]),
                    '/'.join(RPG_CLASS_ABBR[klass] for klass in classes if klass),
                    '/'.join('%i'%level for level in levels if level))
    
    text += r'\n'
    mob.player.sendGameText(RPG_MSG_GAME_EVENT, text)


def GuildWho(mob,args):
    guild = mob.player.guildName
    
    if not guild:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"You are not a member of a guild.\\n")
        return
    
    text = "Members of <%s> in this world:\\n"%guild
    for pname,info in mob.player.world.characterInfos.iteritems():
        prefix,cname,realm,pclass,sclass,tclass,plevel,slevel,tlevel,zone,cguild = info
        
        if guild != cguild:
            continue
        
        classes = (pclass,sclass,tclass)
        levels = (plevel,slevel,tlevel)
        
        text += r'%s <%s> (%s %s)\n'%(' '.join([prefix, cname]), zone,
                    '/'.join(RPG_CLASS_ABBR[klass] for klass in classes if klass),
                    '/'.join('%i'%level for level in levels if level))
    
    text += r'\n'
    mob.player.sendGameText(RPG_MSG_GAME_EVENT, text)


def CmdWhoOld(mob,args):
    filter = None
    if len(args):
        filter = ' '.join(args).upper()
    
    text = ""
    for p in mob.player.world.activePlayers:
        if filter and p.publicName.upper() != filter:
            continue
        
        prefix = ""
        if p.avatar and p.avatar.masterPerspective:
            if p.avatar.masterPerspective.avatars.has_key("GuardianAvatar"):
                prefix = "(Guardian) "
            if p.avatar.masterPerspective.avatars.has_key("ImmortalAvatar"):
                prefix = "(Immortal) "
        
        if p.enteringWorld:
            text += r'%s%s <Entering World> '%(prefix, p.name)
        elif p.zone:
            text += r'%s%s <%s> '%(prefix, p.name, p.zone.zone.niceName)
        else:
            text += r'%s%s '%(prefix, p.name)
            
        if p.party and len(p.party.members):
            c = p.party.members[0]
            classes = (c.spawn.pclassInternal,c.spawn.sclassInternal,c.spawn.tclassInternal)
            levels = (c.spawn.plevel,c.spawn.slevel,c.spawn.tlevel)
            text += r'(%s %s)\n'%('/'.join(RPG_CLASS_ABBR[klass] for klass in classes if klass),
                        '/'.join('%i'%level for level in levels if level))
        else:
            text += r'\n'
    
    text += r'\n'
    mob.player.sendGameText(RPG_MSG_GAME_EVENT, text)


def CmdCoords(mob,args):
    pos = mob.simObject.position
    text = r'Your position is %i %i %i in %s\n'%(pos[0],pos[1],pos[2],mob.player.zone.zone.niceName)
    mob.player.sendGameText(RPG_MSG_GAME_EVENT,text)


def CmdEval(mob,args):
    target = mob.target
    if not target:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"%s has no target.\\n"%mob.name)
        return
    
    if target.level - mob.level <= -5:
        color,text = RPG_MSG_GAME_GREEN,"%s is no match for %s.\\n"%(target.name,mob.name)
    elif target.level - mob.level <= -1:
        color,text = RPG_MSG_GAME_BLUE,"%s might challenge %s.\\n"%(target.name,mob.name)
    elif target.level - mob.level == 0:
        color,text = RPG_MSG_GAME_WHITE,"%s is an even match for %s.\\n"%(target.name,mob.name)
    elif target.level - mob.level <= 2:
        color,text = RPG_MSG_GAME_YELLOW,"%s has a significant advantage over %s.\\n"%(target.name,mob.name)
    else:
        color,text = RPG_MSG_GAME_RED,"%s would cream %s.\\n"%(target.name,mob.name)
    
    if target.spawn.desc:
        mob.player.sendGameText(RPG_MSG_GAME_YELLOW,target.spawn.desc+"  ")
    
    if target.player:
        if AllowHarmful(mob,target):
            mob.player.sendGameText(RPG_MSG_GAME_YELLOW,"%s hasn't quite decided what to make of %s, but seems ready for battle.  "%(target.name,mob.name))
        else:
            mob.player.sendGameText(RPG_MSG_GAME_WHITE,"%s hasn't quite decided what to make of %s.  "%(target.name,mob.name))
    else:
        #faction
        kos = IsKOS(target,mob)
        if not kos:
            worstfaction = 999999999L
            sfactions = target.spawn.factions
            for f in mob.character.characterFactions:
                if kos:
                    break
                for of in sfactions:
                    if f.faction == of:
                        #got one
                        if f.points < RPG_FACTION_DISLIKED:
                            kos = True
                            break
                        if f.points < worstfaction:
                            worstfaction = f.points
    
        if kos:
            mob.player.sendGameText(RPG_MSG_GAME_RED,"%s stares at %s with utter contempt.  "%(target.name,mob.name))
        else:
            if worstfaction == 999999999L:
                worstfaction = 0
            if worstfaction >= RPG_FACTION_ADORED:
                mob.player.sendGameText(RPG_MSG_GAME_GREEN,"%s gazes at %s adoringly.  "%(target.name,mob.name))
            elif worstfaction >= RPG_FACTION_LIKED:
                mob.player.sendGameText(RPG_MSG_GAME_YELLOW,"%s likes %s.  "%(target.name,mob.name))
            elif worstfaction >= 0:
                mob.player.sendGameText(RPG_MSG_GAME_WHITE,"%s hasn't quite decided what to make of %s.  "%(target.name,mob.name))
            else:
                mob.player.sendGameText(RPG_MSG_GAME_BLUE,"%s gives %s a very sour look.  "%(target.name,mob.name))
    
    mob.player.sendGameText(color,text)


def CmdPet(mob,args):
    if not len(args):
        return
    
    if not mob.pet:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"%s has no pet.\\n"%mob.name)
        return
    
    cmd = args[0].upper()
    
    if cmd =='ATTACK':
        if mob.target:
            PetCmdAttack(mob.pet,mob.target)
    elif cmd == 'STAY':
        PetCmdStay(mob.pet)
    elif cmd == 'FOLLOWME':
        PetCmdFollowMe(mob.pet)
    elif cmd == 'STANDDOWN':
        PetCmdStandDown(mob.pet)
    elif cmd == 'DISMISS':
        PetCmdDismiss(mob.pet)


def CmdBind(mob,args):
    #look for a near enough bind point
    
    pos = mob.simObject.position
    for bp in mob.zone.bindpoints:
        x = pos[0]-bp[0]
        y = pos[1]-bp[1]
        z = pos[2]-bp[2]
        
        dist = math.sqrt(x*x+y*y+z*z)
        
        if dist <= 12:
            mob.player.mind.callRemote("playSound","sfx/Magic_Appear01.ogg")
            mob.player.sendGameText(RPG_MSG_GAME_GAINED,"You feel a connection to this place.\\n")
            darkness = mob.player.darkness
            if darkness:
                mob.player.darknessBindZone = mob.zone.zone
            elif mob.player.monster:
                mob.player.monsterBindZone = mob.zone.zone
            else:
                mob.player.bindZone = mob.zone.zone
                
            transform = []
            for p in mob.simObject.position:
                transform.append(p)
            for p in mob.simObject.rotation:
                transform.append(p)

            transform[6]=math.degrees(transform[6])
            if darkness:
                mob.player.darknessBindTransform = transform
            elif mob.player.monster:
                mob.player.monsterBindTransform = transform
            else:
                mob.player.bindTransform = transform
                
            
            return
            
    bindzone = ""
    if mob.player.darkness:
        bindzone = mob.player.darknessBindZone.niceName
    elif mob.player.monster:
        bindzone = mob.player.monsterBindZone.niceName
    else:
        bindzone = mob.player.bindZone.niceName
    mob.player.sendGameText(RPG_MSG_GAME_DENIED,"You cannot bind here and remain bound at %s\\n"%bindzone)
        

#this can be called from simavatar
def CmdZoneInteract(mob,args,trigger = None):
    
    mob.player.endInteraction()
    
    zone = mob.zone

    myx = mob.simObject.position[0]
    myy = mob.simObject.position[1]
    myz = mob.simObject.position[2]
    
    bestdt = None
    bestdist = 999999
    
    for dt in zone.dialogTriggers:
        if not trigger:
            x = myx-dt.position[0]
            y = myy-dt.position[1]
            z = myz-dt.position[2]
            dist = math.sqrt(x*x+y*y+z*z)
            if dist <= dt.range and dist < bestdist:
                bestdist = dist
                bestdt = dt
        elif dt.dialog.name == trigger:
            
            bestdt = dt
            break
            
    if bestdt:
        dt = bestdt
                        
        dialog = dt.dialog
        
        if dialog.greeting:
            #greeting and choices
            mob.player.curDialogLine = dialog.greeting
            mob.player.interacting = dt
            #mob.target.interacting = mob.player
            
            #todo, format choices, and text
            choices = []
            for choice in dialog.greeting.choices:
                choices.append(choice.text)
            greeting = dialog.greeting
            mob.player.mind.callRemote("setInitialInteraction",greeting.text,choices,greeting.journalEntryID,dialog.title)
        else:
            mob.player.mind.callRemote("setInitialInteraction",None,None)
        
        mob.player.dialog = dialog
        mob.player.mind.callRemote("setVendorStock",False,None,0)
        mob.player.mind.callRemote("openNPCWnd",dialog.title)


def gotCheckIgnoreTrade(ignored,player,oplayer):
    if ignored:
        player.sendGameText(RPG_MSG_GAME_DENIED,"%s is ignoring you.\\n"%oplayer.charName)
        return
    from trading import Trade
    Trade(player,oplayer)

def gotCheckIgnoreTradeError(error):
    print "Error in checkIgnore: %s"%str(error)

def CmdInteract(mob,args):
    if mob.player.interacting:
        return #already interacting
        
    if mob.character.dead:
        return
    
    if mob.target and not mob.target.player:
        if IsKOS(mob.target,mob):
            for c in mob.player.party.members:
                c.mob.autoAttack = True
                c.mob.attackOn()
            return
    
    if mob.target and mob.target.player:
        oplayer = mob.target.player
        player = mob.player
        if oplayer == player:
            return #no trading with self!
        if not player.cursorItem:
            return
        
        if oplayer.interacting or oplayer.trade:
            player.sendGameText(RPG_MSG_GAME_DENIED,"%s is busy.\\n"%oplayer.charName)
            return
        if player.trade:
            return
        d = oplayer.mind.callRemote("checkIgnore",player.charName)
        d.addCallback(gotCheckIgnoreTrade,player,oplayer)
        d.addErrback(gotCheckIgnoreTradeError)
        return 

    if mob.target and mob.target.spawn.flags&RPG_SPAWN_INN:
        #we are at an inn!
        if not mob.player.inn:
            # making this not dependend on spawn size would require for some to stand inside innkeeper
            if GetRangeMin(mob,mob.target) <= 4:
                mob.player.inn = Inn(mob.target,mob.player)
            else:
                mob.player.sendGameText(RPG_MSG_GAME_DENIED,"%s is too far away.\\n"%mob.target.name)
        return
    
    if mob.target and mob.target.master and mob.target.master.player == mob.player:# and mob.player.cursorItem:        
        mob.player.mind.callRemote("setCurCharIndex",mob.target.master.charIndex)
        mob.player.mind.callRemote("openPetWindow")
        
    #yuck, rush
    if mob.target and mob.target.spawn.vendorProto and not mob.target.vendor:
        mob.target.spawn.vendorProto.createVendorInstance(mob.target)


    vendor = None
    if mob.target and mob.target.vendor:
        vendor = mob.target.vendor

                
            
    if not mob.target or not (mob.target.spawn.dialog or mob.target.vendor or mob.target.spawn.flags&RPG_SPAWN_BANKER):
        return
           
    
    #make sure to sync range calc in player.tick()
    #we don't use range calc here so we are in sync with player.tick
    #which also checks dialog triggers
    range = (mob.target.spawn.radius*mob.target.spawn.scale)*2.5
    myx = mob.simObject.position[0]
    myy = mob.simObject.position[1]
    myz = mob.simObject.position[2]
    
    x = myx-mob.target.simObject.position[0]
    y = myy-mob.target.simObject.position[1]
    z = myz-mob.target.simObject.position[2]
    
    dist = math.sqrt(x*x+y*y+z*z)
    
    if dist > range:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"%s is too far away.\\n"%(mob.target.name))
        return

    if mob.target.target:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"%s is busy.\\n"%mob.target.name)
        return
    
    #bankers!
    if mob.target.spawn.flags&RPG_SPAWN_BANKER:
        mob.player.mind.callRemote("setVendorStock",False,None,0)
        mob.player.mind.callRemote("setInitialInteraction",None,None)
        mob.player.mind.callRemote("setInitialInteraction",None,None)
        mob.player.mind.callRemote("openNPCWnd",mob.target.spawn.name,True)
        return

    
    if not CoreSettings.SINGLEPLAYER and mob.target.interactTimes.has_key(mob.player):
        t = time.time()
        t-=mob.target.interactTimes[mob.player]
        if t < 15:
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,"%s is busy and can be with you in %i seconds.\\n"%(mob.target.name,16-t))
            return
        
    if mob.target.interacting:
        t = time.time()
        t-=mob.target.interactTimes[mob.target.interacting]
        if t>60:
            mob.target.interacting.endInteraction()
        else:
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,"%s is now busy with %s and will be available in %i seconds.\\n"%(mob.target.name,mob.target.interacting.name,61-t))
            return
        
    if mob.target.battle and not mob.target.battle.over:
        
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"%s is busy.\\n"%mob.target.name)
        return
          
        
        
    spawn = mob.target.spawn
    
    #at this point we should play some vocalization
    
    if not random.randint(0,9):
        #1 in 10 chance of laughing
        mob.target.vocalize(VOX_LAUGH,mob.player)
    elif not random.randint(0,4):
        #1 in 5 of grunting
        mob.target.vocalize(VOX_GRUNT,mob.player)
    else:
        #otherwise, surprise
        mob.target.vocalize(VOX_SURPRISED,mob.player)
        
    
    
    
    
    #hack
        
    if (not spawn.dialog or not spawn.dialog.greeting) and not vendor:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"%s snorts at you.\\n"%mob.target.name)
        return
        
    if vendor:
        #send vendor stock
        vendor.sendStock(mob.player)
    else:
        mob.player.mind.callRemote("setVendorStock",False,None,0)
        
        
        
    
    #alright we should interact
    dialog = spawn.dialog
    if dialog and dialog.greeting and not len(dialog.greeting.choices):
        #no choices, simple greeting, to do, rebuke
        mob.player.sendGameText(RPG_MSG_GAME_NPC_SPEECH,r'%s says, \"%s\"\n'%(mob.target.name,dialog.greeting.text))
        if not vendor:
            return
        
    if dialog and dialog.greeting:
        #greeting and choices
        dialog.setLine(mob.player,dialog.greeting,spawn.name)
            
    else:
        mob.player.mind.callRemote("setInitialInteraction",None,None)
        
    mob.player.interacting = mob.target
    mob.target.interacting = mob.player
    mob.target.interactTimes[mob.player]=time.time()
    
    mob.player.mind.callRemote("openNPCWnd",spawn.name)


def CmdAttack(mob,args):
    if len(args):
        if args[0].upper() == "ON":
            attacking = True
        elif args[0].upper() == "OFF":
            attacking = False
        else:
            attacking = not mob.autoAttack
    else:
        attacking = not mob.autoAttack
    mob.autoAttack = attacking
    
    if mob.character.dead:
        return
    
    if attacking and mob.target:
        if AllowHarmful(mob,mob.target):
            mob.attackOn()
        else:
            mob.attackOff()
    else:
        mob.attackOff()
    
    return


def CmdRangedAttack(mob,args):
    # everything will be handled herein
    mob.shootRanged()
    
    return
        
       
def CmdTargetId(mob,args):
    cycle = int(args[1])
    mobId = int(args[0])
    
    if mobId == 0:
        mob.zone.setTarget(mob,None)
        return

    if not cycle:
        mob.zone.setTargetById(mob,mobId)
    else:
        for m in mob.zone.activeMobs:
            if mobId == m.id:
                if not m.player or not mob.target:
                    mob.zone.setTargetById(mob,mobId)
                    return
                    
                #find valid targets
                oplayer = m.player
                vtargets = []
                for c in oplayer.party.members:
                    if c.dead:
                        continue
                    
                    vtargets.append(c.mob)
                    
                if len(vtargets) == 0:
                    return
                
                if len(vtargets) == 1:
                    mob.zone.setTargetById(mob,vtargets[0].id)
                    return
                    
                cid = mob.target.id
                count = 0
                for vt in vtargets:
                    if vt.id == cid:
                        break
                    count+=1
                    
                count+=1
                count%=len(vtargets)
                
                mob.zone.setTargetById(mob,vtargets[count].id)
                return


def CmdWorldMsg(mob,args):
    if CheckMuted(mob):
        return
    
    mob.player.lastChannel = 'w'
    if not len(args):
        return
    
    # Perform context substitution
    contextSubstitution(mob, args)
    msg = ' '.join(args)
    
    name = mob.player.charName
    
    if CoreSettings.PGSERVER:
        mob.player.world.daemonPerspective.callRemote("worldMsg", name, msg)
    
    for p in mob.player.world.activePlayers:
        #if name.upper() in p.ignored:
        #    continue
        p.sendSpeechText(RPG_MSG_SPEECH_WORLD, r'World: <%s> %s\n'%(name,msg), mob.player.charName)


def CmdGuildMsg(mob,args):
    if CheckMuted(mob):
        return
    
    guild = mob.player.guildName
    if not guild:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"You are not a member of a guild.\\n")
        return
    
    mob.player.lastChannel = 'g'
    if not len(args):
        return
    
    # Perform context substitution
    contextSubstitution(mob, args)
    msg = ' '.join(args)
    
    name = mob.player.charName
    
    if CoreSettings.PGSERVER:
        mob.player.world.daemonPerspective.callRemote("guildMsg", name, msg, mob.player.guildName)
    
    for p in mob.player.world.activePlayers:
        #if name.upper() in p.ignored:
        #    continue
        if p.guildName != mob.player.guildName:
            continue
        p.sendSpeechText(RPG_MSG_SPEECH_GUILD, r'Guild: <%s> %s\n'%(name,msg), mob.player.charName)


def CmdTellMsg(mob,args):
    raise "This is now on IRC which is local to client"
    
    #if CheckMuted(mob):
    #    return
    
    if len(args) < 2:
        return
    
    who = args[0].lower()
    for p in mob.player.world.activePlayers:
        if not p.zone:
            continue #we really should fixup active players list
            
        if p.name.lower() == who:
           # Perform context substitution
            contextSubstitution(mob, args[1:])
            msg = ' '.join(args[1:])
            
            #if mob.player.name.upper() in p.ignored:
            #    return
            
            if p.lastTell != mob.player.charName:
                p.lastTell = mob.player.charName
                p.mind.callRemote("setTell",p.lastTell)

            mob.player.sendSpeechText(RPG_MSG_SPEECH_TOLD,r'You tell %s, \"%s\"\n'%(p.charName,msg),mob.player.charName)
            p.sendSpeechText(RPG_MSG_SPEECH_TELL,r'%s tells you, \"%s\"\n'%(mob.player.charName,msg),mob.player.charName)
            return
            
            
    mob.player.sendGameText(RPG_MSG_GAME_DENIED,"%s is not in this world.\\n"%args[0])


def CmdZoneMsg(mob,args):
    if CheckMuted(mob):
        return
    
    mob.player.lastChannel = 'z'
    if not len(args):
        return
    
    # Perform context substitution
    contextSubstitution(mob, args)
    msg = ' '.join(args)
    
    for p in mob.zone.players:
        #if mob.player.name.upper() in p.ignored:
        #    continue
        p.sendSpeechText(RPG_MSG_SPEECH_ZONE, r'Zone: <%s> %s\n'%(mob.player.charName,msg), mob.player.charName)


def CmdSayMsg(mob,args):
    if CheckMuted(mob):
        return
    
    mob.player.lastChannel = 's'
    if not len(args):
        return
    
    # Perform context substitution
    contextSubstitution(mob, args)
    msg = ' '.join(args)
    
    for p in mob.zone.players:
        #if mob.player.name.upper() in p.ignored:
        #    continue
        
        if p == mob.player:
            p.sendSpeechText(RPG_MSG_SPEECH_SAY, r'You say, \"%s\"\n'%msg, mob.player.charName)
        else:
            if GetRange(mob, p.curChar.mob) < 30:
                p.sendSpeechText(RPG_MSG_SPEECH_SAY, r'%s says, \"%s\"\n'%(mob.player.charName,msg), mob.player.charName)


def CmdLaugh(mob,args):
    #mob.zone.simAvatar.mind.callRemote("playAnimation",mob.simObject.id,"agree")
    mob.cancelStatProcess("feignDeath","$tgt is obviously not dead!\\n")
    mob.cancelStatProcess("sneak","$tgt is no longer sneaking!\\n")
    CmdEmote(mob,["laughs"])
    mob.player.modelChar.mob.vocalize(VOX_LAUGH)

def CmdScream(mob,args):
    mob.cancelStatProcess("feignDeath","$tgt is obviously not dead!\\n")
    mob.cancelStatProcess("sneak","$tgt is no longer sneaking!\\n")
    CmdEmote(mob,["screams"])
    mob.player.modelChar.mob.vocalize(VOX_MADSCREAM)

def CmdGroan(mob,args):
    mob.cancelStatProcess("feignDeath","$tgt is obviously not dead!\\n")
    mob.cancelStatProcess("sneak","$tgt is no longer sneaking!\\n")
    CmdEmote(mob,["groans"])
    mob.player.modelChar.mob.vocalize(VOX_GROAN)


def CmdEmote(mob,args):
    if CheckMuted(mob):
        return
    
    if not len(args):
        return
    
    # Perform context substitution
    contextSubstitution(mob, args)
    msg = ' '.join(args)
    
    for p in mob.zone.players:
        #if mob.player.name.upper() in p.ignored:
        #    continue
        
        if p == mob.player:
            p.sendSpeechText(RPG_MSG_SPEECH_EMOTE, r'%s %s.\n'%(mob.player.charName,msg), mob.player.charName)
        else:
            if GetRange(mob,p.curChar.mob) < 30:
                p.sendSpeechText(RPG_MSG_SPEECH_EMOTE, r'%s %s.\n'%(mob.player.charName,msg), mob.player.charName)


def CmdLastChannel(mob,args):
    if CheckMuted(mob):
        return

    lc = mob.player.lastChannel
    if  lc == 's':
        CmdSayMsg(mob,args)

    elif lc == 'a':
        CmdAllianceMsg(mob,args)

    elif lc == 'z':
        CmdZoneMsg(mob,args)


    elif lc == 'w':
        CmdWorldMsg(mob,args)

    elif lc == 'g':
        CmdGuildMsg(mob,args)


def CmdCamp(mob,args):
    player = mob.player
    player.logout()
    
    
def CmdAllianceMsg(mob,args):
    
    #if CheckMuted(mob):
    #    return
    
    mob.player.lastChannel = 'a'
    
    if not len(args):
        return
    
    # Perform context substitution
    contextSubstitution(mob, args)
    mob.player.alliance.message(mob.player, ' '.join(args))


def CmdTime(mob,args):
    time = mob.player.world.time
    
    am = True
    
    hour = time.hour
    if 10 >= hour >= 4:
        msg = r'It is %i in the morning.\n'%hour
    elif 12 > hour > 10:
        msg = r'It is %i in the late morning.\n'%hour
    elif hour == 12:
        msg = r'It is around noon.\n'
    elif 16 >= hour > 12:
        msg = r'It is %i in the afternoon.\n'%(hour-12)
    elif 19 >= hour > 16:
        msg = r'It is %i in the early evening.\n'%(hour-12)
    elif 24 >= hour > 16:
        msg = r'It is %i at night.\n'%(hour-12)
    elif hour == 0:
        msg = r'It is around midnight.\n'
    else:
        msg = r'It is %i at night.\n'%hour
        
    mob.player.sendGameText(RPG_MSG_GAME_GLOBAL,msg)
        
    
def CmdUpTime(mob,args):
    import time
    import datetime
    
    uptime = time.time() - mob.player.world.launchTime
    t = datetime.timedelta(0,uptime)
    msg = "This world server has been up for %s.\\n"%str(t)
    mob.player.sendGameText(RPG_MSG_GAME_GLOBAL,msg)
    
def CmdVersion(mob,args):
    msg = "Minions of Mirth World Server (v)1.01a\\n"
    msg +="Minions of Mirth Database (v)1.0a\\n"
    mob.player.sendGameText(RPG_MSG_GAME_GLOBAL,msg)
    
    
    
def CmdDance(mob,args):
    mob.cancelStatProcess("feignDeath","$tgt is obviously not dead!\\n")
    mob.zone.simAvatar.mind.callRemote("playAnimation",mob.simObject.id,"dance")
def CmdPoint(mob,args):
    mob.cancelStatProcess("feignDeath","$tgt is obviously not dead!\\n")
    mob.zone.simAvatar.mind.callRemote("playAnimation",mob.simObject.id,"point")
def CmdYes(mob,args):
    mob.cancelStatProcess("feignDeath","$tgt is obviously not dead!\\n")
    mob.zone.simAvatar.mind.callRemote("playAnimation",mob.simObject.id,"agree")
def CmdNo(mob,args):
    mob.cancelStatProcess("feignDeath","$tgt is obviously not dead!\\n")
    mob.zone.simAvatar.mind.callRemote("playAnimation",mob.simObject.id,"disagree")
def CmdBow(mob,args):
    mob.cancelStatProcess("feignDeath","$tgt is obviously not dead!\\n")
    mob.zone.simAvatar.mind.callRemote("playAnimation",mob.simObject.id,"bow")
def CmdWave(mob,args):
    mob.cancelStatProcess("feignDeath","$tgt is obviously not dead!\\n")
    mob.zone.simAvatar.mind.callRemote("playAnimation",mob.simObject.id,"wave")



def CmdCycleTarget(mob,args,doMouse=True,useInputMob = False,reverse = False):
    if not useInputMob:
        #curchar
        mob = mob.player.curChar.mob
    
    zone = mob.zone
    simAvatar = zone.simAvatar
    
    targets = []
    for id in mob.simObject.canSee:
        try:
            otherMob = zone.mobLookup[simAvatar.simLookup[id]]
        except KeyError:
            continue #not spawned yet, though in cansee
        
        kos = IsKOS(otherMob,mob)
        if not kos or otherMob.detached:
            continue
        if GetRange(otherMob,mob) < 100:
            targets.append(id)
    
    if not len(targets):
        return
    
    if not mob.target or mob.target.simObject.id not in targets or len(targets) == 1:
        tid = targets[0]
    else:
        index = targets.index(mob.target.simObject.id)
        
        if reverse:
            index -= 1
            if index < 0:
                index = len(targets) - 1
        else:
            index += 1
            if index == len(targets):
                index = 0
        
        tid = targets[index]
    
    tmob = zone.mobLookup[simAvatar.simLookup[tid]]
    zone.setTarget(mob,tmob)
    if doMouse:
        mob.player.mind.callRemote("mouseSelect",mob.charIndex,tmob.id)


def CmdCycleTargetBackwards(mob,args):        
    CmdCycleTarget(mob,args,True,False,True)


def CmdTargetNearest(mob,args,doMouse=True,useInputMob = False):
    if not useInputMob:
        #curchar
        mob = mob.player.curChar.mob
    
    zone = mob.zone
    simAvatar = zone.simAvatar
    
    target = -1
    best = 999999
    for id in mob.simObject.canSee:
        try:
            otherMob = zone.mobLookup[simAvatar.simLookup[id]]
        except KeyError:
            continue #not spawned yet, though in cansee
        kos = IsKOS(otherMob,mob)
        if not kos or otherMob.detached:
            continue
        r = GetRange(otherMob,mob)
        if  r < best:
            target = id
            best = r
    
    if target == -1:
        return
    
    tmob = zone.mobLookup[simAvatar.simLookup[target]]
    zone.setTarget(mob,tmob)
    if doMouse:
        mob.player.mind.callRemote("mouseSelect",mob.charIndex,tmob.id)


def FindMobByName(src,name):
    zone = src.zone
    mobs = [c.mob for c in src.player.party.members if not c.mob.detached]
    
    for id in src.simObject.canSee:
        try:
            otherMob = zone.mobLookup[zone.simAvatar.simLookup[id]]
        except KeyError:
            continue #not spawned yet, though in cansee
        
        if otherMob.player:
            for c in otherMob.player.party.members:
                if c.mob.detached:
                    continue
                mobs.append(c.mob)
        else:
            if not otherMob.detached:
                mobs.append(otherMob)
    
    for m in mobs:
        if m.detached:
            continue
        if m.spawn.name.upper() == name:
            return m
    
    return None


def CmdAssist(mob,args):
    if 0 == len(args):
        mob.zone.setTarget(mob,mob.target.target)
        return
    
    tname = ' '.join(args)
    
    if tname.upper() == "PET":
        if mob.pet:
            mob.zone.setTarget(mob,mob.pet.target)
            return
        else:
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s cannot assist pet.\n'%mob.name)
            return
    
    m = FindMobByName(mob,tname.upper())
    if m:
        mob.zone.setTarget(mob,m.target)
        return
    
    mob.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s cannot assist %s.\n'%(mob.name,tname))


def CmdTarget(mob,args):
    tname = ' '.join(args)
    
    if tname.upper() == "PET":
        if mob.pet:
            mob.zone.setTarget(mob,mob.pet)
            return
        else:
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s cannot target pet.\n'%mob.name)
            return
    
    m = FindMobByName(mob,tname.upper())
    if m:
        mob.zone.setTarget(mob,m)
        return
    
    mob.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s cannot target %s.\n'%(mob.name,tname))


def CmdCast(mob,args):
    if mob.casting:
        return
    if mob.detached:
        return#XXX should be caught client side
    sname = ' '.join(args)
    upper = sname.upper()
    
    for cspell in mob.character.spells:
        if cspell.spellProto.name.upper() == upper:
            mob.cast(cspell.spellProto,cspell.level)
            return
        
    mob.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s cannot cast %s.\n'%(mob.name,sname))


def CmdSkill(mob,args):
    from skill import UseSkill
    
    sname = ' '.join(args)
    upper = sname.upper()
    
    skillname = ""
    for sk in mob.mobSkillProfiles.iterkeys():
        if sk.upper() == upper:
            skillname = sk
            break
    
    if not skillname:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s cannot use the %s skill.\n'%(mob.name,sname))
        return
    
    UseSkill(mob,mob.target,skillname)


def CmdInvite(mob,args):
    mob.player.avatar.perspective_invite()
    
def OldCmdIgnore(mob,args):
    if not len(args):
        return
    
    from player import PlayerIgnore
    
    ignore = args[0]
    
    for name in mob.player.ignored:
        if ignore.upper() == name:
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,r'You are already ignoring %s.\n'%ignore)
            return
    
    PlayerIgnore(name=ignore.upper(),player = mob.player)
    mob.player.ignoredDirty=True        
    mob.player.sendGameText(RPG_MSG_GAME_GAINED,r'You are now ignoring %s.\n'%ignore)
    

def OldCmdUnignore(mob,args):
    if not len(args):
        return
    
    ignore = args[0]
    
    for pi in mob.player.ignoredInternal:
        if ignore.upper() == pi.name:
            pi.destroySelf()
            mob.player.ignoredDirty=True        
            mob.player.sendGameText(RPG_MSG_GAME_GAINED,r'You are are no longer ignoring %s.\n'%ignore)
            return
    
    mob.player.sendGameText(RPG_MSG_GAME_DENIED,r'You are not ignoring %s.\n'%ignore)

    
def CmdChannel(mob,args):
    player = mob.player
    if len(args)<2:
        return
    channel = args[0].lower()
    mode = args[1].lower()
            
    if channel == "world":
        if mode == "off":
            player.channelWorld =False
            player.sendGameText(RPG_MSG_GAME_GAINED,r'You are are no longer listening to world chat.\n')
        else:
            player.channelWorld =True
            player.sendGameText(RPG_MSG_GAME_GAINED,r'You are are now listening to world chat.\n')
        
    if channel == "zone":
        if mode == "off":
            player.channelZone =False
            player.sendGameText(RPG_MSG_GAME_GAINED,r'You are are no longer listening to zone chat.\n')
        else:
            player.channelZone =True
            player.sendGameText(RPG_MSG_GAME_GAINED,r'You are are now listening to zone chat.\n')
            
    if channel == "combat":
        if mode == "off":
            player.channelCombat =False
            player.sendGameText(RPG_MSG_GAME_GAINED,r"You are are no longer listening to other's combat messages.\n")
        else:
            player.channelCombat =True
            player.sendGameText(RPG_MSG_GAME_GAINED,r"You are now listening to other's combat messages.\n")
        
    
def CmdStopCast(mob,args):
    if mob.casting:
        if mob.stopCastingTimer:
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,r"%s cannot stop casting at this time.\n"%(mob.name))
            return
        mob.stopCastingTimer=60
        mob.casting.cancel()
        mob.player.sendGameText(RPG_MSG_GAME_YELLOW,r"%s stops casting.\n"%(mob.name))
        
    

def CmdSetPassword(mob,args):
    from mud.common.permission import User
    
    if CoreSettings.SINGLEPLAYER:
        return
    if CoreSettings.PGSERVER:
        return
    
    if len(args) != 1:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Please specify a password.\\n")
        return

    player = mob.player

    try:
        user = User.byName(player.publicName)
    except:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Unknown user %s.\\n"%player.publicName)
        return
    
    pw = args[0]
    if len(pw) < 6:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Password must be at least 6 characters.\\n")
        return
    
    user.password = player.password = pw
        
    mob.player.sendGameText(RPG_MSG_GAME_GAINED,"Your password is now set to %s\\n"%(pw))


def CmdGetPassword(mob,args):
    from mud.common.permission import User


    if CoreSettings.SINGLEPLAYER:
        return
    
    if CoreSettings.PGSERVER:
        return

    

    player = mob.player

    try:
        user = User.byName(player.publicName)
    except:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Unknown user %s.\\n"%player.publicName)
        return
    
        
    mob.player.sendGameText(RPG_MSG_GAME_GAINED,"Your password is %s\\n"%(user.password))
    
def CmdCraft(mob,args):
    if not len(args):
        return
    
    from crafting import CraftCommand
    CraftCommand(mob, ' '.join(args))


def CmdDisenchant(mob,args):
    from crafting import DisenchantCmd
    DisenchantCmd(mob, ' '.join(args).upper())

def CmdEnchant(mob,args):
    from crafting import EnchantCmd
    EnchantCmd(mob, ' '.join(args).upper())


def CmdRoll(mob,args):
    r = random.randint(1,100)
    
    GameMessage(RPG_MSG_GAME_LEVELGAINED,mob.zone,mob,mob,"%s has rolled a %i.\\n"%(mob.player.charName,r),mob.simObject.position,20)
    

def CmdUnlearn(mob, args):
    name = ' '.join(args)
    if not len(name):
        return
    
    name = name.lower()
    
    for spell in mob.character.spells:
        if spell.spellProto.name.lower()==name:
            sname = spell.spellProto.name
            spell.destroySelf()
            mob.character.spellsDirty=True
            mob.player.cinfoDirty=True
            mob.player.sendGameText(RPG_MSG_GAME_GAINED,"%s forgets all about the %s spell.\\n"%(mob.name,sname))        
            return
    

    mob.player.sendGameText(RPG_MSG_GAME_DENIED,"%s doesn't know the %s spell.\\n"%(mob.name,name))
    
def CmdClearLastName(mob,args):
    
    player = mob.player
    if not player.curChar.lastName:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"%s doesn't have a last name.\\n"%(player.curChar.name))
        
    player.curChar.lastName = ""
    
    player.zone.simAvatar.setDisplayName(player)

    mob.player.sendGameText(RPG_MSG_GAME_GAINED,"%s's last name has been cleared.\\n"%(player.curChar.name))
    
    
def CmdLastName(mob,args):
    
    
    
    player = mob.player
    
    #if player.curChar.spawn.realm == RPG_REALM_MONSTER:
    #    player.sendGameText(RPG_MSG_GAME_DENIED,"lastname: %s is a monster.\\n"%mob.player.curChar.name)
    #    return
        
    
    
    #perhaps lock this and allow gm's to flag name needing to be changed, ie. blanking name
    #if player.curChar.lastName:
    #    player.sendGameText(RPG_MSG_GAME_DENIED,"%s already has a last name.\\n"%mob.player.curChar.name)
    #    return

    if player.curChar.mob.plevel<25:
        player.sendGameText(RPG_MSG_GAME_DENIED,"%s must be level 25 before acquiring a last name.\\n"%mob.player.curChar.name)
        return
    
    if len(args)!=1:
        player.sendGameText(RPG_MSG_GAME_DENIED,"lastname: incorrect number of arguments\\n")
        return
    
    last = args[0]
    if len(last)>12:
        player.sendGameText(RPG_MSG_GAME_DENIED,"lastname: must be less than 13 characters\\n")
        return

    if len(last)<4:
        player.sendGameText(RPG_MSG_GAME_DENIED,"lastname: must be at least 4 characters\\n")
        return
    
    if not last.isalpha():
        player.sendGameText(RPG_MSG_GAME_DENIED,"Guild names must not contain numbers, spaces, or punctuation marks.\\n")
        return
    
    player.curChar.lastName = last.capitalize()
    
    player.zone.simAvatar.setDisplayName(player)
    
    c = player.curChar
    player.sendGameText(RPG_MSG_GAME_GAINED,"%s is now known as %s %s!\\n"%(c.name,c.name,c.lastName))
    
def CmdChangeClass(mob,args):

    if len(args) != 3:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"changeclass: incorrect number of arguments")
        return
    
    which,name,klass = args
    which = which.upper()
    
    if which not in ("PRIMARY","SECONDARY","TERTIARY"):
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Please specify which class you which to change (primary, secondary, or tertiary)\\n")
        return
    
    if mob.name.upper() != name.upper():
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"You must specify your active character's name (%s)\\n"%mob.name)
        return
    
    #mob.character.pchange = True
    #mob.character.schange = True
    #mob.character.tchange = True
    
    klasses = (mob.spawn.pclassInternal,mob.spawn.sclassInternal,mob.spawn.tclassInternal)
    if klass in klasses:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"%s is already a %s, unchanged.\\n"%(mob.name,klass))
        return
        
    
    if which == "PRIMARY" and not mob.character.pchange:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"%s may not change primary class at this time.\\n"%mob.name)
        return
    if which == "SECONDARY" and not mob.character.schange:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"%s may not change secondary class at this time.\\n"%mob.name)
        return
    if which == "TERTIARY" and not mob.character.tchange:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"%s may not change tertiary class at this time.\\n"%mob.name)
        return
    
    if mob.spawn.realm == RPG_REALM_MONSTER:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"%s is a monster and cannot change class.\\n"%mob.name)
        return

    if mob.spawn.realm == RPG_REALM_LIGHT:
        if klass not in RPG_REALM_LIGHT_CLASSES:
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Invalid class specified (case sensitive and make sure realm allows it).\\n")
            return
    if mob.spawn.realm == RPG_REALM_DARKNESS:
        if klass not in RPG_REALM_DARKNESS_CLASSES:
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Invalid class specified (case sensitive and make sure realm allows it).\\n")
            return
        
    if which == 'PRIMARY':
        mob.spawn.pclassInternal = klass
        mob.levelChanged()
        mob.character.pchange = False
        mob.player.sendGameText(RPG_MSG_GAME_GAINED,"%s's primary class has been changed to %s.\\n"%(mob.name,klass))        
        return
        
    if which == 'SECONDARY':
        if not mob.spawn.sclassInternal or not mob.spawn.slevel:
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,"%s has no secondary class, unchanged.\\n"%(mob.name))
            return
        
        mob.spawn.sclassInternal = klass
        mob.levelChanged()
        mob.character.schange = False
        mob.player.sendGameText(RPG_MSG_GAME_GAINED,"%s's secondary class has been changed to %s.\\n"%(mob.name,klass))        
        return
        
    if which == 'TERTIARY':
        if not mob.spawn.tclassInternal or not mob.spawn.tlevel:
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,"%s has no tertiary class, unchanged.\\n"%(mob.name))
            return
        
        mob.spawn.tclassInternal = klass
        mob.levelChanged()
        mob.character.tchange = False
        mob.player.sendGameText(RPG_MSG_GAME_GAINED,"%s's tertiary class has been changed to %s.\\n"%(mob.name,klass))        
        return
            
def CmdServer(mob,args):
    wname = mob.player.world.multiName.replace("_"," ")
    
    mob.player.sendGameText(RPG_MSG_GAME_GAINED,"You are on the %s server\\n"%wname)        


#
# This function empties the contents of the craft window into the players
# inventory.  This function will attempt to reduce item into stacks if
# possible.
#
def CmdEmptyCraft(mob, args):
    
    #
    # Reduce item stacks.
    #
    items = dict((item.slot,item) for item in mob.character.items
                    if((RPG_SLOT_CRAFTING_BEGIN <= item.slot < RPG_SLOT_CRAFTING_END)
                        or (RPG_SLOT_CARRY_BEGIN <= item.slot < RPG_SLOT_CARRY_END)))
    stackInventory(mob, items)
    
    #
    # Crafting items will be stored in a [slot, item] list.  This allows for preservation of order
    # when moving items to the inventory.
    #
    (CRAFTING_SLOT, CRAFTING_ITEM) = range(2)
    craftingItems = []
    
    #
    # Using a dictiontary for carry slots.  Although dictionary creation takes longer than a list,
    # the deletion invokations later are faster.
    #
    carrySlots = dict((index, '') for index in xrange(RPG_SLOT_CARRY_BEGIN, RPG_SLOT_CARRY_END))
    
    #
    # Iterate over the items, looking at the item's slot and handling it appropriately.
    #
    for slot,item in items.iteritems():
        
        #
        # Only items with a slot higher than crafting window begin are in the
        # crafting window.
        #
        if RPG_SLOT_CRAFTING_BEGIN <= slot:
            craftingItems.append([slot, item])
        
        #
        # Otherwise, the item is in a carry slot.  Delete the carry slot from the dictionary.
        #
        else:
            del carrySlots[slot]
    
    #
    # Sort the crafting items based on their current slots, this allows for order preservation
    # when moving items to carry slots.
    #
    craftingItems.sort()
    
    #
    # Determine how many items will actually be moved.  If there are more items needing moved
    # than slots available, only move the amount of items that will fit in the slots available.
    # Otherwise, move all of the items.
    #
    itemsBeingMoved = 0
    if len(craftingItems) > len(carrySlots):
        itemsBeingMoved = len(carrySlots)
    else:
        itemsBeingMoved = len(craftingItems)
    
    #
    # Get a list of free slots available.  This list is already sorted, so items will be moved to slots
    # appearing at the beginning of the inventory first.
    #
    freeSlots = carrySlots.keys()
    for index in xrange(itemsBeingMoved):
        craftingItems[index][CRAFTING_ITEM].slot = freeSlots[index]


#
# This function calls stackInventory() method, passing in a dictionary of
# all inventory carry slots.
#
def CmdStackInventory(mob, args):
    
    #
    # Create a list of items to be reduced.
    #
    items = dict((item.slot,item) for item in mob.character.items if (RPG_SLOT_CARRY_BEGIN <= item.slot < RPG_SLOT_CARRY_END))
    
    stackInventory(mob, items)


#
# Enums used to define sort types.
#
(ALPHA_SORT, UNUSED_SORT) = range(2)


#    
# This function sorts a subset of a player's inventory based on the 
# various arguments provided.
#
def CmdInventorySort(mob, args):
    
    #
    # By default, the command is invoked as if it had the following arguements:
    # /sort all stack alpha
    #
    start   = RPG_SLOT_CARRY_BEGIN
    end     = RPG_SLOT_CARRY_END
    items   = mob.character.items
    stack   = True
    reverse = False
    sort    = ALPHA_SORT
    
    for word in args:
        if word.upper() == "PAGE1":
            start = RPG_SLOT_CARRY_BEGIN
            end   = RPG_SLOT_CARRY30
        
        elif word.upper() == "PAGE2":
            start = RPG_SLOT_CARRY30
            end   = RPG_SLOT_CARRY_END
        
        elif word.upper() == "NOSTACK":
            stack = False
        
        elif word.upper() == "REVERSE":
            reverse = True
    
    #
    # Iterate through the entire itemset and create an item subset dictionary with key-value pairs
    # of item.slot and item if the item's slot is within the desired boundaries.
    #
    itemSubsetDictionary = dict((item.slot,item) for item in items if (start <= item.slot < end))
    
    #
    # Reduce item stacks if possible.
    #
    if stack:
        stackInventory(mob, itemSubsetDictionary)
    
    #
    # Build a dictionary whose values are sorted positions.
    #
    positionDictionary = createSortedPositionDictionary(sort, reverse, itemSubsetDictionary)
    
    #
    # Sort items in the subset dictionary based on the value in the position dictionary.
    # The start argument is used as the starting point for where the sorted items will be placed.
    # First verify that the dictionaries are the same size.  If they are not, then an item has been
    # removed somewhere in the process.  Sorting will not continue because a new or old item may be lost
    # if the sort assigned an item to the unknown used slot.
    #
    if len(itemSubsetDictionary) == len(positionDictionary):
        
        #
        # Iterate over each item and reassign its slot based on the position dictionary value.
        #
        for key,item in itemSubsetDictionary.iteritems():
            item.slot = start + positionDictionary[key]


#
# Create a sorted position dictionary with a key-value pair of item.slot and sorted position.
#
def createSortedPositionDictionary(sort, reverse, itemSubsetDictionary):
    positionDictionary = {}
    itemSortedList =     []
    
    #
    # Use the supplied caller dictionary to create a list with tuples used for sorting.
    # item.slot always needs to be the last value in any sort tuple.  It is also suggested
    # to use an enumeration to preserve the order if any matches occur.
    #
    if ALPHA_SORT == sort:
        itemSortedList = [(item.name.lower(), item.itemProto.stackMax - item.stackCount, i, slot) for i,(slot,item) in enumerate(itemSubsetDictionary.iteritems())]
    
    #
    # Sort the list.  The overall sort order depends on the created tuples.
    # Reverse sort if caller specified.
    #
    if reverse:
        itemSortedList.sort(reverse=True)
    else:
        itemSortedList.sort()
    
    #
    # Item.slot should always be the last variable in a tuple.  Since the length of the sort tuple may vary, 
    # determine the index for where item.slot is in the tuple.
    #
    idIndex = 0
    if 0 < len(itemSortedList):
        idIndex = len(itemSortedList[0]) - 1
        
        #
        # Iterate through the sorted list, populating a dictionary.  The created
        # dictionary has a key-value pair of [item.slot] = sorted position index.
        #
        for position,item in enumerate(itemSortedList):
            positionDictionary[item[idIndex]] = position
    
    return positionDictionary


#
# This function attempts to stack items within a given item dictionary with item.slot as the key.
# The items argument is a dictionary key-value pair of item.slot and item.  This dictionary
# list may change in size as items are reduced into stacks.
#
def stackInventory(mob, items):
    
    #
    # Define enums used for tuple index.
    #
    (FULL_STACKS, REMAINING_ITEMS, TOTAL_CHARGES) = range(3)
    (ITEM_SLOT, ITEM_OBJECT) = range(2)
    
    stackableItems  = {}
    stackData       = {}
    
    for item in items.itervalues():
        iproto = item.itemProto
        
        #
        # Only process items that stack..
        #
        if 1 < iproto.stackMax:
            
            #
            # Check if the item uses charges.
            #
            itemUsesCharges = (0 < iproto.useMax)
            
            #
            # Append item to the stack list.
            # If there is not an item list for the item name, create one.
            #
            try:
                stackableItems[item.name].append(item)
            except KeyError:
                stackableItems[item.name] = [item]
                stackData[item.name]      = [0, 0, 0]

                #
                # One is set to the remaining items base number when the item uses
                # charges.  This one indicates the one potion that indicates the 
                # charge count.  For example, with an item with 15 stackCount and a
                # 2 useCharge.  There are 14 items with full charge, and one item with
                # a nonfull charge.  One is subtracted from each item stack count
                # because only one item will indicate the charge value after reduction.
                #
                if itemUsesCharges:
                    stackData[item.name][REMAINING_ITEMS] = 1
            
            #
            # Update cumulative value for an item without charges.
            #
            if not itemUsesCharges:
                stackData[item.name][REMAINING_ITEMS] += item.stackCount
            
            #
            # Update to cumulative value for an item with charges, and accumulate charges as well.
            #
            if itemUsesCharges:
                stackData[item.name][REMAINING_ITEMS] += item.stackCount - 1
                stackData[item.name][TOTAL_CHARGES]   += item.useCharges
    
    #
    # Iterate over stackable items.
    #
    for itemName,stackables in stackableItems.iteritems():
        iproto = stackables[0].itemProto
        stackMax = iproto.stackMax
        chargesMax = iproto.useMax
        
        #
        # Attempt to reduce charges to items.
        #
        if 0 < chargesMax:
            while chargesMax < stackData[itemName][TOTAL_CHARGES]:
                stackData[itemName][REMAINING_ITEMS] += 1
                stackData[itemName][TOTAL_CHARGES]   -= chargesMax
        
        #
        # Reduce remaining items to full stacks.
        #
        while stackMax <= stackData[itemName][REMAINING_ITEMS]:
            stackData[itemName][FULL_STACKS]     += 1
            stackData[itemName][REMAINING_ITEMS] -= stackMax
        
        #
        # Create a list and sort based on the item's slot position.  This allows for items appearing
        # earlier in the inventory to be full stacks, and empty stacks later in the inventory to be
        # expunged.
        #
        sortedList = [(item.slot, item) for item in stackables]
        sortedList.sort()
        
        for itemTuple in sortedList:
            item = itemTuple[ITEM_OBJECT]
            
            #
            #  If there are still full stack to make, create a stack with max items.
            #
            if 0 < stackData[itemName][FULL_STACKS]:
                item.stackCount = stackMax
                stackData[itemName][FULL_STACKS] -= 1
                
                #
                # If the item uses charges, charge values need to be updated.
                #
                if 0 < chargesMax:
                    #
                    # If it is not the last stack, set charges to full charge.
                    #
                    if 0 < stackData[itemName][FULL_STACKS] or 0 < stackData[itemName][REMAINING_ITEMS]:
                        item.useCharges = chargesMax
                    #
                    # Otherwise, this is is the last stack, so set the charge value to the stored value.
                    #
                    else:
                        item.useCharges = stackData[itemName][TOTAL_CHARGES]
                    
                    item.itemInfo.refreshDict({'STACKCOUNT':item.stackCount,'USECHARGES':item.useCharges})
                else:
                    item.itemInfo.refreshDict({'STACKCOUNT':item.stackCount})
            
            #
            # At this point, all full stacks have been created. The remaining stack will not be full,
            # so populate it with the remaining items.
            #
            elif 0 < stackData[itemName][REMAINING_ITEMS]:
                item.stackCount = stackData[itemName][REMAINING_ITEMS]
                stackData[itemName][REMAINING_ITEMS] = 0
                
                #
                # If the item uses charges, set the charge value to the stored value.
                #
                if 0 < chargesMax:
                    item.useCharges = stackData[itemName][TOTAL_CHARGES]
                    item.itemInfo.refreshDict({'STACKCOUNT':item.stackCount,'USECHARGES':item.useCharges})
                else:
                    item.itemInfo.refreshDict({'STACKCOUNT':item.stackCount})
            
            #
            # All items have been distributed.  Only empty stacks exists now.
            # These items need to be expunged.
            #
            else:
                del items[item.slot]
                mob.player.takeItem(item)


COMMANDS = {}


COMMANDS['CHANGECLASS']=CmdChangeClass

#COMMANDS['IGNORE']=CmdIgnore
#COMMANDS['UNIGNORE']=CmdUnignore

COMMANDS['ROLL']=CmdRoll

# Inventory/item sorts
COMMANDS['STACK'] = CmdStackInventory
COMMANDS['EMPTY'] = CmdEmptyCraft
COMMANDS['SORT']  = CmdInventorySort

#emotes
COMMANDS['DANCE']=CmdDance
COMMANDS['WAVE']=CmdWave
COMMANDS['YES']=CmdYes
COMMANDS['NO']=CmdNo
COMMANDS['POINT']=CmdPoint
COMMANDS['BOW']=CmdBow


COMMANDS['SETPASSWORD']=CmdSetPassword
COMMANDS['GETPASSWORD']=CmdGetPassword

COMMANDS['SERVER']=CmdServer

COMMANDS['COORDS']=CmdCoords

COMMANDS['ATTACK']=CmdAttack
COMMANDS['RANGEDATTACK']=CmdRangedAttack
COMMANDS['TARGETID']=CmdTargetId
COMMANDS['INTERACT']=CmdInteract

COMMANDS['BIND']=CmdBind
COMMANDS['PET']=CmdPet

COMMANDS['CRAFT']=CmdCraft
COMMANDS['DISENCHANT']=CmdDisenchant
COMMANDS['ENCHANT']=CmdEnchant


COMMANDS['E']=CmdEmote
COMMANDS['ME']=CmdEmote

COMMANDS['EMOTE']=CmdEmote
COMMANDS['LAUGH']=CmdLaugh
COMMANDS['SCREAM']=CmdScream
COMMANDS['GROAN']=CmdGroan

COMMANDS['CHANNEL']=CmdChannel

COMMANDS['S']=CmdSayMsg
COMMANDS['SAY']=CmdSayMsg

COMMANDS['W']=CmdWorldMsg
COMMANDS['WORLD']=CmdWorldMsg

COMMANDS['Z']=CmdZoneMsg
COMMANDS['ZONE']=CmdZoneMsg

COMMANDS['A']=CmdAllianceMsg
COMMANDS['ALLIANCE']=CmdAllianceMsg

#COMMANDS['T']=CmdTellMsg
#COMMANDS['TELL']=CmdTellMsg

COMMANDS['UPTIME']=CmdUpTime

COMMANDS['CAST']=CmdCast
COMMANDS['SKILL']=CmdSkill

COMMANDS['CAMP']=CmdCamp

COMMANDS['TIME']=CmdTime

COMMANDS['EVAL']=CmdEval

COMMANDS['AVATAR']=CmdAvatar

COMMANDS['SUICIDE']=CmdSuicide

COMMANDS['LADDER']=CmdLadder

COMMANDS['CYCLETARGET']=CmdCycleTarget
COMMANDS['CYCLETARGETBACKWARDS']=CmdCycleTargetBackwards
COMMANDS['TARGETNEAREST']=CmdTargetNearest

COMMANDS['TARGET']=CmdTarget
COMMANDS['ASSIST']=CmdAssist

COMMANDS['VERSION']=CmdVersion

COMMANDS['LASTNAME']=CmdLastName
COMMANDS['CLEARLASTNAME']=CmdClearLastName


COMMANDS['WHO']=CmdWho

COMMANDS['LC']=CmdLastChannel

COMMANDS['INVITE']=CmdInvite

COMMANDS['UNSTICK']=CmdUnstick

COMMANDS['STOPCAST']=CmdStopCast

COMMANDS['UNLEARN']=CmdUnlearn

#GUILDS
from guild import GuildCreate,GuildLeave,GuildInvite,GuildJoin,GuildDecline,GuildPromote,GuildDemote,GuildRemove,GuildSetMOTD,GuildClearMOTD,GuildRoster,GuildSetLeader,GuildDisband,GuildCharacters,GuildPublicName

COMMANDS['GCREATE']=GuildCreate
COMMANDS['GLEAVE']=GuildLeave
COMMANDS['GINVITE']=GuildInvite
COMMANDS['GJOIN']=GuildJoin
COMMANDS['GDECLINE']=GuildDecline
COMMANDS['GPROMOTE']=GuildPromote
COMMANDS['GDEMOTE']=GuildDemote
COMMANDS['GREMOVE']=GuildRemove
COMMANDS['GSETMOTD']=GuildSetMOTD
COMMANDS['GCLEARMOTD']=GuildClearMOTD
COMMANDS['GROSTER']=GuildRoster
COMMANDS['GSETLEADER']=GuildSetLeader
COMMANDS['GDISBAND']=GuildDisband
COMMANDS['GWHO']=GuildWho
COMMANDS['GCHARACTERS']=GuildCharacters
COMMANDS['G']=CmdGuildMsg
COMMANDS['GPUBLICNAME']=GuildPublicName



def DoCommand(mob,cmd,args):
    if type(args) != list:
        args = [args]
    
    cmd = cmd.upper()
    if COMMANDS.has_key(cmd):
        COMMANDS[cmd](mob,args)
    else:
        print "Unknown Command",cmd

