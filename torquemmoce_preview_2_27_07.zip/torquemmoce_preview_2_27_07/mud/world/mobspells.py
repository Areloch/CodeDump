#npc spell casting
from sqlobject import *

from spell import SpellClass
from defines import *
from core import *
import random

#we need spell lines, for casting logic! (ie best pet, etc)
#todo, healing logic

#sorts in reverse order
def SpellSort(a,b):
    alevel,blevel = 1000,1000
    
    for sc in a.classes:
        if sc.level < alevel:
            alevel = sc.level
    
    for sc in b.classes:
        if sc.level < blevel:
            blevel =sc.level

    #sorts in reverse order!!!
    if alevel > blevel:
        return -1
    if alevel < blevel:
        return 1
    return 0


def HealingSort(a,b):
    
    av = a[1]
    bv = b[1]
    
    if av < bv:
        return -1
    if av > bv:
        return 1
    return 0

MOB_SPELLS = {}
def InitMobSpells():
    for sc in SpellClass.select():
        
        proto = sc.spellProto
        if not proto.spellType&RPG_SPELL_AICAST:
            continue
        
        if not MOB_SPELLS.has_key(sc.classname):
            MOB_SPELLS[sc.classname]={}
        
        if not MOB_SPELLS[sc.classname].has_key(sc.level):
            d = MOB_SPELLS[sc.classname][sc.level]={}
            d["pet"]=[]
            d["harmful"]=[]
            d["beneficial"]=[]
            d["healing"]=[]
            
        d = MOB_SPELLS[sc.classname][sc.level]
        
        proto = sc.spellProto
        if proto.getPet() and proto not in d["pet"]:
            d["pet"].append(proto)
            continue
        
        if proto.spellType&RPG_SPELL_HARMFUL:
            if proto not in d["harmful"]:
                d["harmful"].append(proto)
            continue
        if proto.spellType&RPG_SPELL_HEALING:
            if proto not in d["healing"]:
                d["healing"].append(proto)
            continue
        if proto not in d["beneficial"]:
            d["beneficial"].append(proto)
            
    
    
class MobSpells:
    def __init__(self,mob,master = None):
        self.mob = mob
        self.spawn = mob.spawn
        self.petSpell = None
        
        self.harmful = []
        self.healing = []
        self.beneficial = []
        self.harmfulSpawnSpells = []
        
        self.slow = []
        
        bestPet = None
        bestPetSpell = None
        bestPetLevel = 0
        
        self.hasSpells = False
        
        #grab spells from all classes
        
        for klass,level in zip((self.spawn.pclassInternal,self.spawn.sclassInternal,self.spawn.tclassInternal),(self.spawn.plevel,self.spawn.slevel,self.spawn.tlevel)):
            if MOB_SPELLS.has_key(klass):
                classSpells = MOB_SPELLS[klass]
                for x in xrange(level-20,level+1):
                    if x < 1:
                        continue
                    levelSpells = classSpells.get(x,None)
                    if not levelSpells:
                        continue
                    
                    for t,spells in levelSpells.iteritems():
                        if not len(spells):
                            continue
                        
                        if t == "pet":
                            for p in spells:
                                pet = p.getPet()
                                if pet.plevel >bestPetLevel:
                                    bestPetLevel = pet.plevel
                                    bestPet = pet
                                    bestPetSpell = p
                                    
                        elif t == "harmful":
                            for p in spells:
                                if mob.master and p.affectsStat("fear"):
                                    continue
                                if p.affectsStat("slow"):
                                    self.slow.append(p)
                                if p not in self.harmful:
                                    self.harmful.append(p)
                        elif t == "beneficial":
                            for p in spells:
                                if p not in self.beneficial:
                                    self.beneficial.append(p)
                        elif t == "healing":
                            for p in spells:
                                if p not in self.healing:
                                    self.healing.append(p)
                                    
        for spell in mob.spawn.spawnSpells:            
            if spell.spellType&RPG_SPELL_HARMFUL:
                if spell not in self.harmful:
                    self.harmful.append(spell) #even more likely to use spawnspell
                self.harmfulSpawnSpells.append(spell)
            else:
                if spell not in self.beneficial:
                    self.beneficial.append(spell)
                if spell.spellType&RPG_SPELL_HEALING:
                    if spell not in self.healing:
                        self.healing.append(s)
                
        
        self.petSpell = bestPetSpell
        
        #minute and a half (beneficial spells)
        self.beneTimer = random.randint(0,3*90) 
        self.harmTimer = random.randint(0,40)
        self.healTimer = 0
        
        self.harmful.sort(SpellSort)
        self.healing.sort(SpellSort)
        self.beneficial.sort(SpellSort)
        self.slow.sort(SpellSort)
        
        if self.petSpell or len(self.harmful) or len(self.healing) or len(self.beneficial):
            self.hasSpells = True
        
#        print mob.name
#        print "----------------------"
#        if self.petSpell:
#            print bestPet.name
#        for s in self.harmful:
#            print s.name
#        for s in self.beneficial:
#            print s.name
#        for s in self.healing:
#            print s.name
#        print "----------------------"
        
        
    def considerHealing(self):
        mob = self.mob
        zone = mob.zone
        simAvatar = zone.simAvatar
        
        found = False
        for proto in self.healing:
            if mob.mana >= proto.manaCost:
                found = True
                break
            
        if not found:
            return False
            

                
        #build up the tactical map
        pmobs = []
        for id in mob.simObject.canSee:
            
            try:
                otherMob = zone.mobLookup[simAvatar.simLookup[id]]
            except KeyError:
                continue #not spawned yet, though in cansee
                
            if  otherMob.detached:                
                continue
            
            if otherMob.player:
                continue
            
            r = float(otherMob.health)/float(otherMob.maxHealth)
            if r > .5:
                continue
            
            if IsKOS(mob,otherMob):
                continue
                    
                    
            pmobs.append((otherMob,r))
            
        r = float(mob.health)/float(mob.maxHealth)
        if r <= .5:
            pmobs.append((mob,r))
            
                
        if not len(pmobs):
            return False
        
        if len(pmobs) > 1:
            pmobs.sort(HealingSort)
        
        #cast
        mob.spellTarget = pmobs[0][0]
        mob.cast(proto)
        
        return True
        
        
        
        
                
    def think(self):
        mob = self.mob
        zone = mob.zone
        
        if len(self.healing) and self.healTimer>3:
            self.healTimer-=3

        
        if mob.casting:
            return #already casting a spell
        
        if mob.sleep > 0  or mob.stun > 0:
            return
        
        if mob.master and mob.visibility <= 0:
            return
        
        if len(self.healing) and not mob.master:
            self.healTimer-=3
            if self.healTimer <= 0:
                self.healTimer = random.randint(60,180) 
                if self.considerHealing():
                    return
        
        if mob.target and len(self.harmful) and IsKOS(mob,mob.target) and mob.target.simObject.id in mob.simObject.canSee:
            self.harmTimer-=3
            if self.harmTimer > 0:
                return
            self.harmTimer = random.randint(0,40)
            if mob.master:
                self.harmTimer*=2
            
            proto = None
            if self.petSpell and not mob.pet and not mob.petSpawning and not mob.master and mob.petCounter <2:
                proto = self.petSpell
            
            elif len(self.harmfulSpawnSpells) and not random.randint(0,2): #1 in 3 chance of casting spawn spell
                
                if len(self.harmfulSpawnSpells) == 1:
                    proto = self.harmfulSpawnSpells[0]
                else:
                    proto = self.harmfulSpawnSpells[random.randint(0,len(self.harmfulSpawnSpells)-1)]
            
            if not proto:    
                if len(self.harmful) == 1:
                    proto = self.harmful[0]
                else:
                    if len(self.slow) and mob.target.slow <=0 and not random.randint(0,2):
                        if len(self.slow)==1:
                            proto = self.slow[0]
                        else:
                            proto = self.slow[random.randint(0,len(self.slow)-1)]
                    else:
                        proto = self.harmful[random.randint(0,len(self.harmful)-1)]
            
            if mob.mana < proto.manaCost:
                return
            
            if proto == self.petSpell:
                mob.petCounter+=1
            self.spellTarget = mob.target	# just to make sure
            self.mob.cast(proto)
            
        elif len(self.beneficial) and not mob.master:
            self.beneTimer-=3
            if self.beneTimer > 0:
                return
            
            self.beneTimer = random.randint(0,3*90) 
            
            proto = None
            if self.petSpell and not mob.pet and not mob.petSpawning and not mob.master:
                proto = self.petSpell

            if not proto:
                #look for someone to buff
                
                if not len(self.beneficial):
                    return  

                pmobs = [mob]
                for id in mob.simObject.canSee:
                    
                    try:
                        otherMob = zone.mobLookup[zone.simAvatar.simLookup[id]]
                    except KeyError:
                        continue #not spawned yet, though in cansee
                    
                    if otherMob.player:
                        continue
                    if otherMob == mob:
                        continue
                        
                    if not otherMob.player and otherMob.detached:
                        #detached but still in cansee
                        continue
                    
                    if IsKOS(mob,otherMob):
                        continue
                    
                    
                    pmobs.append(otherMob)
                
                if not len(pmobs):
                    return
                
                mob.spellTarget = None
                
                if len(self.beneficial) == 1:
                    proto = self.beneficial[0]
                else:
                    proto = self.beneficial[random.randint(0,len(self.beneficial)-1)]
                
                if proto.target == RPG_TARGET_OTHER:
                    if len(pmobs) == 1:
                        mob.spellTarget = pmobs[0]
                    else:
                        mob.spellTarget = pmobs[random.randint(0,len(pmobs)-1)]
                
                
            if mob.mana < proto.manaCost:
                return
            self.mob.cast(proto)
            
        
        
            
            
            
        
                
            
        
            
        