"""
Character Advancement System

This module provides the database objects for storing definitions of
advancements.  These are used to define the requirements, restrictions, and
stat changes that make up an advancement.

Examples of use can be found in the genesis/advancement directory
"""

from mud.common.persistent import Persistent
from sqlobject import *

class AdvancementClass(Persistent):
    " Class this advancement applies to "
    advancementProto = ForeignKey('AdvancementProto')
    classname = StringCol()
    level = IntCol()

class AdvancementRace(Persistent):
    " Race restriction, if any "
    advancementProto = ForeignKey('AdvancementProto')
    racename = StringCol()
    level = IntCol()

class AdvancementRequirement(Persistent):
    " Other advances required before this one's available "
    advancementProto = ForeignKey('AdvancementProto')
    require = StringCol()
    rank = IntCol(default=1)
    
class AdvancementExclusion(Persistent):
    " If you have this Advance, the excluded advance is removed? "
    advancementProto = ForeignKey('AdvancementProto')
    exclude = StringCol()
    
class AdvancementStat(Persistent):
    " Stat to increase when this Advance is taken "
    advancementProto = ForeignKey('AdvancementProto')
    statname = StringCol()
    value    = FloatCol()

class AdvancementSkill(Persistent):
    " Skill to provide with this Advance "
    advancementProto = ForeignKey('AdvancementProto')
    skillname = StringCol()
       
class AdvancementProto(Persistent):
    """
    Class to instantiate to create an Advancement.
    
    This is the object that should be created first when creating an Advancement
    - this is then handed into each of the above classes as "advancementProto".
    In the database, this is the defining item for an advance, that will be used
    as a foreign key to tie the above together.
    
    Advances have the following attributes set on creation:
        name, level, desc (description), cost (in Tin)
        
    Advances provide stats, skills, classes, races, requirements, and
    exclusions as a read-only summary of the details set on them.
    """
    name = StringCol(alternateID = True)
    level = IntCol(default=1)
    desc = StringCol(default="")
    cost = IntCol(default=1)
    maxRank = IntCol(default = 1)    
    stats = MultipleJoin('AdvancementStat')
    skills = MultipleJoin('AdvancementSkill')
    classes = MultipleJoin('AdvancementClass')
    races = MultipleJoin('AdvancementRace')
    requirements = MultipleJoin('AdvancementRequirement')
    exclusionsInternal = MultipleJoin('AdvancementExclusion')
    
    def _init(self, *args, **kwargs):
        Persistent._init(self, *args, **kwargs)
        self.exclusions = self.exclusionsInternal

