"""
Initially races are going to be extremely simple, there is simply too much to do

Troll
Ogre
Goblin
Orc
Dwarf
Human
Elf
Halfling
Gnome
Drakken
"""
from defines import *

class Race:
    def __init__(self):
        self.name = ""
        self.xpMod = 1.0
        self.regenHealth = 1.0
        self.regenMana = 2
        self.regenStamina = 1
        self.consumeWater = 1
        self.consumeFood = 1
        self.move = 1
        #starting skills probably
        self.swim = 1  
        self.resists = {}
        self.realm = RPG_REALM_MONSTER
        
    def getXPMod(self):
        return self.xpMod
        
        
class Troll(Race):
    def __init__(self):
        self.name = "Troll"
        Race.__init__(self)

        self.xpMod = 1.05
        self.regenHealth = 1.05
        self.regenMana = 2
        self.regenStamina = 2
        self.realm = RPG_REALM_DARKNESS


class Ogre(Race):
    def __init__(self):
        self.name = "Ogre"
        Race.__init__(self)
        
        self.regenHealth = 1.0
        self.regenMana = 2
        self.regenStamina = 1
        
        self.realm = RPG_REALM_DARKNESS
        
        self.resists = {
        RPG_RESIST_DISEASE:10
        }


        
class Goblin(Race):
    def __init__(self):
        self.name = "Goblin"
        Race.__init__(self)
        self.realm = RPG_REALM_DARKNESS
        
class Orc(Race):
    def __init__(self):
        self.name = "Orc"
        Race.__init__(self)

        self.regenHealth = 1.0
        self.regenMana = 2.0
        self.regenStamina = 2
        self.realm = RPG_REALM_DARKNESS
        
class Dwarf(Race):
    def __init__(self):
        self.name = "Dwarf"
        Race.__init__(self)

        self.regenHealth = 1.025
        self.regenMana = 2.0
        self.regenStamina = 2
        self.realm = RPG_REALM_LIGHT

class Gnome(Race):
    def __init__(self):
        self.name = "Gnome"
        Race.__init__(self)
        self.realm = RPG_REALM_NEUTRAL
        
class Human(Race):
    def __init__(self):
        self.name = "Human"
        Race.__init__(self)
        self.realm = RPG_REALM_NEUTRAL
        
class Elf(Race):
    def __init__(self):
        self.name = "Elf"
        Race.__init__(self)
        
        self.regenMana = 2.5
        self.realm = RPG_REALM_LIGHT
        
class Halfling(Race):
    def __init__(self):
        self.name = "Halfling"
        Race.__init__(self)

        self.regenHealth = 1.05
        self.regenStamina = 2
        self.realm = RPG_REALM_LIGHT
        
        
class Drakken(Race):
    def __init__(self):
        self.name = "Drakken"
        Race.__init__(self)
        self.xpMod = 1.1
        self.regenHealth = 1.1
        self.regenMana = 2
        self.regenStamina = 1
        self.realm = RPG_REALM_DARKNESS
        self.resists = {
        RPG_RESIST_COLD:-25
        }

RACES = {}        
RACES['Troll']=Troll()
RACES['Ogre']=Ogre()
RACES['Goblin']=Goblin()
RACES['Orc']=Orc()
RACES['Dwarf']=Dwarf()
RACES['Gnome']=Gnome()
RACES['Halfling']=Halfling()
RACES['Drakken']=Drakken()
RACES['Elf']=Elf()
RACES['Human']=Human()

        
def GetRace(racename):
    if not RACES.has_key(racename):
        RACES[racename]=Human()
        RACES[racename].name = racename
        
    return RACES[racename]
