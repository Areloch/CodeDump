import math
from defines import *
from zone import Zone
from core import *
import sys

def CmdMute(mob,args):
    if not len(args):
        return
    
    from player import Player
    try:
        player = Player.byPublicName(args[0])
    except:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Unknown player %s.\\n"%args[0])
        return
    
    if not IsUserSuperior(mob.player.publicName,player.publicName):
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"You do not have the required permission for this action.\\n")
        return
        
    
    from command import MUTEDPLAYERS
    
    mob.player.sendGameText(RPG_MSG_GAME_GAINED,"User %s has been muted.\\n"%args[0])
    
    MUTEDPLAYERS[args[0]]=True
    
def CmdUnmute(mob,args):
    if not len(args):
        return
    
    from player import Player
    try:
        player = Player.byPublicName(args[0])
    except:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Unknown player %s.\\n"%args[0])
        return
    
    from command import MUTEDPLAYERS
    
    mob.player.sendGameText(RPG_MSG_GAME_GAINED,"User %s has been unmuted.\\n"%args[0])
    
    MUTEDPLAYERS[args[0]]=False
    
    


def CmdKick(mob,args):
    from player import Player
    try:
        player = Player.byPublicName(args[0])
    except:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Unknown player %s.\\n"%args[0])
        return
    
    
    if not IsUserSuperior(mob.player.publicName,player.publicName):
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"You do not have the required permission for this action.\\n")
        return

    
    mob.player.sendGameText(RPG_MSG_GAME_GAINED,"Player %s has been kicked.\\n"%args[0])
    world = mob.player.world
    world.kickPlayer(player)
    
def CmdUnban(mob,args):
    if not len(args):
        return
    
    from mud.common.permission import BannedUser
    try:
        banned = BannedUser.byName(args[0])
        banned.destroySelf()
        mob.player.sendGameText(RPG_MSG_GAME_GAINED,"User %s has been unbanned.\\n"%args[0])
        return
    except:
        pass

    mob.player.sendGameText(RPG_MSG_GAME_DENIED,"User %s hasn't been banned.\\n"%args[0])
    

def CmdBan(mob,args):
    from mud.common.permission import User,Role, BannedUser
    from player import Player
    
    if not len(args):
        return

    try:
        player = Player.byPublicName(args[0])
    except:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Unknown player %s.\\n"%args[0])
        return
    
    if not IsUserSuperior(mob.player.publicName,player.publicName):
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"You do not have the required permission for this action.\\n")
        return

    
    try:
        banned = BannedUser.byName(args[0])
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"User %s already banned.\\n"%args[0])
        return
    except:
        pass
    
    try:
        user = User.byName(args[0])
    except:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Unknown user %s.\\n"%args[0])
        return
    
    #bye bye
    BannedUser(name=args[0])
    mob.player.sendGameText(RPG_MSG_GAME_GAINED,"User %s has been banned.\\n"%args[0])


    world = mob.player.world
    world.kickPlayer(player)


def CmdPlayerInfo(mob,args):
    from player import Player
    
    if not len(args):
        return

    try:
        player = Player.byPublicName(args[0])
    except:
        try:
            player = Player.byFantasyName(args[0])
        except:
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Unknown player %s.\\n"%args[0])
            return
    
    ip = "???"
    try:
        if player.avatar and player.avatar.mind:
            ip = player.avatar.mind.broker.transport.getPeer().host
    except:
        pass
        
    mob.player.sendGameText(RPG_MSG_GAME_GAINED,"Player Info for %s:\\n Public Name: %s\\nAvatar Name: %s\\nIP: %s\\n"%(args[0],player.publicName,player.fantasyName,ip))



COMMANDS = {}
COMMANDS['BAN']=CmdBan
COMMANDS['UNBAN']=CmdUnban
COMMANDS['KICK']=CmdKick
COMMANDS['MUTE']=CmdMute
COMMANDS['UNMUTE']=CmdUnmute
COMMANDS['PLAYERINFO']=CmdPlayerInfo


def DoGuardianCommand(player,cmd,args):
    mob = player.curChar.mob
    
    if type(args)!=list:
        args = [args]
    cmd = cmd.upper()
    if COMMANDS.has_key(cmd):
        COMMANDS[cmd](mob,args)
    else:
        print "Unknown Command",cmd
 