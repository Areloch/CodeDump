from random import randint
from sqlobject import *
from defines import *
import spawn
from item import ItemProto,ItemSpellTemp,Item
from spell import SpellProto,Spell
from core import GenMoneyText
from mud.common.persistent import Persistent
from mud.world.shared.playdata import ItemInfo
from mud.world.shared.sounddefs import *
import math
import traceback
from mud.world.itemvariants import AddStatVariant,V_STAT

#Blacksmithing
#Tailoring
#Weapon Craft 
#Armor Craft 
#Alchemy
#Enchanting
#Cooking
#Scribing

WEAPON_SKILLS = (
"1H Pierce",
"2H Pierce",
"1H Impact",
"2H Impact",
"1H Cleave",
"2H Cleave",
"1H Slash",
"2H Slash",
"Archery"
)

ARMOR_SKILLS = (
"Light Armor",
"Medium Armor",
"Heavy Armor",
"Shield"
)
class RecipeIngredient(Persistent):
    recipe = ForeignKey('Recipe')
    itemProto = ForeignKey('ItemProto')
    count = IntCol(default=1)
    
class Recipe(Persistent):
    name = StringCol(alternateID = True)
    
    #result item
    craftedItemProto = ForeignKey('ItemProto')
    craftSound = StringCol(default="")
    
    skillname = StringCol()
    skillLevel = IntCol()
    
    filterClass = StringCol(default="")
    filterRealm = IntCol(default=-1)
    filterRace = StringCol(default="")
    filterLevelMin = IntCol(default=0)
    filterLevelMax = IntCol(default=1000)
    
    costTP = IntCol(default=0L)
    
    ingredients = MultipleJoin('RecipeIngredient')



# --- Blacksmithing
# list of forges per zone, list contains (location,active radius squared)
# Warning: active radiuses need testing
FORGE_LOOKUP = {
"anidaenforest":(654.112, -175.686, 146.782, 25),
"hazerothkeep":(677.667, 511.046, 251.94, 25),
"kauldur":(-231.828, -492.118, 159.758, 25),
"mountain":(650.116, -607.307, 160.346, 25),
"trinst":(128.59, 173.801, 136.85, 25)
}

def doBlacksmithing(mob,recipe,citems = []):
    slevel = mob.skillLevels.get("Blacksmithing",0)
    noForge = False
    notify = False
    if slevel <= 100 or not mob.simObject:
        noForge = True
    elif mob.zone.zone.name not in FORGE_LOOKUP:
        noForge = True
        notify = True
    else:
        mobPos = mob.simObject.position
        forgePos = FORGE_LOOKUP[mob.zone.zone.name]
        x = mobPos[0] - forgePos[0]
        y = mobPos[1] - forgePos[1]
        z = mobPos[2] - forgePos[2]
        if x*x + y*y + z*z - 25 > 0:  # out of range of a forge
            noForge = True
            notify = True
    
    player = mob.player
    char = mob.character
    craftProto = recipe.craftedItemProto
    if notify:
        player.sendGameText(RPG_MSG_GAME_DENIED,"%s can't use a forge here and may only craft items of lesser quality.\\n"%char.name)
    
    # get blacksmithing mods
    protoUseMax = craftProto.useMax
    protoStackDefault = craftProto.stackDefault
    if noForge:
        charges = int(math.ceil(0.5 * float(protoUseMax)))
        stackCount = protoStackDefault
        moneyMod = 5.0
    else:
        mod = float(slevel - 10) / 900.0
        if protoUseMax > 1:
            charges = int(math.ceil(0.5 * float(protoUseMax) * (1.0 + mod)))
            if charges > protoUseMax:  # just a failsafe
                charges = protoUseMax
            stackCount = protoStackDefault
            moneyMod = 0.2 * (float(charges) - float(protoUseMax) / 2.0) + 1.0
        elif craftProto.stackMax > 1:
            charges = protoUseMax
            stackCount = int(float(protoStackDefault) * (1.0 + mod))
            moneyMod = 0.2 * float(stackCount - protoStackDefault) + 1.0
        else:
            charges = protoUseMax
            stackCount = 1
            moneyMod = 1.5 - mod
    
    # check money
    cost = long(moneyMod * recipe.costTP)
    if not player.checkMoney(cost):
        player.sendGameText(RPG_MSG_GAME_DENIED,"This Blacksmithing requires %s.\\n"%GenMoneyText(cost))
        return
    
    targetSlot = RPG_SLOT_CRAFTING0
    consumed = {}
    if not len(citems):  # craft command, check for space and ingredients
        # list ingredients
        itemProtos = {}
        for i in recipe.ingredients:
            proto = i.itemProto
            if proto in itemProtos:
                itemProtos[proto] += i.count
            else:
                itemProtos[proto] = i.count
        emptySlots = range(RPG_SLOT_CRAFTING_BEGIN,RPG_SLOT_CRAFTING_END)
        
        for i in char.items:
            proto = i.itemProto
            if proto in itemProtos:
                # charges on an ingredient represent its durability if max charges > 1
                # only one charge should be consumed per craft and item if max charges > 1
                if proto.useMax > 1:
                    itemProtos[proto] -= 1
                    if proto.craftConsumed:
                        consumed[i] = 1
                else:
                    itemProtos[proto] -= i.stackCount
                    if proto.craftConsumed:
                        if itemProtos[proto] < 0:
                            consumed[i] = i.stackCount + itemProtos[proto]
                        else:
                            consumed[i] = i.stackCount
                if itemProtos[proto] <= 0:
                    del itemProtos[proto]
            if RPG_SLOT_CRAFTING_END > i.slot >= RPG_SLOT_CRAFTING_BEGIN:
                emptySlots.remove(i.slot)
        if len(itemProtos):
            player.sendGameText(RPG_MSG_GAME_DENIED,"%s lacks %s for this craft.\\n"%(char.name,', '.join("%i %s"%(c,i.name) for c,i in itemProtos.iteritems())))
            return
        if not len(emptySlots):
            player.sendGameText(RPG_MSG_GAME_DENIED,"%s has no more room in the crafting inventory.\\n"%char.name)
            return
        targetSlot = emptySlots.pop()
        del emptySlots
    
    # take away items and money
    if len(citems):
        x = 1
        for item in citems:
            iproto = item.itemProto
            if iproto.craftConsumed:
                if iproto.useMax > 1:
                    item.useCharges -= 1
                    if item.useCharges <= 0:
                        player.takeItem(item)
                    else:
                        item.slot = RPG_SLOT_CRAFTING0 + x
                        item.itemInfo.refresh()
                        x += 1
                else:
                    player.takeItem(item)
            else:
                item.slot = RPG_SLOT_CRAFTING0 + x
                item.itemInfo.refresh()
                x += 1
    else:
        for item,count in consumed.items():
            proto = item.itemProto
            if proto.useMax > 1:
                item.useCharges -= 1
                if item.useCharges <= 0:
                    item.stackCount -= 1
                    if item.stackCount <= 0:
                        player.takeItem(item)
                    else:
                        item.useCharges = proto.useMax
                        item.itemInfo.refreshDict({'STACKCOUNT':item.stackCount,'USECHARGES':item.useCharges})
                else:
                    item.itemInfo.refreshDict({'USECHARGES':item.useCharges})
            else:
                item.stackCount -= count
                if item.stackCount <= 0:
                    player.takeItem(item)
                else:
                    item.itemInfo.refreshDict({'STACKCOUNT':item.stackCount})
    player.takeMoney(cost)
    
    craft = craftProto.createInstance()
    craft.slot = targetSlot
    craft.stackCount = stackCount
    craft.useCharges = charges
    craft.setCharacter(char)
    craft.descOverride = "Crafted by %s"%char.name
    craft.crafted = True
    
    player.sendGameText(RPG_MSG_GAME_GAINED,"%s has crafted a %s!\\n"%(char.name,craftProto.name))
    t = GenMoneyText(cost)
    if t:
        player.sendGameText(RPG_MSG_GAME_YELLOW,"This Blacksmithing consumes %s.\\n"%t)
    
    try:
        mlevel = mob.mobSkillProfiles["Blacksmithing"].maxValue
    except KeyError:
        mlevel = 0
    if slevel >= mlevel:
        player.sendGameText(RPG_MSG_GAME_YELLOW,"%s currently cannot gain any more skill in Blacksmithing.\\n"%char.name)
    else:
        char.checkSkillRaise("Blacksmithing",3,4)
    
    if recipe.craftSound:
        player.mind.callRemote("playSound",recipe.craftSound)
    
    return True



# --- ENCHANTING / DISENCHANTING ---
# Some definitions for easier modding
ENCHANT_skillname = 'Enchanting'
# How many lower level enchanting materials will be needed to produce one of a higher level:
ENCHANT_MergeCount = 2
# How many different enchantments can be put on an item at maximum:
ENCHANT_MaxEnchantTypes = 5
# At which level a spell has to be known before a proc enchantment is allowed:
ENCHANT_MinSpellLevelReq = 3
# How many times normal amount of components are needed for the spell proc enchantment
ENCHANT_SpellComponentMod = 3
# list of raw materials
ENCHANT_RawItems = ["Sandstone","Coal","Icy Shard","Bark","Limestone","Quartz","Blighted Shard","Vine","Muck-Covered Stone"]
# list of quality prefixes, 'raw' is not yet enchanted item (Coal, Sandstone, ...), raw can't be dropped, only gained from disenchanting so this prefix won't be used normally and is just here for completion/easier list use
ENCHANT_QualityPrefix = ["Raw","Fractured","Rough","Jagged","Smooth","Clear","Pristine","Exquisite"]
# list of skill required to use or produce an enchanting item with the prefix from above
# rough is still for level 1 since merging ENCHANT_MergeCount fractured focii is the lowest enchantment possible
ENCHANT_QualitySkillReq = [1,1,1,60,120,180,240,300]
# all the quality lists share the same length:
ENCHANT_QualityCount = len(ENCHANT_QualityPrefix)
# list of attributes that raw materials can be enchanted with, their corresponding item attrib strings and difficulty
ENCHANT_RawAttribsLUT = {
"HEALTH":["Health",50],
"MANA":["Ether",50],"ETHER":["Ether",50],
"STAMINA":["Endurance",50],"ENDURANCE":["Endurance",50],
"STRENGTH":["Strength",200],
"BODY":["Constitution",200],"CONSTITUTION":["Constitution",200],
"REFLEX":["Instinct",200],"INSTINCT":["Instinct",200],
"AGILITY":["Nimbleness",200],"NIMBLENESS":["Nimbleness",200],
"DEXTERITY":["Quickness",200],"QUICKNESS":["Quickness",200],
"MIND":["Insight",200],"INSIGHT":["Insight",200],
"WISDOM":["Clarity",200],"CLARITY":["Clarity",200],
"MYSTICISM":["the Arcane",200],"THE ARCANE":["the Arcane",200]
}
# lookuptable of possible focus's per slot, overall max possible value and needed skill (as to suffer no penalty)
# 'all' = applicable to all crafted items whatever the slot
# everything up to and with the 'of' in focii names will be cut before tests
# Max values get scaled with a funcion of second order depending on item level. So absolute max is really hard to achieve with insufficient skill, with insufficient item level even impossible.
# An exquisite focus can only provide 1/10 of this max value, focii of lesser quality even less.
# not all stats can be active at the same time (max ENCHANT_MaxEnchantTypes different types)
# WARNING: to safe another variable, all maxvalues >10 indicate a stat of type int, max values <=10 indicate no conversion from float
ENCHANT_SlotLUT = {
'all':{"Strength":['str',250,300],"Constitution":['bdy',250,300],"Instinct":['ref',250,300],"Nimbleness":['agi',250,300],"Quickness":['dex',250,300],"Insight":['mnd',250,300],"Clarity":['wis',250,300],"the Arcane":['mys',250,300]},
RPG_SLOT_HEAD:{"Health":["maxHealth",800,1],"Ether":["maxMana",4000,1],"Defense":['armor',300,100],"Physical Protection":["resistPhysical",60,500],"Magic Protection":["resistMagical",60,500],"Aelieas":["regenMana",50,800]},
RPG_SLOT_BACK:{"Ether":["maxMana",2400,1],"Defense":['armor',200,100],"Magic Protection":["resistMagical",80,500],"the Sphinx":["castHaste",.15,800]},
RPG_SLOT_CHEST:{"Health":["maxHealth",4000,1],"Endurance":["maxStamina",1500,1],"Defense":['armor',600,100],"Physical Protection":["resistPhysical",80,500],"Fiery Protection":["resistFire",80,500],"Cold Protection":["resistCold",80,500],"Acidity":["resistAcid",80,500],"Electrical Resistance":["resistElectrical",80,500],"the Dwarven King":["regenHealth",30,800]},
RPG_SLOT_ARMS:{"Health":["maxHealth",600,1],"Defense":['armor',300,100],"Fiery Protection":["resistFire",30,500],"Cold Protection":["resistCold",30,500],"Lightning":['castDmgMod',0.75,900]},
RPG_SLOT_HANDS:{"Health":["maxHealth",600,1],"Ether":["maxMana",900,1],"Defense":['armor',200,100],"Fiery Protection":["resistFire",30,500],"Cold Protection":["resistCold",30,500],"Acidity":["resistAcid",30,500],"Electrical Resistance":["resistElectrical",30,500],"the Warling Cleric":['castHealMod',1.5,700],"the Sphinx":["castHaste",.4,800]},
# undead bane enchantment is handled as a special case, if further races are wanted, search for 'undead' and modify accordingly in code, it's easier to test for undead than to evaluate which bane should be applied if multiple are chosen.
RPG_SLOT_PRIMARY:{"the Ghoul Slayer":["Undead Bane",10,400]},	# also different spell procs
RPG_SLOT_RANGED:{"the Ghoul Slayer":["Undead Bane",10,400]},	# also different spell procs
RPG_SLOT_WAIST:{"Health":["maxHealth",600,1],"Defense":['armor',100,100],"Poison Resist":["resistPoison",80,500],"Disease Resist":["resistDisease",80,500],"Volsh":["haste",1.25,800]},
RPG_SLOT_LEGS:{"Health":["maxHealth",800,1],"Endurance":["maxStamina",1200,1],"Defense":['armor',400,100],"Physical Protection":["resistPhysical",60,500],"the Dwarven King":["regenHealth",20,800],"the Cavebear":["regenStamina",20,800]},
RPG_SLOT_FEET:{"Health":["maxHealth",600,1],"Endurance":["maxStamina",3000,1],"Defense":['armor',300,100],"Poison Resist":["resistPoison",75,500],"Disease Resist":["resistDisease",75,500],"Acidity":["resistAcid",50,500],"Electrical Resistance":["resistElectrical",50,500],"the Cavebear":["regenStamina",35,800],"Speed":["move",2.0,800]},
RPG_SLOT_SHIELD:{"Defense":['armor',600,100],"Physical Protection":["resistPhysical",120,500],"Magic Protection":["resistMagical",120,500],"Fiery Protection":["resistFire",120,500],"Cold Protection":["resistCold",120,500],"Poison Resist":["resistPoison",120,500],"Disease Resist":["resistDisease",120,500],"Acidity":["resistAcid",120,500],"Electrical Resistance":["resistElectrical",120,500]},
RPG_SLOT_SHOULDERS:{}
}

def FocusGenSpecific(focusname):
    try:
        focusQuality,focusType = focusname.split(' ',1)
        if not focusQuality in ENCHANT_QualityPrefix:
            return None
        if focusQuality == 'Raw':    # better use directly ItemProto.byName without the raw prefix
            return None
        enchFocus = ItemProto.byName(focusType)
        focus = enchFocus.createInstance()
        focus.spellEnhanceLevel = ENCHANT_QualityPrefix.index(focusQuality) + 10	# spellEnhanceLevel is used for quality of this item type (less attribs), values < 10 are used to identify tomes, so use values 10 - 17
        focus.name = focusname
        focus.slot = -1
        return focus
    except:
        return None



# This function gets invoked when the user uses a '/Enchant ...' command in the console.
# No attributes to this function tries to enchant the crafted item in the crafting window with the focii also therein or if no crafted item is available tries to merge the focii in the crafting window. Else the attribute specifies the desired enchantment upon a raw material or proc on a weapon.
# Only stat - related enchantments can be put on a raw material (str,bdy,ref,agi,dex,mnd,wis,mys,health,mana,stamina), specials stay rare. Before such an added enchantment, these raw materials are of no use for item enchantments. Command used to enchant a raw material is "/enchant focus of ...". Costs for this function are really high. The player looses either stat points, health, mana, stamina and again some mana. Random focii drops are made specially rare so that the player uses this function in conjunction with disenchanting more often. Enchanting as it is is designed for players with high expectations. Other players will have to wait for socketing. This can be made much easier and less costly but should also generate items of lesser value than enchanting. The stat decrease is handled like stat potions, that means they use the same cap. Virtually you could put a stat potion in the crafting window for the enchantment.
# A weapon can be enchanted to proc a specified spell, enchanter has to know this spell for at least ENCHANT_MinSpellLevelReq levels before being able to attempt this and only harmful spells are allowed - no stun, sleep, fear or charms.
def EnchantCmd(mob,enchName):
    # init vars
    player = mob.player
    char = mob.character
    enchFocii = [[] for i in xrange(ENCHANT_QualityCount)]	# list of all items that aid in enchanting, sorted by level
    enchTarget = []	# list of all enchantable items in crafting window (should be only one!)
    emptySlots = range(RPG_SLOT_CRAFTING_BEGIN,RPG_SLOT_CRAFTING_END)	# holds all empty slots in crafting window
    enchanted = False	# if true we merged or enchanted something
    healthCost = 0	# enchanting eventually uses health, this variable holds the costs
    manaCost = 0	# all enchanting uses mana, this variable holds the costs
    staminaCost = 0	# enchanting eventually uses stamina, this variable holds the costs
    statCost = []	# enchanting eventually drains a stat, this variable holds the costs
    slevel = mob.skillLevels.get(ENCHANT_skillname,0)
    if not slevel:
        player.sendGameText(RPG_MSG_GAME_DENIED,"%s doesn't know how to enchant anything.\\n"%char.name)
        return
    if ENCHANT_skillname in mob.skillReuse:
        player.sendGameText(RPG_MSG_GAME_DENIED,"$src is still recovering from a previous enchant,\\n%$srche can enchant again in about %i seconds.\\n"%mob.skillReuse[ENCHANT_skillname],mob)
        return
    mskill = mob.mobSkillProfiles[ENCHANT_skillname]
    mob.skillReuse[ENCHANT_skillname] = mskill.reuseTime
    skillReq = 0	# 'required' skill, for skillup check purposes
    costMod = 1 - 5e-4 * slevel	# with 1000 skill, only half costs for enchanting anything
    costModSQ = costMod * costMod
    
    # don't allow enchanting while doing anything else
    if mob.attacking or mob.charmEffect or mob.isFeared or (mob.sleep > 0) or (mob.stun > 0) or mob.casting:
        player.sendGameText(RPG_MSG_GAME_DENIED,r'$src\'s enchanting failed, $srche is in no condition to enchant anything!\n',mob)
        return
    mob.cancelInvisibility()
    mob.cancelFlying()
    mob.cancelStatProcess("feignDeath","$tgt is obviously not dead!\\n")
    mob.cancelStatProcess("sneak","$tgt is no longer sneaking!\\n")
    
    
    # get a list of all items in the crafting inventory, sort them accordingly
    foundFocus = False	# if true we found at least one enchanting focus
    for item in char.items:
        if RPG_SLOT_CRAFTING_END > item.slot>=RPG_SLOT_CRAFTING_BEGIN:
            emptySlots.remove(item.slot)
            if item.crafted:
                for islot in item.slots:
                    if islot in ENCHANT_SlotLUT:
                        enchTarget.append(item)
                        break
            elif item.skill == ENCHANT_skillname:	# only focii should have this skill attached
                spellEnhanceLevel = item.spellEnhanceLevel
                # raw focii may have a spellEnhanceLevel of 0 because spellEnhanceLevel is item wise and not itemProto, so can only be set dynamically
                if spellEnhanceLevel:
                    spellEnhanceLevel -= 10
                (enchFocii[spellEnhanceLevel]).append(item)
                foundFocus = True
    
    
    # no focusing item found, nothing to enchant here
    if not foundFocus:
        player.sendGameText(RPG_MSG_GAME_DENIED,"%s can't focus on anything to enchant.\\n"%char.name)
        return
    
    
    # check if an attribute has been specified
    if len(enchName):
        firstWord = enchName.split(' ',1)[0]
        
        # raw focus enchantment
        if firstWord == 'FOCUS':
            if not len(enchFocii[0]):
                player.sendGameText(RPG_MSG_GAME_DENIED,"%s doesn't have a raw focus to enchant.\\n"%char.name)
                return
            
            skillReq = 1000
            enchNameAttrib = enchName.split(' OF ',1)[-1]
            try:
                skillReq = ENCHANT_RawAttribsLUT[enchNameAttrib][1]
                enchNameAttrib = ENCHANT_RawAttribsLUT[enchNameAttrib][0]
            except:
                player.sendGameText(RPG_MSG_GAME_DENIED,"%s can't enchant a focus with this attribute.\\n"%char.name)
                return
            
            # pick first available focus
            enchTarget = None
            # no more room in crafting inventory, try to find a raw focus with stackcount <=1
            if not len(emptySlots):
                for foc in enchFocii[0]:
                    if foc.stackCount <= 1:
                        enchTarget = foc
                        break
                if not enchTarget:
                    player.sendGameText(RPG_MSG_GAME_DENIED,"%s has no more room in the crafting inventory.\\n"%char.name)
                    return
            else:
                enchTarget = enchFocii[0][0]
            
            basicCost = skillReq * costModSQ
            if enchNameAttrib == "Health":
                healthCost = int(basicCost * 4)
                manaCost = int(basicCost) << 1
            elif enchNameAttrib == "Ether":
                manaCost = int(basicCost * 6)
            elif enchNameAttrib == "Endurance":
                staminaCost = int(basicCost * 4)
                manaCost = int(basicCost) << 1
            else:
                manaCost = int(basicCost * 8)
                statCost.append(ENCHANT_SlotLUT['all'][enchNameAttrib][0])
                statCost.append(statCost[0]+"Base")
                statCost.append(statCost[0]+"Raise")
                statCost.append(-1)
                statCost.append(getattr(char,statCost[2]))
                # 300 as defined as default in character.py, we don't want this to get any higher
                if statCost[-1] >= 300:
                    player.sendGameText(RPG_MSG_GAME_DENIED,"%s isn't powerful enough for this enchantment.\\n"%char.name)
                    return
            if mob.health < healthCost + 1:	# make sure player can't die from enchantment
                player.sendGameText(RPG_MSG_GAME_DENIED,"%s doesn't have enough health to power the focus.\\n"%char.name)
                return
            if mob.mana < manaCost:
                player.sendGameText(RPG_MSG_GAME_DENIED,"%s doesn't have enough mana to power the focus.\\n"%char.name)
                return
            if mob.mana < staminaCost:
                player.sendGameText(RPG_MSG_GAME_DENIED,"%s doesn't have enough stamina to power the focus.\\n"%char.name)
                return
            
            # check for critical failure, no stat drain if not successful.
            # only crit if enchanter hasn't enough skill, min 10% chance for success.
            if slevel < skillReq and randint(0,int((1.0 - float(slevel)/float(skillReq)) * 10.0)):
                player.sendGameText(RPG_MSG_GAME_DENIED,"%s failed the focus enchantment.\\n"%char.name)
                # linearly decrease drain with higher skill level
                buffMod = 2.0 - float(slevel) / 1000.0
                mob.processesPending.append(Spell(mob,mob,SpellProto.byName("Enchanting - Mana drain"),buffMod,0,True))
                mob.mana -= manaCost
                mob.stamina -= staminaCost
                mob.health -= healthCost
                if mob.health < 1:	# don't let player die because of enchanting failure
                    mob.health = 1
                return
            
            # generate new focus
            newFocus = enchTarget.itemProto.createInstance()
            # can create up to Exquisite (only with highest skill level)
            newFocus.spellEnhanceLevel = int(1+slevel/166)
            newFocus.name = ENCHANT_QualityPrefix[newFocus.spellEnhanceLevel] + " " + newFocus.name + " of " + enchNameAttrib
            newFocus.spellEnhanceLevel += 10	# focii use spellEnhanceLevel 10 - 17; < 10 is used for tomes
            newFocus.descOverride = "This %s gleams with a magical hue. It may be used to enchant items."%enchTarget.name
            if enchTarget.stackCount <= 1:
                newFocus.slot = enchTarget.slot
                player.takeItem(enchTarget)
            else:
                newFocus.slot = emptySlots.pop()
                enchTarget.stackCount -= 1
                enchTarget.itemInfo.refreshDict({'STACKCOUNT':enchTarget.stackCount})
            newFocus.setCharacter(char)
            
            player.sendGameText(RPG_MSG_GAME_GAINED,"%s successfully enchanted a raw focus with mystic power.\\n"%char.name)
            enchanted = True
        
        
        # Weapon proc enchantment, procs are only temporary, duration depending on skill and luck.
        # Only harmful spells can be applied to a weapon - no stun, sleep, fear or charm; and only if the caster knows this spell at least at level ENCHANT_MinSpellLevelReq.
        # To prevent these procs from getting overpowered, the costs for an actual enchantment are pretty high (at least 10* normal spell mana costs added again the item level *50). A spell also needs at least an item of spell level / 0.9 to be allowed. High-end nukes are automagically taken out like this. As a further restriction, the proc only lasts for about one fight, if at all and there's a high chance for failure.
        # One application may be that several players can bestow their power upon a single weapon, shortly before the tank in their group tries to finish off the dangerous mob in a quick strike. Some new kind of preparing for battle.
        else:
            # none or too much enchantment targets in crafting window
            if not len(enchTarget) == 1:
                player.sendGameText(RPG_MSG_GAME_DENIED,"You need to put one single crafted item into the crafting window.\\n")
                return
            enchTarget = enchTarget[0]	# else just get this single target
            enchProto = enchTarget.itemProto
            
            # only weapons can be enchanted with a proc, that means bows and melee weapons
            # exclude arrows because of possible stack with bow procs
            if not enchProto.wpnDamage or enchProto.projectile:
                player.sendGameText(RPG_MSG_GAME_DENIED,"Only melee weapons or bows can be enchanted with a proc.\\n")
                return
            
            # don't allow more than RPG_ITEMPROC_MAX simultaneous procs, included any poisons
            if len(enchTarget.procs) >= RPG_ITEMPROC_MAX:
                player.sendGameText(RPG_MSG_GAME_DENIED,"This weapon can't hold any more power enchantments.\\n")
                return
            
            enchSpell = None
            cspell = None
            # try to get specified spell
            for cspell in char.spells:
                if cspell.spellProto.name.upper() == enchName:
                    enchSpell = cspell
                    cspell = enchSpell.spellProto
                    break
            if not enchSpell:
                player.sendGameText(RPG_MSG_GAME_DENIED,"%s cannot cast this spell.\\n"%char.name)
                return
            if not cspell.spellType&RPG_SPELL_HARMFUL:
                player.sendGameText(RPG_MSG_GAME_DENIED,"Weapons can only be enchanted with harmful spells.\\n")
                return
            if not enchSpell.level >= ENCHANT_MinSpellLevelReq:
                player.sendGameText(RPG_MSG_GAME_DENIED,"%s doesn't know this spell enough to enchant a weapon with it.\\n"%char.name)
                return
            # check if this spell contains stunning, 'sleeping', fearing or charming - don't allow them
            charms = False
            for eff in cspell.effectProtos:
                if eff.flags&RPG_EFFECT_CHARM:
                    charms = True
                    break
            if charms or cspell.affectsStat("stun") or cspell.affectsStat("sleep") or cspell.affectsStat("fear"):
                player.sendGameText(RPG_MSG_GAME_DENIED,"Stun, sleep, fear and charm spells aren't allowed for weapon enchantments.\\n")
                return
            if mob.recastTimers.has_key(cspell):
                player.sendGameText(RPG_MSG_GAME_DENIED,"%s has to wait another %i seconds before attempting to cast this spell again.\\n"%(char.name,int(mob.recastTimers[cspell]/6)))
                return
            
            # costs depending on spell mana cost and item level
            # manaCosts scale only linearly here
            manaCost = int((cspell.manaCost + enchTarget.level * 5) * 10 * costMod)
            staminaCost = int(0.2 * mob.maxStamina * costModSQ)
            if mob.mana < manaCost:
                player.sendGameText(RPG_MSG_GAME_DENIED,"%s doesn't have enough mana to enchant this item.\\n"%char.name)
                return
            if mob.stamina < staminaCost:
                player.sendGameText(RPG_MSG_GAME_DENIED,"%s doesn't have enough stamina to enchant this item.\\n"%char.name)
                return
            
            components = []
            counts = []
            # check for component costs
            if len(cspell.components):
                for c in cspell.components:
                    components.append(c.itemProto)
                    counts.append(int(c.count * ENCHANT_SpellComponentMod))
                checkComponents = components[:]
                checkCounts = counts[:]
                if not player.checkItems(checkComponents,checkCounts,True):
                    needings = []
                    for c,ip in zip(counts,components):
                        if c:
                            needings.append("%i %s"%(c,ip.name))
                    player.sendGameText(RPG_MSG_GAME_DENIED,"$src lacks the spell components for this enchantment,\\n$srche needs: %s\\n"%', '.join(needings),mob)
                    return
            
            # from now on, count the spell as casted
            if cspell.recastTime:
                mob.recastTimers[cspell] = cspell.recastTime
            
            # check if item is allowed to hold that kind of spell power
            # only drain half mana and stamina and don't charge spell ingredients on failure
            if enchTarget.itemProto.level * 0.9 < cspell.level:
                player.sendGameText(RPG_MSG_GAME_DENIED,"The %s can't hold this amount of power and it just seeps out again.\\n"%enchTarget.name)
                mob.mana -= manaCost >> 1
                mob.stamina -= staminaCost >> 1
                return
            
            if len(components):
                # if we get here, the components will get used
                player.takeItems(components,counts)
            
            # check for critical failure, on failure, no enchantment and no skillup but mana drain
            # don't calculate with spell level, since the caster already has some good knowledge of it, defined by ENCHANT_MinSpellLevelReq
            # enchanting 1000 skill -> succeed in 1 of 2 tries,
            # 1 skill -> succeed in 1 of 22 tries
            # also lower durability of weapon on failure
            if randint(0,int(math.ceil(21-0.02*slevel))):
                mob.processesPending.append(Spell(mob,mob,SpellProto.byName("Enchanting failure")))
                player.sendGameText(RPG_MSG_GAME_LOST,"The enchantment was too unstable and vanishes in an explosion!\\n")
                mob.mana -= manaCost
                mob.stamina -= staminaCost
                mob.health -= int(mob.maxHealth * 0.4)
                if mob.health < 1:	# don't let player die because of enchanting failure
                    mob.health = 1
                if enchTarget.repairMax and enchTarget.repair:
                    enchTarget.repair -= randint(1,25)
                    if enchTarget.repair < 0:
                        enchTarget.repair = 0
                    repairRatio = float(enchTarget.repair)/float(enchTarget.repairMax)
                    if not repairRatio:
                        player.sendGameText(RPG_MSG_GAME_RED,"%s's %s has shattered in the explosion! (%i/%i)\\n"%(char.name,enchTarget.name,enchTarget.repair,enchTarget.repairMax))
                        mob.playSound("sfx/Shatter_IceBlock1.ogg")
                    elif repairRatio < .2:
                        player.sendGameText(RPG_MSG_GAME_YELLOW,"%s's %s got severely damaged by the explosion! (%i/%i)\\n"%(char.name,enchTarget.name,enchTarget.repair,enchTarget.repairMax))
                        mob.playSound("sfx/Menu_Horror24.ogg")
                
                enchTarget.itemInfo.refresh()
                return
            
            # calculate skillReq via manacosts; mana costs already get calculated out of needed level to be able to cast the spell, so this is a much easier approach. Item level has been weighed before, so this isn't needed anymore either. This value is only gets used for skillup check purposes.
            skillReq = manaCost / 10
            if skillReq > 1000:
                skillReq = 1000
            
            # apply proc like a poison, effective only for a certain amount of hits
            # duration depending on level 2 - 10 and an additional "luck"-modifier of -3 to 2; yields a nonlinear range of 1-12 (caps at 1)
            duration = int(round(0.008*slevel+2)) - randint(-3,2)
            if duration < 1:
                duration = 1
            # frequency depending on level 10 - 2 and an additional "luck"-modifier of -1 to +5; yields a nonlinear range of 15 - 2 (caps at 2)
            # higher frequency = less often
            frequency = int(round(10-0.008*slevel)) + randint(-1,5)
            if frequency < 2:
                frequency = 2
            newProc = ItemSpellTemp(cspell,RPG_ITEM_TRIGGER_POISON,frequency)
            enchTarget.procs[newProc] = [duration,RPG_ITEMPROC_ENCHANTMENT]
            enchTarget.itemInfo.refresh()
            
            player.sendGameText(RPG_MSG_GAME_GAINED,"%s successfully enchanted the %s with %s.\\n"%(char.name,enchTarget.name,cspell.name))
            enchanted = True
    
    
    # check if we got an enchanting target. If so, apply enchantment
    elif len(enchTarget):
        # too many crafted items that could be enchanted currently in crafting window
        if len(enchTarget) > 1:
            player.sendGameText(RPG_MSG_GAME_DENIED,"It's too stressful to enchant multiple items at once.\\n")
            return
        
        enchTarget = enchTarget[0]	# else just get this single item
        basicProto = enchTarget.itemProto	# get the basic item
        
        primarySuccessMod = 1.0	# the difficulty of the enchantment, 1.0 = succeeds always, used for failure mods
        desiredEnchantments = {}	# list of desired enchantments along with previous values and assigned focii, internally like: {<statname>:[<value>,[<list of assigned focii>]]}
        # desiredEnchantments holds focii which are just wasted with the key 0; value is here number of focii
        desiredEnchantments[0] = [0,[]]
        # Check if the enchanter has basic ability to enchant this item. If not, decrease primary success mod.
        # From 500 skill on, there will be no penalty for enchanting an item of any level.
        skillReq = basicProto.level * 5
        modif = float(slevel) / float(skillReq)
        if modif < 1:
            primarySuccessMod *= modif
        
        # calculate modifier for max possible stat as a function of third order, depending on item level
        # /100 to scale by max item level, +0.005 to set base value for x = 1, 0.995* to scale once more so level 100 gets us max value
        rel = basicProto.level/100.0
        enchStatMod = 0.005 + 0.995 * rel * rel * rel
        
        # concatenate the focus lists for further use, raw items can't be focused on so drop them
        enchFocii = reduce(list.__add__,enchFocii[1:])
        
        # get all active enchantments on this item
        try:
            for var in enchTarget.variants[V_STAT]:
                if desiredEnchantments.has_key(var[0]):  # shouldn't happen normally, but you never know
                    desiredEnchantments[var[0]][0] += var[1]
                else:
                    desiredEnchantments[var[0]] = [var[1],[]]
        except KeyError:
            pass
        if enchTarget.wpnRaceBaneMod:
            # by design only undead bane is allowed to be enchanted, maybe modify for future expansion
            if enchTarget.wpnRaceBane == "Undead":
                desiredEnchantments["Undead Bane"] = [enchTarget.wpnRaceBaneMod,[]]
        
        
        # run through all focii, sorting them and calculating difficulty mods, manaCost and perform different checks
        foundFocus = False
        for foc in enchFocii:
            # check if this focus can actually be applied to the base item typewise
            enchAttrName = foc.name.split(' of ',1)[-1]	# strip everything up to and with the of
            focusType = None
            try:
                focusType = ENCHANT_SlotLUT['all'][enchAttrName]
            except:
                try:
                    focusType = ENCHANT_SlotLUT[basicProto.slots[0]][enchAttrName]
                except:	# this focus can't be used with this item
                    continue
            foundFocus = True
            focusSuccessMod = primarySuccessMod
            # 0 is in meaning equal to 1, but 1 is easier for calculating stuff further down
            if not foc.stackCount:
                foc.stackCount = 1
            # apply focus specific difficulty
            skillReq += int(focusType[2] / 10.0 * float(foc.stackCount))
            modif = float(slevel) / focusType[2]
            if modif < 1:
                focusSuccessMod *= modif
            
            # check if enchanter has enough skill to use this focus quality. If not, decrease focus success mod
            # double the skill is needed to successfully (100%) apply a focus to an item than merging two lower focus's to this one
            spellEnhanceLevel = foc.spellEnhanceLevel - 10
            modif = 0.5 * slevel / float(ENCHANT_QualitySkillReq[spellEnhanceLevel])
            skillReq += int(float(ENCHANT_QualitySkillReq[spellEnhanceLevel]) / 10.0 * float(foc.stackCount))
            if modif < 1:
                focusSuccessMod *= modif
            
            # get stat enchantment value, depending on focus quality, max stat enchantment of that kind and focusSuccessMod
            # values result in 1/40 to 1/10 of what can be maximally achieved, of course nonlinear
            focusEnchantValue = 0.2 * focusType[1] / float(9 - spellEnhanceLevel)
            if focusSuccessMod < 0.01:
                focusSuccessMod = 0.01
            # modify enchantment value by successmod. Successmod = 1 yields 0.8 to 1.2 times standard value, the lower the successmod, the broader the distribution. Max value is always 1.2 but min value goes down to -1.2 (this is per focus)
            # instead of going through a loop for every single focus, directly modify the calculation with the stack count
            focusEnchantValue *= (randint(40*foc.stackCount,60*foc.stackCount) - randint(0,foc.stackCount*int(round(1/focusSuccessMod - 1)))) / 50.0
            
            
            # check if this enchantment is allowed relative to max enchantments, store focus accordingly
            if desiredEnchantments.has_key(focusType[0]):
                # It's more difficult to modify an already existing enchantment than to create a new one, because the existing forces have to be altered
                manaCost += 2*focusType[2]*foc.stackCount
                desiredEnchantments[focusType[0]][0] += focusEnchantValue
                desiredEnchantments[focusType[0]][1].append(foc)
                # clamp to max value, also power wasted drains additionally on mana
                focMaxValue = enchStatMod*focusType[1]
                if desiredEnchantments[focusType[0]][0] > focMaxValue:
                    manaCost += int(200 * (desiredEnchantments[focusType[0]][0]/focMaxValue - 1.0))
                    desiredEnchantments[focusType[0]][0] = focMaxValue
                # all max values <= 10 indicate a float type for stat value as per definition of the ENCHANT_SlotLUT
                if focusType[1] > 10:
                    desiredEnchantments[focusType[0]][0] = int(math.ceil(desiredEnchantments[focusType[0]][0]))
            elif len(desiredEnchantments) <= ENCHANT_MaxEnchantTypes:	# 0 item is always present, but doesn't count
                manaCost += focusType[2]*foc.stackCount
                desiredEnchantments[focusType[0]] = [focusEnchantValue,[foc]]
                # clamp to max value, also power wasted drains additionally on mana
                focMaxValue = enchStatMod*focusType[1]
                if desiredEnchantments[focusType[0]][0] > focMaxValue:
                    manaCost += int(100 * (desiredEnchantments[focusType[0]][0]/focMaxValue - 1.0))
                    desiredEnchantments[focusType[0]][0] = focMaxValue
                # all max values <= 10 indicate a float type for stat value as per definition of the ENCHANT_SlotLUT
                if focusType[1] > 10:
                    desiredEnchantments[focusType[0]][0] = int(math.ceil(desiredEnchantments[focusType[0]][0]))
            else:	# else this focus just gets wasted, big number of wasted focii will further increase primary successmod
                # trying to enchant an item with energy it can't hold uses up more mana than normal
                # it's a more realistic warning to the player when he can't afford the enchantment
                manaCost += 3*focusType[2]*foc.stackCount
                desiredEnchantments[0][1].append(foc)
                desiredEnchantments[0][0] += foc.stackCount
        # apply cost mod on mana costs
        manaCost = int(manaCost * costMod)
        
        
        # check if we still have some applicable focii left and if player can afford the enchantment manawise
        if not foundFocus:
            player.sendGameText(RPG_MSG_GAME_DENIED,"%s doesn't know how to use these focii in conjuction with the %s.\\n"%(char.name,enchTarget.name))
            return
        if mob.mana < manaCost:
            player.sendGameText(RPG_MSG_GAME_DENIED,"%s doesn't have enough mana for this enchantment.\\n"%char.name)
            return
        
        # modify primary successmod by the number of focii, the player tries to force enchant. Two are allowed without penalty
        if desiredEnchantments[0][0]:
            modif = 2.0 / desiredEnchantments[0][0]
            if modif < 1.0:
                primarySuccessMod *= modif
        
        # check for critical failure (item gets destroyed, along with all focus ingredients)
        # if this test gets passed, the item will be enchanted, for good or worse
        if primarySuccessMod < 1:
            if not randint(0,int(primarySuccessMod*10)):
                mob.processesPending.append(Spell(mob,mob,SpellProto.byName("Enchanting failure")))
                player.takeItem(enchTarget)
                for foc in enchFocii:
                    player.takeItem(foc)
                mob.mana -= manaCost
                mob.health -= int(mob.maxHealth * 0.4)
                if mob.health < 1:	# don't let player die because of enchanting failure
                    mob.health = 1
                player.sendGameText(RPG_MSG_GAME_LOST,"%s accidentally turned this enchantment into a puff of smoke.\\n"%char.name)
                return
        
        # cap skill weight
        if skillReq > 1000:
            skillReq = 1000
        
        
        # generate enchanted item
        enchTarget.levelOverride = basicProto.level
        enchTarget.clearVariants()
        if desiredEnchantments[0][0]:
            player.sendGameText(RPG_MSG_GAME_LOST,"The %s can't hold all of that power and some of it just seeps out again.\\n"%enchTarget.name)
        expungeList = desiredEnchantments.pop(0)
        expungeList = expungeList[1]
        for foc in expungeList:
            player.takeItem(foc)
        for attr in desiredEnchantments:
            enchValue = desiredEnchantments[attr][0]
            for foc in desiredEnchantments[attr][1]:
                player.takeItem(foc)
            if not enchValue:
                continue
            enchanted = True
            AddStatVariant(enchTarget,attr,enchValue)
            enchTarget.levelOverride += 2	# increase item level by 2 for every added stat
        if enchanted:
            enchTarget.name = "Enchanted " + basicProto.name
            if enchTarget.levelOverride > 100:
                enchTarget.levelOverride = 100
            enchTarget.descOverride = enchTarget.descOverride.split('\\n')[0] + "\\nEnchanted by %s"%char.name
            enchTarget.hasVariants = True
            enchTarget.spellEnhanceLevel = 9999	# flag as enchanted, hack
        else:
            enchTarget.descOverride = enchTarget.descOverride.split('\\n')[0]	# strip eventual "Enchanted by"
            enchTarget.hasVariants = False
            enchTarget.spellEnhanceLevel = 0	# hack, flag as not enchanted
        enchTarget.crafted = True
        enchTarget.refreshFromProto()
        enchanted = True
    
    
    # try to merge focii (only one appliance even if there are more possibilities)
    else:
    	# ignore raw and exquisite items, since they can't be merged
    	# qualityIndex actually stores the index of the higher focus
        for qualityIndex,partialFociiList in zip(range(2,ENCHANT_QualityCount),enchFocii[1:-1]):
            # no focus at this level, skip
            if not len(partialFociiList):
                continue
            
            # Check for skill level and mana.
            # Merging focii is a more "traditional" process, player needs exact skill to merge.
            skillReq = ENCHANT_QualitySkillReq[qualityIndex]
            if slevel < skillReq:
                player.sendGameText(RPG_MSG_GAME_DENIED,"%s doesn't know how to merge these items yet.\\n"%char.name)
                return
            manaCost = int(skillReq * 10 * costModSQ)	# merging uses up to 3000 mana for highest merge
            if mob.mana < manaCost:
                player.sendGameText(RPG_MSG_GAME_DENIED,"%s doesn't have enough mana to merge these items.\\n"%char.name)
                return
            
            # look for something to merge
            # first, get a list of all entries with the same name on this level
            focusName = partialFociiList[0].name
            focusCount = partialFociiList[0].stackCount
            # stackCount = 0 is the same as = 1, but 1 is easier for calculation and tests
            if not focusCount:
                focusCount = 1
            for counter in xrange(1,len(partialFociiList)):
                foc = partialFociiList[counter]
                if foc.name == focusName:
                    if not foc.stackCount:
                        focusCount += 1
                    else:
                        focusCount += foc.stackCount
                else:
                    player.sendGameText(RPG_MSG_GAME_DENIED,"Only focii of the same kind can be merged.\\n")
                    return
            
            # not enough of this focus type
            if focusCount < ENCHANT_MergeCount:
                player.sendGameText(RPG_MSG_GAME_DENIED,"%s hasn't enough %s to merge.\\n"%(char.name,focusName))
                return
            
            # check if we have enough place in the crafting inventory to store the new focus
            if not len(emptySlots):
                player.sendGameText(RPG_MSG_GAME_DENIED,"%s has no more room in the crafting inventory.\\n"%char.name)
                return
            
            # else try to merge
            focusNameStripped = focusName.split(' ',1)[-1]	# away with the quality prefix
            focusShort = focusNameStripped.split(' of ',1)[0]
            newFocusKind = ItemProto.byName(focusShort)
            newFocus = newFocusKind.createInstance()
            newFocus.name = ENCHANT_QualityPrefix[qualityIndex] + " " + focusNameStripped
            newFocus.descOverride = "This %s gleams with a magical hue. It may be used to enchant items."%focusShort
            newFocus.spellEnhanceLevel = qualityIndex + 10	# focus spellEnhanceLevel range is 10-17 (and 0) because of tomes
            newFocus.slot = emptySlots.pop()
            newFocus.setCharacter(char)
            # remove correct amount of lesser focii
            remainingKills = ENCHANT_MergeCount
            for eraseFoc in partialFociiList:
                eraseCount = eraseFoc.stackCount
                if not eraseCount:
                    eraseCount = 1
                if eraseCount <= remainingKills:
                    player.takeItem(eraseFoc)
                    remainingKills -= eraseCount
                else:
                    eraseFoc.stackCount -= remainingKills
                    eraseFoc.itemInfo.refreshDict({'STACKCOUNT':eraseFoc.stackCount})
                    break
                if not remainingKills:
                    break
            
            enchanted = True
            player.sendGameText(RPG_MSG_GAME_GAINED,"%s successfully merged %i focii.\\n"%(char.name,ENCHANT_MergeCount))
            break
    
    
    if not enchanted:
        player.sendGameText(RPG_MSG_GAME_DENIED,"%s wasn't able to do anything with these items.\\n"%char.name)
        return
    
    
    else:
        mob.processesPending.append(Spell(mob,mob,SpellProto.byName("Dis - Enchanting")))
        mob.health -= healthCost
        mob.mana -= manaCost
        mob.stamina -= staminaCost
        if len(statCost):
            setattr(char,statCost[2],int(statCost[4]-statCost[3]))
            setattr(mob.spawn,statCost[1],int(getattr(mob.spawn,statCost[1])+statCost[3]))
            setattr(mob,statCost[0],int(getattr(mob,statCost[0])+statCost[3]))
            player.cinfoDirty = True
        
        try:
            mlevel = mob.mobSkillProfiles[ENCHANT_skillname].maxValue
        except KeyError:
            mlevel = 0
        if slevel >= mlevel:
            player.sendGameText(RPG_MSG_GAME_YELLOW,"%s currently cannot gain any more skill in %s.\\n"%(char.name,ENCHANT_skillname))
        elif slevel - skillReq < 10:
            char.checkSkillRaise(ENCHANT_skillname,1,1)
        else:
            player.sendGameText(RPG_MSG_GAME_YELLOW,"%s can't learn anything new from this enchantment.\\n"%char.name)
        player.sendGameText(RPG_MSG_GAME_YELLOW,"%s feels drained.\\n"%char.name)
    
    return



# This function allows the user to disenchant an artifact class item (which has been put into crafting window). If the item to be disenchanted is a player-enchanted item, the attribute to be stripped can be specified in the command line (attribute like in the automatic item stat description). Else the item gets stripped of all attributes and there is a chance to gain raw enchantment materials or trigger a mana regen spell, based on skill level (low chance). Soulbound items can't be disenchanted as to prevent quest item disenchantment.
def DisenchantCmd(mob,attribs):
    player = mob.player
    char = mob.character
    slevel = mob.skillLevels.get('Disenchanting',0)
    if not slevel:
        player.sendGameText(RPG_MSG_GAME_DENIED,"%s doesn't know how to disenchant anything.\\n"%char.name)
        return
    if 'Disenchanting' in mob.skillReuse:
        player.sendGameText(RPG_MSG_GAME_DENIED,"$src is still recovering from a previous disenchant,\\n$srche can disenchant again in about %i seconds.\\n"%mob.skillReuse['Disenchanting'],mob)
        return
    mskill = mob.mobSkillProfiles['Disenchanting']
    mob.skillReuse['Disenchanting'] = mskill.reuseTime
    disenchanted = False
    skillReq = 0	# required skill to disenchant something, for skillup check purposes (in general there isn't a specific skill required, but outcome depends upon skill)
    diffMod = 1000	# difficulty of the disenchantment (depends upon item/skill level and kind of disenchantment); diffMod < 0 means char has some 'experience' with these things, cap to -500
    manaCost = 0	# how much mana this disenchanting costs
    
    
    # don't allow disenchanting while doing anything else
    if mob.attacking or mob.charmEffect or mob.isFeared or (mob.sleep > 0) or (mob.stun > 0) or mob.casting:
        player.sendGameText(RPG_MSG_GAME_DENIED,r'$src\'s disenchanting failed, $srche is in no condition to disenchant anything!\n',mob)
        return
    mob.cancelInvisibility()
    mob.cancelFlying()
    mob.cancelStatProcess("feignDeath","$tgt is obviously not dead!\\n")
    mob.cancelStatProcess("sneak","$tgt is no longer sneaking!\\n")
    
    
    # get a list of all items in the crafting inventory
    disenchTarget = []
    for item in char.items:
        if RPG_SLOT_CRAFTING_END > item.slot >= RPG_SLOT_CRAFTING_BEGIN:
            disenchTarget.append(item)
    
    
    # if there's more than one or no item in the crafting window, warn the user and return
    if not len(disenchTarget) == 1:
        player.sendGameText(RPG_MSG_GAME_DENIED,"You need to put one single item into the crafting window.\\n")
        return
    
    
    disenchTarget = disenchTarget[0]	# else just get the single item
    # extract enchantments currently applied to the item
    disenchTargetStats = []
    if not disenchTarget.spellEnhanceLevel == 9999:
        for st in disenchTarget.itemProto.stats:
            disenchTargetStats.append((st.statname,st.value))
    try:
        disenchTargetStats.extend(disenchTarget.variants[V_STAT])
    except KeyError:
        pass
    if not len(disenchTargetStats):
        player.sendGameText(RPG_MSG_GAME_DENIED,"This item doesn't bear any enchantments and therefore can't be disenchanted.\\n")
        return
    disenchItemLevel = disenchTarget.level	# level of the item to be disenchanted
    
    # modify item level by class recommendations
    # take max level for difficulty calculations
    classes = list(disenchTarget.itemProto.classes)
    if len(classes):
        for cl in classes:
            if cl.level > disenchItemLevel:
                disenchItemLevel = cl.level
    
    # create a list of all free crafting slots
    freeslots = range(RPG_SLOT_CRAFTING_BEGIN,RPG_SLOT_CRAFTING_END)
    freeslots.remove(disenchTarget.slot)
    
    
    # player enchanted item, strip one single enchantment
    if disenchTarget.flags&RPG_ITEM_ENCHANTED and disenchTarget.crafted:
        # it's more difficult to just remove a single enchantment
        skillReq = disenchItemLevel*10
        diffMod = skillReq - slevel
        if diffMod < -500:
            diffMod = -500
        
        # charge the player mana for disenchanting
        # mana costs increase cubic with item level and decrease quadratic with skill level
        # 1000 skillpoints - lvl 100 item ~ (4096 * stat count) mana
        # 1000 skillpoints - lvl 1 item ~ (2 * stat count) mana
        # 1 skillpoint - lvl 100 item ~ (65536 * stat count) mana
        # 1 skillpoint - lvl 1 item ~ (24 * stat count) mana
        iScale = float(disenchItemLevel) * 0.15 + 1.0
        sScale = (1000.0 - float(slevel)) / 333.0 + 1.0
        isScale = iScale * sScale
        manaCost = int(round(isScale * isScale * iScale * len(disenchTargetStats)))
        if mob.mana < manaCost:
            player.sendGameText(RPG_MSG_GAME_DENIED,"%s doesn't have enough mana to disenchant this item.\\n"%char.name)
            return
        
        # critical failure, destroy item, no skillup or anything but drain mana
        if diffMod>0 and randint(0,int(diffMod/10.0)):
            mob.processesPending.append(Spell(mob,mob,SpellProto.byName("Enchanting failure")))
            player.sendGameText(RPG_MSG_GAME_LOST,"%s drained too much energy, accidentally destroying the %s.\\n"%(char.name,disenchTarget.name))
            player.takeItem(disenchTarget)
            mob.mana -= manaCost
            return
        
        # get stat names
        disenchTypeNames = []
        for dts in disenchTargetStats:
            disenchTypeNames.append(dts[0].upper())
        # if no attribute specified just strip the first stat attribute in list
        disenchIndex = 0
        # try to strip specified attribute (only allowed on player enchanted items)
        if len(attribs):
            try:
                if attribs == 'HEALTH':
                    attribs = 'maxHealth'
                elif attribs == 'MANA':
                    attribs = 'maxMana'
                elif attribs == 'STAMINA':
                    attribs = 'maxStamina'
                elif attribs == 'MELEE HASTE':
                    attribs = 'haste'
                elif attribs == 'CASTING HASTE':
                    attribs = 'castHaste'
                elif attribs == 'REGENERATION':
                    attribs = 'regenHealth'
                elif attribs == 'REVITALIZATION':
                    attribs = 'regenStamina'
                elif attribs == 'MANA REGEN':
                    attribs = 'regenMana'
                disenchIndex = disenchTypeNames.index(attribs)
            except:
                player.sendGameText(RPG_MSG_GAME_DENIED,"Couldn't find %s in %s's stats. Possible stats are: %s\\n"%(attribs,disenchTarget.name,', '.join(disenchTypeNames)))
                return
        disenchTargetStats.pop(disenchIndex)
        
        # recreate partially disenchanted item
        disenchTarget.clearVariants()
        disenchTarget.name = disenchTarget.itemProto.name
        if len(disenchTargetStats):
            disenchTarget.name = "Enchanted " + disenchTarget.name
            for oldStat in disenchTargetStats:
                AddStatVariant(disenchTarget,oldStat[0],oldStat[1])
            # increase itemlevel by 2 per stat
            disenchTarget.levelOverride = disenchTarget.itemProto.level + 2*len(disenchTargetStats)
            if disenchTarget.levelOverride > 100:
                disenchTarget.levelOverride = 100
            disenchTarget.hasVariants = True
            disenchTarget.spellEnhanceLevel = 9999	# flag as enchanted
        else:
            disenchTarget.descOverride = disenchTarget.descOverride.split('\\n')[0]
            disenchTarget.levelOverride = disenchTarget.itemProto.level
            disenchTarget.hasVariants = False
            disenchTarget.spellEnhanceLevel = 0	# hack, flag as not enchanted
        disenchTarget.crafted = True
        disenchTarget.refreshFromProto()
        
        disenchanted = True
    
    
    elif disenchTarget.flags&RPG_ITEM_ARTIFACT and not disenchTarget.flags&RPG_ITEM_SOULBOUND:
        # the following means, that it is possible to gain disenchanting skill levels by disenchanting artifacts only up to 750. After that, disenchanting previously enchanted items is necessary (of at least item level 75). Currently it is not possible to get 1000 in skill due to crafted item levels limitations.
        skillReq = int(disenchItemLevel*7.4)
        diffMod = skillReq - slevel	# min: 7-1000=-993
        if diffMod < -500:
            diffMod = -500
        
        # charge the player mana for disenchanting, only half costs for this kind of disenchantment
        # mana costs increase cubic with item level and decrease quadratic with skill level
        # 1000 skillpoints - lvl 100 item ~ (2048 * stat count) mana
        # 1000 skillpoints - lvl 1 item ~ (1 * stat count) mana
        # 1 skillpoint - lvl 100 item ~ (32768 * stat count) mana
        # 1 skillpoint - lvl 1 item ~ (12 * stat count) mana
        iScale = float(disenchItemLevel) * 0.15 + 1.0
        sScale = (1000.0 - float(slevel)) / 333.0 + 1.0
        isScale = iScale * sScale
        manaCost = int(round(0.5 * isScale * isScale * iScale * len(disenchTargetStats)))
        if mob.mana < manaCost:
            player.sendGameText(RPG_MSG_GAME_DENIED,"%s doesn't have enough mana to disenchant this item.\\n"%char.name)
            return
        
        # critical failure, destroy item, no skillup or anything but drain mana
        # chance for critical failure for artifacts is higher than for player enchanted items, even if the skill required is lower here because the enchantments on artifacts are more ancient.
        if diffMod > 0 and randint(0,int(diffMod/5.0)):
            mob.processesPending.append(Spell(mob,mob,SpellProto.byName("Enchanting failure")))
            player.sendGameText(RPG_MSG_GAME_LOST,"%s drained too much energy, accidentally turning the %s to dust.\\n"%(char.name,disenchTarget.name))
            player.takeItem(disenchTarget)
            mob.mana -= manaCost
            return
        
        # strip all stats but otherwise leave the item 'intact'
        else:
            disenchTarget.name = "Powerless " + disenchTarget.name
            disenchTarget.clearVariants()
            disenchTarget.descOverride = "Stripped from it's power by %s"%char.name
            # as class recommendations are based on itemProto, these can't be adjusted.
            # they also don't need to...
            disenchTarget.levelOverride = disenchTarget.itemProto.level - 10
            if disenchTarget.levelOverride < 1:
                disenchTarget.levelOverride = 1
            disenchTarget.hasVariants = True	# to ensure all stats get removed
            disenchTarget.spellEnhanceLevel = 9999	# 9999 used as 'enchanted' identifier
            disenchTarget.refreshFromProto()
        disenchanted = True
    
    
    # no other items than enchanted or artifacts and no soulbounds allowed for disenchanting
    else:
        player.sendGameText(RPG_MSG_GAME_DENIED,"%s can't disenchant this kind of item.\\n"%char.name)
        return
    
    
    # if we disenchanted something, check for skillup and item/regen gains
    if disenchanted:
        mob.processesPending.append(Spell(mob,mob,SpellProto.byName("Dis - Enchanting")))
        player.sendGameText(RPG_MSG_GAME_GAINED,"%s successfully disenchanted the artifact.\\n"%char.name)
        mob.mana -= manaCost
        
        # chance to get raw enchanting materials, nonlinear distribution ranging from 5% to 100%
        if not randint(0,int(math.ceil((diffMod+500)/75.0))):
            # number of raw enchanting materials we can salvage, max 3 from 900 skill on
            numEnchItems = randint(1,int(slevel/450)+1)
            for i in xrange(numEnchItems):
                enchItem = ItemProto.byName(ENCHANT_RawItems[randint(0,len(ENCHANT_RawItems)-1)])
                item = enchItem.createInstance()
                if len(freeslots):
                    item.slot = freeslots.pop()
                    item.setCharacter(char)
                else:
                    break
            player.sendGameText(RPG_MSG_GAME_GAINED,"Some of the mystic energy drained from the item forms into solid matter.\\n")
            
        # small chance to trigger a mana regen effect upon disenchanting, depending on skill level
        # 1 skill - 1%, 1000 skill - 10%
        if not randint(0,int(100-slevel*0.09)):
            # modify strength of the spell by skill level - lvl 1 ~ 1.0, lvl 1000 ~ 11.0
            buffMod = slevel / 100.0 + 1.0
            mob.processesPending.append(Spell(mob,mob,SpellProto.byName("Disenchanting Focus"),buffMod))
            player.sendGameText(RPG_MSG_GAME_GAINED,"%s managed to harness some mystic energy drained from the item.\\n"%char.name)
        
        try:
            mlevel = mob.mobSkillProfiles['Disenchanting'].maxValue
        except KeyError:
            mlevel = 0
        if slevel >= mlevel:
            player.sendGameText(RPG_MSG_GAME_YELLOW,"%s currently cannot gain any more skill in Disenchanting.\\n"%char.name)
        elif slevel - skillReq < 10:
            char.checkSkillRaise('Disenchanting',1,1)
        else:
            player.sendGameText(RPG_MSG_GAME_YELLOW,"%s can't learn anything new from this disenchantment.\\n"%char.name)
    return



def Craft(mob):
    player = mob.player
    char = mob.character
    
    gotone = False
    
    citems = []
    for item in char.items:
        if RPG_SLOT_CRAFTING_END > item.slot >= RPG_SLOT_CRAFTING_BEGIN:
            citems.append(item)
            
    if not len(citems):
        return #XXX should be caught on client
    
    #TO DO RECIPES
    recipe = None
    for ingred in citems[0].itemProto.ingredients:
        rec = ingred.recipe
        #test this recipe
        ringreds = list(rec.ingredients)
        if not len(ringreds):
            continue
        stackCounts = []
        counts = []
        ips = []
        for i in ringreds:
            counts.append(i.count)
            ips.append(i.itemProto)
        
        passed = True
        
        for item in citems:
            found = False
            for x in xrange(0,len(ringreds)):
                if not counts[x]:
                    continue
                if item.itemProto == ips[x]:
                    sc = item.stackCount
                    if not sc:
                        sc = 1
                    counts[x]-=sc
                    found=True
                    break
            if not found:
                passed = False
                break
        
        if passed:
            for x in counts:
                if x: #can be negative if too much
                    passed = False
                    break
            
        if passed:
            recipe = rec
            break
    
    if recipe:
        cskillname = recipe.skillname
        cskilllevel = mob.skillLevels.get(cskillname,0)
        
        passed = True
        if not player.checkMoney(recipe.costTP):
            player.sendGameText(RPG_MSG_GAME_DENIED,"This %s requires %s.\\n"%(cskillname,GenMoneyText(recipe.costTP)))
            passed = False

        
        if cskilllevel >= recipe.skillLevel and passed:
            if cskillname in mob.skillReuse:
                player.sendGameText(RPG_MSG_GAME_DENIED,"$src is still cleaning $srchis tools,\\nsrche can use the %s skill again in about %i seconds.\\n"%(cskillname,mob.skillReuse[cskillname]),mob)
                return
            if cskillname != 'Archery':
                mskill = mob.mobSkillProfiles[cskillname]
                mob.skillReuse[cskillname] = mskill.reuseTime
                if cskillname == "Blacksmithing":
                    doBlacksmithing(mob,recipe,citems)
                    return
            else:
                mob.skillReuse[cskillname] = 12
            #TODO Filters
            gotone = True
            player.takeMoney(recipe.costTP)
            item = recipe.craftedItemProto.createInstance()
            item.slot = RPG_SLOT_CRAFTING0
            item.setCharacter(char)
            item.descOverride = "Crafted by %s"%char.name
            item.crafted = True
            
            player.sendGameText(RPG_MSG_GAME_GAINED,"%s has crafted a %s!\\n"%(char.name,item.name))
            t = GenMoneyText(recipe.costTP)
            if t:
                player.sendGameText(RPG_MSG_GAME_YELLOW,"This %s consumes %s.\\n"%(cskillname,t))
            
            # modification already got cskilllevel, why query a second time?
            try:
                mlevel = mob.mobSkillProfiles[cskillname].maxValue
            except KeyError:
                mlevel = 0
                
            if cskilllevel >= mlevel:	# modification cskilllevel = slevel
                player.sendGameText(RPG_MSG_GAME_YELLOW,"%s currently cannot gain any more skill in %s.\\n"%(char.name,cskillname))
            
            if cskilllevel - recipe.skillLevel < 15:    
                char.checkSkillRaise(cskillname,1,2)
            
            if recipe.craftSound:
                player.mind.callRemote("playSound",recipe.craftSound)
            
        else:
            if cskilllevel < recipe.skillLevel:
                player.sendGameText(RPG_MSG_GAME_DENIED,"%s requires a %i skill in %s.\\n"%(char.name,recipe.skillLevel,cskillname))
    
    
    #TOME UPGRADES (4 of same gets you next upper)    
    if mob.skillLevels.get("Scribing",0) and not gotone and not recipe:
        if "Scribing" in mob.skillReuse:
            player.sendGameText(RPG_MSG_GAME_DENIED,"$src is still cleaning $srchis tools,\\n$srche can use the %s skill again in about %i seconds.\\n"%("Scribing",mob.skillReuse["Scribing"]),mob)
            return
        mskill = mob.mobSkillProfiles["Scribing"]
        mob.skillReuse["Scribing"] = mskill.reuseTime
        spellEnhanceLevel = citems[0].spellEnhanceLevel
        name = citems[0].name
        passed = True
        if spellEnhanceLevel > 0 and spellEnhanceLevel < 10:
            count = 0
            for item in citems:
                if not item.spellEnhanceLevel or spellEnhanceLevel != item.spellEnhanceLevel or name!=item.name:
                    passed = False
                    break
                count+=item.stackCount
                
            if count == 2 and passed:
                #upgrade tome       
                gotone = True
                
                char.checkSkillRaise("Scribing",1,2)
                player.mind.callRemote("playSound","sfx/Pencil_WriteOnPaper2.ogg") 
                player.sendGameText(RPG_MSG_GAME_GOOD,r'%s has successfully combined the knowledge of the %s tomes.\n'%(char.name,citems[0].name))
                
                spellname = citems[0].itemProto.spellProto.name
                scroll = ItemProto.byName("Scroll of %s"%spellname)
                nitem = scroll.createInstance("STUFF/38")
                nitem.spellEnhanceLevel = spellEnhanceLevel+1
                roman = ("I","II","III","IV","V","VI","VII","VIII","IX","X") #I isn't used
                
                nitem.name = "Tome of %s %s"%(spellname,roman[spellEnhanceLevel])
                nitem.slot = RPG_SLOT_CRAFTING0
                nitem.descOverride = "This tome contains secrets of the %s spell. %s must have level %s knowledge to understand this tome."%(spellname,char.name,roman[spellEnhanceLevel-1])
                nitem.setCharacter(char)	# modification no itemInfo reset needed after this function call
    
                    
    if not gotone:
        player.sendGameText(RPG_MSG_GAME_DENIED,r'%s is unable to craft anything with these items.\n'%(char.name))
    else:
        x = 1
        for item in citems:
            iproto = item.itemProto
            if iproto.craftConsumed:
                if iproto.useMax > 1:
                    item.useCharges -= 1
                    if item.useCharges <= 0:
                        player.takeItem(item)
                    else:
                        item.slot = RPG_SLOT_CRAFTING0 + x
                        item.itemInfo.refresh()
                        x += 1
                else:
                    player.takeItem(item)
            elif not recipe:
                player.takeItem(item)
            else:
                item.slot = RPG_SLOT_CRAFTING0 + x
                item.itemInfo.refresh()
                x += 1






def CraftCommand(mob,rname):
    player = mob.player
    char = mob.character
    
    try:
        recipe = Recipe.byName(rname)
    except:
        try:
            #
            # List of words that need to be lowercase in recipe names.
            #
            lowercaseWords = ("a", "the", "of")
            
            formattedRecipeName = []
            firstWord = True
            
            #
            # Populate the formattedRecipeName list, formatting words before appending.
            #
            for word in rname.split():
                wlower = word.lower()
                if firstWord or wlower not in lowercaseWords:
                    formattedRecipeName.append(word.capitalize())
                    firstWord = False
                else:
                    formattedRecipeName.append(wlower)
            
            recipe = Recipe.byName(' '.join(formattedRecipeName))
        
        except:
            player.sendGameText(RPG_MSG_GAME_DENIED,r'%s is not a valid recipe.  Please check the recipe name and try again.\n'%(rname))        
            return
    
    
    cskillname = recipe.skillname
    cskilllevel = mob.skillLevels.get(cskillname,0)
    
    if not player.checkMoney(recipe.costTP):
        player.sendGameText(RPG_MSG_GAME_DENIED,"This %s requires %s.\\n"%(cskillname,GenMoneyText(recipe.costTP)))
        return
    
    if cskilllevel >= recipe.skillLevel:
        if cskillname in mob.skillReuse:
            player.sendGameText(RPG_MSG_GAME_DENIED,"$src is still cleaning $srchis tools,\\n$srche can use the %s skill again in about %i seconds.\\n"%(cskillname,mob.skillReuse[cskillname]),mob)
            return
        if cskillname != 'Archery':
            mskill = mob.mobSkillProfiles[cskillname]
            mob.skillReuse[cskillname] = mskill.reuseTime
            if cskillname == "Blacksmithing":
                doBlacksmithing(mob,recipe)
                return
        else:
            mob.skillReuse[cskillname] = 12
        craftProto = recipe.craftedItemProto
        
        # list ingredients
        itemProtos = {}
        for i in recipe.ingredients:
            proto = i.itemProto
            if proto in itemProtos:
                itemProtos[proto] += i.count
            else:
                itemProtos[proto] = i.count
        emptySlots = range(RPG_SLOT_CRAFTING_BEGIN,RPG_SLOT_CRAFTING_END)
        consumed = {}
        stackItems = []
        
        # define two different loops, so we don't have to check for stackMax in the loop each time
        # also directly check ingredients and consumables within the same loop
        if craftProto.stackMax > 1:
            freeSpace = 0
            for i in char.items:
                proto = i.itemProto
                if proto in itemProtos:
                    # charges on an ingredient represent its durability if max charges > 1
                    # only one charge should be consumed per craft and item if max charges > 1
                    if proto.useMax > 1:
                        itemProtos[proto] -= 1
                        if proto.craftConsumed:
                            consumed[i] = 1
                    else:
                        itemProtos[proto] -= i.stackCount
                        if proto.craftConsumed:
                            if itemProtos[proto] < 0:
                                consumed[i] = i.stackCount + itemProtos[proto]
                            else:
                                consumed[i] = i.stackCount
                    if itemProtos[proto] <= 0:
                        del itemProtos[proto]
                if RPG_SLOT_CRAFTING_END > i.slot >= RPG_SLOT_CRAFTING_BEGIN:
                    emptySlots.remove(i.slot)
                    if craftProto.name == i.name:
                        diff = proto.stackMax - i.stackCount
                        if diff > 0:
                            stackItems.append((i,diff))
                            freeSpace += diff
            
            if freeSpace < craftProto.stackDefault and not len(emptySlots):
                player.sendGameText(RPG_MSG_GAME_DENIED,"%s has no more room in the crafting inventory.\\n"%(char.name))
                return
        else:
            for i in char.items:
                proto = i.itemProto
                if proto in itemProtos:
                    # charges on an ingredient represent its durability if max charges > 1
                    # only one charge should be consumed per craft and item if max charges > 1
                    if proto.useMax > 1:
                        itemProtos[proto] -= 1
                        if proto.craftConsumed:
                            consumed[i] = 1
                    else:
                        itemProtos[proto] -= i.stackCount
                        if proto.craftConsumed:
                            if itemProtos[proto] < 0:
                                consumed[i] = i.stackCount + itemProtos[proto]
                            else:
                                consumed[i] = i.stackCount
                    if itemProtos[proto] <= 0:
                        del itemProtos[proto]
                if RPG_SLOT_CRAFTING_END > i.slot >= RPG_SLOT_CRAFTING_BEGIN:
                    emptySlots.remove(i.slot)
            
            if not len(emptySlots):
                player.sendGameText(RPG_MSG_GAME_DENIED,"%s has no more room in the crafting inventory.\\n"%char.name)
                return
        if len(itemProtos):
            player.sendGameText(RPG_MSG_GAME_DENIED,"%s lacks %s for this craft.\\n"%(char.name,', '.join("%i %s"%(c,i.name) for i,c in itemProtos.iteritems())))
            return
        
        for item,count in consumed.items():
            proto = item.itemProto
            if proto.useMax > 1:
                item.useCharges -= 1
                if item.useCharges <= 0:
                    item.stackCount -= 1
                    if item.stackCount <= 0:
                        player.takeItem(item)
                    else:
                        item.useCharges = proto.useMax
                        item.itemInfo.refreshDict({'STACKCOUNT':item.stackCount,'USECHARGES':item.useCharges})
                else:
                    item.itemInfo.refreshDict({'USECHARGES':item.useCharges})
            else:
                item.stackCount -= count
                if item.stackCount <= 0:
                    player.takeItem(item)
                else:
                    item.itemInfo.refreshDict({'STACKCOUNT':item.stackCount})
        
        
        #TODO Filters
        player.takeMoney(recipe.costTP)
        
        newCount = craftProto.stackDefault
        for i,diff in stackItems:
            if diff > newCount:
                diff = newCount
            i.stackCount += diff
            newCount -= diff
            i.itemInfo.refreshDict({'STACKCOUNT':i.stackCount})
        
        if newCount:
            item = craftProto.createInstance()
            item.slot = emptySlots.pop()
            item.stackCount = newCount
            item.setCharacter(char)
            item.descOverride = "Crafted by %s"%char.name
            item.crafted = True
        
        player.sendGameText(RPG_MSG_GAME_GAINED,"%s has crafted a %s!\\n"%(char.name,craftProto.name))
        t = GenMoneyText(recipe.costTP)
        if t:
            player.sendGameText(RPG_MSG_GAME_YELLOW,"This %s consumes %s.\\n"%(cskillname,t))
        
        # modification already got cskilllevel, why query a second time?
        try:
            mlevel = mob.mobSkillProfiles[cskillname].maxValue
        except KeyError:
            mlevel = 0
            
        if cskilllevel >= mlevel:	# modification cskilllevel = slevel
            player.sendGameText(RPG_MSG_GAME_YELLOW,"%s currently cannot gain any more skill in %s.\\n"%(char.name,cskillname))
            
        if cskilllevel - recipe.skillLevel < 15:    
            char.checkSkillRaise(cskillname,1,2)
        
        if recipe.craftSound:
            player.mind.callRemote("playSound",recipe.craftSound)
        
    else:
        if cskilllevel < recipe.skillLevel:
            player.sendGameText(RPG_MSG_GAME_DENIED,"%s requires a %i skill in %s.\\n"%(char.name,recipe.skillLevel,cskillname))
            
        
    
    
 
