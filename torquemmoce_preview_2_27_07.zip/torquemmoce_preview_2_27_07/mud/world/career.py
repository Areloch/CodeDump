"""
The database abstraction for storing class information
"""

from mud.common.persistent import Persistent
from sqlobject import *

class ClassProto(Persistent):
    """
    Database storage for name, archetype, xpMod, and a set of skills
    to make up a class definition.
    """
    name = StringCol(alternateID = True)
    archetype = StringCol(default = "")
    xpMod = FloatCol(default=1.0)
    skills = RelatedJoin('ClassSkill')