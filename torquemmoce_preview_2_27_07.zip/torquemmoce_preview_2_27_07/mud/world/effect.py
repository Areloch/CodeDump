
#spells have effects, skills can too
#stacking

from mud.common.persistent import Persistent
from sqlobject import *
import spell
from defines import *
from core import *
from damage import Damage,Heal
import random,math
import traceback,time
#RPG_EFFECT_LEECH #dd and dot leech
#RPG_EFFECT_DRAIN
#RPG_EFFECT_DAMAGE #dd and dot
#RPG_EFFECT_AGGRO

#RPG_EFFECT_RESIST <-- stat

#RPG_EFFECT_ROOT

#RPG_EFFECT_ABSORPTION #certain amount, # of attacks, #of spells

#RPG_EFFECT_LIGHTSOURCE #also darkness
#RPG_EFFECT_RESURRECTION
#RPG_EFFECT_STUN
#RPG_EFFECT_SLEEP
#RPG_EFFECT_HEAL
#RPG_EFFECT_CURE
#RPG_EFFECT_NEGATE #negate effects
#RPG_EFFECT_INTERRUPT #interrupt casting

#RPG_EFFECT_MELEEHASTE
#RPG_EFFECT_SPELLHASTE
#RPG_EFFECT_MELEESLOW
#RPG_EFFECT_SPELLSLOW

#RPG_EFFECT_POINT #point to something, north, nearest animal, etc


#RPG_EFFECT_TELEPORT #between zones, safe spot in same zone, evacs, to bindpoint, random in zone
#RPG_EFFECT_SIZE
#RPG_EFFECT_ILLUSION

#RPG_EFFECT_LEVITATION
#RPG_EFFECT_SWIM
#RPG_EFFECT_HOLDBREATH

#RPG_EFFECT_REGEN

#RPG_EFFECT_ENCHANT

#RPG_EFFECT_MODULATE #modulate another effect

#RPG_EFFECT_STATMOD

#RPG_EFFECT_IMMUNITY
#RPG_EFFECT_INVISIBILITY
#RPG_EFFECT_VISION
#RPG_EFFECT_BANISH

#RPG_EFFECT_DAMAGESHIELD

#RPG_EFFECT_SACRIFICE


#RPG_EFFECT_FEAR
#RPG_EFFECT_CHARM

#RPG_EFFECT_MELEEREFLECTION
#RPG_EFFECT_SPELLREFLECTION

#one shot
#RPG_EFFECT_SUMMONITEM
#RPG_EFFECT_SUMMONPET
#RPG_EFFECT_SUMMONMONSTER
#RPG_EFFECT_SUMMONALLY

#RPG_EFFECT_COMBAT

#RPG_EFFECT_TRIGGER_HIT 
#RPG_EFFECT_TRIGGER_STRIKE
#RPG_EFFECT_TRIGGER_DEATH
#RPG_EFFECT_TRIGGER_EFFECT_CREATE
#RPG_EFFECT_TRIGGER_EFFECT_BEGIN

#RPG_EFFECT_FACTION


#global stats should never be health,mana,stamina... globals
#get popped on the end... likewise, str, bdy, etc should always
#be global


class EffectDamage(Persistent):
    type = IntCol(default=RPG_DMG_PHYSICAL)
    amount = IntCol(default=1)
    stage = IntCol(default=RPG_EFFECT_STAGE_GLOBAL)
    effectProto = ForeignKey('EffectProto')

class EffectStat(Persistent):
    statname = StringCol()
    value = FloatCol()
    stage = IntCol()
    effectProto = ForeignKey('EffectProto')

class EffectPermanentStat(Persistent):
    statname = StringCol()
    value = FloatCol()
    effectProto = ForeignKey('EffectProto')

class EffectLeech(Persistent):
    leechType = StringCol(default = "")
    leechBegin = IntCol(default = 0)
    leechEnd = IntCol(default = 0)
    leechTick = IntCol(default = 0)
    leechTickRate = IntCol(default = 0)
    effectProto = ForeignKey('EffectProto')

class EffectDrain(Persistent):
    drainType = StringCol(default = "")
    drainBegin = IntCol(default = 0)
    drainEnd = IntCol(default = 0)
    drainTick = IntCol(default = 0)
    drainTickRate = IntCol(default = 0)
    effectProto = ForeignKey('EffectProto')

class EffectRegen(Persistent):
    regenType = StringCol(default = "")
    regenBegin = IntCol(default = 0)
    regenEnd = IntCol(default = 0)
    regenTick = IntCol(default = 0)
    regenTickRate = IntCol(default = 0)
    effectProto = ForeignKey('EffectProto')

class EffectIllusion(Persistent):
    illusionModel = StringCol(default = "")
    illusionAnimation = StringCol(default = "")
    illusionTextureSingle = StringCol(default = "")
    illusionTextureBody = StringCol(default = "")
    illusionTextureHead = StringCol(default = "")
    illusionTextureLegs = StringCol(default = "")
    illusionTextureHands = StringCol(default = "")
    illusionTextureFeet = StringCol(default = "")
    illusionTextureArms = StringCol(default = "")
    illusionSex = StringCol(default = "")
    illusionRace = StringCol(default = "")
    illusionSndProfile = ForeignKey('SpawnSoundProfile',default = None)
    # if non-zero sets the illusion to a size rather than scaling (to do)
    illusionSize = FloatCol(default = 0.0)


class EffectProto(Persistent):
    name = StringCol(alternateID=True)
    
    leechEffect = ForeignKey('EffectLeech',default = None)
    drainEffect = ForeignKey('EffectDrain',default = None)
    regenEffect = ForeignKey('EffectRegen',default = None)
    
    #aggro
    aggro = IntCol(default=0)
    
    #stats
    stats = MultipleJoin('EffectStat')
    permanentStats = MultipleJoin('EffectPermanentStat')
    giveSkill = StringCol(default="")
    damage = MultipleJoin('EffectDamage')
    
    flags = IntCol(default = 0)
    
    #absorption
    absorbType = StringCol(default="")
    absorbCount = IntCol(default=0)

    #light
    light = FloatCol(default=0)
    
    invisibility = FloatCol(default=0)
    seeinvisibile = FloatCol(default=0)
    
    #resurrection
    resurrectionXP = FloatCol(default = 0) #percent exp gain
    
    cure = IntCol(default=0)
    negate = IntCol(default=0)
    negateMaxLevel = IntCol(default=0)
    
    point = StringCol(default="")
    
    teleport = StringCol(default="") #zone, random, safespot
    teleportDst = StringCol(default="") #for zone
    
    size = FloatCol(default=1.0) 
    
    illusion = ForeignKey('EffectIllusion',default = None)
    
    enchantItem = ForeignKey('ItemProto',default=None)
    
    immunityType = StringCol(default="")
    
    sacrificeLevel = StringCol(default="")
    sacrificeItem = ForeignKey('ItemProto',default=None)
    
    dmgReflectionType = IntCol(default = RPG_DMG_PHYSICAL)
    dmgReflectionPercent = FloatCol(default=0)
    dmgReflectionMax = IntCol(default=0)
    
    spellReflectionPercent = FloatCol(default=0)
    spellReflectionMax = IntCol(default=0)
    
    summonPet = ForeignKey('Spawn',default=None)
    summonItem = ForeignKey('ItemProto',default=None)
    
    #XXX TO DO COMBAT
    
    
    level =    IntCol(default=1)
    tickRate = IntCol(default=0)
    harmful =  BoolCol(default=False)
    resist =   IntCol(default=RPG_RESIST_MAGICAL) #also dictates type of damage
    trigger =  IntCol(default=0)
    
    spellProtos = RelatedJoin('SpellProto')
    
    def affectsStat(self,statname):
        for st in self.stats:
            if st.statname == statname:
                return True
        return False
    
    def _init(self,*args,**kw):
        Persistent._init(self, *args, **kw)
        
        if len(self.permanentStats):
            self.hasPermanentStats = True
        else:
            self.hasPermanentStats = False

def UndoIllusion(effect):
    
    dst = effect.dst
    if not dst.player:
        return
    
    if dst.illusionEffect == effect:
        from spell import Spell
        ieffect = None     
        sndProfile = None   
        for p in dst.processesIn:
            if isinstance(p,Spell):
                for e in p.effects:
                    if e == effect:
                        continue
                    proto = e.effectProto
                    if proto.illusion:
                        ieffect = e
                        sndProfile = proto.illusion.illusionSndProfile
                        #break
        
        dst.illusionEffect = ieffect
        dst.spawn.sndProfileOverride = sndProfile
        
                
        if not ieffect:
            si = dst.spawn.getSpawnInfo()
            si.refresh()
        else:
            DoIllusion(ieffect,ieffect.src,ieffect.dst)
        

def BreakCharm(effect):
    proto = effect.effectProto
    if not proto.flags&RPG_EFFECT_CHARM:
        return

    
    src = effect.src
    dst = effect.dst
    
    if not src.pet or src.pet != dst:
        return
    
    pet = src.pet
    
    pet.realm = pet.charmBackupRealm
    pet.aggro = pet.charmBackupAggro
    pet.charmEffect = None
    pet.master = None
    src.pet = None
    pet.playerPet = False
    pet.addAggro(src,100)
    

def DoCharm(effect,src,dst):
    proto = effect.effectProto
    if not proto.flags&RPG_EFFECT_CHARM:
        return
    
    if dst.player:
        return
    
    if src.pet or src.petSpawning:
        return
    
    if dst.master:
        return
    
    pet = dst
    
    pet.charmBackupRealm = pet.realm
    pet.charmBackupAggro = pet.aggro
    pet.realm = src.realm
    pet.master = src
    if src.player:
        pet.playerPet = True
        
    src.pet = pet
    
    from pet import PetCmdFollowMe
    PetCmdFollowMe(pet)

    pet.aggro = {}
        
    pet.setTarget(None)
        
    pet.charmEffect = effect


def DoIllusion(effect,src,dst):
    proto = effect.effectProto
    if not dst.player:
        return
    if not proto.illusion:
        return
    
    si = dst.spawn.spawnInfo
    gotone = False
    illusion = proto.illusion
    if illusion.illusionRace:
        gotone = True
        si.race = illusion.illusionRace
        si.modelname = ""
        si.textureSingle = ""
        si.textureBody = ""
        si.textureHead = ""
        si.textureLegs = ""
        si.textureArms = ""
        si.textureHands = ""
        si.textureFeet = ""
        
    if illusion.illusionModel:
        gotone = True
        si.modelname = illusion.illusionModel
        si.race = "Illusion" #hack
        si.textureSingle = illusion.illusionTextureSingle
        si.textureBody = illusion.illusionTextureBody
        si.textureHead = illusion.illusionTextureHead
        si.animation = illusion.illusionAnimation
        
        
    if gotone:
        dst.spawn.sndProfileOverride = illusion.illusionSndProfile
        dst.illusionEffect=effect
        si.refresh()
     
def DoPermanentStats(effect,src,dst):
    proto = effect.effectProto
    if not proto.hasPermanentStats:
        return
    
    if not dst.character:
        return
    
    for stat in proto.permanentStats:
        
        stname = stat.statname
        
        if stname.lower() == "advancementpoints":
            dst.character.advancementPoints+=int(stat.value)
            return
            
        
        stname = stname.replace("Perm","Base")
        
        c = dst.character
        
        rname = stname.replace("Base","Raise")
        
        r = getattr(c,rname)
        
        v = stat.value
        
        if v > r:
            v = r
        
        try:
            setattr(c,rname,int(getattr(c,rname)-v))
        except:
            traceback.print_exc()
        
        try:
            setattr(dst.spawn,stname,int(getattr(dst.spawn,stname)+v))
        except:
            traceback.print_exc()
            
        if "Base" in stname:
            st = stname[:-4]
            try:
                setattr(dst,st,int(getattr(dst,st)+v))
            except:
                traceback.print_exc()
    
    
def DoGiveSkill(effect,src,dst):
    proto = effect.effectProto
    skill =proto.giveSkill 
    if not skill:
        return
    
    if not dst.character:
        return
    
    
    skilllevel = dst.skillLevels.get(skill,0)
    if not skilllevel:
        from character import CharacterSkill
        dst.player.sendGameText(RPG_MSG_GAME_YELLOW,"%s has learned %s!\\n"%(dst.name,skill))
        CharacterSkill(character=dst.character,skillname = skill,level =1)
        dst.skillLevels[skill]=1

 
def DoSummonItem(effect,src):
    proto = effect.effectProto
    
    if not proto.summonItem:
        return
        
    
        
    if not src.character:
        return
        
    if not src.character.checkGiveItems(1):
        return
        
    src.character.giveItemProtos([proto.summonItem],[1])
  
def DoSummonPet(effect,src):
    proto = effect.effectProto
    if not proto.summonPet:
        return
    
    if src.battle:
        #XXX - don't cast this at all eventually
        return
    
    if src.pet and src.pet.charmEffect:
        src.pet.charmEffect.parent.cancel()
        if src.pet:
            traceback.print_stack()
            print "AssertionError: charm effect resisted breaking!"
            return
    
    zone = src.zone
    if src.pet:
        zone.removeMob(src.pet) #remove existing pet
    pos = src.simObject.position
    rot = src.simObject.rotation
    
    spawn = proto.summonPet

    transform = (pos[0],pos[1],pos[2],rot[0],rot[1],rot[2],rot[3])
    if not src.player and not src.target:
        x1 = random.randint(0,1)
        y1 = random.randint(0,1)
        if not x1:
            x1 = -1
        if not y1:
            y1 = -1
        
        s = src.spawn.scale/2.0
        if s < 1.0:
            s = 1.0
        if s > 3.0:
            s = 3.0
        x,y = pos[0]+float(x1)*s,pos[1]+float(y1)*s
        
        transform = (x,y,pos[2]+1.0,rot[0],rot[1],rot[2],rot[3])
    
    sizemod = 1.0
    if not src.player:
        sizemod = src.spawn.scale*.8 / spawn.scale
    
    try:
        pet = zone.spawnMob(spawn,transform,-1,src,sizemod)
    except:
        pass
    
    if not src.player:
        pet.move = src.move
        pet.flying = src.flying
    

    #pet will not be in actionMobs until simserver has spawned the bot
    #so, we set the pet's master here and we'll set the master's pet attribute later
    
    pet.realm = src.realm
    pet.master = src
    if src.player:
        pet.playerPet = True
        
    src.petSpawning = True
    
    mod = effect.mod
    if mod > 1:
        mod = 1.0 + (mod-1.0)*.25
    
    if not src.player:
        pet.maxHealthScalar=.5
    else:
        pet.maxHealthScalar=mod
    
    if effect.parent and isinstance(effect.parent,spell.Spell):
        adj = math.floor(effect.parent.level/3)
        if effect.parent.level == 10:
            adj+=1
        pet.level+=adj        
        pet.plevel+=adj
        if adj:
            pet.updateClassStats()
        
    pet.offenseScalar=mod
    pet.defenseScalar=mod
    pet.updateDerivedStats()
    pet.health = pet.maxHealth


def DoBanish(effect,src,dst):
    proto = effect.effectProto
    if not proto.flags&RPG_EFFECT_BANISH:
        return
    
    if dst.pet:
        if dst.pet.charmEffect:
            dst.pet.charmEffect.parent.cancel()
            if dst.pet:
                traceback.print_stack()
                print "AssertionError: pet charm effect resisted breaking!"
            return
        
        if dst.player:
            dst.player.sendGameText(RPG_MSG_GAME_PET_SPEECH,r'Your pet screams, \"I\'m banished master!!!\"\n')
        dst.pet.zone.removeMob(dst.pet)


def DoInterrupt(effect,src,dst):
    proto = effect.effectProto
    if not proto.flags&RPG_EFFECT_INTERRUPT:
        return
    
    if dst.casting:
        dst.zone.simAvatar.mind.callRemote("casting",dst.simObject.id,False)
        if dst.player:
            dst.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s\'s casting got interrupted by %s!\n'%(dst.name,src.name))
        dst.casting = None


def DoNegate(effect,src,dst):
    proto = effect.effectProto
    if not proto.negate or not proto.negateMaxLevel:
        return
    
    cancel = []
    for p in dst.processesIn:
        if isinstance(p,spell.Spell) and p.spellProto.spellType&RPG_SPELL_HARMFUL and p.spellProto.duration and p.spellProto.level<=proto.negateMaxLevel:
            cancel.append(p)
            if len(cancel) >= proto.negate:
                break
            
    for p in cancel:
        
        p.cancel()


def DoDrain(effect):
    proto = effect.effectProto
    drain = proto.drainEffect
    if drain:
        effect.drainTimer -= 3
        if effect.drainTimer <= 0:
            dst = effect.dst
            effect.drainTimer = drain.drainTickRate
            if drain.drainType == "health":
                Damage(dst,effect.src,drain.drainTick*effect.mod,DAMAGEFORRESIST[proto.resist],None,False,False,True)
            elif drain.drainType == "mana":
                dst.mana -= drain.drainTick*effect.mod
                if dst.mana < 0:
                    dst.mana = 0
            elif drain.drainType == "stamina":
                dst.stamina -= drain.drainTick*effect.mod
                if dst.stamina < 0:
                    dst.stamina = 0


def DoRegen(effect):
    proto = effect.effectProto
    regen = proto.regenEffect
    if regen:
        effect.regenTimer -= 3
        if effect.regenTimer <= 0:
            dst = effect.dst
            effect.regenTimer = regen.regenTickRate
            if regen.regenType == "health":
                dst.health += regen.regenTick*effect.mod
                if dst.health > dst.maxHealth:
                    dst.health = dst.maxHealth
            elif regen.regenType == "mana":
                dst.mana += regen.regenTick*effect.mod
                if dst.mana > dst.maxMana:
                    dst.mana = dst.maxMana
            elif regen.regenType == "stamina":
                dst.stamina += regen.regenTick*effect.mod
                if dst.stamina > dst.maxStamina:
                    dst.stamina = dst.maxStamina


def DoLeech(effect):
    proto = effect.effectProto
    leech = proto.leechEffect
    if not leech:
        return
    effect.leechTimer -= 3
    if effect.leechTimer <= 0:
        src = effect.src
        effect.leechTimer = leech.leechTickRate
        if leech.leechType == 'health':
            src.health += leech.leechTick*effect.mod
            if src.health > src.maxHealth:
                src.health = src.maxHealth
        elif leech.leechType == 'mana':
            src.mana += leech.leechTick*effect.mod
            if src.mana > src.maxMana:
                src.mana = src.maxMana
        elif leech.leechType == 'stamina':
            src.stamina += leech.leechTick*effect.mod
            if src.stamina > src.maxStamina:
                src.stamina = src.maxStamina



def DoResurrection(effect,src,dst):
    proto = effect.effectProto
    if not proto.flags&RPG_EFFECT_RESURRECTION:
        return

    if CoreSettings.MAXPARTY != 1:
        player = dst.player
        if not player:
            return
        
        for c in player.party.members:
            if c.dead:
                c.resurrect(proto.resurrectionXP)
    else:
        if src.player:
            #player resurrection of grave
            #gather up the corpses in the zone
            cnames = []
            for pname,dm in src.player.world.deathMarkers.iteritems():
                try:
                    charName,realm,zoneName,t,rot = dm
                    if zoneName == src.player.zone.zone.name:
                        p1 = src.simObject.position
                        x = p1[0]-t[0]
                        y = p1[1]-t[1]
                        z = p1[2]-t[2]
                        r = math.sqrt(x*x+y*y+z*z)
                        if r < 5:
                            cnames.append(charName)
                except:
                    traceback.print_exc()
                    
                
            #for p in src.player.world.activePlayers:
                
            #    try:
            #        c = p.party.members[0]
            #        if c.deathZone == src.player.zone.zone:
            #            t = c.deathTransform
            #            p1 = src.simObject.position
            #            x = p1[0]-t[0]
            #            y = p1[1]-t[1]
            #            z = p1[2]-t[2]
            #            r = math.sqrt(x*x+y*y+z*z)
            #            if r < 5:
            #                cnames.append(c.name)
            #    except:
            #        traceback.print_exc()
                    
            if not len(cnames):
                src.player.sendGameText(RPG_MSG_GAME_DENIED,r'There are no graves near enough to resurrect.\n')
                return

            #send a list of names to resurrect to the player
            src.player.mind.callRemote("setResurrectNames",cnames)
            src.player.resurrection = (time.time(),proto,cnames)
            
        else:
            #hm, this is a mob resurrection, we could wipe the grave location and return some XP
            #for now, do nothing
            return
            
def DoTeleportReal(effect,src,dst):
    if not dst.player:
        return

    player = dst.player
    proto = effect.effectProto
    
    player.telelink = None
    
    if proto.teleport:
        if not player.zone or not player.zone.zone:
            return #fix this, one teleport effect per character please
        
        teleport = proto.teleport
        teleportDst = proto.teleportDst
        if teleport.lower() == 'bindstone':
            if player.darkness:
                teleport = player.darknessBindZone.name
                trans = player.darknessBindTransform
            elif player.monster:
                teleport = player.monsterBindZone.name
                trans = player.monsterBindTransform
            else:
                teleport = player.bindZone.name
                trans = player.bindTransform
            teleportDst = ' '.join(str(i) for i in trans)
        
        #are we in the same zone?
        if player.zone.zone.name == teleport:
            #good
            #we just need to respawn player, whew
            player.zone.respawnPlayer(player,teleportDst)
        else:
            from zone import TempZoneLink
            zlink = TempZoneLink(teleport,teleportDst)
            player.world.onZoneTrigger(player,zlink)
    
    
def DoTeleport(effect,src,dst):
    #sets the tp, will tp next tick
    if not dst.player:
        return 

    player = dst.player
    proto = effect.effectProto
    
    if proto.teleport:
        player.telelink = (effect,src,dst)
        return
    

class Effect:
    def __init__(self,parent,src,dst,proto,time,mod=1.0,fromStore=False):
        self.effectProto = proto
        self.time = time
        self.parent = parent #can be a spell, etc
        self.src = src
        self.dst = dst
        self.fromStore = fromStore
        
        self.leechTimer = 0
        self.drainTimer = 0
        self.regenTimer = 0
        
        self.mod = mod
        self.popped = False
                
        #accumulated damage (spell outputs this stuff)
        self.damage = 0
        self.stats = {}
        
        self.statMods = {}
        self.derivedStatMods = {}
      
    def takeOwnership(self,newOwner):
        self.src = newOwner  
        
    def globalPush(self):
        #apply stats and stuff
        proto = self.effectProto
        src = self.src
        dst = self.dst
        dst.derivedDirty = True
        fromStore = self.fromStore
        
        
        if not fromStore:
            for dmg in proto.damage:
                
                if dmg.stage == RPG_EFFECT_STAGE_GLOBAL:
                    value = dmg.amount*self.mod
                    if dst.player and value>24000:
                        value = 24000
                    Damage(dst,src,value,dmg.type)

        
        for st in proto.stats:
            if st.stage == RPG_EFFECT_STAGE_GLOBAL:
                if st.statname == "feignDeath":
                    dst.autoAttack = False
                    dst.attackOff()

                value = st.value*self.mod
                if not fromStore and st.statname == 'health' and value < 0:
                    if dst.player and value < -24000:
                        value = -24000
                    Damage(dst,src,-value,DAMAGEFORRESIST[proto.resist])#, textDesc = None):
                elif not fromStore and st.statname == 'health' and value > 0:
                    Heal(dst,src,value)
                elif not fromStore and st.statname in ('mana','stamina'):
                    setattr(dst,st.statname,getattr(dst,st.statname)+value)
                else:
                    
                    if st.statname in RPG_DERIVEDSTATS:
                        self.derivedStatMods[st.statname]=value
                    elif st.statname in RPG_RESISTSTATS:
                        try:
                            dst.resists[RPG_RESISTLOOKUP[st.statname]]+=value
                        except KeyError:
                            dst.resists[RPG_RESISTLOOKUP[st.statname]]=value
                        try:
                            self.statMods[st.statname]+=value
                        except KeyError:
                            self.statMods[st.statname]=value
                        
                            
                    else:
                        try:
                            self.statMods[st.statname]+=value
                        except KeyError:
                            self.statMods[st.statname]=value
                            
                        if src.player and st.statname == "fear" and not dst.simObject.canKite:
                            src.player.sendGameText(RPG_MSG_GAME_DENIED,r'Fear effects only work outside.\n')
                        
                        if st.statname == "effectHaste":
                            e,v = dst.effectHaste
                            if v < value:
                                dst.effectHaste = (self,value)
                                
                            continue
                        try:    
                            setattr(dst,st.statname,getattr(dst,st.statname)+value)
                        except:
                            traceback.print_exc()
                            
        
    def begin(self):
        
        self.globalPush()
        self.iter = self.tick()
        proto = self.effectProto
        src = self.src
        dst = self.dst
        dst.derivedDirty = True
        
        
        if self.time==0:
            
            for dmg in proto.damage:
                
                if dmg.stage == RPG_EFFECT_STAGE_BEGIN:
                    value = dmg.amount*self.mod
                    if dst.player and value > 24000:
                        value = 24000
                    Damage(dst,src,value,dmg.type)
            
            for st in proto.stats:
                if st.stage == RPG_EFFECT_STAGE_BEGIN:
                    value = st.value*self.mod
                    if st.statname == 'health' and value < 0:
                        if dst.player and value < -24000:
                            value = -24000

                        Damage(dst,src,-value,DAMAGEFORRESIST[proto.resist])#, textDesc = None):
                    elif st.statname == 'health' and value > 0:
                        Heal(dst,src,value)
                    elif st.statname in ('mana','stamina'):
                        setattr(dst,st.statname,getattr(dst,st.statname)+value)
                    else:
                        try:
                            self.statMods[st.statname]+=value
                        except KeyError:
                            self.statMods[st.statname]=value
                        
                        try:
                            setattr(dst,st.statname,getattr(dst,st.statname)+value)
                        except:
                            traceback.print_exc()

                        
        try:
            if not self.fromStore:                
                DoTeleport(self,src,dst) 
                DoResurrection(self,src,dst)
                DoSummonPet(self,src)
                DoSummonItem(self,src)
                DoPermanentStats(self,src,dst)
                DoGiveSkill(self,src,dst)
                DoCharm(self,src,dst)
                DoNegate(self,src,dst)
                DoBanish(self,src,dst)
                DoInterrupt(self,src,dst)
                
            DoIllusion(self,src,dst)
        except:
            traceback.print_exc()
                
        
        return True
    
    
    #generator function
    def tick(self):
        while 1:
            DoDrain(self)
            DoLeech(self)
            DoRegen(self)
            
            self.time += 1
            
            yield True
    
    
    def end(self):
        #parent will global pop
        #self.globalPop()
        return 
        
    def cancel(self):
        self.canceled = True
        self.iter = None
        #self.end() don't get end stuff
        
    def globalPop(self):
        self.dst.derivedDirty = True
        UndoIllusion(self)
        BreakCharm(self)
        
        for st,value in self.statMods.iteritems():
            if st == "effectHaste":
                e,v = self.dst.effectHaste
                if e == self:
                    #find best
                    beste = None
                    bestv = 0
                    for p in self.dst.processesIn:
                        if p == self.parent:
                            continue
                        if isinstance(p,spell.Spell):
                            for e in p.effects:
                                for s,v in e.statMods.iteritems():
                                    if s == "effectHaste":
                                        if v > bestv:
                                            bestv = v
                                            beste = e
                                        break
                    self.dst.effectHaste = (beste,bestv)
                    
                continue
                
                
            if st in RPG_RESISTSTATS:
                self.dst.resists[RPG_RESISTLOOKUP[st]]-=value
            else:
                try:
                    setattr(self.dst,st,getattr(self.dst,st)-value)
                except:
                    traceback.print_exc()
            
            
"""

mob types:
normal
undead
summoned
plant
planar
demon
elemental
animal

some of this stuff goes into spell/skill

cast time
recast time
fizzle time
range
activated

skill
mana cost 


components

target self
target aoe
target single
target party
target pet
target alliance


harmful <-- flag
watchful aura that notifies you when invaded (area when mob walks into)

#combat
#modify combat stats
increased melee damage (with damage type), dual wield every round, every hit a critical,etc
impossible to miss,always riposte, damage to me every time I hit

"""

    

    
        
        
        
        
        
    
    
    