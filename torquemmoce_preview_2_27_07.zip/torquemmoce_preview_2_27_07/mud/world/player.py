from sqlobject import *
from mud.common.persistent import Persistent
from datetime import datetime
from character import CharacterFaction
from defines import *
import math
import traceback
from core import *
import random
import time
from messages import MessagePersonalize
from item import Item,ItemProto,ItemInstance

XPBONUS = (1,1.6,1.8,2.2,2.4,3.0)

class PlayerXPCredit(Persistent):
    player = ForeignKey('Player')
    xp = IntCol(default=0)
    
class PlayerMonsterSpawn(Persistent):
    player = ForeignKey('Player')
    spawn = StringCol()
    
class PlayerIgnore(Persistent):
    name = StringCol()
    player = ForeignKey('Player')
    
class Player(Persistent):    
    publicName = StringCol(alternateID = True,default="")
    fantasyName = StringCol(alternateID = True,default="")
    password = StringCol(default="")
    
    #all characters are bound to the same fate, er bindpoint/log point
    bindTransformInternal = StringCol(default="0 0 0 1 0 0 0") 
    bindZone = ForeignKey('Zone')
    logTransformInternal = StringCol(default="0 0 0 1 0 0 0") 
    logZone = ForeignKey('Zone')

    darknessBindTransformInternal = StringCol(default="0 0 0 1 0 0 0") 
    darknessBindZone = ForeignKey('Zone')
    darknessLogTransformInternal = StringCol(default="0 0 0 1 0 0 0") 
    darknessLogZone = ForeignKey('Zone')

    monsterBindTransformInternal = StringCol(default="0 0 0 1 0 0 0") 
    monsterBindZone = ForeignKey('Zone')
    monsterLogTransformInternal = StringCol(default="0 0 0 1 0 0 0") 
    monsterLogZone = ForeignKey('Zone')
    
    xpCredits = MultipleJoin('PlayerXPCredit')
    characters = MultipleJoin('Character')
    creationTime = DateTimeCol(default = datetime.now)
    
    lightTin =      IntCol(default=0)
    lightCopper =   IntCol(default=0)
    lightSilver =   IntCol(default=0)
    lightGold =     IntCol(default=0)
    lightPlatinum = IntCol(default=0)
    
    darknessTin =      IntCol(default=0)
    darknessCopper =   IntCol(default=0)
    darknessSilver =   IntCol(default=0)
    darknessGold =     IntCol(default=0)
    darknessPlatinum = IntCol(default=0)

    monsterTin =      IntCol(default=0)
    monsterCopper =   IntCol(default=0)
    monsterSilver =   IntCol(default=0)
    monsterGold =     IntCol(default=0)
    monsterPlatinum = IntCol(default=0)
    
    monsterSpawns = MultipleJoin('PlayerMonsterSpawn')

        
    avatarCharName = StringCol(default = "")
    
    ignoredInternal = MultipleJoin('PlayerIgnore')
    
    #channel filters
    channelGlobal = BoolCol(default=True)
    channelWorld = BoolCol(default=True)
    channelZone = BoolCol(default=True)
    channelCombat = BoolCol(default=False)
    
    bankItemsInternal = MultipleJoin("Item")
    
    remoteLeaderNames = {}
    
    
    def _init(self,*args,**kw):
        Persistent._init(self, *args, **kw)
        
        #this also needs to be persistent
        self.lastChannel = 'h'
        
        self.enteringWorld = True
        self.ignoredList = []
        self.ignoredDirty = True
        self.darkness = False
        self.monster = False
        self.party = None
        
        self.premium = False
        
        self.guildName = ""
        self.guildInfo = ""
        self.guildMOTD = ""
        self.guildRank = 0
        self.guildInvite = None
        
        #not persistent, because I don't want to update the database right now, some day
        #these should actually be client side maybe
        self.channelGlobal = True
        self.channelWorld = True
        self.channelZone = True
        
        self.channelCombat = False

        self.channelClan = True
        self.channelHelp = True
        self.channelOffTopic = True
        
        #whatever the most recent character name is
        self.charName = ""
        
        self.reset()
    
    def _get_bankItems(self):
        if not self.bankList:
            self.bankList = []
            for item in self.bankItemsInternal:
                if item.itemProto.flags & RPG_ITEM_ETHEREAL:
                    item.destroySelf()
                    continue
                self.bankList.append(ItemInstance(item))
        return self.bankList
    
    
    def _get_ignored(self):
        if self.ignoredDirty:
            self.ignoredList = []
            for ip in self.ignoredInternal:
                self.ignoredList.append(ip.name.upper())
            self.ignoredDirty = False
        return self.ignoredList
        
        
    def reset(self):
        self.friends = []
        self.friendsInfo = {}
        self.curChar = None
        self.zone = None
        self.avatar = None
        self.mind = None
        self.simObject = None        
        self.cursorItem = None
        self.interacting = None
        self.dialog = None
        self.curDialogLine = None
        self.transfering = False
        self.cinfoDirty = True
        self.alliance = None
        
        self.textMessages = []
        self.textTicker = 0
        
        self.extract = True
        
        self.allianceTimeStamp = None
        
        #time, effect, cnames tuple
        self.resurrection = None
        #time, effect tuple
        self.resurrectionRequest = None

        
        self.realm = None
        self.telelink = None
        
        self.lastInnAddTime = time.time()
        self.cserverInfos = None
        
        self.triggeredZoneOptions = []
        self.triggeredZoneLink = None
        self.invite = None
        self.name = self.fantasyName
        self.loggingOut = False
        self.trade = None
        self.world = None
        self.inn = None
        if self.party:
            for m in self.party.members:
                if m.mob:
                    m.mob.character = None
                    m.mob.player = None
                m.mob = None
        self.party = None
        self.rootInfo = None
        
        self.msgCombatNotCloseEnough = 0
        self.msgCombatCantSee = 0
        
        self.trackingTimer = 0
        self.trackingId = 0
        
        self.lastTell = None
        self.looting = None
        
        self.spellEffectCastTime = time.time()
        self.spellEffectBeginTime = time.time()
        
        self.bankList = None
        
        self.encounterSetting = RPG_ENCOUNTER_PVE
    
    
#money
    
    def _get_tin(self):
        if self.darkness:
            return self.darknessTin
        if self.monster:
            return self.monsterTin
        return self.lightTin

    def _get_copper(self):
        if self.darkness:
            return self.darknessCopper
        if self.monster:
            return self.monsterCopper
        return self.lightCopper
        
    def _get_silver(self):
        if self.darkness:
            return self.darknessSilver
        if self.monster:
            return self.monsterSilver
        return self.lightSilver

    def _get_gold(self):
        if self.darkness:
            return self.darknessGold
        if self.monster:
            return self.monsterGold
        return self.lightGold

    def _get_platinum(self):
        if self.darkness:
            return self.darknessPlatinum
        if self.monster:
            return self.monsterPlatinum
        return self.lightPlatinum

    def _set_tin(self,amount):
        if self.darkness:
            self.darknessTin = amount
            return
        if self.monster:
            self.monsterTin = amount
            return
        self.lightTin = amount

    def _set_copper(self,amount):
        if self.darkness:
            self.darknessCopper = amount
            return
        if self.monster:
            self.monsterCopper = amount
            return
        self.lightCopper = amount

    def _set_silver(self,amount):
        if self.darkness:
            self.darknessSilver = amount
            return
        if self.monster:
            self.monsterSilver = amount
            return
        self.lightSilver = amount

    def _set_gold(self,amount):
        if self.darkness:
            self.darknessGold = amount
            return
        if self.monster:
            self.monsterGold = amount
            return
        self.lightGold = amount

    def _set_platinum(self,amount):
        if self.darkness:
            self.darknessPlatinum = amount
            return
        if self.monster:
            self.monsterPlatinum = amount
            return
        self.lightPlatinum = amount
    
    
    def _get_bindTransform(self):
        return map(float, self.bindTransformInternal.split(" "))

    def _set_bindTransform(self,transform):
        self.bindTransformInternal = ' '.join(map(str,transform))
        
    def _get_logTransform(self):
        return map(float, self.logTransformInternal.split(" "))

    def _set_logTransform(self,transform):
        self.logTransformInternal = ' '.join(map(str,transform))
        
    #darkness
        
    def _get_darknessBindTransform(self):
        return map(float, self.darknessBindTransformInternal.split(" "))

    def _set_darknessBindTransform(self,transform):
        self.darknessBindTransformInternal = ' '.join(map(str,transform))
        
    def _get_darknessLogTransform(self):
        return map(float, self.darknessLogTransformInternal.split(" "))

    def _set_darknessLogTransform(self,transform):
        self.darknessLogTransformInternal = ' '.join(map(str,transform))


    #monster
        
    def _get_monsterBindTransform(self):
        return map(float, self.monsterBindTransformInternal.split(" "))

    def _set_monsterBindTransform(self,transform):
        self.monsterBindTransformInternal = ' '.join(map(str,transform))
        
    def _get_monsterLogTransform(self):
        return map(float, self.monsterLogTransformInternal.split(" "))

    def _set_monsterLogTransform(self,transform):
        self.monsterLogTransformInternal = ' '.join(map(str,transform))

    
    def clientCharCommand(self,mob,cmd,*args):
            
        cmd = cmd.upper()
        myargs = [arg.upper() for arg in args]
            
        index = 0
        found = False
        for c in self.party.members:
            if c.mob == mob:
                found = True
                break
            index+=1
            
        if not found:
            traceback.print_stack()
            print "AssertionError: mob has been removed from party!"
            return
        
        self.mind.callRemote("clientCharCommand",index,cmd,myargs)
    
    def sendGameText(self,textCode,text,mob=None,tgt=None):
        text = str(text)
        if mob:
            text = MessagePersonalize(text,mob,tgt)
        self.textMessages.append((0,textCode,text,""))
        #try:
        #    self.mind.callRemote("receiveGameText",textCode,str(text))
        #except:
        #    pass
        
    def sendSpeechText(self,textCode,text,src=""):
        if textCode == RPG_MSG_SPEECH_ZONE and not self.channelZone:
            return
        if textCode == RPG_MSG_SPEECH_GLOBAL and not self.channelGlobal:
            return
        if textCode == RPG_MSG_SPEECH_WORLD and not self.channelWorld:
            return
        self.textMessages.append((1,textCode,str(text),src.upper()))
        #try:
        #    self.mind.callRemote("receiveSpeechText",textCode,str(text))
        #except:
        #    pass
        
    def endInteraction(self,closeWindow = True):
        if not self.interacting:            
            return
        
        if hasattr(self.interacting,"interactTimes"):
            self.interacting.interactTimes[self]=time.time()
        
        self.interacting.interacting = None
        self.interacting = None
        
        if hasattr(self,"zone"):
            if self.zone:
                for c in self.party.members:
                    self.zone.setTarget(c.mob,None)

        
        if closeWindow:    
            self.mind.callRemote("closeNPCWnd")
        
        

        
    def giveItem(self,itemname,fullStack=False):
        try:
            ip = ItemProto.byName(itemname)
        except:
            return None
        
        item = ip.createInstance()
        if fullStack:
            item.stackCount = ip.stackMax
        
        if not self.curChar.giveItemInstance(item):
            item.destroySelf()
            return None
        
        return item
    
    
    def takeItem(self,item):
        if not item:
            return
        if (item.player and item.player == self) or (item.character and item.character in self.party.members):
            if item == self.cursorItem:
                self.cursorItem = None
                item.slot = -1
                self.updateCursorItem(item)
            item.destroySelf()
            self.cinfoDirty = True
            return
        raise ValueError,"Attempting to take an item from player %s not belonging to this player!"%self.publicName
    
    
    def collapseMoney(self):
        tin = self.tin
        copper = self.copper
        silver = self.silver
        gold = self.gold
        platinum = self.platinum

        #convert to tin
        tin = long(tin)
        tin += copper*100L
        tin += silver*10000L
        tin += gold*1000000L
        tin += platinum*100000000L
        
        self.tin,self.copper,self.silver,self.gold,self.platinum = CollapseMoney(tin)
    
    def checkMoney(self,worth):
        if not worth:
            return True
        tin = self.tin
        copper = self.copper
        silver = self.silver
        gold = self.gold
        platinum = self.platinum
        
        if tin < 0 or copper < 0 or silver < 0 or gold < 0 or platinum < 0:
            traceback.print_stack()
            print "AssertionError: player %s wealth whackiness!"%self.publicName
            return
        
        tin = long(tin)
        tin += copper*100L
        tin += silver*10000L
        tin += gold*1000000L
        tin += platinum*100000000L
        
        if tin >= worth:
            return True
        return False
    
    def takeMoney(self,worth):
        if not worth:
            return
        if not self.checkMoney(worth):
            traceback.print_stack()
            print "AssertionError: player doesn't have enough money!"
            return
        
        tin = self.tin
        copper = self.copper
        silver = self.silver
        gold = self.gold
        platinum = self.platinum
        
        if tin < 0 or copper < 0 or silver < 0 or gold < 0 or platinum < 0:
            traceback.print_stack()
            print "AssertionError: player %s wealth whackiness!"%self.publicName
            return
        
        #convert to tin
        tin = long(tin)
        tin += copper*100L
        tin += silver*10000L
        tin += gold*1000000L
        tin += platinum*100000000L
        
        tin -= worth
        self.tin,self.copper,self.silver,self.gold,self.platinum = CollapseMoney(tin)
    
    def giveMoney(self,worth):
        if not worth:
            return
        #convert to tin
        tin = long(self.tin)
        tin += self.copper*100L
        tin += self.silver*10000L
        tin += self.gold*1000000L
        tin += self.platinum*100000000L
        
        tin += worth
        self.tin,self.copper,self.silver,self.gold,self.platinum = CollapseMoney(tin)
    
    
    def rewardXP(self,totalXP):
        #the no single XP giving event reward more than 1/level*5 takes care of grouping 
        #uber and newbie characters... so just do a flat out share
            
        members = []
        for c in self.party.members:
            if not c.dead:
                members.append(c)
                
        if not len(members):
            return
        
        num = len(members)
        bonus = XPBONUS[num-1]
        totalXP*=bonus
        
        memberXP = int(math.ceil(totalXP/num))
        if not memberXP:
            return
        
        for c in members:
            c.gainXP(memberXP)
    
    
    def updateCursorItem(self,oldCursorItem):
        party = self.party
        
        #catch character cursor slot wackiness 
        if not self.cursorItem:
            for c in party.members:
                for item in c.items:
                    if item.slot == RPG_SLOT_CURSOR:
                        self.cursorItem = item
                        break
        
        if not self.cursorItem and not self.trade:
            #look for trade items gone wrong
            for c in party.members:
                for item in c.items:
                    if RPG_SLOT_TRADE_END > item.slot >= RPG_SLOT_TRADE_BEGIN:
                        self.cursorItem = item
                        break
        
        if oldCursorItem != self.cursorItem:
            if self.cursorItem:
                self.mind.callRemote("setCursorItem",self.cursorItem.itemInfo)
            else:
                self.mind.callRemote("setCursorItem",None)
    
    
    def restoreTradeItems(self):
        titems = []
        limbo = []
        
        for c in self.party.members:
            for item in c.items:
                if RPG_SLOT_TRADE_END > item.slot >= RPG_SLOT_TRADE_BEGIN:
                    titems.append(item)
        
        for item in titems:
            char = item.character
            if not char.restoreTradeItem(item):
                limbo.append(item)
        
        #we have items in limbo, that can't be given back to original character
        for item in limbo:
            origchar = item.character
            found = False
            for c in self.party.members:
                if c == origchar:
                    continue
                item.setCharacter(c)
                if c.restoreTradeItem(item):
                    found = True
                    break
            
            if not found:
                #the item must remain in limbo, blah
                if not origchar:
                    print "*** WARNING ****: Trade item has no original char!"
                item.setCharacter(origchar)
    
    
    def giveItemInstance(self,item):
        #first try the current char
        if self.curChar.giveItemInstance(item):
            return True
        
        for c in self.party.members:
            if c == self.curChar:
                continue
            if c.giveItemInstance(item):
                return True
        return False
                
    def getFreeCarrySlots(self):
        free = 0
        for c in self.party.members:
            free+=len(c.getFreeCarrySlots())
        return free
        
    def track(self,id):
        self.trackingId = id
        self.updateTracking()
        
    def updateTracking(self):
        #import time
        #tm = time.time()
        if not self.zone:
            return
        
        
        
        self.trackingTimer = 30 #5 seconds
            
        mymob = self.party.members[0].mob
        
        if not mymob:
            return
        
        bestT = 0
        for c in self.party.members:
            if c.dead:
                continue
            
            
            c.checkSkillRaise("Tracking",20,50,False,True)
            t = c.mob.mobSkillProfiles['Tracking'].maxValue
            if t > bestT:
                bestT = t
                
        range = 100+bestT
        range/=2
        range+=100
            
        players = []
        tracking = {}
        
        found = False
        for m in self.zone.activeMobs:
            if m.player == self or m.detached:
                continue
            
            if m.simObject.simZombie:
                continue
            
            if m.player and (m.player in players or not m.player.simObject):
                continue
            
            if m.master:
                continue #pets don't show up on tracking
            
            #normal mob
            type = 0
            kos = IsKOS(m,self.party.members[0].mob)
            if kos:
                type = 1
            if m.vendor:
                type = 2
            dialog = m.spawn.dialog
            if dialog and dialog.greeting and dialog.greeting.numChoices:
                type = 3
            
            if m.player:
                if AllowHarmful(m,self.curChar.mob):
                    type = 1
                else:
                    type = 4
            
            if m.spawn.flags&RPG_SPAWN_INN:
                type = 5
            
            r = GetRange(mymob,m)
            passed = False
            if type != 4:
                if mymob.seeInvisible or r <= float(range)*float(m.visibility):
                    passed = True
            if  type == 4 or passed:
                if m.id == self.trackingId:
                    found = True
                if m.player:
                    players.append(m.player)
                    tracking[m.id] = (m.player.charName,m.player.simObject.position,r,type)
                else:
                    tracking[m.id] = (m.name,m.simObject.position,r,type)
                    
        if self.trackingId and not found:
            self.trackingId = 0
            self.sendGameText(RPG_MSG_GAME_EVENT,"The trail has grown cold.\\n")
                    
        tracking['RANGE']=range
        tracking['TRACKINGID']=self.trackingId
        
        self.mind.callRemote("setTracking",tracking)
        if self.world.mutedPlayers.has_key(self.publicName):
            self.mind.callRemote("setMuteTime",self.world.mutedPlayers[self.publicName])
        else:
            self.mind.callRemote("setMuteTime",0)
        
        
        
    def tick(self):
        from mob import Mob
        from dialog import DialogTrigger
        
        #move to client, send combat stats in infos
        if self.msgCombatNotCloseEnough > 0:
            self.msgCombatNotCloseEnough -= 1
            
        if self.msgCombatCantSee > 0:
            self.msgCombatCantSee -= 1
            
        self.trackingTimer -= 3
        if self.trackingTimer <= 0:
            self.updateTracking()
            
        self.textTicker -= 3
        if self.textTicker < 0:
            self.textTicker = 7
            if len(self.textMessages):
                try:
                    self.mind.callRemote("receiveTextList",self.textMessages)
                except:
                    pass
            self.textMessages = []
        
        bankItems = self.bankItems
        for item in bankItems:
            item.tick()
        
        if self.inn:
            # to account for the new distance calculation on innkeeper interaction
            if GetRangeMin(self.party.members[0].mob,self.inn.innkeeper) > 5:
                self.inn.endInteraction()
        
        if self.interacting:
            if isinstance(self.interacting,Mob):
                #make sure to sync range calc to commandinteract (this buffers a bit further out)
                range = (self.interacting.spawn.radius*self.interacting.spawn.scale)*2.75
                pos = self.interacting.simObject.position
            elif isinstance(self.interacting,DialogTrigger):
                range = self.interacting.range
                pos = self.interacting.position
                
            
                
            myx = self.simObject.position[0]
            myy = self.simObject.position[1]
            myz = self.simObject.position[2]
            
            x = myx-pos[0]
            y = myy-pos[1]
            z = myz-pos[2]
            
            dist = math.sqrt(x*x+y*y+z*z)
            if dist > range:
                self.endInteraction()
        
        #OPTIMIZE
        finfo={}
        if len(self.friends):
            gplayers = self.world.globalPlayers
            for f in self.friends:
                try:
                    info = gplayers[f]
                except KeyError:
                    continue
                
                finfo[f]=info
            
        if self.friendsInfo!=finfo:
            self.friendsInfo = finfo
            try:
                self.mind.callRemote("setFriendsInfo",finfo)
            except:
                pass
        
        
    def logout(self):
        try:
            #clear inn if any
            self.lastTell = None
            
            if self.inn:
                self.inn.endInteraction()
                self.inn = None
            
            if self.party and self.party.members:
                for c in self.party.members:
                    for item in c.items[:]:
                        flags = item.itemProto.flags
                        if flags & RPG_ITEM_ETHEREAL:
                            item.destroySelf()
                        else:
                            item.storeToItem()
            try:
                for item in self.bankList[:]:
                    flags = item.itemProto.flags
                    if flags & RPG_ITEM_ETHEREAL:
                        item.destroySelf()
                    else:
                        item.storeToItem()
            except:  # bankItems were never queried, no save needed
                pass
            
            self.cursorItem = None
            
            if self.looting:
                self.looting.looter = None
                self.looting = None
            
            if self.invite:
                self.invite.cancel()
                self.invite = None
                
            if self.trade:
                self.trade.cancel()
            
            if hasattr(self,"alliance") and self.alliance:
                self.alliance.leave(self)
            
            if hasattr(self,"zone"):
                if self.zone:
                    self.endInteraction(False)
                    
                    if self.simObject:
                        transform = []
                        for v in self.simObject.position:
                            transform.append(v)
                        for v in self.simObject.rotation:
                            transform.append(v)
                    
                        transform[6]=math.degrees(transform[6])
                        
                        if self.darkness:
                            self.darknessLogZone = self.zone.zone
                            self.darknessLogTransform = transform
                        elif self.monster:
                            self.monsterLogZone = self.zone.zone
                            self.monsterLogTransform = transform
                        else:
                            self.logZone = self.zone.zone
                            self.logTransform = transform
                            
                    
                    if self.zone.owningPlayer != self:
                        from theworld import World
                        world = World.byName("TheWorld")
                        if not world.singlePlayer:
                            self.zone.kickPlayer(self)
                        self.zone.removePlayer(self)
                        
                    
                self.zone = None
        except:
            traceback.print_exc()

        if self.world:
            self.world.playerLeaveWorld(self)
        self.world = None
        
        self.reset()
        #self.expire()
        
    def prepForZoneOut(self):
        self.trackingId = 0
        self.backupItems()
        #self.updateTracking()
    
    def backupItems(self):
        try:
            for item in self.bankList:
                item.storeToItem()
        except:  # bankItems were never queried, no save needed
            pass
        if self.party and self.party.members:
            for c in self.party.members:
                c.backupItems()
    
    
    def takeItems(self,itemProtos,counts,silent=False):
        for c in self.party.members:
            c.takeItems(itemProtos,counts,silent)
    
    
    def checkItems(self,itemProtos,counts,silent=False):
        for c in self.party.members:
            index = 0
            for checkItem in itemProtos:
                if not counts[index]:
                    index += 1
                    continue #already satisfied
                
                for item in c.items:
                    if RPG_SLOT_TRADE_END > item.slot >= RPG_SLOT_TRADE_BEGIN:
                        continue
                    if RPG_SLOT_LOOT_END > item.slot >= RPG_SLOT_LOOT_BEGIN:
                        continue
                    
                    if item.itemProto == checkItem:
                        sc = item.stackCount
                        if not sc:
                            sc = 1
                        if sc > counts[index]:
                            sc = counts[index]
                        
                        counts[index] -= sc
                        if not counts[index]:
                            break
                index += 1
        
        gotone = False
        for ip,c in zip(itemProtos,counts):
            if c:
                gotone = True
                if not silent:
                    if c > 1:
                        self.sendGameText(RPG_MSG_GAME_DENIED,"You need %i %s.\\n"%(c,ip.name))
                    else:
                        self.sendGameText(RPG_MSG_GAME_DENIED,"You need a %s.\\n"%ip.name)
        
        return not gotone
    
    
    def updateKOS(self):
        from faction import KOS
        if self.party:
            for c in self.party.members:
                spawn = c.spawn
                KOS[spawn.name] = []
                for f in c.characterFactions:
                    for s in f.faction.spawns:
                        try:
                            if f.points < RPG_FACTION_DISLIKED:
                                #player kos
                                #KOS[spawn.name].append(s.name)
                                if spawn.name not in KOS[s.name]:
                                    KOS[s.name].append(spawn.name)
                            else:
                                if spawn.name in KOS[s.name]:
                                    KOS[s.name].remove(spawn.name)
                        except:
                            pass
                        
                
                    
                        
        
    def rewardFaction(self,faction,amount):
        if faction.realm != -1:
            if faction.realm == RPG_REALM_LIGHT:
                if self.darkness or self.monster:
                    return
            if faction.realm == RPG_REALM_DARKNESS:
                if not self.darkness:
                    return
            if faction.realm == RPG_REALM_MONSTER:
                if not self.monster:
                    return
        
        from faction import KOS
        for c in self.party.members:
            spawn = c.spawn
            KOS[spawn.name] = []
            gotit = False
            for f in c.characterFactions:
                if f.faction == faction:
                    f.points += amount
                    gotit = True
                    for s in f.faction.spawns:
                        try:
                            if f.points < RPG_FACTION_DISLIKED:
                                if spawn.name not in KOS[s.name]:
                                    KOS[s.name].append(spawn.name)
                            else:
                                if spawn.name in KOS[s.name]:
                                    KOS[s.name].remove(spawn.name)
                        except:
                            pass
                    break
            
            if not gotit:
                CharacterFaction(faction=faction,character=c,points=amount)
        
            if amount > 0:    
                self.sendGameText(RPG_MSG_GAME_GREEN,r'%s\'s reputation with %s has increased!\n'%(c.name,faction.name))
            if amount < 0:    
                self.sendGameText(RPG_MSG_GAME_RED,r'%s\'s reputation with %s has decreased!\n'%(c.name,faction.name))
    
    
    def applyEncounterSetting(self,index):
        if self.encounterSetting == index:
            return
        self.encounterSetting = index
        
        # tell pet to cease unallowed attacks
        if index != RPG_ENCOUNTER_PVP:
            for c in self.party.members:
                if c.mob and c.mob.pet:
                    pet = c.mob.pet
                    if pet.attacking and not AllowHarmful(pet,pet.target):
                        pet.cancelAttack()
        
        if index == RPG_ENCOUNTER_PVE:
            self.sendGameText(RPG_MSG_GAME_GREEN,r'You no longer have to fear attacks from fellow players. But keep an eye out, the environment still doesn\'t like you.\n')
        elif index == RPG_ENCOUNTER_RVR:
            self.sendGameText(RPG_MSG_GAME_YELLOW,r'Watch your back! Hostile encounters with players from a different realm than yours may occur.\n')
            self.mind.callRemote("playSound","sfx/College_DrumCadence11.ogg")
        elif index == RPG_ENCOUNTER_GVG:
            self.sendGameText(RPG_MSG_GAME_YELLOW,r'Watch your back! Hostile encounters with players from a different guild than yours may occur.\n')
            self.mind.callRemote("playSound","sfx/College_DrumCadence11.ogg")
        else:
            self.sendGameText(RPG_MSG_GAME_RED,r'Stay sharp! You\'re no longer safe from the attacks of hostile players.\n')
            self.mind.callRemote("playSound","sfx/College_DrumCadence25.ogg")
    
    
    def destroySelf(self):
        for o in self.xpCredits:
            o.destroySelf()
            
        for o in self.characters:
            o.destroySelf()

        for o in self.monsterSpawns:
            o.destroySelf()
            
        for o in self.ignoredInternal:
            o.destroySelf()
            
        for o in self.bankItemsInternal:
            o.destroySelf()
        
        Persistent.destroySelf(self)


