"""
The classes in this module define various maximums and derived stats for
characters of particular classes.  For instance, combat classes have a high
max health.

The classes are arrayed in order - a base archetype first to define all the
default behaviour, then classes inheriting from that in groups.

By convention, stats are divided by a series of numbers depending on how
important the stat is for this class/derived stat.  The ordering is basically
5, 10, 25, 50, 100
"""

from career import ClassProto

# module variable used to track available classes
CLASSES = {}

class Archetype:
    """
    The base class for all in-game "classes".  This provides the basic methods
    required, to be override by the actual classes such as ranger, druid, etc
    """
    def __init__(self):
        """
        Setup initial variables
        """
        self.xpMod = 1.0
        # This try...except because self.name is defined by the class that
        # inherits from this.  We could setup a proper initialization function
        # and do away with the try...except, if we really wanted.
        # I believe this fails only when we're in the Genesis building code,
        # creating the database structure.
        try:
            self.classProto = ClassProto.byName(self.name)
            # Copy here so we aren't querying from DB everytime we access the
            # skills list
            self.classSkills = list(self.classProto.skills)            
        except:
            self.classProto = None
            self.classSkills = []
        
    def getMaxHealth(self, mob, level):
        """
        Return the max health - overridden by subclasses
        
        :Parameters:
            - `mob` the mob we're dealing with, to provide stats
            - `level` the level to calculate value for
            
        :Returns:
            int the max health for this mob at this level
        """
        return level*level+10

    def getMaxMana(self, mob, level):
        """
        Return the max mana - overridden by subclasses
        
        :Parameters:
            - `mob` the mob we're dealing with, to provide stats
            - `level` the level to calculate value for
            
        :Returns:
            int the max mana for this mob at this level
        """
        return 100

    def getMaxStamina(self, mob, level):
        """
        Return the max stamina - overridden by subclasses
        
        :Parameters:
            - `mob` the mob we're dealing with, to provide stats
            - `level` the level to calculate value for
            
        :Returns:
            int the max stamina for this mob at this level
        """
        return level*level

    def getOffense(self, mob, level):
        """
        Return the offense - overridden by subclasses
        
        :Parameters:
            - `mob` the mob we're dealing with, to provide stats
            - `level` the level to calculate value for
            
        :Returns:
            int the offense for this mob at this level
        """
        return level*level
        
    def getDefense(self, mob, level):
        """
        Return the defence - overridden by subclasses
        
        :Parameters:
            - `mob` the mob we're dealing with, to provide stats
            - `level` the level to calculate value for
            
        :Returns:
            int the defence for this mob at this level
        """
        return level*level

    def getXPMod(self):
        """
        Return the XP Modifier - overridden by subclasses
        
        :Parameters:
            - `mob` the mob we're dealing with, to provide stats
            - `level` the level to calculate value for
            
        :Returns:
            int the XP Modifier for this mob at this level
        """
        return 1

    def getPrimaryAttackRate(self, mob, level):
        """
        Return the main weapon attack speed - overridden by subclasses
        
        :Parameters:
            - `mob` the mob we're dealing with, to provide stats
            - `level` the level to calculate value for
            
        :Returns:
            int the ticks between primary attacks for this mob at this level
        """
        # 8 ticks to a second - 16 gives one attack every 2 seconds
        return 16

    def getSecondaryAttackRate(self, mob, level):
        """
        Return the secnodary weapon attack speed - overridden by subclasses
        
        :Parameters:
            - `mob` the mob we're dealing with, to provide stats
            - `level` the level to calculate value for
            
        :Returns:
            int the ticks between secondary attacks for this mob at this level
        """
        # off-hand is 1 attack every 3 seconds by default (8 ticks to a second)
        return 24

    def getCritical(self, mob, level):
        """
        Return the chance of a critical hit - overridden by subclasses
        
        :Parameters:
            - `mob` the mob we're dealing with, to provide stats
            - `level` the level to calculate value for
            
        :Returns:
            float chance for a critical hit - 1.0 is baseline
        """
        return 1.0

    def getClassStats(self, mob, level):
        """
        Called when mobs are created, to update their derived stats (offense,
        defence, etc) based on class definitions.
        
        :Parameters:
            - `mob` the mob we're dealing with, to provide stats
            - `level` the level to calculate value for
            
        :Returns:
            dict a dictionary of derived stats based on the other methods above
        """
        stats = {}
        health = self.getMaxHealth(mob, level)
        if not mob.player and level > 20:
            health *= level/20
            # Uncomment the following to really raise the bar on tough mobs
            # over level 20
            #if mob.spawn.difficultyMod > 1.0:
            #    health += int(health * (mob.spawn.difficultyMod / 2.0))
        # We return a dict of variables, based on the methods above, each of
        # which can be overridden by more specific classes.
        stats['maxHealth'] = health
        stats['maxMana'] = self.getMaxMana(mob, level)+6
        stats['maxStamina'] = self.getMaxStamina(mob, level)
        stats['offense'] = self.getOffense(mob, level)
        stats['defense'] = self.getDefense(mob, level)
        stats['primaryAttackRate'] = self.getPrimaryAttackRate(mob, level)
        stats['secondaryAttackRate'] = self.getSecondaryAttackRate(mob, level)
        stats['critical'] = self.getCritical(mob, level)
        return stats
        
# ARCHETYPES - Combatant, Magi, Priest, Rogue, the basic four.  None of these
# are meant to be used directly, hence their .name attribute is not set.

class Combatant(Archetype):
    """ Melee fighter types """
    def __init__(self):
        Archetype.__init__(self)
        
    def getMaxMana(self, mob, level):
        return 0
    
    def getCritical(self, mob, level):
        return 1.0
    
    def getMaxHealth(self, mob, level):
        s1 = level/10.0
        s2 = level/25.0
        return int((level*level+50+(mob.bdy*s1)+(mob.str*s2)))+mob.pre*5

    def getMaxStamina(self, mob, level):
        s1 = level/10.0
        s2 = level/25.0
        return int((level*level+50+(mob.bdy*s1)+(mob.str*s2)))+mob.pre*5

        
    def getOffense(self, mob, level):
        s1 = level/10.0
        s2 = level/25.0
        s3 = level/50.0
        return int(level*level+10+(mob.str*s1)+(mob.dex*s2)+(mob.ref*s3))+mob.pre*10
    
    def getDefense(self, mob, level):
        s1 = level/10.0
        s2 = level/25.0
        s3 = level/50.0
        s4 = level/100.0
        base = int(level*level+10+(mob.bdy*s1)+(mob.dex*s2)+(mob.ref*s3)+(mob.agi*s4))
        base+=mob.armor*4++mob.pre*4
        return base
        
class Magi(Archetype):
    """ Spellcasters """
    def __init__(self):
        Archetype.__init__(self)

    def getMaxStamina(self, mob, level):
        s1 = level/10.0
        s2 = level/25.0
        return int((level*level+50+(mob.bdy*s1)+(mob.str*s2)))/2+16+mob.pre*5

    def getMaxMana(self, mob, level):
        x = int((mob.mnd/10)*level)+int(mob.pre*level*.5)
        x += int(mob.mnd*5*float(level)/100.0)
        return x
        
    def getMaxHealth(self, mob, level):
        # NPC's get more health, to make them more of a challenge to fight
        if not mob.player:
            return int(CLASSES['Warrior'].getMaxHealth(mob, level)*.75)
        s1 = level/10.0
        s2 = level/25.0
        return int((level*level+50+(mob.bdy*s1)+(mob.str*s2)))/4+16+mob.pre*2
        
    def getOffense(self, mob, level):
        s1 = level/10.0
        s2 = level/25.0
        s3 = level/50.0
        offence = int(level*level+10+(mob.str*s1)+(mob.dex*s2)+(mob.ref*s3))
        return offence / 4 + mob.pre
    
    def getDefense(self, mob, level):
        s1 = level/10.0
        s2 = level/25.0
        s3 = level/50.0
        s4 = level/100.0
        base = int(level*level+10+(mob.bdy*s1)+(mob.dex*s2)+(mob.ref*s3)+(mob.agi*s4))
        base+=mob.armor*4+mob.pre
        return base/5

    def getCritical(self, mob, level):
        return .5

class Priest(Archetype):
    """ Healers and buffers """
    def __init__(self):
        Archetype.__init__(self)

    def getMaxStamina(self, mob, level):
        s1 = level/10.0
        s2 = level/25.0
        return int((level*level+50+(mob.bdy*s1)+(mob.str*s2)))+16+mob.pre*5

    def getMaxMana(self, mob, level):
        x = int((mob.mys/10)*level)+int(mob.pre*level*.5)
        x += int(mob.mys*5*float(level)/100.0)
        return x
        
    def getMaxHealth(self, mob, level):
        # NPC's get more health, to make them more of a challenge to fight
        if not mob.player:
            return int(CLASSES['Warrior'].getMaxHealth(mob, level)*.75)
        s1 = level/10.0
        s2 = level/25.0
        return int((level*level+50+(mob.bdy*s1)+(mob.str*s2)))/2
        
    def getOffense(self, mob, level):
        s1 = level/10.0
        s2 = level/25.0
        s3 = level/50.0
        return int(level*level+10+(mob.str*s1)+(mob.dex*s2)+(mob.ref*s3))/2
    
    def getDefense(self, mob, level):
        s1 = level/10.0
        s2 = level/25.0
        s3 = level/50.0
        s4 = level/100.0
        base = int(level*level+10+(mob.bdy*s1)+(mob.dex*s2)+(mob.ref*s3)+(mob.agi*s4))
        base+=mob.armor*4
        return base/2

    def getCritical(self, mob, level):
        return .8

class Rogue(Archetype):
    """ Jack of all trades """
    def __init__(self):
        Archetype.__init__(self)

    def getMaxStamina(self, mob, level):
        s1 = level/10.0
        s2 = level/25.0
        return int((level*level+50+(mob.bdy*s1)+(mob.str*s2)))+mob.pre*5

    def getMaxMana(self, mob, level):
        x = int((mob.mnd/10)*level)+int(mob.pre*level*.5)
        x += int(mob.mnd*5*float(level)/100.0)
        return x
        
    def getMaxHealth(self, mob, level):
        # NPC's get more health, to make them more of a challenge to fight
        if not mob.player:
            return int(CLASSES['Warrior'].getMaxHealth(mob, level)*.85)
        s1 = level/10.0
        s2 = level/25.0
        return int(((level*level+50+(mob.bdy*s1)+(mob.str*s2)))*.75)+mob.pre*5
        
    def getOffense(self, mob, level):
        s1 = level/10.0
        s2 = level/25.0
        s3 = level/50.0
        base = int((level*level+10+(mob.str*s2)+(mob.dex*s1)+(mob.ref*s2))*1.3)
        return base + mob.pre * 6
    
    def getDefense(self, mob, level):
        s1 = level/10.0
        s2 = level/25.0
        s3 = level/50.0
        s4 = level/100.0
        base = int((level*level+10+(mob.bdy*s2)+(mob.dex*s1)+(mob.ref*s2)+(mob.agi*s2))*.75)
        base+=mob.armor*3+mob.pre*3
        return base
    
    def getCritical(self, mob, level):
        return 1.2

# COMBATANT based classes

class Warrior(Combatant):
    """ Your basic fighter """
    def __init__(self):
        self.name = "Warrior"
        Combatant.__init__(self)

    def getXPMod(self):
        return .9

    def getCritical(self, mob, level):
        return 1.1

    def getDefense(self, mob, level):
        return int(Combatant.getDefense(self, mob, level)*1.20)
            
    def getMaxHealth(self, mob, level):
        return int(Combatant.getMaxHealth(self, mob, level)*1.3)

class Ranger(Combatant):
    """ Ranged with pets """
    def __init__(self):
        self.name = "Ranger"
        Combatant.__init__(self)

    def getXPMod(self):
        return 1

    def getMaxMana(self, mob, level):
        x = int((mob.mnd/10)*level)+int(mob.pre*level*.5)
        x += int(mob.mnd*5*float(level)/100.0)
        return x

    def getMaxHealth(self, mob, level):
        return int(Combatant.getMaxHealth(self, mob, level)*1)

class Paladin(Combatant):
    """ Tin cans with heal spells """
    def __init__(self):
        self.name = "Paladin"
        Combatant.__init__(self)

    def getXPMod(self):
        return 1.05
    
    def getMaxMana(self, mob, level):
        x = int((mob.wis/10)*level)+int(mob.pre*level*.5)
        x += int(mob.wis*5*float(level)/100.0)
        return x

    def getDefense(self, mob, level):
        return int(Combatant.getDefense(self, mob, level)*1.10)
            
    def getMaxHealth(self, mob, level):
        return int(Combatant.getMaxHealth(self, mob, level)*1.2)

class DoomKnight(Combatant):
    """ Evil equivalent of Paladins """
    def __init__(self):
        self.name = "Doom Knight"
        Combatant.__init__(self)

    def getMaxMana(self, mob, level):
        x = int((mob.mnd/10)*level)+int(mob.pre*level*.5)
        x += int(mob.mnd*5.0*float(level)/100.0)
        return x

    def getXPMod(self):
        return .9

class Barbarian(Combatant):
    """ All brawn, no brains """
    def __init__(self):
        self.name = "Barbarian"
        Combatant.__init__(self)

    def getXPMod(self):
        return 1.05

    def getOffense(self, mob, level):
        return int(Combatant.getOffense(self, mob, level)*1.2)

    def getDefense(self, mob, level):
        return int(Combatant.getDefense(self, mob, level)*.9)
        
    def getMaxHealth(self, mob, level):
        return int(Combatant.getMaxHealth(self, mob, level)*1.1)

class Monk(Combatant):
    """ Hand-to-hand specialist """
    def __init__(self):
        self.name = "Monk"
        Combatant.__init__(self)

    def getXPMod(self):
        return 1.1

    def getMaxHealth(self, mob, level):
        s1 = level/10.0
        s2 = level/25.0
        return int((level*level+50+(mob.bdy*s1)+(mob.str*s2)))+mob.pre*7
        
    def getOffense(self, mob, level):
        s1 = level/10.0
        s2 = level/25.0
        s3 = level/50.0
        base = int((level*level+10+(mob.str*s1)+(mob.dex*s2)+(mob.ref*s3))*1.25)
        return base + mob.pre * 6
    
    def getDefense(self, mob, level):
        s0 = level/5.0
        s1 = level/10.0
        s2 = level/25.0
        s3 = level/50.0
        s4 = level/100.0
        base = int(level*level+10+(mob.bdy*s1)+(mob.dex*s2)+(mob.ref*s1)+(mob.agi*s0))
        base+=mob.armor*2+mob.pre*4
        return base

# ROGUE based classes

class Assassin(Rogue):
    """ The blade in the night - stealth and sudden damage """
    def __init__(self):
        self.name = "Assassin"
        Rogue.__init__(self)

    def getXPMod(self):
        return 1.1

    def getCritical(self, mob, level):
        return 1.4

class Thief(Rogue):
    """ Basic thief """
    def __init__(self):
        self.name = "Thief"
        Rogue.__init__(self)

    def getXPMod(self):
        return 1

class Bard(Rogue):
    """ Spellcasters of a sort """
    def __init__(self):
        self.name = "Bard"
        Rogue.__init__(self)

    def getXPMod(self):
        return 1

    def getMaxStamina(self, mob, level):
        s1 = level/10.0
        s2 = level/25.0
        return int((level*level+50+(mob.bdy*s1)+(mob.str*s2)))+mob.pre*5
    
    def getCritical(self, mob, level):
        return 1.0
    
    def getMaxHealth(self, mob, level):
        s1 = level/10.0
        s2 = level/25.0
        return int((level*level+50+(mob.bdy*s1)+(mob.str*s2)))+mob.pre*6
        
    def getOffense(self, mob, level):
        s1 = level/10.0
        s2 = level/25.0
        s3 = level/50.0
        base = int(level*level+10+(mob.str*s1)+(mob.dex*s2)+(mob.ref*s3))
        return base + mob.pre * 4
    
    def getDefense(self, mob, level):
        s1 = level/10.0
        s2 = level/25.0
        s3 = level/50.0
        s4 = level/100.0
        base = int(level*level+10+(mob.bdy*s1)+(mob.dex*s2)+(mob.ref*s3)+(mob.agi*s4))
        base+=mob.armor*4+mob.pre*4
        return base

# MAGI based classes

class Wizard(Magi):
    """ Straight damage caster """
    def __init__(self):
        self.name = "Wizard"
        Magi.__init__(self)

    def getXPMod(self):
        return 1.05

class Revealer(Magi):
    """ Portal spells and some buffs/debuffs """
    def __init__(self):
        self.name = "Revealer"
        Magi.__init__(self)

    def getXPMod(self):
        return 1.05

class Necromancer(Magi):
    """ Pet-based - raise the dead, cast diseases """
    def __init__(self):
        self.name = "Necromancer"
        Magi.__init__(self)

    def getXPMod(self):
        return 1.1

# PRIEST based classes

class Cleric(Priest):
    """ Basic healer """
    def __init__(self):
        self.name = "Cleric"
        Priest.__init__(self)

    def getXPMod(self):
        return 1

    def getMaxMana(self, mob, level):
        x = int((mob.wis/10)*level)+int(mob.pre*level*.5)
        x += int(mob.wis*5*float(level)/100.0)
        return x

class Tempest(Priest):
    """ Master of the elements """
    def __init__(self):
        self.name = "Tempest"
        Priest.__init__(self)

    def getXPMod(self):
        return 1.05

class Shaman(Priest):
    """ Pets, buffs, and debuffs """
    def __init__(self):
        self.name = "Shaman"
        Priest.__init__(self)

    def getXPMod(self):
        return 1.05

class Druid(Priest):
    """ Ports, buffs and debuffs """
    def __init__(self):
        self.name = "Druid"
        Priest.__init__(self)
        
    def getMaxMana(self, mob, level):
        x = int((mob.mnd/10)*level)+int(mob.pre*level*.5)
        x += int(mob.mnd*5.0*float(level)/100.0)
        return x

    def getXPMod(self):
        return 1

def InitClassSkills():
    """
    This method sets up the CLASSES module attribute, to contain all the
    relevant classes.
    
    Called on startup, at response to Imm command, or by first call to
    "getClass"
    """
    global CLASSES
    # Wipe and re-create
    CLASSES = {}
    # Combatants
    CLASSES['Warrior'] = Warrior()
    CLASSES['Ranger'] = Ranger()
    CLASSES['Paladin'] = Paladin()
    CLASSES['Doom Knight'] = DoomKnight()
    CLASSES['Barbarian'] = Barbarian()
    CLASSES['Monk'] = Monk()
    # Rogues
    CLASSES['Thief'] = Thief()
    CLASSES['Assassin'] = Assassin()
    CLASSES['Bard'] = Bard()
    # Magi
    CLASSES['Wizard'] = Wizard()
    CLASSES['Revealer'] = Revealer()
    CLASSES['Necromancer'] = Necromancer()
    # Priests
    CLASSES['Cleric'] = Cleric()
    CLASSES['Tempest'] = Tempest()
    CLASSES['Shaman'] = Shaman()
    CLASSES['Druid'] = Druid()
    # Setup classSkills for handy reference
    for cl in CLASSES.itervalues():
        if cl.classProto:
            cl.classSkills = cl.classProto.skills
    
def GetClass(classname):
    """
    Return a named class
    
    Parameters:
        - `classname` str name of class to return
        
    :Returns:
        - an instance of the appropriate class from above, or warrior if
          named class is not found.
    """
    if not len(CLASSES):
        InitClassSkills()
    try:
        return CLASSES[classname]
    except KeyError:
        print "WARNING: Unknown class:", classname
        return CLASSES["Warrior"]
