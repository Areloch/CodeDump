"""
Battle code covers sequenced battles between two forces of multiple mobs.
"""

import random, traceback

from sqlobject import *
from mud.common.persistent import Persistent
from defines import *
from core import *
from messages import ZoneMessage, ZoneSound

class BattleGroup(Persistent):
    """ Basic battle group database definition """
    triggerSpawnGroup = StringCol(default="")
    spawnGroup = StringCol(default="")
    attackDelay = IntCol(default=0)
    passive = BoolCol(default=False)
    battleSequence = ForeignKey('BattleSequence', default=None)
    
class BattleSequence(Persistent):
    """
    Basic sequence database definition, for joining groups into the fight
    """
    battleGroups = MultipleJoin('BattleGroup')    
    zoneSound = StringCol(default="")
    zoneMessage = StringCol(default="")
    delay = IntCol(default=0)
    nextSequence = ForeignKey("BattleSequence", default=None)
    
class BattleResult(Persistent):
    """
    Basic database definition for the results of the battle
    Includes zone messages
    """
    triggerSpawnGroup = StringCol(default="")
    spawnGroup = StringCol(default="")
    zoneSound = StringCol(default="")
    zoneMessage = StringCol(default="")
    # TODO be able to alter zone
    
class BattleMustSurvive(Persistent):
    """
    database definition to store names of mobs that must survive for the
    fight to continue
    """
    name = StringCol()
    battleProto = ForeignKey('BattleProto')

class BattleProto(Persistent):
    """
    Database definition for the battle itself.
    
    Instantiate one of these, then it gets passed to the other classes to
    link the battle groups etc into the battle itself.
    """
    # Attributes about the battle, including which zone it's in
    name = StringCol(alternateID = True)
    zoneName = StringCol(default="")
    zoneMessage = StringCol(default="")
    zoneSound = StringCol(default="")
    # Start sequences, victory results, and defeat results as attributes
    side1StartSequence = ForeignKey('BattleSequence', default = None)
    side2StartSequence = ForeignKey('BattleSequence', default = None)
    side1VictoryResult = ForeignKey('BattleResult', default=None)
    side2VictoryResult = ForeignKey('BattleResult', default=None)
    side1DefeatResult = ForeignKey('BattleResult', default=None)
    side2DefeatResult = ForeignKey('BattleResult', default=None)
    battleMustSurvive = MultipleJoin('BattleMustSurvive')
    
class BattleSide:
    """
    Basic object that encapsulates the behaviour of a single side in the battle
    
    This code is not called directly - it's a class to be inherited from for any
    battles you want to define.  There are certain attributes on the class
    that are only defined once the side is part of a battle (eg. self.zone,
    self.battle).
    """
    def __init__(self):
        """ Setup attributes """
        self.battle = None
        self.zone = None
        self.delay = 0
        self.sequence = None
        # battleGroups is a list of the mobs on our side
        self.battleGroups = {}
        # and their attack timers
        self.battleGroupAttackTimers = {}
        self.thinkTimer = 0
        self.forfeit = False
        self.mobs = []
                
    def triggerSequence(self):
        """
        Very basic state machine to move the side through a number of sequences
        """
        if not self.sequence:
            traceback.print_stack()
            print "AssertionError: battle side has no sequence assigned!"
            return
        # clear the list of mobs and their timers, to be refreshed
        self.battleGroups = {}
        self.battleGroupAttackTimers = {}
        # Pick the next sequence
        sequence = self.sequence
        self.sequence = sequence.nextSequence
        self.mobs = []
        # If we have a message on entering this sequence, spit it out
        if sequence.zoneMessage:
            ZoneMessage(self.zone, sequence.zoneMessage)
        if sequence.zoneSound:
            ZoneSound(self.zone, sequence.zoneSound)
        # For each battlegroup, process any spawns, and setup attack timers
        for bg in sequence.battleGroups:
            self.battleGroups[bg] = []
            self.battleGroupAttackTimers[bg] = bg.attackDelay
            # if we have a spawngroup specified, then spawn it
            override = None
            if bg.spawnGroup:
                # Find the spawngroup to pass to triggeredSpawn
                for sg in self.zone.zone.spawnGroups:
                    if sg.groupName == bg.spawnGroup:
                        override = sg
                        break
                # Now, find the spawn point and bring them into being
                for sp in self.zone.spawnpoints:
                    if sp.groupName == bg.triggerSpawnGroup:
                        mob = sp.triggeredSpawn(override)
                        if mob:
                            self.battleGroups[bg].append(mob)
                            self.mobs.append(mob)
                            mob.battle = self.battle
        # TODO sfx/message
        
    def updateMobTarget(self, mob):
        """
        For each mob, pick a target if none exists currently
        
        :Parameters:
            - `mob` the mob we're working with
        """
        # Already fighting someone, nothing to do
        if mob.target:
            return
        # Find the enemy
        oside = self.battle.side1
        if oside == self:
            oside = self.battle.side2
        # Pick a random enemy
        x = len(oside.mobs)
        if x:
            if x > 1:
                x = random.randint(0, x-1)
            else:
                x = 0
            target = oside.mobs[x]
            # The commented code finds the closest enemy instead of picking a
            # random one
            #target = None
            #best = 1000000    
            #for omobs in oside.battleGroups.values():
            #    for omob in omobs:
            #        r = GetRange(mob,omob)
            #        if r < best:
            #            best = r
            #            target = omob
            # If the target we've selected is available and not "detached"
            # (dead), and we're not already aggro'ed toward it, then add some
            # aggro.  This'll let the standard target selection code work out
            # what to hit.
            if target and not target.detached:
                if target not in mob.aggro.keys():
                    mob.addAggro(target, 10)

    def tick(self):
        """
        Code called on each tick from the battle's tick
        
        :Returns:
            - bool True if we've been defeated, False otherwise
        """
        # countdown in 3's until we reach time, then trigger the sequence
        # code.
        if self.delay:
            self.delay -= 3
            if self.delay <= 0:
                self.delay = 0
                #trigger sequence
                self.triggerSequence()
        # Check if we've lost
        if not len(self.battleGroups):
            if not self.sequence:
                return True
            self.delay = self.sequence.delay + 3
        else:
            # We have some mobs, update their targets and set attack timers
            self.thinkTimer -= 3
            if self.thinkTimer <= 0:
                self.thinkTimer = 18
                for bg, mobs in self.battleGroups.iteritems():
                    if bg.passive:
                        continue
                    if self.battleGroupAttackTimers.get(bg) > 0:
                        self.battleGroupAttackTimers[bg] -= 18
                    if self.battleGroupAttackTimers.get(bg) <= 0:
                        for mob in mobs:
                            self.updateMobTarget(mob)
        return False
        
    def detachMob(self, mob):
        """
        Remove the mob from our group - called for death of a mob
        
        :Parameters:
            - `mob` the mob to remove
            
        :Returns:
            - bool True if there's no more mobs in this side (defeat)
        """
        for bg, mobs in self.battleGroups.iteritems():
            if mob in mobs:
                mob.battle = None
                mobs.remove(mob)
                self.mobs.remove(mob)
                if not len(mobs):
                    del self.battleGroups[bg]
                return True    
        return False
    
class Battle:
    """ The battle itself - again, inherit from to use """
    def __init__(self, zone, bproto):
        """
        Setup basic attributes, including start sequences, send initial sounds
        
        :Parameters:
            - `zone` the zone we're fighting in
            - `bproto` the BattleProto object for link to database
        """
        self.over = False
        self.forfeit = False
        self.name = bproto.name
        self.zone = zone
        zone.battles.append(self)
        self.battleProto = bproto
        # Create sides
        side1 = self.side1 = BattleSide()
        side2 = self.side2 = BattleSide()
        side1.battle = self
        side2.battle = self
        # Set initial sequences
        s1seq = bproto.side1StartSequence
        s2seq = bproto.side2StartSequence
        if not s1seq or not s2seq:
            traceback.print_stack()
            print "AssertionError: battle %s is missing a start sequence!" \
                % self.name
            return
        # XXX These should really be set as part of init'ing the side 
        side1.zone = zone
        side2.zone = zone
        side1.sequence = s1seq
        side2.sequence = s2seq
        # Initial delays for actions
        side1.delay = s1seq.delay + 3
        side2.delay = s2seq.delay + 3
        # Setup the crucial parties to each side
        self.battleMustSurvive = []
        for ms in bproto.battleMustSurvive:
            self.battleMustSurvive.append(ms.name)
        # Send messages and sounds to announce the battle
        if bproto.zoneMessage:
            ZoneMessage(zone, bproto.zoneMessage)
        if bproto.zoneSound:
            ZoneSound(zone, bproto.zoneSound)
            

    def detachMob(self, mob):
        """ I die!
        
        :Parameters:
            - `mob` the mob that just died
        """
        forfeit = False
        if mob.spawn.name in self.battleMustSurvive and not self.forfeit:
            # Crucial party died - give up
            ZoneMessage(self.zone, "%s has been slain!!!" % mob.spawn.name)
            forfeit = self.forfeit = True
        # Last member of whichever side has died, give up
        if self.side1.detachMob(mob):
            if forfeit:
                self.side1.forfeit = True
        if self.side2.detachMob(mob):
            if forfeit:
                self.side2.forfeit = True

    def end(self):
        """
        Called at end of battle, to reset things back to pre-battle settings
        """
        self.over = True
        self.zone.battles.remove(self)
        # Set the mobs to wander off (despawn) in about 10 minutes
        for m in self.side1.mobs:
            m.despawnTimer = 60 * 10 * 6
        for m in self.side2.mobs:
            m.despawnTimer = 60 * 10 * 6

    def updateMobTarget(self, mob):
        """
        Pick a new target - call the side target choice code
        
        :Parameters:
            - `mob` mob that's looking for something new to attack
        """
        if mob in self.side1.mobs:
            self.side1.updateMobTarget(mob)
        else:
            self.side2.updateMobTarget(mob)

    def doResult(self, result):
        """
        Action the end of battle results
        
        :Parameters:
            - `result` a result object containing what to do
        """
        # Send messages and sounds
        if result.zoneMessage:
            ZoneMessage(self.zone, result.zoneMessage)
        if result.zoneSound:
            ZoneSound(self.zone, result.zoneSound)
        # if we have a spawngroup specified for end of battle, spawn them
        override = None
        if result.spawnGroup:
            for sg in self.zone.zone.spawnGroups:
                if sg.groupName == result.spawnGroup:
                    override = sg
                    break
            for sp in self.zone.spawnpoints:
                if sp.groupName == result.triggerSpawnGroup:                        
                    mob = sp.triggeredSpawn(override)
                    if mob:
                        mob.despawnTimer = 60*10*6 # 10 minutes
                        mob.battle = self

    def tick(self):
        """ Check for victory from either side, clean up if so """
        end = False
        result = None
        if self.side1.tick() or self.side1.forfeit:
            # Side 1 lost
            end = True
            result = self.battleProto.side2VictoryResult
            # Remove their mobs from the field of battle
            for m in self.side1.mobs[:]:
                m.zone.removeMob(m)
        if self.side2.tick() or self.side2.forfeit:
            # Side 2 lost
            result = self.battleProto.side1VictoryResult
            end = True
            for m in self.side2.mobs[:]:
                m.zone.removeMob(m)
        # If either side lost, call the cleanups and finish
        if end:
            if result:
                self.doResult(result)
            self.end()