from random import randint
from sqlobject import *
from defines import *
import spawn
from item import ItemProto
from mud.common.persistent import Persistent
from mud.world.shared.playdata import ItemInfo
from mud.world.shared.sounddefs import *
import math
import traceback
from core import *


from mud.world.itemvariants import GenVariantItem

ZONE_POTIONS = {
"anidaenforest":"Potion of Anidaen Gate",
"arctic":"Potion of Frostbite Gate",
"jakrethjungle":"Potion of Jakreth Gate",
"talrimhills":"Potion of Talrim Gate",
"desertmohrum":"Potion of Mohrum Gate",
"trinst":"Potion of Trinst Gate",
"kauldur":"Potion of Kauldur Gate",
"swamp":"Potion of Swamp Gate"
}

# modification begin
# list of which enchanting focii will drop in which zone
ZONE_ENCHANTINGITEMS = {
"desertmohrum":["Sandstone of Clarity","Sandstone of Strength","Sandstone of Health","Sandstone of Ether","Sandstone of Endurance","Sandstone of the Sphinx"],
"mountain":["Coal of Insight","Coal of Fiery Protection","Coal of Health","Coal of Ether","Coal of Endurance","Coal of the Dwarven King"],
"arctic":["Icy Shard of Instinct","Icy Shard of the Arcane","Icy Shard of Cold Protection","Icy Shard of Health","Icy Shard of Ether","Icy Shard of Endurance","Icy Shard of Volsh"],
"anidaenforest":["Bark of Magic Protection","Bark of Health","Bark of Ether","Bark of Endurance","Bark of Speed"],
"talrimhills":["Limestone of Constitution","Limestone of Electrical Resistance","Limestone of Health","Limestone of Ether","Limestone of Endurance","Limestone of Lightning"],
"hazerothkeep":["Quartz of Nimbleness","Quartz of Physical Protection","Quartz of Health","Quartz of Ether","Quartz of Endurance","Quartz of the Warling Cleric"],
"wasteland":["Blighted Shard of Quickness","Blighted Shard of Defense","Blighted Shard of Health","Blighted Shard of Ether","Blighted Shard of Endurance","Blighted Shard of Aelieas"],
"jakrethjungle":["Vine of Poison Resist","Vine of Disease Resist","Vine of Health","Vine of Ether","Vine of Endurance","Vine of the Cavebear"],
"swamp":["Muck-Covered Stone of Acidity","Muck-Covered Stone of Health","Muck-Covered Stone of Ether","Muck-Covered Stone of Endurance","Muck-Covered Stone of the Ghoul Slayer"]
}
# list of quality prefixes, 'raw' is not yet enchanted item (Coal, Sandstone, ...), raw can't be dropped, only gained from disenchanting and the prefix won't be used anyway.
ENCHANT_QualityPrefix = ["Raw ","Fractured ","Rough ","Jagged ","Smooth ","Clear ","Pristine ","Exquisite "]
# raw can't be dropped, so 0; chances are [0%,50%,25%,13%,6%,3%,2%,1%]
ENCHANT_QualityDropDistribution = [0,50,75,88,94,97,99,100]
# modification end

#Potion of and Elixir of
STAT_POTIONS = ("Strength","Mind","Reflex","Agility","Body","Wisdom","Mysticism","Dexterity")

WILDTOMES = ("Paladin","Cleric","Necromancer","Tempest","Wizard","Shaman","Revealer","Druid","Ranger","Bard","Doom Knight")

class LootItem(Persistent):
    lootProto = ForeignKey('LootProto')
    itemProto = ForeignKey('ItemProto')
    freq = IntCol(default=RPG_FREQ_ALWAYS)
    flags = IntCol(default=0)
    
class LootProto(Persistent):
    spawns = MultipleJoin('Spawn')
    lootItems = MultipleJoin('LootItem')
    
    tin = IntCol(default = 0L)
    
    def _init(self,*args,**kw):
        Persistent._init(self, *args, **kw)
        self.lootItemList = None
    
    def _get_itemDetails(self):
        if self.lootItemList != None:
            return self.lootItemList
        self.lootItemList = {}
        for item in self.lootItems:
            self.lootItemList[item.itemProto.name] = item.flags
        return self.lootItemList
    
class Loot:
            
    def initRandomLoot():
        from dialog import DialogGiveItem,DialogTakeItem,DialogCheckItem
        #to do, better
        Loot.randomItemProtos = []
        spellScrolls = Loot.spellScrolls = {}
        
        con = ItemProto._connection.getConnection()
        
        protos={}
        
        for id,flags,rating,spell_proto_id in con.execute("SELECT id,flags,rating,spell_proto_id FROM item_proto;"):
            if spell_proto_id:
                for classname,level in con.execute("SELECT classname,level FROM spell_class WHERE spell_proto_id = %i;"%spell_proto_id):
                    if not spellScrolls.has_key(classname):
                        spellScrolls[classname]={}
                    d = spellScrolls[classname]
                    if not d.has_key(level):
                        d[level]=[]
                        
                    ip = protos.get(id,None)
                    if not ip:
                        ip = ItemProto.get(id)
                        protos[id]=ip
                                                
                    d[level].append(ip)
                    
                continue
            
            if rating != 1:
                continue
            
            if flags&RPG_ITEM_SOULBOUND:
                continue
            
            ip = protos.get(id,None)
            if not ip:
                ip = ItemProto.get(id)
                protos[id]=ip
            
            Loot.randomItemProtos.append(ip)
            
            
        #"unique" variant loot
        uloot = {}
        
        for itemid,freq in con.execute("SELECT item_proto_id,freq FROM loot_item WHERE loot_proto_id IN (SELECT DISTINCT loot_proto_id from spawn where not flags&%i) AND freq >= %i;"%(RPG_SPAWN_UNIQUE,RPG_FREQ_COMMON)):
            if con.execute("SELECT id FROM item_slot WHERE item_proto_id=%i LIMIT 1;"%itemid).fetchone():
                #equippable
                if uloot.has_key(itemid):
                    if freq > uloot[itemid]:
                        uloot[itemid] = freq
                else:
                    uloot[itemid] = freq
        
        
        #level -> list of item protos
        Loot.uniqueItemProtos = {}
        uprotos = []
        for itemid,freq in uloot.iteritems():
            ip = protos.get(itemid,None)
            if not ip:
                ip = ItemProto.get(itemid)
                protos[itemid]=ip

            
            level = ip.level
            for cl in ip.classes:
                if cl.level > level:
                    level = cl.level
                    
            if level == 1:
                continue
            
            if ip in uprotos:
                continue
            
            uprotos.append(ip)
                    
            if not Loot.uniqueItemProtos.has_key(level):
                Loot.uniqueItemProtos[level]=[]
                
            Loot.uniqueItemProtos[level].append((freq,ip))
        
    initRandomLoot = staticmethod(initRandomLoot)
        
    
    def __init__(self,mob,lootProto):
        self.mob = mob
        self.lootProto = lootProto
        
        self.items = []
        
        self.tin = 0L
        
        self.fleshDone = False
        self.corpseLootGenerated = False
        self.pickPocketCount = 3  # here because some mobs don't even have loot
        self.pickPocketTimer = 0  # timer won't allow immediate repickpocketing
     
    def giveMoney(self,player):
        gotsome = False
        if self.tin:
            gotsome=True
            player.alliance.giveMoney(player,self.tin)
        
        self.tin = 0L
        
        return gotsome
    
    def generateCorpseLoot(self):
        
        loot = self.items
        
        if self.corpseLootGenerated:
            if len(loot):
                return True
            if self.tin:
                return True
            return False
        
        spawn = self.mob.spawn
        proto = self.lootProto
        self.corpseLootGenerated = True
        
        if proto:
            #$$$, to do, curve these
            if proto.tin:
                self.tin = randint(0,proto.tin)
            
            for lootitem in proto.lootItems:
                if not len(lootitem.itemProto.slots):
                    freq = lootitem.freq
                    r = 0
                    if freq > 1:
                        r = randint(0,freq-1)
                    if not r:
                        #got it
                        iproto = lootitem.itemProto
                        item = iproto.createInstance()
                        
                        #possibly generate a variant
                        GenVariantItem(item,self.mob.plevel)
                        
                        item.slot = -1
                        #item.itemInfo = ItemInfo(item)
                        loot.append(item)
                        if len(loot) == 16:
                            break
                    
                    if len(loot) == 16:
                        break

        num = randint(0,int(spawn.plevel/10)+1)
        for x in xrange(0,num):
            if randint(0,3): #25%
                continue
            if len(loot)==16:
                break

            iproto = Loot.randomItemProtos[randint(0,len(Loot.randomItemProtos)-1)]
            item = iproto.createInstance()
            GenVariantItem(item,self.mob.plevel)

            item.slot = -1
            loot.append(item)
            if len(loot)==16:
                break
            
        #zone potion
        if len(loot)<16:
            #zone or stat potion
            chance = 35-spawn.plevel/3
            if not randint(0,chance):
                try:
                    zpotion = ZONE_POTIONS[self.mob.zone.zone.name]
                    zpotion = ItemProto.byName(zpotion)
                    item = zpotion.createInstance()
                    item.slot = -1
                    loot.append(item)
                    
                except:
                    pass
                    #traceback.print_exc()

        if len(loot)<16:
            #moon powder
            chance = 35-spawn.plevel/4
            if not randint(0,chance):
                try:
                    
                    p = ItemProto.byName("Moon Powder")
                    item = p.createInstance()
                    item.slot = -1
                    loot.append(item)
                    
                except:
                    pass
                    #traceback.print_exc()
                    
        #stat potion
        num = 1
        if self.mob.uniqueVariant:
            num = 2
        for x in xrange(0,num):
            if len(loot)<16:
                #zone or stat potion
                chance = (110-spawn.plevel)/2
                if not randint(0,chance):
                    try:
                        index = randint(0,len(STAT_POTIONS)-1)
                        stat = STAT_POTIONS[index]
                        potion = "Potion of %s"%stat
                        if spawn.plevel >= 25:
                            chance = (110-spawn.plevel)/3
                            if not randint(0,chance):
                                potion = "Elixir of %s"%stat
                        
                        potion = ItemProto.byName(potion)
                        item = potion.createInstance()
                        item.slot = -1
                        loot.append(item)
                        
                    except:
                        traceback.print_exc()
        
        num = 1
        if self.mob.uniqueVariant:
            num = 2
        for x in xrange(0,num):                    
            if len(loot)<16:
                if not randint(0,4): #got one
                    scrolls = []
                    if not randint(0,2):
                        wclass = WILDTOMES[randint(0,len(WILDTOMES)-1)]
                        wlevel = spawn.plevel
                        classes = ((spawn.pclassInternal,spawn.plevel),(spawn.sclassInternal,spawn.slevel),(spawn.tclassInternal,spawn.tlevel),(wclass,wlevel))
                    else:
                        classes = ((spawn.pclassInternal,spawn.plevel),(spawn.sclassInternal,spawn.slevel),(spawn.tclassInternal,spawn.tlevel))
                        
                    for cl,level in classes:
                        if Loot.spellScrolls.has_key(cl):
                            spellScrolls = Loot.spellScrolls[cl]
                            for x in xrange(1,level+11):
                                if x < level - 5:
                                    continue
                                if spellScrolls.has_key(x):
                                    for ip in spellScrolls[x]:
                                        if ip not in scrolls:
                                            scrolls.append(ip)
                            
                            
                    scroll = None
                    if len(scrolls)==1:
                        scroll = scrolls[0]
                    elif len(scrolls)>1:
                        scroll = scrolls[randint(0,len(scrolls)-1)]
                                    
                    if scroll:
                        v = (0,30,55,75,85,90,94,97,101)
                        x = randint(0,100)
                        y = 1
                        for z in xrange(0,9):
                            if x < v[z]:
                                break
                            y+=1
                            
                        x=y
                        
                        if self.mob.uniqueVariant:
                            x+=5
                            if x > 10:
                                x = 10
                                                
                        item = scroll.createInstance("STUFF/38")
                        item.spellEnhanceLevel = x
                        roman = ("I","II","III","IV","V","VI","VII","VIII","IX","X") #I isn't used
                        spellname = scroll.spellProto.name
                        item.name = "Tome of %s %s"%(spellname,roman[x-1])
                        item.slot = -1
                        item.descOverride = "This tome contains secrets of the %s spell.  It can increase the reader's potency up to level %s in casting."%(spellname,roman[x-1])
                        item.itemInfo.reset()
                        
                        loot.append(item)
                    
        #books of learning
        num = 1
        if self.mob.uniqueVariant:
            num = 2
        for x in xrange(0,num):
            if len(loot)<16:
                chance = (110-spawn.plevel)/2
                if not randint(0,chance):
                    try:
                        
                        
                        iname = "Scroll of Learning"
                        if spawn.plevel >= 60:
                            chance = (110-spawn.plevel)/3
                            if not randint(0,chance):
                                iname = "Book of Learning"
                        
                        book = ItemProto.byName(iname)
                        item = book.createInstance()
                        item.slot = -1
                        loot.append(item)
                        
                    except:
                        traceback.print_exc()
        
        #uniqueVariants
        
        if len(loot)<16 and self.mob.uniqueVariant:
            x = spawn.plevel - 20
            if x < 1:
                x = 1
            
            items = {}
            for level in xrange(x,spawn.plevel+1):
                if Loot.uniqueItemProtos.has_key(level):
                    for freq,ip in Loot.uniqueItemProtos[level]:
                        if not items.has_key(freq):
                            items[freq]=[]
                        items[freq].append(ip)
            
            if len(items):
                for x in xrange(0,3):
                    ip = None
                    if not randint(0,2):
                        for freq in sorted(items.iterkeys(),reverse = True):
                            if not randint(0,freq):
                                if len(items[freq])==1:
                                    ip = items[freq][0]
                                    break
                                else:
                                    ip = items[freq][randint(0,len(items[freq])-1)]
                                    break
                    if ip:
                        item = ip.createInstance()
                        item.slot = -1
                        loot.append(item)
        
        
        # zone dependend enchanting-item drop, last item per list is more rare than the rest
        if len(loot)<16:
            # check if we got one; ok, this is actually 1 in RPG_FREQ_RARE+1 but that's good enough
            if not randint(0,RPG_FREQ_RARE):
                try:
                    zoneEnchItemList = ZONE_ENCHANTINGITEMS[self.mob.zone.zone.name]
                    
                    # check if this is even an uber enchantment type (chance total: 1 in 561)
                    # this seems like an extremely low drop chance, but considering it gets applied to every single loot collection...
                    enchQuality = 0
                    # because the special enchantments are this rare and because of their power, they're always exquisite
                    if not randint(0,RPG_FREQ_IMPOSSIBLE):
                        enchName = zoneEnchItemList[-1]	# get last item of list (uber enchantment)
                        enchQuality = len(ENCHANT_QualityPrefix) - 1
                    else:
                        enchName = zoneEnchItemList[randint(0,len(zoneEnchItemList)-2)]	# random normal type
                        # random quality for item (lower quality items can be combined for higher quality)
                        qualityCursor = randint(1,100)	# don't allow 0 (raw drop)
                        for qualityTester in xrange(0,len(ENCHANT_QualityPrefix)):
                            if qualityCursor <= ENCHANT_QualityDropDistribution[qualityTester]:
                                break
                            enchQuality += 1
                    
                    enchItem = ItemProto.byName(enchName)
                    item = enchItem.createInstance()
                    item.spellEnhanceLevel = enchQuality + 10	# spellEnhanceLevel is used for quality of this item type (less attribs), values < 10 are used to identify tomes, so use values 10 - 17
                    item.name = ENCHANT_QualityPrefix[enchQuality] + item.name
                    item.slot = -1
                    loot.append(item)
                    
                except:
                    pass
                
        #Essence of the Void
        if len(loot)<16:
            if not randint(0,RPG_FREQ_IMPOSSIBLE*3):
                try:
                    p = ItemProto.byName("Essence of the Void")
                    item = p.createInstance()
                    item.slot = -1
                    loot.append(item)
                    
                except:
                    traceback.print_exc()

                    
        
        for item in loot:
            #Generate Repair
            if not (item.flags & RPG_ITEM_INDESTRUCTIBLE) and item.repairMax > 0:
                if item.repairMax == 1:
                    item.repair = 1
                else:
                    item.repair = randint(1,item.repairMax)
        
        if len(loot):
            self.items = loot
            return True
        if self.tin:
            return True
        return False
   
    def generateLoot(self):
        #ONLY SPAWN LOOT FROM LOOT TABLE THAT CAN BE EQUIPPED HERE!!!!!
        spawn = self.mob.spawn
        
        proto = self.lootProto
        self.items = loot = []
        if proto:
            for lootitem in proto.lootItems:
                if len(lootitem.itemProto.slots):
                    freq = lootitem.freq
                    r = 0
                    if freq > 1:
                        r = randint(0,freq-1)
                    if not r:
                        #got it
                        iproto = lootitem.itemProto
                        
                        item = iproto.createInstance()
                        
                        #possibly generate a variant
                        GenVariantItem(item,self.mob.plevel)
                        
                        item.slot = -1
                        #item.itemInfo = ItemInfo(item)
                        loot.append(item)
                    
                        if len(loot) == 16:
                            break





def GenerateLoot(mob):
    
    if mob.player or (mob.master and not mob.spawn.lootProto):
        return
    
    mob.loot = Loot(mob,mob.spawn.lootProto)
    mob.loot.generateLoot()
    #mob.loot.mob = None
    #mob.loot = None
     
        
