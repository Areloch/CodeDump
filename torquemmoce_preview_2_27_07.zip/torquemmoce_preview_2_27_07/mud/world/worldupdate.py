from genesistime import GENESISTIME
import sys,os,traceback,imp
from datetime import datetime
import re
import shutil

from sqlobject import *

from mud.world.defines import *
from mud.common.dbconfig import SetDBConnection
from mud.common.permission import User,Role
from mud.common.persistent import Persistent

from mud.world.player import Player,PlayerXPCredit,PlayerMonsterSpawn
from mud.world.zone import Zone
from mud.world.character import Character,CharacterSpell,CharacterSkill,CharacterAdvancement,CharacterDialogChoice,CharacterVaultItem,CharacterFaction
from mud.world.spawn import Spawn,SpawnResistance,SpawnStat
from mud.world.spell import SpellProto
from mud.world.advancement import AdvancementProto
from mud.world.faction import Faction

from mud.world.item import Item,ItemProto,ItemSpell
from mud.world.itemvariants import ItemVariant

from sqlite3 import dbapi2 as sqlite

try:
    from tgenative import *
    from mud.tgepython.console import TGEExport
except:
    pass


WSCHEMA = {}
TABLES = ["Player","PlayerXPCredit","PlayerMonsterSpawn","PlayerIgnore",
"Character","CharacterSpell","CharacterSkill","CharacterAdvancement","CharacterDialogChoice","CharacterVaultItem","CharacterFaction",
"Item","ItemVariant","Spawn","SpawnResistance","SpawnStat","User","Role"
]

FROMGAME = False
FORCE = False


def main_is_frozen():
   return (hasattr(sys, "frozen") or # new py2exe
           hasattr(sys, "importers") # old py2exe
           or imp.is_frozen("__main__")) # tools/freeze


def CheckWorld(worldPath,baselinePath):
    global WCONN
    global BCONN
    
    
    #Genesis Time
    gdate,gtime = GENESISTIME.split(" ")
    gyear,gmonth,gday = gdate.split("-")
    ghour,gminute,gsecond = gtime.split(":")
    gyear = int(gyear)
    gmonth = int(gmonth)
    gday = int(gday)
    ghour = int(ghour)
    gminute = int(gminute)
    gsecond = int(gsecond)
    
    #World Time
        
    WCONN = sqlite.connect(worldPath)
    
    wcur = WCONN.cursor()
    
    try:
        wcur.execute('select genesis_time from World where name="TheWorld"')
    
        #World Time
        wdate,wtime = wcur.fetchone()[0].split(" ")
        wyear,wmonth,wday = wdate.split("-")
        whour,wminute,wsecond = wtime.split(":")
        wyear = int(wyear)
        wmonth = int(wmonth)
        wday = int(wday)
        whour = int(whour)
        wminute = int(wminute)
        wsecond = int(wsecond)
    except:
        wyear=wmonth=wday=whour=wminute=wsecond=1


    #Baseline Time
        
    BCONN = sqlite.connect(baselinePath)
    
    bcur = BCONN.cursor()
    
    bcur.execute('select genesis_time from World where name="TheWorld"')
    
    #World Time
    bdate,btime = bcur.fetchone()[0].split(" ")
    byear,bmonth,bday = bdate.split("-")
    bhour,bminute,bsecond = btime.split(":")
    byear = int(byear)
    bmonth = int(bmonth)
    bday = int(bday)
    bhour = int(bhour)
    bminute = int(bminute)
    bsecond = int(bsecond)
    
    bcur.close()
    wcur.close()
    BCONN.close()
    BCONN = None
    WCONN.close()
    WCONN = None
    
    
    wdatetime = datetime(wyear,wmonth,wday,whour,wminute,wsecond)
    gdatetime = datetime(gyear,gmonth,gday,ghour,gminute,gsecond)
    bdatetime = datetime(byear,bmonth,bday,bhour,bminute,bsecond)
    
    #We can add this if we want
    #if main_is_frozen():
    #    if gdatetime != bdatetime:
    #        if FROMGAME:
    #            TGEEval('canvas.setContent("MainMenuGui");')
    #            TGECall("MessageBoxOK","Error updating world!","Genesis Time does not match Baseline Time!")        
    #            return -1
                    
    if wdatetime < bdatetime or FORCE:
        #we need to upgrade
        return 1
    
    return 0

def FilterColumns(klass,dbAttr):
    #filter columns that no longer exist        
    del dbAttr["id"]
    for col,value in dbAttr.items():
        found = False
        for ncol in klass.sqlmeta._columns:
            if col == ncol.name:
                if ncol._sqliteType() == "TIMESTAMP":
                    #convert to datetime
                    date,time = value.split(" ")
                    year,month,day = date.split("-")
                    hour,minute,second = time.split(":")
                    year = int(year)
                    month = int(month)
                    day = int(day)
                    hour = int(hour)
                    minute = int(minute)
                    second = int(second)
                    dbAttr[col]=datetime(year,month,day,hour,minute,second)

                found = True
                break
        if not found:
            del dbAttr[col]
        


class ItemVariantCopier:
    def __init__(self,cur,id):
        self.dbAttr = {}
        t = mixedToUnder("ItemVariant")
        cur.execute("SELECT * from %s WHERE id = %i;"%(t,id))
        for name,value in zip(WSCHEMA["ItemVariant"],cur.fetchall()[0]):
            self.dbAttr[str(name)]=value
            
    def install(self,item):
        FilterColumns(ItemVariant,self.dbAttr)
        self.dbAttr["itemID"]=item.id
        ItemVariant(**self.dbAttr)

class ItemCopier:
    def __init__(self,cur,id):
        self.dbAttr = {}
        t = mixedToUnder("Item")
        cur.execute("SELECT * from %s WHERE id = %i;"%(t,id))
        protoID = -1
        for name,value in zip(WSCHEMA["Item"],cur.fetchall()[0]):
            if name == "itemProtoID":
                protoID = value
            self.dbAttr[str(name)]=value
            
        cur.execute("select name from item_proto where id = %i"%protoID)
        self.protoName = cur.fetchall()[0][0]
        
        variants = self.variants = []
        
        cur.execute("select id from item_variant where item_id = %i;"%id)
        for r in cur.fetchall():
            f = ItemVariantCopier(cur,r[0])
            variants.append(f)

        
        
    def install(self,char):
        try:
            ip = ItemProto.byName(self.protoName)
        except:
            print "Item: %s no longer exists"%self.protoName
            return

        FilterColumns(Item,self.dbAttr)
        self.dbAttr["itemProtoID"]=ip.id
        self.dbAttr["characterID"]=char.id            
        item=Item(**self.dbAttr)
        
        if not item.stackCount and item.itemProto.stackMax>1:
            item.stackCount = item.itemProto.stackDefault

        for iv in self.variants:
            iv.install(item)
            
        return item

class CharacterFactionCopier:
    def __init__(self,cur,id):
        self.dbAttr = {}
        t = mixedToUnder("CharacterFaction")
        cur.execute("SELECT * from %s WHERE id = %i;"%(t,id))
        for name,value in zip(WSCHEMA["CharacterFaction"],cur.fetchall()[0]):
            self.dbAttr[str(name)]=value
            
        cur.execute("select name from faction where id = %i"%self.dbAttr["factionID"])
        self.factionName = cur.fetchall()[0][0]

    def install(self,char):
        try:
            f = Faction.byName(self.factionName)
        except:
            print "Faction: %s no longer exists"%self.factionName
            return
        FilterColumns(CharacterFaction,self.dbAttr)
        self.dbAttr["characterID"]=char.id
        self.dbAttr["factionID"]=f.id
        CharacterFaction(**self.dbAttr)


class PlayerMonsterSpawnCopier:
    def __init__(self,cur,id):
        self.dbAttr = {}
        t = mixedToUnder("PlayerMonsterSpawn")
        cur.execute("SELECT * from %s WHERE id = %i;"%(t,id))
        for name,value in zip(WSCHEMA["PlayerMonsterSpawn"],cur.fetchall()[0]):
            self.dbAttr[str(name)]=value
            
    def install(self,player):
        FilterColumns(PlayerMonsterSpawn,self.dbAttr)
        self.dbAttr["playerID"]=player.id
        PlayerMonsterSpawn(**self.dbAttr)


class CharacterAdvancementCopier:
    def __init__(self,cur,id):
        self.dbAttr = {}
        t = mixedToUnder("CharacterAdvancement")
        cur.execute("SELECT * from %s WHERE id = %i;"%(t,id))
        
        protoID = -1
        for name,value in zip(WSCHEMA["CharacterAdvancement"],cur.fetchall()[0]):
            if name == "advancementProtoID":
                protoID = value
            self.dbAttr[str(name)]=value

        cur.execute("select name from advancement_proto where id = %i"%protoID)
        self.protoName = cur.fetchall()[0][0]
            
    def install(self,char):
        try:
            adv = AdvancementProto.byName(self.protoName)
        except:
            print "Advancement: %s no longer exists"%self.protoName
            return

        FilterColumns(CharacterAdvancement,self.dbAttr)
        self.dbAttr["advancementProtoID"]=adv.id
        self.dbAttr["characterID"]=char.id            
        CharacterAdvancement(**self.dbAttr)
        

class CharacterVaultItemCopier:
    def __init__(self,cur,id):
        self.dbAttr = {}
        t = mixedToUnder("CharacterVaultItem")
        cur.execute("SELECT * from %s WHERE id = %i;"%(t,id))
        for name,value in zip(WSCHEMA["CharacterVaultItem"],cur.fetchall()[0]):
            self.dbAttr[str(name)]=value
            
        self.item = ItemCopier(cur,self.dbAttr["itemID"])
            
    def install(self,char):
        FilterColumns(CharacterVaultItem,self.dbAttr)
        self.dbAttr["characterID"]=char.id            
        item = self.item.install(char)
        self.dbAttr["itemID"]=item.id
        CharacterVaultItem(**self.dbAttr)
        
        
class CharacterSkillCopier:
    def __init__(self,cur,id):
        self.dbAttr = {}
        t = mixedToUnder("CharacterSkill")
        cur.execute("SELECT * from %s WHERE id = %i;"%(t,id))
        for name,value in zip(WSCHEMA["CharacterSkill"],cur.fetchall()[0]):
            self.dbAttr[str(name)]=value
            
    def install(self,char):
        FilterColumns(CharacterSkill,self.dbAttr)
        self.dbAttr["characterID"]=char.id            
        CharacterSkill(**self.dbAttr)

class CharacterDialogChoiceCopier:
    def __init__(self,cur,id):
        self.dbAttr = {}
        t = mixedToUnder("CharacterDialogChoice")
        cur.execute("SELECT * from %s WHERE id = %i;"%(t,id))
        for name,value in zip(WSCHEMA["CharacterDialogChoice"],cur.fetchall()[0]):
            self.dbAttr[str(name)]=value
            
    def install(self,char):
        FilterColumns(CharacterDialogChoice,self.dbAttr)
        self.dbAttr["characterID"]=char.id            
        CharacterDialogChoice(**self.dbAttr)

class CharacterSpellCopier:
    def __init__(self,cur,id):
        self.dbAttr = {}
        t = mixedToUnder("CharacterSpell")
        cur.execute("SELECT * from %s WHERE id = %i;"%(t,id))
        protoID = -1
        for name,value in zip(WSCHEMA["CharacterSpell"],cur.fetchall()[0]):
            if name == "spellProtoID":
                protoID = value
            self.dbAttr[str(name)]=value
            
        cur.execute("select name from spell_proto where id = %i"%protoID)
        self.protoName = cur.fetchall()[0][0]

    def install(self,char):
        try:
            sp = SpellProto.byName(self.protoName)
        except:
            print "Spell: %s no longer exists"%self.protoName
            return

        FilterColumns(CharacterSpell,self.dbAttr)
        self.dbAttr["spellProtoID"]=sp.id
        self.dbAttr["characterID"]=char.id            
        CharacterSpell(**self.dbAttr)
        

class SpawnStatCopier:
    def __init__(self,cur,id):
        self.dbAttr = {}
        t = mixedToUnder("SpawnStat")
        cur.execute("SELECT * from %s WHERE id = %i;"%(t,id))
        for name,value in zip(WSCHEMA["SpawnStat"],cur.fetchall()[0]):
            self.dbAttr[str(name)]=value
            
    def install(self,spawn):
        FilterColumns(SpawnStat,self.dbAttr) 
        self.dbAttr["spawnID"]=spawn.id   
        s = SpawnStat(**self.dbAttr)
        return s


class SpawnResistanceCopier:
    def __init__(self,cur,id):
        self.dbAttr = {}
        t = mixedToUnder("SpawnResistance")
        cur.execute("SELECT * from %s WHERE id = %i;"%(t,id))
        for name,value in zip(WSCHEMA["SpawnResistance"],cur.fetchall()[0]):
            self.dbAttr[str(name)]=value
            
    def install(self,spawn):
        FilterColumns(SpawnResistance,self.dbAttr) 
        self.dbAttr["spawnID"]=spawn.id   
        s = SpawnResistance(**self.dbAttr)
        return s


class SpawnCopier:
    def __init__(self,cur,id):
        self.dbAttr = {}
        t = mixedToUnder("Spawn")
        cur.execute("SELECT * from %s WHERE id = %i;"%(t,id))
        for name,value in zip(WSCHEMA["Spawn"],cur.fetchall()[0]):
            self.dbAttr[str(name)]=value
            
    def install(self):
        FilterColumns(Spawn,self.dbAttr)  
        try:  
            s = Spawn(**self.dbAttr)
        except:
            print "Problem installing %s trying with an appended X to name"%(self.dbAttr["name"])
            self.dbAttr["name"] = self.dbAttr["name"]+"X"
            try:
                s = Spawn(**self.dbAttr)
            except:
                raise "Error"
        return s


class CharacterCopier:
    def __init__(self,cur,id):
        self.dbAttr = {}
        t = mixedToUnder("Character")
        cur.execute("SELECT * from %s WHERE id = %i;"%(t,id))
        
        spawnID = -1
        for name,value in zip(WSCHEMA["Character"],cur.fetchall()[0]):
            if name == "spawnID":
                spawnID = value
            self.dbAttr[str(name)]=value
        
        #Spawn        
        self.spawn = SpawnCopier(cur,spawnID)
        
        #spawnresists
        sresists = self.sresists = []
        cur.execute("select id from spawn_resistance where spawn_id = %i;"%spawnID)
        for r in cur.fetchall():
            f = SpawnResistanceCopier(cur,r[0])
            sresists.append(f)

        #spawnstats
        sstats = self.sstats = []
        cur.execute("select id from spawn_stat where spawn_id = %i;"%spawnID)
        for r in cur.fetchall():
            f = SpawnStatCopier(cur,r[0])
            sstats.append(f)

        
        #advancements
        advancements = self.advancements = []
        cur.execute("select id from character_advancement where character_id = %i;"%id)
        for r in cur.fetchall():
            f = CharacterAdvancementCopier(cur,r[0])
            advancements.append(f)

        #skills
        skills = self.skills = []
        cur.execute("select id from character_skill where character_id = %i;"%id)
        for r in cur.fetchall():
            f = CharacterSkillCopier(cur,r[0])
            skills.append(f)

        #spells
        spells = self.spells = []
        cur.execute("select id from character_spell where character_id = %i;"%id)
        for r in cur.fetchall():
            f = CharacterSpellCopier(cur,r[0])
            spells.append(f)

        #vault items
        vaultItems = self.vaultItems = []
        try:
            cur.execute("select id from character_vault_item where character_id = %i;"%id)
            for r in cur.fetchall():
                f = CharacterVaultItemCopier(cur,r[0])
                vaultItems.append(f)
        except:
            #really need versioning information!
            traceback.print_exc()
        
        
        # factions
        factions = self.factions = []
        try:
            cur.execute("select id from character_faction where character_id = %i;"%id)
            for r in cur.fetchall():
                f = CharacterFactionCopier(cur,r[0])
                factions.append(f)
        except:
            traceback.print_exc()

            
        #items        
        items = self.items = []
        cur.execute("select id from item where character_id = %i;"%id)
        for r in cur.fetchall():
            f = ItemCopier(cur,r[0])
            items.append(f)
            
        #dialog
        try:
            dc = self.dc = []
            cur.execute("select id from character_dialog_choice where character_id = %i;"%id)
            for r in cur.fetchall():
                f = CharacterDialogChoiceCopier(cur,r[0])
                dc.append(f)
        except:
            self.dc = []
        
            
    def install(self,player):        
        spawn = self.spawn.install()
        
        FilterColumns(Character,self.dbAttr)
        self.dbAttr["name"]=spawn.name #may be renamed
        self.dbAttr["spawnID"]=spawn.id
        self.dbAttr["playerID"]=player.id
        char = Character(**self.dbAttr)
        spawn.character = char #version 1.0 didn't have a foreign key to character from spawn
        spawn.playerName = player.publicName
        
        for a in self.sresists:
            a.install(spawn)

        for a in self.sstats:
            a.install(spawn)
            
        
        #advancements
        for a in self.advancements:
            a.install(char)
        
        #spells
        for s in self.spells:
            s.install(char)

        #skills
        for s in self.skills:
            s.install(char)
            
        #items
        for i in self.items:
            i.install(char)

        #vault items
        for i in self.vaultItems:
            i.install(char)
        
        # character factions
        for f in self.factions:
            f.install(char)
        
        #dialog choices
        for dc in self.dc:
            dc.install(char)

            
class PlayerCopier:
    def __init__(self,conn,id):
        self.dbAttr = {}
        cur = conn.cursor()
        t = mixedToUnder("Player")
        cur.execute("SELECT * from %s WHERE id = %i;"%(t,id))
        
        bindZoneID = -1
        logZoneID = -1
        darknessBindZoneID = -1
        darknessLogZoneID = -1
        monsterBindZoneID = -1
        monsterLogZoneID = -1
        
        for name,value in zip(WSCHEMA["Player"],cur.fetchall()[0]):
            if name == "bindZoneID":
                bindZoneID = value
            if name == "logZoneID":
                logZoneID = value
            if name == "darknessBindZoneID":
                darknessBindZoneID = value
            if name == "darknessLogZoneID":
                darknessLogZoneID = value
            if name == "monsterBindZoneID":
                monsterBindZoneID = value
            if name == "monsterLogZoneID":
                monsterLogZoneID = value

            self.dbAttr[str(name)]=value
            
        #zones
        cur.execute("select name from Zone where id = %i;"%bindZoneID)
        self.bindZone = cur.fetchall()[0][0]
        cur.execute("select name from Zone where id = %i;"%logZoneID)
        self.logZone = cur.fetchall()[0][0]
        cur.execute("select name from Zone where id = %i;"%darknessBindZoneID)
        self.darknessBindZone = cur.fetchall()[0][0]
        cur.execute("select name from Zone where id = %i;"%darknessLogZoneID)
        self.darknessLogZone = cur.fetchall()[0][0]
        try:
            cur.execute("select name from Zone where id = %i;"%monsterBindZoneID)
            self.monsterBindZone = cur.fetchall()[0][0]
            cur.execute("select name from Zone where id = %i;"%monsterLogZoneID)
            self.monsterLogZone = cur.fetchall()[0][0]
        except:
            self.monsterBindZone = self.bindZone
            self.monsterLogZone = self.logZone
            
        
        #Character copier
        chars = self.characters = []
        
        cur.execute("select id from Character where player_id = %i;"%id)
        
        for r in cur.fetchall():
            c = CharacterCopier(cur,r[0])
            chars.append(c)
        
        #monster spawn copier
        mspawns = self.mspawns = []
        
        try:
            cur.execute("select id from player_monster_spawn where player_id = %i;"%id)
        except:
            cur.close()
            return
        
        for r in cur.fetchall():
            f = PlayerMonsterSpawnCopier(cur,r[0])
            mspawns.append(f)
        
        #items
        items = self.items = []
        try:
            cur.execute("select id from item where player_id = %i;"%id)
            for r in cur.fetchall():
                f = ItemCopier(cur,r[0])
                items.append(f)
        except:
            pass
        
        cur.close()
        

    def install(self):
        
        if not FROMGAME:
            print "Installing Player: %s"%self.dbAttr["publicName"]
        
        try:
            #if RPG_BUILD_DEMO and self.bindZone not in ("trinst","trinstsewer"):
            #    raise "Demo: invalid zone"
            
            bindZone = Zone.byName(self.bindZone)
            logZone = Zone.byName(self.logZone)
            
            darknessBindZone = Zone.byName(self.darknessBindZone)
            darknessLogZone = Zone.byName(self.darknessLogZone)
            monsterBindZone = Zone.byName(self.monsterBindZone)
            monsterLogZone = Zone.byName(self.monsterLogZone)
            
        except:
            bindZone = Zone.byName("trinst")
            logZone = Zone.byName("trinst")
            self.dbAttr["bindTransformInternal"] = "17.699 -288.385 121.573 0 0 1 35.9607"
            self.dbAttr["logTransformInternal"] = "17.699 -288.385 121.573 0 0 1 35.9607"
            
            darknessBindZone = Zone.byName("kauldur")
            darknessLogZone = Zone.byName("kauldur")
            self.dbAttr["darknessBindTransformInternal"] = "-203.48 -395.96 150.1 0 0 1 38.92"
            self.dbAttr["darknessLogTransformInternal"] = "-203.48 -395.96 150.1 0 0 1 38.92"

            monsterBindZone = Zone.byName("trinst")
            monsterLogZone = Zone.byName("trinst")
            self.dbAttr["monsterBindTransformInternal"] = "-169.032 -315.986 150.9353 0 0 1 10.681"
            self.dbAttr["monsterLogTransformInternal"] = "-169.032 -315.986 150.9353 0 0 1 10.681"

        
        #leave this for awhile
        #monsterBindZone = Zone.byName("trinst")
        #monsterLogZone = Zone.byName("trinst")
        #self.dbAttr["monsterBindTransformInternal"] = "-169.032 -315.986 150.9353 0 0 1 10.681"
        #self.dbAttr["monsterLogTransformInternal"] = "-169.032 -315.986 150.9353 0 0 1 10.681"


        #todo, initial monster before live

        self.dbAttr["bindZoneID"]=bindZone.id
        self.dbAttr["logZoneID"]=logZone.id
        self.dbAttr["darknessBindZoneID"]=darknessBindZone.id
        self.dbAttr["darknessLogZoneID"]=darknessLogZone.id
        self.dbAttr["monsterBindZoneID"]=monsterBindZone.id
        self.dbAttr["monsterLogZoneID"]=monsterLogZone.id
        
        FilterColumns(Player,self.dbAttr)    
        player = Player(**self.dbAttr)
        
        for c in self.characters:
            c.install(player)
    
        for f in self.mspawns:
            f.install(player)
            
        #bank items
        for i in self.items:
            i.install(player)

    
class UserCopier:
    def __init__(self,conn,id):
        self.dbAttr = {}
        cur = conn.cursor()
        t = mixedToUnder("User")
        cur.execute("SELECT * from %s WHERE id = %i;"%(t,id))
        
        for name,value in zip(WSCHEMA["User"],cur.fetchall()[0]):
            self.dbAttr[str(name)]=value        
            
        #roles
        self.roles = []
        cur.execute("select role_id from role_user where user_id = %i;"%id)
        
        for r in cur.fetchall():
            cur.execute("select name from role where id = %i;"%r[0])
            
            self.roles.append(cur.fetchall()[0][0])
            
    def install(self):
        
        if self.dbAttr["name"]=="ZoneServer":
            return
        
        FilterColumns(User,self.dbAttr)    
        user = User(**self.dbAttr)
        
        for r in self.roles:
            try:
                role = Role.byName(r)
            except:
                print "Role: %s no longer exists"%r
                continue
            
            user.addRole(role)
        
    
def QuerySchema(wconn):
    cur = wconn.cursor()
    
    for t in TABLES:
        cols=WSCHEMA[t]=[]
        
        cur.execute('PRAGMA table_info(%s);'%mixedToUnder(t))
        
        for col in cur.fetchall():
            cname = str(underToMixed(col[1]))
            cols.append(cname)
                
    cur.close()

def WorldUpdate(worldPath,baselinePath,fromgame = False,force = False):
    global FROMGAME
    global FORCE
    FROMGAME = fromgame
    FORCE = force
    
    try:
        result = CheckWorld(worldPath,baselinePath)
    except:
        traceback.print_exc()
        return -1
    
    #0 = no update needed, 1 = updated needed, -1 = error
    if result != 1:
        return result
    
    try:
        #we need to update the world
        
        if FROMGAME:
            TGECall("MessagePopup","Updating World...","Please wait...")
            TGEEval("Canvas.repaint();")
            
          
        
        WCONN = sqlite.connect(worldPath)
        
        QuerySchema(WCONN)
        
        #copy the players
        
        players = []
        users = []
        
        cur = WCONN.cursor()
    
        #players
        cur.execute("select id from Player;")
        
        for r in cur.fetchall():
            pc = PlayerCopier(WCONN,r[0])
            players.append(pc)
            
        #users
        cur.execute("select id from user;")
        
        for r in cur.fetchall():
            u = UserCopier(WCONN,r[0])
            users.append(u)
        
        cur.close()
        
        WCONN.close()
        
        #backup
        shutil.copyfile(worldPath,worldPath+".bak")
        
        #new
        shutil.copyfile(baselinePath,worldPath+".new")
        
        DATABASE = "sqlite:///%s.new"%worldPath
        SetDBConnection(DATABASE)
        
        #install players into new baseline
        conn = Player._connection.getConnection()
        cursor = conn.cursor()
        cursor.execute("BEGIN;")
        
        for u in users:
            u.install()
        
        for p in players:
            p.install()
            
        cursor.execute("END;")
        cursor.close()
        
        SetDBConnection(None)
        
        shutil.copyfile(worldPath+".new",worldPath)
    except:
        traceback.print_exc()
        return -1
        
    if FROMGAME:
        TGECall("MessagePopup","Loading World...","Please wait...")
        TGEEval("Canvas.repaint();")
    
    return 0
            
    
_underToMixedRE = re.compile('_.')
def underToMixed(name):
    if name.endswith('_id'):
        return underToMixed(name[:-3] + "ID")
    return _underToMixedRE.sub(lambda m: m.group(0)[1].upper(),
                               name)
    
    
_mixedToUnderRE = re.compile(r'[A-Z]+')
def mixedToUnder(s):
    if s.endswith('ID'):
        return mixedToUnder(s[:-2] + "_id")
    trans = _mixedToUnderRE.sub(mixedToUnderSub, s)
    if trans.startswith('_'):
        trans = trans[1:]
    return trans

def mixedToUnderSub(match):
    m = match.group(0).lower()
    if len(m) > 1:
        return '_%s_%s' % (m[:-1], m[-1])
    else:
        return '_%s' % m

    

    
    

