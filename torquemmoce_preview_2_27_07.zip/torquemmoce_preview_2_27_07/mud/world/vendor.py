
from sqlobject import *
from mud.common.persistent import Persistent
from twisted.internet import reactor

from item import ItemProto
from defines import *
import random
import spawn
import math
from core import *
import traceback


class VendorItem(Persistent):
    itemProto = ForeignKey('ItemProto')
    frequency = IntCol(default = RPG_FREQ_ALWAYS)
    count = IntCol(default = -1)  # -1 = infinite amount
    vendorProtos = RelatedJoin('VendorProto')


class VendorProto(Persistent):
    name = StringCol(alternateID=True)
    markup = FloatCol(default = 1.0)
    restockRate = IntCol(default = 10)  # in realtime minutes, might be nice if this was per item but hey
    vendorItems = RelatedJoin('VendorItem')
    
    spawns = MultipleJoin('Spawn')
    
    def createVendorInstance(self,mob):
        vi = VendorInstance(self,mob)
        mob.vendor = vi



# !!! restock timer only ticks if no one is interacting
class VendorInstance:
    def __init__(self,vendorProto,mob):
        self.mob = mob
        self.vendorProto = vendorProto
        self.markup = vendorProto.markup
        self.restockRate = vendorProto.restockRate * durMinute
        #we do this to ensure that this is always ordered the same
        #I am not entirely sure that the related join ensures this
        self.selection = vendorProto.vendorItems[:]
        #selection index -> list of items
        self.stock = {}
        
        self.playerSubmitted = []
        self.regenerateStock()
    
    
    def destroyStock(self):
        for item in self.stock.iterkeys():
            item.destroySelf()
        self.stock = {}
        
        for item in self.playerSubmitted:
            item.destroySelf()
    
    
    def regenerateStock(self):
        if self.mob.detached:
            return
        
        if not self.mob.interacting:
            self.stock = {}
            for vitem in self.selection:
                count = vitem.count
                if vitem.frequency != RPG_FREQ_ALWAYS:
                    if count > 0:
                        count = 0
                        for x in xrange(vitem.count):
                            if not random.randint(0,vitem.frequency - 1):
                                count += 1
                    elif count == -1:  # infinite amount
                        if random.randint(0,vitem.frequency - 1):
                            count = 0
                if count != 0:
                    myItem = vitem.itemProto.createInstance(False,True)
                    self.stock[myItem] = count
        
        reactor.callLater(self.restockRate,self.regenerateStock)
    
    
    def sendStock(self,player):
        # indexes 20 and above are reserved for vendor default items
        itemInfos = dict((item.itemInfo,i+20) for i,item in enumerate(self.stock.iterkeys()))
        
        if len(self.playerSubmitted) > 20:
            remove = self.playerSubmitted[0:len(self.playerSubmitted)-20]
            for x in remove:
                self.playerSubmitted.remove(x)
                x.destroySelf()
        
        for i,p in enumerate(self.playerSubmitted):
            itemInfos[p.itemInfo] = i
        
        player.mind.callRemote("setVendorStock",True,itemInfos,self.markup)
    
    
    def getItem(self,lookitem):
        if lookitem < 20:
            if 0 <= lookitem < len(self.playerSubmitted):  # valid index
                return self.playerSubmitted[lookitem]
        elif lookitem - 20 < len(self.stock):  # valid index
            return self.stock.keys()[lookitem - 20]
        
        return None
    
    
    def removeItem(self,item):
        if item in self.playerSubmitted:
            self.playerSubmitted.remove(item)
            return True
        
        if item in self.stock:
            if self.stock[item] != -1:
                self.stock[item] -= 1
                if self.stock[item] == 0:
                    del self.stock[item]
                return True
        
        return False
    
    
    
    def sellItem(self,player,char,itemIndex):
        # validate and get the item by index
        buyitem = self.getItem(itemIndex)
        if not buyitem:
            print "Warning: Player buying item vendor doesn't have!!!!"
            return
        
        money = buyitem.getWorth(self.markup)
        
        #first check $$$
        if not player.checkMoney(money):
            player.sendGameText(RPG_MSG_GAME_DENIED,"%s cannot afford this.\\n"%char.name)
            return
        
        if player.cursorItem:
            player.sendGameText(RPG_MSG_GAME_DENIED,"Please empty your cursor first.\\n")
            return
        
        myitem = buyitem
        
        stackMax = buyitem.itemProto.stackMax
        if stackMax > 1:
            #see if we can add to existing stacks
            amt = buyitem.stackCount
            for item in char.items:
                if item.name == buyitem.name and item.stackCount < stackMax:
                    amt -= (stackMax - buyitem.stackCount)
                    if amt <= 0:
                        myitem = None
                        break
            
            if not myitem:
                #we can stack
                amt = buyitem.stackCount
                for item in char.items:
                    if item.name == buyitem.name and item.stackCount < stackMax:
                        add = stackMax - item.stackCount
                        if add > amt:
                            add = amt
                        item.stackCount += add
                        item.itemInfo.refreshDict({'STACKCOUNT':item.stackCount})
                        amt -= add
                        if not amt:
                            break
            
            elif buyitem not in self.playerSubmitted:
                myitem = buyitem.itemProto.createInstance()
        elif buyitem not in self.playerSubmitted:
            myitem = buyitem.itemProto.createInstance()
        
        
        if myitem and not player.giveItemInstance(myitem):
            player.sendGameText(RPG_MSG_GAME_DENIED,"%s's inventory is full.\\n"%char.name)
            if myitem != buyitem:
                myitem.destroySelf() #optimize should check earlier than making item!
            return
        
        if not money:
            player.sendGameText(RPG_MSG_GAME_GAINED,"%s receives the item for free.\\n"%char.name)
        else:
            wtext = GenMoneyText(money)
            player.sendGameText(RPG_MSG_GAME_LOST,"%s pays %s for the item.\\n"%(char.name,wtext))
            player.takeMoney(money)
        
        refresh = False
        if not myitem and buyitem in self.playerSubmitted:  # was stacked
            refresh = self.removeItem(buyitem)
            buyitem.destroySelf()
        else:
            refresh = self.removeItem(buyitem)
        if refresh:
            self.sendStock(player)
    
    
    
    def buyItem(self,player,item):
        proto = item.itemProto
        if item.flags&(RPG_ITEM_SOULBOUND|RPG_ITEM_ETHEREAL|RPG_ITEM_WORLDUNIQUE) or not proto.worthTin:
            player.sendGameText(RPG_MSG_GAME_DENIED,"That item cannot be sold.\\n")
            return
        
        for c in player.party.members:
            if c == item.character:
                item.setCharacter(None)
                item.slot = -1
                if item == player.cursorItem:
                    player.cursorItem = None
                    player.updateCursorItem(item)
                
                money = item.getWorth(self.markup*0.1)
                player.giveMoney(money)
                
                if not money:
                    player.sendGameText(RPG_MSG_GAME_DENIED,"%s receives nothing for the item.\\n"%c.name)
                else:
                    wtext = GenMoneyText(money)
                    player.sendGameText(RPG_MSG_GAME_GAINED,"%s receives %s for the item.\\n"%(c.name,wtext))
                
                if item.crafted or item.spellEnhanceLevel == 9999 or proto.stackMax > 1:
                    item.destroySelf()
                else:
                    self.playerSubmitted.append(item)
                    self.sendStock(player)
                
                return
        
        print "Warning: Player item selling wackiness!!!"


