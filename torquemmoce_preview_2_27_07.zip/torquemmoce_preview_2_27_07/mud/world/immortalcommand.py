
import math
from defines import *
from zone import Zone
from core import *
import sys
from mud.common.permission import User

def CmdDespawn(mob,args):
    for sp in mob.zone.spawnpoints:
        for spMob in sp.activeMobs:
            mob.zone.removeMob(spMob)

def CmdKill(mob,args):
    from damage import Damage
    if mob.target:
        Damage(mob.target,mob,10000000,RPG_DMG_MAGICAL)
       

def CmdSet(mob,args):
    if not len(args):
        return
    
    what = args[0].upper()
    args = args[1:]
    
    if not len(args):
        return
    
    if what == 'WIND':
        CmdSetWind(mob,args)

    elif what == 'TIME':
        CmdSetTime(mob,args)
    elif what == 'WEATHER':
        CmdSetWeather(mob,args)
        
def CmdSetWind(mob,args):
    wind = int(args[0])
    if wind < 1:
        wind = 1
    if wind > 10:
        wind = 10
    mob.zone.weather.windspeed = wind
    mob.zone.weather.dirty = True
    mob.player.sendGameText(RPG_MSG_GAME_GAINED,"Wind set.\\n")
    
def CmdSetWeather(mob,args):
    precip = int(args[0])

    if precip > 10:
        precip = 10

    mob.zone.weather.cloudCover = precip
    mob.zone.weather.precip = precip
    mob.zone.weather.lastPrecipChange = 0
    mob.zone.weather.lastCoverChange = 0
    
    if mob.zone.weather.cloudCover < 1:
        mob.zone.weather.cloudCover = 1

    mob.zone.weather.dirty = True
    
    mob.player.sendGameText(RPG_MSG_GAME_GAINED,"Weather set.\\n")
            
def CmdSetTime(mob,args):
    try:
        hour = int(args[0])
        minute = 0
        if len(args)==2:
            minute = int(args[1])
            
        
        from mud.world.theworld import World
        world = World.byName("TheWorld")
        world.time.hour = hour
        world.time.minute = minute
        
        for player in world.activePlayers:
            player.mind.callRemote("syncTime",world.time.hour,world.time.minute)
            
        
        mob.player.sendGameText(RPG_MSG_GAME_GAINED,"The time is now: %i:%i\\n"%(world.time.hour,world.time.minute))
    except:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Problem setting time\\n")
    
    

def CmdGiveMonster(mob,args):
    
    if not len(args):
        return
    
    mspawn = ' '.join(args)
    
    for ms in mob.player.monsterSpawns:
        if ms.spawn==mspawn:
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,"You already have the %s monster template.\\n"%mspawn)
            return
    
    from spawn import Spawn
    try:
        s = Spawn.byName(mspawn)
    except:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"No such spawn %s.\\n"%mspawn)
        return
    
    from player import PlayerMonsterSpawn
    PlayerMonsterSpawn(player=mob.player,spawn=mspawn)
        
    mob.player.sendGameText(RPG_MSG_GAME_GAINED,"You now have the %s monster template.\\n"%mspawn)

def CmdGrantMonster(mob,args):
    
    from player import Player
    
    if len(args) < 2:
        return
    
    pname = args[0]
    args = args[1:]
    
    mspawn = ' '.join(args)
    
    try:
        player = Player.byPublicName(pname)
    except:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"No player by public name %s.\\n"%pname)
        return
        
    
    for ms in player.monsterSpawns:
        if ms.spawn==mspawn:
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,"%s already has the %s monster template.\\n"%(pname,mspawn))
            return
    
    from spawn import Spawn
    try:
        s = Spawn.byName(mspawn)
    except:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"No such spawn %s.\\n"%mspawn)
        return
    
    from player import PlayerMonsterSpawn
    PlayerMonsterSpawn(player=player,spawn=mspawn)
    
    mob.player.sendGameText(RPG_MSG_GAME_GAINED,"You have granted %s the %s monster template.\\n"%(pname,mspawn))
    if player.zone:    
        player.sendGameText(RPG_MSG_GAME_GAINED,"You now have the %s monster template.\\n"%mspawn)

def CmdListMonsters(mob,args):
    
    from player import Player
    
    if len(args) < 1:
        return
    
    pname = args[0]
    
    mspawn = ' '.join(args)
    
    try:
        player = Player.byPublicName(pname)
    except:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"No player by public name %s.\\n"%pname)
        return
        
    text = "%s has the following monster templates: %s\\n"%(pname,', '.join(ms.spawn for ms in player.monsterSpawns))
    
    mob.player.sendGameText(RPG_MSG_GAME_GAINED,text)


def CmdDenyMonster(mob,args):
    
    from player import Player
    
    if len(args) < 2:
        return
    
    pname = args[0]
    args = args[1:]
    
    mspawn = ' '.join(args)
    
    try:
        player = Player.byPublicName(pname)
    except:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"No player by public name %s.\\n"%pname)
        return
    
    if not IsUserSuperior(mob.player.publicName,player.publicName):
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"You do not have the required permission for this action.\\n")
        return

    
    if player.enteringWorld:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Player is entering the world and needs to log out first!\\n")
        return

    if player.zone:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Player is in the world and needs to log out first!\\n")
        return
        
        
    delete = []
    for c in player.characters:
        if c.spawn.template == mspawn:
            delete.append(c)
            
    for x in delete[:]:
        mob.player.avatar.perspective_deleteCharacter(x.name)
            
    for ms in player.monsterSpawns:
        if ms.spawn==mspawn:
            ms.destroySelf()
            break
    
    mob.player.sendGameText(RPG_MSG_GAME_GAINED,"You have denied %s the %s monster template.\\n"%(pname,mspawn))
    if player.zone:    
        player.sendGameText(RPG_MSG_GAME_DENIED,"You no longer have the %s monster template.\\n"%mspawn)
        
    
            
def CmdGrantLevel(mob,args):
    
    from player import Player
    
    if len(args) < 2:
        return
    
    pname = args[0]
    klass = args[1]
    
    
    try:
        player = Player.byPublicName(pname)
    except:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"No player by public name %s.\\n"%pname)
        return
    
    if not player.party or not len(player.party.members):
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Player isn't logged in %s.\\n"%pname)
        return
    
    c = player.party.members[0]
    gained = False
    if c.spawn.pclassInternal == klass:
        c.gainLevel(0)
        gained=True
    if c.spawn.sclassInternal == klass:
        c.gainLevel(1)
        gained = True
    if c.spawn.tclassInternal == klass:
        c.gainLevel(2)
        gained = True
        
    if gained:
        spawn = c.spawn
        t = "%s %s %s %i %i %i"%(spawn.pclassInternal,spawn.sclassInternal,spawn.tclassInternal,spawn.plevel,spawn.slevel,spawn.tlevel)
        mob.player.sendGameText(RPG_MSG_GAME_GAINED,"%s is now a %s.\\n"%(c.spawn.name,t))
    else:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Character doesn't have that class\\n")

def CmdGimme(mob,args):
    from item import ItemProto
    argUpper = args[0].upper()
    if argUpper == 'TOME':
        itemname = argUpper
        tomename = ' '.join(args[2:-1])    # strip "Tome of" and tome level
    elif argUpper not in ("PLEVEL","SLEVEL","TLEVEL","SKILL","MONEY","XP","RENEW","VISIBILITY"):
        itemname = ' '.join(args)
    else:
        itemname = argUpper
        levels = 1
        if len(args) > 1:
            if argUpper != "VISIBILITY":
                levels = int(args[1])
            else:
                levels = float(args[1])
        
    if itemname == 'MONEY':
        mob.player.platinum+=1000
        mob.player.sendGameText(RPG_MSG_GAME_GAINED,"Gained 1000 platinum.\\n")
        return
    elif itemname == 'XP':
        for c in mob.player.party.members:
            c.gainXP(1000000)
        return
    elif itemname == 'PLEVEL':
        for x in xrange(0,levels):
            mob.player.curChar.gainLevel(0)
        return
    elif itemname == 'SLEVEL':
        for x in xrange(0,levels):
            mob.player.curChar.gainLevel(1)
        return
    elif itemname == 'TLEVEL':
        for x in xrange(0,levels):
            mob.player.curChar.gainLevel(2)
        return
    elif itemname == 'SKILL':
        m = mob.player.curChar.mob
        for x in xrange(0,levels):
            for skname in m.skillLevels.iterkeys():
                mob.player.curChar.checkSkillRaise(skname,0,0)
        return
    elif itemname == 'RENEW':
        for c in mob.player.party.members:
            m = c.mob
            m.health = m.maxHealth
            m.mana = m.maxMana
            m.stamina = m.maxStamina
        
            m.skillReuse = {}
            m.recastTimers = {}
        
        mob.player.cinfoDirty = True
        return
    elif itemname == 'VISIBILITY':
        if levels > 1.0:
            levels = 1.0
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Max visibility modifier is 1.0!\\n")
        elif levels < 0.0:
            levels = 0.0
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Min visibility modifier is 0.0!\\n")
        for c in mob.player.party.members:
            c.mob.visibility = levels
        return
    elif itemname == 'TOME':
        char = mob.player.curChar
        levels = ['1','2','3','4','5','6','7','8','9','10']
        roman = ["I","II","III","IV","V","VI","VII","VIII","IX","X"]
        lupper = args[-1].upper()
        try:
            tomelevel = levels.index(lupper)
        except:
            try:
                tomelevel = roman.index(lupper)
            except:
                mob.player.sendGameText(RPG_MSG_GAME_DENIED,"%s isn't a valid tome level!\\n"%args[-1])
                return
        if tomelevel == 0:   # actual tomelevel is this variable +1
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,"%s isn't a valid tome level!\\n"%args[-1])
            return
        try:
            scroll = ItemProto.byName("Scroll of %s"%tomename)
        except:
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,"%s is no spell name!\\n"%tomename)
            return
        nitem = scroll.createInstance("STUFF/38")
        nitem.spellEnhanceLevel = tomelevel+1
        nitem.name = "Tome of %s %s"%(tomename,roman[tomelevel])
        nitem.descOverride = "This tome contains secrets of the %s spell. You must have level %s knowledge to understand this tome."%(tomename,roman[tomelevel - 1])
        if not char.giveItemInstance(nitem):
            nitem.destroySelf()
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,"%s doesn't have enough inventory space\\n"%char.name)
            return
        char.refreshItems()
        mob.player.sendGameText(RPG_MSG_GAME_GAINED,"Gained %s\\n"%nitem.name)
        return
    
    from crafting import FocusGenSpecific
    item = FocusGenSpecific(itemname)
    if item:
        if not mob.player.curChar.giveItemInstance(item):
            item.destroySelf()
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,"%s doesn't have enough inventory space\\n"%char.name)
            return
    else:
        item = mob.player.giveItem(itemname,True)
    
    if item:
        if RPG_SLOT_WORN_END > item.slot >= RPG_SLOT_WORN_BEGIN:
            mob.equipItem(item.slot,item)
        mob.player.sendGameText(RPG_MSG_GAME_GAINED,"Gained %s\\n"%itemname)
        return
    
    mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Failure getting %s\\n"%itemname)
        

def CmdSpawn(mob,args):
    mname = ' '.join(args)
    
    #find the closest spawnpoint
    bestdist = 999999
    bestsp = None
    mypos = mob.simObject.position
    for sp in mob.zone.spawnpoints:
        x = sp.transform[0]-mypos[0]
        y = sp.transform[1]-mypos[1]
        z = sp.transform[2]-mypos[2]
        
        dist = math.sqrt(x*x+y*y+z*z)
        
        if dist < bestdist:
            bestdist = dist
            bestsp = sp
            
    
    if not bestsp:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Failure spawning %s, no spawnpoints.\\n"%mname)
        return
        
    for spMob in bestsp.activeMobs:
        mob.zone.removeMob(spMob)
        
    if bestsp.spawnMobByName(mname):
        mob.player.sendGameText(RPG_MSG_GAME_GAINED,"%s spawned at nearest spawnpoint.\\n"%mname)
        return
        
    mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Failure spawning %s, this spawn doesn't exist.\\n"%mname)
        
    
def CmdWorldAggro(mob,args):
    aggroOff = not mob.player.world.aggroOn
    if not len(args):
        aggroOff = not aggroOff
    else:
        if args[0].lower()=='off':
            aggroOff = True
        else:
            aggroOff = False
        
        
    mob.player.world.aggroOn = not aggroOff
     
    if aggroOff:
        mob.player.sendGameText(RPG_MSG_GAME_GLOBAL,"Monsters will NOT initiate an attack.\\n")
    else:
        mob.player.sendGameText(RPG_MSG_GAME_GLOBAL,"Monsters WILL initiate attacks.\\n")
    
def CmdMyAggro(mob,args):
    aggroOff = mob.aggroOff
    if not len(args):
        aggroOff = not aggroOff
    else:
        if args[0].lower()=='off':
            aggroOff = True
        else:
            aggroOff = False
        
    for c in mob.player.party.members:
        c.mob.aggroOff = aggroOff    
    
     
    if aggroOff:
        mob.player.sendGameText(RPG_MSG_GAME_GLOBAL,"Monsters will NOT attack your party.\\n")
    else:
        mob.player.sendGameText(RPG_MSG_GAME_GLOBAL,"Monsters WILL attack your party.\\n")
        


    
def CmdTP(mob,args):
    player = mob.player
    zname = args[0]
    
    if zname.lower() == 'bindstone':
        if player.darkness:
            z = player.darknessBindZone
            trans = player.darknessBindTransform
        elif player.monster:
            z = player.monsterBindZone
            trans = player.monsterBindTransform
        else:
            z = player.bindZone
            trans = player.bindTransform
        dst = ' '.join(str(i) for i in trans)
    else:
        try:
            z = Zone.byName(zname)
            dst = z.immTransform
        except:
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Unknown zone or zone not setup for immortal command %s.\\n"%zname)
            return
    
    #are we in the same zone?
    if player.zone.zone == z:
        #good
        #we just need to respawn player, whew
        player.zone.respawnPlayer(player,dst)
    else:
        from zone import TempZoneLink
        zlink = TempZoneLink(zname,dst)
        player.world.onZoneTrigger(player,zlink)

def CmdSystemMsg(mob,args):
    if not len(args):
        return
    msg = ' '.join(args)

    for p in mob.player.world.activePlayers:
        p.sendSpeechText(RPG_MSG_SPEECH_SYSTEM,r'SYSTEM: %s\n'%msg)

def CmdRecompile(mob,args):
    CmdDespawn(mob,args)
    from genesis.updateworld import UpdateWorld
    seconds = UpdateWorld()

    zones = mob.player.world.liveZoneInstances[:]
    zones.extend(mob.player.world.waitingZoneInstances)
    
    for z in zones:
        for sp in z.spawnpoints:
            sp.removeMob()
            
        z.spawnpoints = []
        
    #reattach some stuff
    from mud.world.archetype import InitClassSkills
    InitClassSkills()
        
    #refresh items, editing supported in single player only right now (although you really can in multi too)
    for c in mob.player.party.members:
        c.mob.skillReuse = {}
        c.mob.updateClassStats()
        for item in c.items:
            item.refreshFromProto()
        for spell in c.spells:
            spell.spellInfo.fullRefresh()
            
    from faction import InitKOS
    InitKOS()
    
        
    for z in zones:
        z.simAvatar.refreshBindpoints()
        z.simAvatar.refreshSpawnPoints()
        
    mob.player.sendGameText(RPG_MSG_GAME_GLOBAL,"*** Database recompiled in %i seconds.\\n"%seconds)
    

def CmdReloadCommands(mob,args):
    reload(sys.modules['mud.world.command'])
    
def CmdReloadModule(mob,args):
    reload(sys.modules[args[0]])

    
def CmdGrant(mob,args):
    from mud.common.permission import User,Role
    
    if len(args) < 2:
        return
    
    try:
        user = User.byName(args[0])
    except:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Unknown user %s.\\n"%args[0])
        return
    
    try:
        role = Role.byName(args[1])
    except:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Unknown role %s.\\n"%args[1])
        return
    
    for r in user.roles:
        if r.name == role.name:
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,"User %s already has the %s role.\\n"%(args[0],args[1]))
            return
        
    if role.name == "Immortal":
        from newplayeravatar import NewPlayerAvatar
        if mob.player.publicName != NewPlayerAvatar.ownerPublicName:
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Immortal access can only be granted by the server's owner.\\n")
            return

            
    
    mob.player.sendGameText(RPG_MSG_GAME_GAINED,"User %s granted the %s role.\\n"%(args[0],args[1]))
    user.addRole(role)
    
def CmdDeny(mob,args):
    from mud.common.permission import User,Role
    from player import Player
    
    if len(args) < 2:
        return
    
    try:
        user = User.byName(args[0])
    except:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Unknown user %s.\\n"%args[0])
        return
    
    
    if not IsUserSuperior(mob.player.publicName,user.name):
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"You do not have the required permission for this action.\\n")
        return

    
    try:
        role = Role.byName(args[1])
    except:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Unknown role %s.\\n"%args[1])
        return
    
    for r in user.roles:
        if r.name == role.name:
            user.removeRole(r)
            try:
                player = Player.byPublicName(args[0])
                if player.avatar and player.avatar.masterPerspective:
                    player.avatar.masterPerspective.removeAvatar("GuardianAvatar")            
            except:
                pass

            mob.player.sendGameText(RPG_MSG_GAME_GAINED,"User %s denied the %s role.\\n"%(args[0],args[1]))
            return
    
            
    mob.player.sendGameText(RPG_MSG_GAME_DENIED,"User %s doesn't have the %s role.\\n"%(args[0],args[1]))
    
    
def CmdSetPlayerPassword(mob,args):
    from player import Player
    
    if CoreSettings.SINGLEPLAYER:
        return

    
    if len(args) != 2:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Please specify a player and a password\\n")
        return

    try:
        player = Player.byPublicName(args[0])
    except:
        try:
            player = Player.byFantasyName(args[0])
        except:
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Unknown player %s.\\n"%args[0])
            return

    try:
        user = User.byName(args[0])
    except:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Unknown user %s.\\n"%args[0])
        return

    if not IsUserSuperior(mob.player.publicName,user.name):
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"You do not have the required permission for this action.\\n")
        return

    
    pw = args[1]
    if len(pw) < 6:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Password must be at least 6 characters.\\n")
        return
    
    user.password = player.password = pw
        
    mob.player.sendGameText(RPG_MSG_GAME_GAINED,"Player %s password set to %s\\n"%(player.publicName,pw))

def CmdGetPlayerPassword(mob,args):
    
    if CoreSettings.SINGLEPLAYER:
        return

    if len(args) != 1:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Please specify a player\\n")
        return

    try:
        user = User.byName(args[0])
    except:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Unknown user %s.\\n"%args[0])
        return
    
    if not IsUserSuperior(mob.player.publicName,user.name):
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"You do not have the required permission for this action.\\n")
        return
        
    mob.player.sendGameText(RPG_MSG_GAME_GAINED,"Player %s password is: %s\\n"%(user.name,user.password))



COMMANDS = {}
COMMANDS['SPAWN']=CmdSpawn
COMMANDS['DESPAWN']=CmdDespawn
COMMANDS['GIMME']=CmdGimme
COMMANDS['TP']=CmdTP
COMMANDS['KILL']=CmdKill
COMMANDS['WORLDAGGRO']=CmdWorldAggro
COMMANDS['MYAGGRO']=CmdMyAggro
COMMANDS['SYSMSG']=CmdSystemMsg

COMMANDS['RECOMPILE']=CmdRecompile
COMMANDS['RELOADCOMMANDS']=CmdReloadCommands
COMMANDS['RELOADMODULE']=CmdReloadModule


COMMANDS['GIVEMONSTER']=CmdGiveMonster
COMMANDS['GRANTMONSTER']=CmdGrantMonster
COMMANDS['DENYMONSTER']=CmdDenyMonster
COMMANDS['LISTMONSTERS']=CmdListMonsters

COMMANDS['GETPLAYERPASSWORD']=CmdGetPlayerPassword
COMMANDS['SETPLAYERPASSWORD']=CmdSetPlayerPassword




COMMANDS['SET']=CmdSet

COMMANDS['GRANTLEVEL']=CmdGrantLevel

COMMANDS['GRANT']=CmdGrant
COMMANDS['DENY']=CmdDeny

def CmdCExtract(mob,args):
    from mud.worldserver.charutil import ExtractCharacters
    ExtractCharacters(mob.player.party.members)
    

COMMANDS['CEXTRACT']=CmdCExtract


def DoImmortalCommand(player,cmd,args):
    mob = player.curChar.mob
    
    if type(args)!=list:
        args = [args]
    cmd = cmd.upper()
    if COMMANDS.has_key(cmd):
        COMMANDS[cmd](mob,args)
    else:
        print "Unknown Command",cmd
        
