
from core import *

from random import randint
from math import floor,ceil,sqrt
from damage import Damage
from defines import *
import traceback

from mud.common.persistent import Persistent
from sqlobject import *

class ClassSkillQuestRequirement(Persistent):
    classSkill = ForeignKey('ClassSkill')
    choiceIdentifier = StringCol()
    levelBarrier = IntCol()    # level that still can be reached without the required quest

class ClassSkillRaceRequirement(Persistent):
    classSkill = ForeignKey('ClassSkill')
    race = StringCol()
    
class ClassSkill(Persistent):
    skillname = StringCol(default = "")
    levelGained = IntCol(default = 0)
    levelCapped = IntCol(default = 0)
    minReuseTime = IntCol(default = 0)
    maxReuseTime = IntCol(default = 0)
    maxValue = IntCol(default = 0)
    trained = BoolCol(default = False)
    spellProto = ForeignKey('SpellProto',default = None)
    classProtos = RelatedJoin('ClassProto')
    raceRequirementsInternal = MultipleJoin('ClassSkillRaceRequirement')
    questRequirementsInternal = MultipleJoin('ClassSkillQuestRequirement')
    
    def _init(self,*args,**kw):
        Persistent._init(self, *args, **kw)
        self.raceRequirements = []
        for r in list(self.raceRequirementsInternal):
            self.raceRequirements.append(r.race)
        self.questRequirements = []
        for qreq in list(self.questRequirementsInternal):
            self.questRequirements.append((qreq.choiceIdentifier,qreq.levelBarrier))
        
        

    
    def getMaxValueForLevel(self,level):
        if level < self.levelGained:
            return 0
        if not self.maxValue:
            return 0
        if not self.levelGained:
            return 0
        
        if level >= self.levelCapped:
            return self.maxValue
        
        if self.levelGained == self.levelCapped:
            return self.maxValue

            
        step = floor((self.maxValue/(self.levelCapped-self.levelGained)))
        
        value = floor((level - self.levelGained) * step+step) 
        if value > self.maxValue:
            value = self.maxValue
        return int(value)
        
    def getReuseTimeForLevel(self,level):
        if not self.maxReuseTime or not self.minReuseTime:
            return 0
        if not self.maxValue:
            return 0        
        if level < self.levelGained:
            return 0   

        if level > self.levelCapped:
            level = self.levelCapped

        
        if self.levelGained == self.levelCapped:
            return self.minReuseTime
        
        spread = float(self.maxReuseTime) - float(self.minReuseTime)
        gap = float(self.levelCapped) - float(self.levelGained)
        
        if not gap:
            return self.maxReuseTime
        
        phase = float((level-self.levelGained))/gap
        spread*=phase
        
        t = floor(self.maxReuseTime-spread)
            
        if t < self.minReuseTime:
            t = self.minReuseTime
            
        return int(t)
            
def DoDisarm(mob):
    if not mob.player:
        print "WARNING: Non-player mob attempting to disarm."
        return False
    
    tgt = mob.target
    player = mob.player
    
    if not tgt:
        player.sendGameText(RPG_MSG_GAME_DENIED,r'%s\'s disarm failed, no target.\n'%mob.name)
        return False
    
    if tgt.player or (tgt.master and tgt.master.player):
        return False #cannot disarm players (maybe for PvP)
    
    if not tgt.worn.has_key(RPG_SLOT_PRIMARY) and not tgt.worn.has_key(RPG_SLOT_SECONDARY):
        return False
    
    weapon = tgt.worn.get(RPG_SLOT_SECONDARY)
    if not weapon:
        weapon = tgt.worn.get(RPG_SLOT_PRIMARY)
        
    if not weapon:
        return False
        
        
    if GetRangeMin(mob,tgt) > 2.0:
        player.sendGameText(RPG_MSG_GAME_DENIED,r'%s\'s disarm failed, out of range.\n'%mob.name)
        return False
    
    
    pplevel = mob.plevel#skillLevels['Disarm']/10
    spread = pplevel-mob.target.plevel
    
    failed = False
    if spread < -5:
        failed = True
    else:
        chance = 6+spread
        r = randint(0,chance)
        if not r:
            failed = True
    
    if failed:
        player.sendGameText(RPG_MSG_GAME_DENIED,"%s has failed to disarm %s!\\n"%(mob.name,tgt.name))
        if not tgt.aggro.get(mob):
            tgt.addAggro(mob,10)
        return False
    
    tgt.unequipItem(weapon.slot)
    weapon.slot = -1
    tgt.mobInfo.refresh()
    
    stolen = False
    # if weapon is not soulbound, thiefs have a chance to directly steal weapon
    if not weapon.flags&RPG_ITEM_SOULBOUND and not weapon.flags&RPG_ITEM_UNIQUE:
        pplevel = mob.skillLevels.get('Pick Pocket',0) / 10
        mod = mob.target.difficultyMod
        if pplevel:
            difficulty = int(round(5.0 * (mod * mod * float(mob.target.plevel)) / float(pplevel)))
            if not randint(0,difficulty):    # not only disarm but steal weapon
                if player.giveItemInstance(weapon):
                    player.sendGameText(RPG_MSG_GAME_GAINED,"%s successfully yanks away %s's %s!\\n"%(weapon.character.name,tgt.name,weapon.name))
                    loot = tgt.loot
                    loot.items.remove(weapon)
                    if not len(loot.items):
                        tgt.loot = None
                    stolen = True
    
    if not stolen:
        player.sendGameText(RPG_MSG_GAME_GAINED,"%s has disarmed %s's %s.\\n"%(mob.name,tgt.name,weapon.name))
    
    mob.character.checkSkillRaise("Disarm")
    player.mind.callRemote("playSound","sfx/Hit_HugeMetalPlatformDrop.ogg")
    return True
    
    

    
    

def DoPickPocket(mob):
    if not mob.player:
        print "WARNING: Non-player mob attempting to pick pocket"
        return False
    
    tgt = mob.target
    if tgt == mob:
        return False

    if not tgt:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s\'s pick pocket failed, no target.\n'%mob.name)
        return False
    
    if tgt.player or (tgt.master and tgt.master.player):
        return False #cannot pick pocket of players (maybe for PvP)
    
    if tgt.target == mob and tgt.sleep <= 0 and tgt.stun <= 0:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"Pick pocket failed, %s has a keen eye on %s.\\n"%(tgt.name,mob.name))
        return False
    if mob.attacking:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"%s is too occupied with combat to pick pocket.\\n"%mob.name)
        return False
    
    loot = tgt.loot
    
    nothing = True
    if tgt.loot:
        if tgt.loot.generateCorpseLoot():
            nothing = False
    
    if nothing:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s has nothing to steal.\n'%tgt.name)
        return False
    
    pickpocketing = []
    specialPickPocket = []    # items specially flagged for thieves
    for item in loot.items:
        if loot.lootProto.itemDetails.has_key(item.itemProto.name):
            if loot.lootProto.itemDetails[item.itemProto.name]&RPG_LOOT_PICKPOCKET:
                specialPickPocket.append(item)
            continue
        pickpocketing.append(item)
    
    if not loot.tin and not len(pickpocketing) and not len(specialPickPocket):
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s has nothing to steal.\n'%tgt.name)
        return False

        
    if GetRangeMin(mob,tgt) > 2.0:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s\'s pick pocket failed, out of range.\n'%mob.name)
        return False
        
    # from here on increment pick pocket counter
    if loot.pickPocketCount <= 0:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"%s's pick pocket failed, %s has grown really paranoid.\\n"%(mob.name,tgt.name))
        if tgt.sleep > 0:  # wake up
            tgt.cancelSleep()
        return False
    else:
        loot.pickPocketCount -= 1
    
    pplevel = mob.skillLevels.get('Pick Pocket',0)
    
    succ = 500.0/sqrt(tgt.difficultyMod) * (1.0 - sqrt(loot.pickPocketTimer/360)) * (1.0 - (float(tgt.plevel) - float(pplevel)/10.0)/100.0)
    if tgt.sleep > 0 or tgt.stun > 0:
        succ *= 1.5
    
    # pick pocket timer doesn't directly prevent continuous pick pocketing,
    # but serves as a diminishing difficulty to pick pocket again.
    loot.pickPocketTimer = 360  # 1 minute
    
    succ = int(succ)
    if succ > 950:
        succ = 950
    if succ < 1:
        succ = 1
    if randint(0,1000) > succ:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"%s has noticed %s's pick pocketing!\\n"%(tgt.name,mob.name))
        if tgt.sleep > 0:  # wake up
            tgt.cancelSleep()
        if not tgt.aggro.get(mob):
            tgt.addAggro(mob,10)
        return False
    elif tgt.sleep > 0 and randint(0,1500) > succ:  # wake up
        tgt.cancelSleep()
        if not tgt.aggro.get(mob):
            tgt.addAggro(mob,10)
    if succ <= 500:
        mob.character.checkSkillRaise("Pick Pocket",4,4)
    
    
    msg = "%s pick pockets %s.\\n"%(mob.name,tgt.name)
    if len(specialPickPocket):    # items specially flagged for thieves
        x = len(specialPickPocket) - 1
        if x >= 1:
            x = randint(0,x)
        item = specialPickPocket[x]
        if mob.player.giveItemInstance(item):
            mob.player.sendGameText(RPG_MSG_GAME_GAINED,"%s successfully pick pockets a %s!\\n"%(item.character.name,item.name))
            loot.items.remove(item)
            if not len(loot.items):
                tgt.loot = None
            return True
    
    takeItem = False
    if len(pickpocketing):
        if loot.tin:
            if not randint(0,2):    # 1:3 chance to prefer item even if money is available
                takeItem = True
        else:
            takeItem = True
    if takeItem:
        x = len(pickpocketing) - 1
        if x >= 1:
            x = randint(0,x)
        item = pickpocketing[x]
        
        if mob.player.giveItemInstance(item):
            mob.player.sendGameText(RPG_MSG_GAME_GAINED,"%s successfully pick pockets a %s!\\n"%(item.character.name,item.name))
            loot.items.remove(item)
            if not len(loot.items):
                tgt.loot = None
            return True
    
    if loot.tin:    # got some money
        half = loot.tin >> 1    # divide in half
        tin = loot.tin - half    # for odd numbers
        loot.tin = half
        
        worth = GenMoneyText(tin)
        mob.player.giveMoney(tin)
        mob.player.sendGameText(RPG_MSG_GAME_GAINED,"%s successfully pick pockets %s.\\n"%(mob.name,worth))
        if not len(loot.items):
            tgt.loot = None
        return True
    else:
        if tgt.sleep > 0:  # wake up
            tgt.cancelSleep()
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,"$src quickly retracts $srchis hand before $tgt notices $srchim.\\n",mob)
        return True


def DoBackstab(mob):
    if not mob.player:
        print "WARNING: Non-player mob attempting to backstab"
        return False
    
    tgt = mob.target
    
    if not tgt:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s\'s backstab failed, no target.\n'%mob.name)
        return False
    
    if not AllowHarmful(mob,tgt) or tgt.plevel-3>mob.plevel:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s lacks the skill to backstab %s.\n'%(mob.name,tgt.name))
        return False
    
    if mob in tgt.aggro.keys():
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s cannot backstab a current enemy.\n'%(mob.name))
        return False
    
    wpnRange = 0
    pweapon = mob.worn.get(RPG_SLOT_PRIMARY,None)
    if not pweapon or not pweapon.skill or pweapon.skill == "Fists":
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s cannot backstab with his fists.\n'%mob.name)
        return False
    noBackstab = ("1H Impact","2H Impact")
    if pweapon.skill in noBackstab:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s cannot backstab with a %s weapon.\n'%(mob.name,pweapon.skill))
        return False
    if pweapon and pweapon.wpnRange > wpnRange:
        wpnRange = pweapon.wpnRange / 5.0
    
    if GetRangeMin(mob,tgt) > wpnRange:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s cannot backstab %s, out of range.\n'%(mob.name,tgt.name))
        return False
    
    tgt.addAggro(mob,200)
    
    bs = mob.skillLevels.get("Backstab",0)/10
    bs = randint(300+bs,bs*bs+300)
    
    Damage(tgt,mob,bs,RPG_DMG_PHYSICAL,"backstabs",False)
    
    mob.character.checkSkillRaise("Backstab",3,3)
    mob.cancelStatProcess("sneak","$tgt is no longer sneaking!\\n")
    mob.player.mind.callRemote("playSound","sfx/DarkMagic_ProjectileLaunch.ogg")
    return True


def DoRescue(mob):
    if not mob.player:
        print "WARNING: Non-player mob attempting to rescue"
        return False
    
    members = []
    for m in mob.player.alliance.members:
        for c in m.party.members:
            members.append(c.mob)
            
    
    if len(members)==1:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,r'There is no one to rescue.\n')
        return False
    
    
    

    aggro = {}
    
        
    for m in mob.zone.activeMobs:
        if m.player:
            continue
        for amob,amt in m.aggro.iteritems():
            if amob in members:
                if amt > aggro.get(m,0):
                    aggro[m]=amt

    if not len(aggro):
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,r'There is no one in need of rescue.\n')
        return False

                     
    for m,amt in aggro.iteritems():
        m.aggro[mob]=amt*1.25
        
    mob.character.checkSkillRaise("Rescue")    
    mob.player.sendGameText(RPG_MSG_GAME_BLUE,r'%s rescues the alliance!\n'%mob.name)    
    mob.player.mind.callRemote("playSound","sfx/Fireball_Launch5.ogg")
    return True


# Okay, Evade... here goes!
def DoEvade(mob):
    if not mob.player:
        print "WARNING: Non-player mob attempting to evade"
        return False
    
    members = [c.mob for m in mob.player.alliance.members for c in m.party.members]
    
    if len(members) == 1:
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,r'$src needs a member of $srchis alliance to shift the focus of the aggressor onto.\n',mob)
        return False
    
    mobAggro = {}
    memberAggro = {}
    
    for m in mob.zone.activeMobs:
        if m.player:
            continue
        for amob,amt in m.aggro.iteritems():
            if amob == mob:
                if amt > mobAggro.get(m,0):
                    mobAggro[m] = amt
            elif amob in members:
                if amt > memberAggro.get(m,0):
                    memberAggro[m] = amt
    
    if not len(mobAggro):
        mob.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s has no one to evade.\n'%mob.character.name)
        return False
    
    slevel = mob.skillLevels.get("Evade",0)
    aggroMod = 0.05 * slevel/1000.0
    for m,amt in mobAggro.iteritems():
        try:
            memberAmt = memberAggro[m]
        except:
            continue
        if amt < memberAmt:  # one of our alliance members has highest aggro
            m.aggro[mob] -= int(ceil(aggroMod * m.aggro[mob]))
        else:  # we have highest aggro
            m.aggro[mob] = memberAmt - int(ceil(aggroMod * m.aggro[mob]))
    
    mob.character.checkSkillRaise("Evade")
    mob.player.sendGameText(RPG_MSG_GAME_BLUE,r'%s evades the focus of the aggressor!\n'%mob.name)
    mob.player.mind.callRemote("playSound","sfx/Fireball_Launch5.ogg")
    return True


def DoShieldBash(mob):
    tgt = mob.target
    
    if not tgt:
        if mob.player:
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s\'s shield bash failed, no target.\n'%mob.name)
        return False
    
    wshield = mob.worn.get(RPG_SLOT_SHIELD,None)
    if not wshield or not wshield.skill or wshield.skill != "Shields":
        if mob.player:
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s cannot shield bash without a shield.\n'%mob.name)
        return False
    
    if GetRangeMin(mob,tgt) > 1:
        if mob.player:
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s cannot shield bash %s, out of range.\n'%(mob.name,tgt.name))
        return False
    
    tgt.addAggro(mob,15)
    mob.cancelStatProcess("sneak","$tgt is no longer sneaking!\\n")
    return True


#------------------------------------------------------


SKILLS = {}
SKILLS['Pick Pocket'] = DoPickPocket
SKILLS['Disarm']      = DoDisarm
SKILLS['Rescue']      = DoRescue
SKILLS['Backstab']    = DoBackstab
SKILLS['Evade']       = DoEvade
SKILLS['Shield Bash'] = DoShieldBash


#------------------------------------------------------


def GetSkill(name):
    return SKILLS[name]

def GetPlayerHealingTarget(src,tgt):
    if tgt:
        if tgt.health<tgt.maxHealth:
            return tgt
    for c in src.player.party.members:
        if c.mob.health<c.mob.maxHealth:
            return c.mob
        
    return None

    
def DoSkillSpell(mob,skillname):
    from projectile import Projectile
    from spell import SpawnSpell
    
    mskill = mob.mobSkillProfiles[skillname]
    cskill = mskill.classSkill
    
    mv = mob.skillLevels.get(skillname,0)
    if not mv:
        return
    
    mod = float(mv)/float(cskill.maxValue)
    
    if mod < .1:
        mod = .1
    
    proto = cskill.spellProto

    tgt = mob.target
    if proto.target == RPG_TARGET_SELF:
        tgt = mob
    elif proto.target == RPG_TARGET_PARTY:
        tgt = mob
    elif proto.target == RPG_TARGET_ALLIANCE:
        tgt = mob
    elif proto.target == RPG_TARGET_PET:
        tgt = mob.pet
    elif mob.player and proto.spellType&RPG_SPELL_HEALING and proto.target == RPG_TARGET_OTHER:
        tgt = GetPlayerHealingTarget(mob,tgt)
        
    if not tgt:
        if mob.player:
            if proto.spellType&RPG_SPELL_HARMFUL:
                from command import CmdTargetNearest
                CmdTargetNearest(mob,None,False,True)
                tgt = mob.target
                if not tgt:
                    mob.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s\'s skill failed, no target.\n'%mob.name)                    
                    
            else:
                tgt=mob

        
    if not tgt:
        return
    
    if proto.spellType&RPG_SPELL_HARMFUL:
        if not AllowHarmful(mob,tgt) and not proto.aoeRange:
            return
        if not mob.player and not (mob.master and mob.master.player) and not IsKOS(mob,tgt):
            return
    
    if not proto.spellType&RPG_SPELL_HARMFUL and mob.target == tgt:
        if tgt and IsKOS(tgt,mob):
            tgt = mob

    if mob.character:
        c = 10
        if mskill.reuseTime > 180:
            c = 5

        if mskill.reuseTime > 180*2:
            c = 3
    
        mob.character.checkSkillRaise(skillname,c)
    
    if proto.animOverride:
        mob.zone.simAvatar.mind.callRemote("playAnimation",mob.simObject.id,proto.animOverride)
    if len(proto.particleNodes):
        mob.zone.simAvatar.mind.callRemote("triggerParticleNodes",mob.simObject.id,proto.particleNodes)

        
    if proto.projectile:
        p = Projectile(mob,mob.target)
        p.spellProto = proto
        p.launch()                
    else:
        SpawnSpell(proto,mob,tgt,tgt.simObject.position,mod,True)

    

def UseSkill(mob,tgt,skillname):
    #find the skill
    if not mob.mobSkillProfiles.has_key(skillname):
        #todo, better warning
        if mob.player:
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s has lost his ability in %s!\n'%(mob.spawn.name,skillname))
        return
    
    mskill = mob.mobSkillProfiles[skillname]
    cskill = mskill.classSkill
    
    if not mskill.reuseTime:
        return #passive
    if mob.skillReuse.has_key(cskill.skillname):
        return
    
    mob.skillReuse[cskill.skillname] = mskill.reuseTime
    
    passed = False
    if skillname in SKILLS:
        if skillname not in mob.skillLevels:
            traceback.print_stack()
            print "AssertionError: mob %s doesn't know the skill %s!"%(mob.name,skillname)
            return
        func = SKILLS.get(skillname)
        passed = func(mob)
    else:
        passed = True
    
    if passed and cskill.spellProto:
        DoSkillSpell(mob,skillname)


