
#a process is a command, skill, spell, etc

class Process:
    processCounter = 1L
    def __init__(self,src,dst):
        self.src = src
        self.dst = dst
        self.iter = None
        self.tickCounter = 0
        self.tickRate = 1
        self.canceled = False
        self.pid = Process.processCounter
        Process.processCounter+=1
        
    def globalPush(self):
        self.src.processesOut.append(self)
        self.dst.processesIn.append(self)
        
    def clearSrc(self):
        self.src = None
        
    def clearDst(self):
        self.dst = None
        
    def begin(self):
        self.globalPush()
        self.iter = self.tick()
        return True
        
    #generator function
    def tick(self):
        return False
    
    def end(self):
        if self.canceled:
            return
        self.globalPop()
        return 
        
    def cancel(self):
        if self.canceled:
            return 
        
        self.canceled = True
        self.iter = None
        #self.end()
        self.globalPop()
        
        
    def globalPop(self):
        if self in self.src.processesOut:
            self.src.processesOut.remove(self)
        if self in self.dst.processesIn:
            self.dst.processesIn.remove(self)
        
        
                
            
            
            
            
        
        
        
        