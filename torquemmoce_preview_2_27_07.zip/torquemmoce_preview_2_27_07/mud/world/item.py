
from defines import *
from mud.common.persistent import Persistent
from random import randint
from math import floor,ceil
from sqlobject import *
from spell import SpellProto,SpawnSpell
from mud.world.shared.playdata import ItemInfo
from projectile import Projectile
from core import *
import traceback
from copy import copy

class ItemSoundProfile(Persistent):
    
    #sounds (could split to seperate table)
    sndAttack1 = StringCol(default="")
    sndAttack2 = StringCol(default="")
    sndAttack3 = StringCol(default="")
    sndAttack4 = StringCol(default="")
    sndAttack5 = StringCol(default="")
    sndAttack6 = StringCol(default="")
    sndAttack7 = StringCol(default="")
    sndAttack8 = StringCol(default="")

    sndHit1 = StringCol(default="")
    sndHit2 = StringCol(default="")
    sndHit3 = StringCol(default="")
    sndHit4 = StringCol(default="")
    sndHit5 = StringCol(default="")
    sndHit6 = StringCol(default="")
    sndHit7 = StringCol(default="")
    sndHit8 = StringCol(default="")
    
    sndUse = StringCol(default="")
    
    #override
    sndEquip = StringCol(default="")
    
    def _init(self,*args,**kw):
        Persistent._init(self, *args, **kw)
        
        
        #setup numSndIdleLoop, etc
        sndattribs = ['sndAttack','sndHit']
        for snd in sndattribs:
            num = 0
            for x in xrange(1,5):
                if not getattr(self,snd+str(x)):
                    break
                num+=1
                
            setattr(self,"numS"+snd[1:],num)
            
        sounds = self.sounds = {}
        sounds["sndAttack"]=self.numSndAttack
        sounds["sndHit"]=self.numSndHit
        
        
            
    def getSound(self,snd):
        w = self.sounds[snd]
        w = random.randint(1,w)
        return getattr(self,snd+str(w))

class ItemStat(Persistent):
    itemProto = ForeignKey('ItemProto')
    statname = StringCol()
    value = FloatCol()
    
class ItemSlot(Persistent):
    itemProto = ForeignKey('ItemProto')
    slot = IntCol()

class ItemRace(Persistent):
    itemProto = ForeignKey('ItemProto')
    racename = StringCol()

class ItemRealm(Persistent):
    itemProto = ForeignKey('ItemProto')
    realmname = IntCol()
    level = IntCol(default=0)

#item class level recommendation
class ItemClass(Persistent):
    itemProto = ForeignKey('ItemProto')
    classname = StringCol()
    level = IntCol()
    
class ItemSpell(Persistent):
    itemProto = ForeignKey('ItemProto')
    spellProto = ForeignKey('SpellProto')
    trigger = IntCol(default = RPG_ITEM_TRIGGER_WORN)
    frequency = IntCol(default = RPG_FREQ_ALWAYS) #freq always applies the effect when worn and never rechecks
    duration = IntCol(default=0) # for poisons and things (proc duration is in successful hits)

class ItemSpellTemp: # no duration here, this is handled differently
    def __init__(self,spellProto,trigger,frequency):
        self.spellProto = spellProto
        self.trigger = trigger
        self.frequency = frequency

class ItemSet(Persistent):
    itemProto = ForeignKey('ItemProto')
    itemSetProto = ForeignKey('ItemSetProto')
    contribution = StringCol()

#item proto is for exceptional
class ItemProto(Persistent): 

    name = StringCol(alternateID=True)
    
    flags = IntCol(default = 0)
    
    racesInternal = MultipleJoin('ItemRace')

    realmsInternal = MultipleJoin('ItemRealm')
    
    slotsInternal = MultipleJoin('ItemSlot')
    
    #recommendations
    classesInternal = MultipleJoin('ItemClass')
    
    statsInternal = MultipleJoin('ItemStat')
    spellsInternal = MultipleJoin('ItemSpell')

    
    #level recommendation (blanket)
    level = IntCol(default=1)
    
    #-6 -> 6
    rating = IntCol(default=0)
    
    noise = IntCol(default = 0)
    
    
    food = IntCol(default=0)
    drink = IntCol(default=0)
    
    skill = StringCol(default = "")
    
    effectDesc = StringCol(default = "")
    desc = StringCol(default = "")
    
    equipMessage = StringCol(default = "")
    
    worthTin = IntCol(default=0L)
    
    #TODO PROCS
    
    #USE
    useDestroy = BoolCol(default=True)
    useMax = IntCol(default = 0)
    
    #weapons
    wpnRaceBane = StringCol(default="")
    wpnRaceBaneMod = FloatCol(default=0) #10%
    
    wpnResistDebuff = IntCol(default=RPG_RESIST_PHYSICAL)
    wpnResistDebuffMod = IntCol(default=0)
    
    wpnDamage = FloatCol(default = 0)
    wpnRate = FloatCol(default = 0)
    wpnRange = FloatCol(default = 0)
    wpnAmmunitionType = StringCol(default="")
    
    isAmmunitionType = StringCol(default="")
    projectile = StringCol(default="")
    speed = FloatCol(default = 0)
    
    #armor
    armor = IntCol(default=0)
    
    weight = FloatCol(default = 0)
    
    #stackable items are always normal quality!!!
    stackMax = IntCol(default = 1)
    stackDefault = IntCol(default=1)
    
    #repair
    repairMax = FloatCol(default = 0)
    lifeTime = IntCol(default = 0)  # 0 = infinite, else in ticks
    
    items = MultipleJoin('Item')
    itemSetsInternal = MultipleJoin('ItemSet')
    
    #graphics
    bitmap = StringCol(default="") #for gui
    model = StringCol(default="")

    sndProfile = ForeignKey('ItemSoundProfile',default=None)
    
    #texture override
    material = StringCol(default="")
    
    spellProto = ForeignKey('SpellProto',default=None) #scrolls
    
    light = FloatCol(default=0.0)
    
    craftConsumed = BoolCol(default=True)
    
    ingredientsInternal = MultipleJoin("RecipeIngredient")
    
    
    
    equippedParticle = StringCol(default="")
    equippedParticleTexture = StringCol(default="")

    def _init(self,*args,**kw):
        Persistent._init(self, *args, **kw)
        
        self.raceList = None
        self.realmList = None
        self.slotList = None
        self.classList = None
        self.statList = None
        self.spellList = None
        self.itemSets = self.itemSetsInternal[:]
        self.ingredientList = None


    def _get_ingredients(self):
        if self.ingredientList != None:
            return self.ingredientList
        
        self.ingredientList = list(self.ingredientsInternal)
        return self.ingredientList
    
    def _get_races(self):
        if self.raceList != None:
            return self.raceList
        
        self.raceList = tuple(race.racename for race in self.racesInternal)
        return self.raceList

    def _get_realms(self):
        if self.realmList != None:
            return self.realmList
        
        self.realmList = list(self.realmsInternal)
        return self.realmList

    def _get_slots(self):
        if self.slotList != None:
            return self.slotList
        
        self.slotList = tuple(slot.slot for slot in self.slotsInternal)
        return self.slotList
    
    def _get_classes(self):
        if self.classList != None:
            return self.classList
        
        self.classList = list(self.classesInternal)
        return self.classList


    def _get_stats(self):
        if self.statList != None:
            return self.statList
        
        self.statList = list(self.statsInternal)
        return self.statList
    
    def _get_spells(self):
        if self.spellList != None:
            return self.spellList
        
        self.spellList = list(self.spellsInternal)
        return self.spellList
    
    
    def createInstance(self,bitmapOverride = None,normalQuality=True):
        quality = RPG_QUALITY_EXCEPTIONAL
        repairMax = self.repairMax
        
        if not self.flags and not self.spellProto and len(self.slots):
            if normalQuality:
                quality = RPG_QUALITY_NORMAL
                repairMax = floor(repairMax*.8)
            elif self.stackMax <= 1:
                #generate quality
                r = randint(0,99)
                if r < 50:
                    quality = RPG_QUALITY_NORMAL
                    repairMax = floor(repairMax*.8)
                elif r < 65:
                    quality = RPG_QUALITY_CRUDDY
                    repairMax = floor(repairMax*.6)
                elif r < 85:
                    quality = RPG_QUALITY_SHODDY
                    repairMax = floor(repairMax*.7)
                elif r < 95:
                    quality = RPG_QUALITY_SUPERIOR
                    repairMax = floor(repairMax*.9)
                #otherwise exceptional, which is already set
        
        if self.flags & RPG_ITEM_INDESTRUCTIBLE:
            repairMax = 0
        elif self.repairMax > 0 and not repairMax:
            repairMax = 1
        else:
            repairMax = int(repairMax)
        
        repair = repairMax
        #create the instance
        
        if self.stackMax > 1 and self.stackDefault > 1:
            stackCount = self.stackDefault
        else:
            stackCount = 1
        
        if bitmapOverride:
            bitmap = bitmapOverride
        else:
            bitmap = self.bitmap
        
        item = ItemInstance()
        item.name       = self.name
        item.itemProto  = self
        item.quality    = quality
        item.repair     = repair
        item.repairMax  = repairMax
        item.lifeTime   = self.lifeTime
        item.character  = None
        item.stackCount = stackCount
        item.food       = self.food
        item.drink      = self.drink
        item.useCharges = self.useMax
        item.bitmap     = bitmap
        item.refreshFromProto()
        
        return item


DAMAGELOOKUP = {
"1H Pierce":RPG_DMG_PIERCING,
"2H Pierce":RPG_DMG_PIERCING,
"1H Impact":RPG_DMG_IMPACT,
"2H Impact":RPG_DMG_IMPACT,
"1H Cleave":RPG_DMG_CLEAVE,
"2H Cleave":RPG_DMG_CLEAVE,
"1H Slash":RPG_DMG_SLASHING,
"2H Slash":RPG_DMG_SLASHING,
}


class Item(Persistent):
    name = StringCol()
    itemProto = ForeignKey('ItemProto')
    
    #instance specifics
    
    stackCount = IntCol(default = 1)
    
    useCharges = IntCol(default = 0)
    
    quality = IntCol(default=RPG_QUALITY_NORMAL)
    
    food = IntCol(default=0)
    drink = IntCol(default=0)
    
    repairMax = FloatCol(default = 0)
    repair = FloatCol(default = 0)
    lifeTime = IntCol(default = 0)  # 0 = infinite, else in ticks
    
    slot = IntCol(default=0) #where the item is on the character
    
    #persistent items only owned by characters
    character = ForeignKey('Character',default = None)
    player = ForeignKey('Player',default=None)
    
    xpCoupon = IntCol(default = 0)
    
    descOverride = StringCol(default="")
    levelOverride = IntCol(default=0)
    
    spellEnhanceLevel = IntCol(default=0)
    
    bitmap = StringCol(default = "")
    
    #todo, store reuse
    #persistentReuseTimer = IntCol(default=0)
    
    #variants
    hasVariants = BoolCol(default=False)
    variants = MultipleJoin("ItemVariant")
    
    crafted = BoolCol(default=False)
    
    
    def _init(self,*args,**kw):
        Persistent._init(self, *args, **kw)
    
    
    def expire(self):
        for v in self.variants:
            v.expire()
        Persistent.expire(self)
    
    
    def destroySelf(self):
        for v in self.variants:
            v.destroySelf()
        Persistent.destroySelf(self)




class ItemInstance:
    def __init__(self,item=None):
        self.worthIncreaseTin  = 0
        # timer for poisons and spell enchantments
        self.procs             = {}
        self.itemInfo          = ItemInfo(self)
        if not item:
            self.item              = None  # associated db item
            # fields that better be initialized
            self.stackCount        = 1
            self.useCharges        = 0
            self.quality           = RPG_QUALITY_NORMAL
            self.food              = 0
            self.drink             = 0
            self.repairMax         = 0
            self.repair            = 0
            self.lifeTime          = 0
            self.slot              = -1 #where the item is on the character
            self.character         = None
            self.player            = None
            self.xpCoupon          = 0
            self.descOverride      = ""
            self.levelOverride     = 0
            self.spellEnhanceLevel = 0
            self.bitmap            = ""
            #variants
            self.hasVariants       = False
            self.variants          = {}
            self.crafted           = False
        else:
            self.loadFromItem(item)
    
    
    def loadFromItem(self,item):
        self.item              = item  # associated db item
        self.name              = item.name
        self.itemProto         = item.itemProto
        self.stackCount        = item.stackCount
        self.useCharges        = item.useCharges
        self.quality           = item.quality
        self.food              = item.food
        self.drink             = item.drink
        self.repairMax         = item.repairMax
        self.repair            = item.repair
        self.lifeTime          = item.lifeTime
        self.slot              = item.slot #where the item is on the character
        self.character         = item.character
        self.player            = item.player
        self.xpCoupon          = item.xpCoupon
        self.descOverride      = item.descOverride
        self.levelOverride     = item.levelOverride
        self.spellEnhanceLevel = item.spellEnhanceLevel
        self.bitmap            = item.bitmap
        #variants
        self.hasVariants       = item.hasVariants
        from itemvariants import ItemVariantsLoad
        ItemVariantsLoad(self)
        self.crafted           = item.crafted
        self.refreshFromProto()
        return self
    
    
    def storeToItem(self,override = False):
        # only store items in the posession of a player!
        if not self.character and not self.player and not override:
            return
        if not self.item:
            self.item = Item(name = self.name,itemProto = self.itemProto)
        item = self.item
        item.name              = self.name
        item.stackCount        = self.stackCount
        item.useCharges        = self.useCharges
        item.quality           = self.quality
        item.food              = self.food
        item.drink             = self.drink
        item.repairMax         = self.repairMax
        item.repair            = self.repair
        item.lifeTime          = self.lifeTime
        item.slot              = self.slot #where the item is on the character
        item.character         = self.character
        item.player            = self.player
        item.xpCoupon          = self.xpCoupon
        item.descOverride      = self.descOverride
        item.levelOverride     = self.levelOverride
        item.spellEnhanceLevel = self.spellEnhanceLevel
        item.bitmap            = self.bitmap
        #variants
        item.hasVariants       = self.hasVariants
        from itemvariants import ItemVariantsSave
        ItemVariantsSave(self)
        item.crafted           = self.crafted
    
    
    def clone(self):
        nitem = self.itemProto.createInstance()
        #instance specifics
        nitem.name              = self.name
        nitem.quality           = self.quality
        nitem.repair            = self.repair
        nitem.repairMax         = self.repairMax
        nitem.lifeTime          = self.lifeTime
        nitem.stackCount        = self.stackCount
        nitem.food              = self.food
        nitem.drink             = self.drink
        nitem.useCharges        = self.itemProto.useMax
        nitem.bitmap            = self.bitmap
        nitem.xpCoupon          = self.xpCoupon
        nitem.descOverride      = self.descOverride
        nitem.levelOverride     = self.levelOverride
        nitem.spellEnhanceLevel = self.spellEnhanceLevel
        nitem.variants          = copy(self.variants)
        return nitem
    
    
    def destroySelf(self):
        if self.character:
            self.character.items.remove(self)
        if self.player:
            self.player.bankItems.remove(self)
        if self.item:
            self.item.destroySelf()
    
    
    # Just a little function for easier dynamic changes to an object (enchanting, socketing, ...)
    def clearVariants(self):
        self.variants = {}
        self.hasVariants = False
    
    
    def numVariants(self):
        num = 0
        for varList in self.variants.itervalues():
            if isinstance(varList,tuple):
                num += 1
            else:
                num += len(varList)
        return num
    
    
    # if stacking is not possible, switch items
    # returns a tuple with (switched,item1,item2)
    # Warning: does no expunging, will have to be done at caller
    def doStack(self,item):
        proto = self.itemProto
        if not item or not proto.stackMax > 1 or self.name != item.name:  # just switch
            return (True,item,self)
        if not item.stackCount:
            item.stackCount = 1
        if not self.stackCount:
            self.stackCount = 1
        
        updateStack = False
        updateCharges = False
        switch = False
        
        # check stackCounts
        amt = proto.stackMax - self.stackCount
        if amt >= item.stackCount:
            self.stackCount += item.stackCount
            item.stackCount = 0
            updateStack = True
        elif amt > 0:
            self.stackCount = proto.stackMax
            item.stackCount -= amt
            updateStack = True
        else:
            switch = True
        
        # check useCharges
        if proto.useMax > 0:
            amt = proto.useMax - self.useCharges
            if item.stackCount <= 0:
                updateCharges = True
                if amt >= item.useCharges:
                    self.useCharges += item.useCharges
                    self.stackCount -= 1    # must have stacked before...
                else:
                    self.useCharges = item.useCharges - amt
            elif amt >= item.useCharges:
                self.useCharges += item.useCharges
                updateCharges = True
                if proto.useDestroy:
                    item.stackCount -= 1
                    item.useCharges = proto.useMax
                else:
                    item.useCharges = 0
        
        if updateCharges and updateStack:
            if self.stackCount > 0:
                self.itemInfo.refreshDict({'STACKCOUNT':self.stackCount,'USECHARGES':self.useCharges})
            if item.stackCount > 0:
                item.itemInfo.refreshDict({'STACKCOUNT':item.stackCount,'USECHARGES':item.useCharges})
        elif updateStack:
            if self.stackCount > 0:
                self.itemInfo.refreshDict({'STACKCOUNT':self.stackCount})
            if item.stackCount > 0:
                item.itemInfo.refreshDict({'STACKCOUNT':item.stackCount})
        elif updateCharges:
            if self.stackCount > 0:
                self.itemInfo.refreshDict({'USECHARGES':self.useCharges})
            if item.stackCount > 0:
                item.itemInfo.refreshDict({'USECHARGES':item.useCharges})
        
        if not item.stackCount:
            result = None
        else:
            result = item
        
        if switch and result:
            return (True,result,self)
        else:
            return (False,self,result)
    
    
    def doItemSpellUse(self,mob,proto):
        tgt = mob.target
        if proto.target == RPG_TARGET_SELF:
            tgt = mob
        if proto.target == RPG_TARGET_PARTY:
            tgt = mob
        if proto.target == RPG_TARGET_ALLIANCE:
            tgt = mob
        if proto.target == RPG_TARGET_PET:
            tgt = mob.pet
        
        if not tgt:
            return
        
        if proto.animOverride:
            mob.zone.simAvatar.mind.callRemote("playAnimation",mob.simObject.id,proto.animOverride)
        if len(proto.particleNodes):
            mob.zone.simAvatar.mind.callRemote("triggerParticleNodes",mob.simObject.id,proto.particleNodes)
        
        mod = 1.0 #to do recommneded level
        
        if proto.projectile:
            p = Projectile(mob,mob.target)
            p.spellProto = proto
            p.launch()
        else:
            SpawnSpell(proto,mob,tgt,tgt.simObject.position,mod)
    
    
    def use(self,mob):
        #a ranged weapon?
        #everything below will be handled in shootRanged() anyway so test here
        if self.wpnDamage and self.wpnRange and self.slot == RPG_SLOT_RANGED and mob.rangedReuse <= 0:
            mob.shootRanged()
            return
        
        player = mob.player
        
        if not self.isUseable(mob) or self.penalty:
            player.sendGameText(RPG_MSG_GAME_DENIED,"%s cannot currently use this item.\\n"%(mob.name))
            return
            
        if self.reuseTimer:
            return
        
        if mob.sleep > 0 or mob.stun > 0  or mob.isFeared:
            player.sendGameText(RPG_MSG_GAME_DENIED,"%s cannot use items while asleep, stunned, or feared.\\n"%(mob.name))
            return
        
        #todo proper timing
        
        if self.skill:
            if not mob.skillLevels.get(self.skill):
                player.sendGameText(RPG_MSG_GAME_DENIED,"%s cannot use this item as it requires the %s skill.\\n"%(mob.name,self.skill))
                return
            try:
                mskill = mob.mobSkillProfiles[self.skill]
                self.reuseTimer = mskill.reuseTime
                
            except:
                self.reuseTimer = 60
                
        else:
            self.reuseTimer = 0
        
        self.itemInfo.refresh()
        
        if len(self.spells) and mob.character:
            gotone = False
            for ispell in self.spells:
                if ispell.trigger == RPG_ITEM_TRIGGER_POISON:
                    pw = mob.worn.get(RPG_SLOT_PRIMARY,None)
                    if not pw:
                        if player:
                            player.sendGameText(RPG_MSG_GAME_DENIED,"%s must have a primary weapon equipped to apply a poison.\\n"%mob.name)
                        return
                    # apply poison, funnier than ever before
                    if pw.procs.has_key(ispell):    # just refresh old poison
                        pw.procs[ispell] = [ispell.duration,RPG_ITEMPROC_POISON]
                        player.sendGameText(RPG_MSG_GAME_GAINED,"%s refreshes %s.\\n"%(mob.name,self.name))
                    elif len(pw.procs) < RPG_ITEMPROC_MAX:    # check for max temporary procs on weapon
                        pw.procs[ispell] = [ispell.duration,RPG_ITEMPROC_POISON]
                        player.sendGameText(RPG_MSG_GAME_GAINED,"%s applies %s.\\n"%(mob.name,self.name))
                    else:
                        overwriting = []
                        for proc in pw.procs.iterkeys():    # overwrite poison with lowest duration
                            if pw.procs[proc][1] != RPG_ITEMPROC_ENCHANTMENT:
                                if not overwriting or overwriting[1] < pw.procs[proc][0]:
                                    overwriting = (proc,pw.procs[proc][0])
                        if not overwriting:
                            player.sendGameText(RPG_MSG_GAME_DENIED,"%s radiates so much power that %s evaporates.\\n"%(pw.name,self.name))
                        else:    # found something to overwrite
                            del pw.procs[overwriting[0]]
                            pw.procs[ispell] = [ispell.duration,RPG_ITEMPROC_POISON]
                            player.sendGameText(RPG_MSG_GAME_DENIED,"The applied %s nullifies %s.\\n"%(self.name,overwriting[0].spellProto.name))
                    # only need to update for description,
                    # so only do if attacker is a player or a player pet
                    if player or mob.master.player:
                        pw.itemInfo.refreshProcs()
                    mob.playSound("sfx/Underwater_Bubbles2.ogg")
                    gotone=True
                
                elif ispell.trigger == RPG_ITEM_TRIGGER_USE:
                    for e in ispell.spellProto.effectProtos:
                        if e.hasPermanentStats:
                            for stat in e.permanentStats:
                                if "Base" in stat.statname:
                                    stname = stat.statname.replace("Base","Raise")
                                    if not getattr(mob.character,stname):
                                        if player:
                                            player.sendGameText(RPG_MSG_GAME_DENIED,"You cannot raise your stat higher in this manner.\\n")
                                        return
                        if e.giveSkill:
                            if mob.skillLevels.get(e.giveSkill,0):
                                if player:
                                    player.sendGameText(RPG_MSG_GAME_DENIED,"%s already knows the %s skill.\\n"%(mob.name,e.giveSkill))
                                return
                                    
                    gotone = True
                    self.doItemSpellUse(mob,ispell.spellProto)
            if gotone and self.useCharges:
                self.useCharges-=1
                if not self.useCharges and self.itemProto.useDestroy:
                    
                    # no need to check for positive stackCount
                    self.stackCount-=1
                    if self.stackCount <= 0:
                        player.takeItem(self)
                    else:
                        self.useCharges = self.itemProto.useMax
                        self.itemInfo.refreshDict({'STACKCOUNT':self.stackCount,'USECHARGES':self.useCharges})
                    return
                else:
                    if self.useCharges < 0:
                        self.useCharges = 0
                    else:
                        self.itemInfo.refreshDict({'USECHARGES':self.useCharges})
        
        #an xpCoupin?
        if self.xpCoupon:
            #always destroys self
            mob.character.gainXP(self.xpCoupon,False)
            player.takeItem(self)
    
    
    def tick(self):
        if self.reuseTimer:
            self.reuseTimer -= 1
            if self.reuseTimer <= 0:
                self.reuseTimer = 0
                self.itemInfo.refreshDict({'REUSETIMER':self.reuseTimer})
        if (self.character or self.player) and self.itemProto.lifeTime > 0:
            self.lifeTime -= 1
            if self.lifeTime <= 0:
                if self.character:
                    player = self.character.player
                    char = self.character
                else:
                    player = self.player
                    char = player.curChar
                player.takeItem(self)
                player.sendGameText(RPG_MSG_GAME_LOST,r'The %s has magically been whisked away from %s!\n'%(self.name,char.name))
    
    
    def isUseable(self,mob):
        spawn = mob.spawn
        proto = self.itemProto
        
        if RPG_BUILD_DEMO and mob.player and not mob.player.premium:
            if self.level>=50 or self.itemProto.flags&RPG_ITEM_PREMIUM:
                return False
        
        if proto.skill:            
            if not mob.skillLevels.get(proto.skill):
                return False
        
        if len(proto.races):
            if spawn.race not in proto.races:
                return False #can't use based on race
        
        if len(proto.realms):
            found = False
            for r in proto.realms:
                if spawn.realm == r.realmname:
                    found = True
                    break
            if not found:
                return False #can't use based on realm
        
        if len(proto.classes):
            found = False
            for cl in proto.classes:
                if cl.classname == spawn.pclass.name or (spawn.sclass and spawn.sclass.name == cl.classname) or (spawn.tclass and spawn.tclass.name == cl.classname):
                    found = True
                    break
            if not found:
                return False #can't use based on class
        
        return True #can use!
    
    
    def setCharacter(self,char,refresh = True):
        if hasattr(char,"mob") and char.mob:
            self.canUse = self.isUseable(char.mob)
            self.penalty = self.getPenalty(char.mob)
        
        if self.character == char:
            if refresh:
                self.refreshFromProto()
            return
        
        if self.character:
            if hasattr(self.character,"mob") and self.character.mob:
                if self in self.character.mob.worn.itervalues():
                    self.character.mob.unequipItem(self.slot)
            self.character.items.remove(self)
        if self.player:
            self.player.bankItems.remove(self)
        
        self.character = char
        if char:
            char.items.append(self)
        
        # changes to character attribute have to be written to db immediately,
        # else a player giving away an item and logging in before said item gets
        # backupped will receive the item again.
        if self.item:
            self.item.character = char
        
        if refresh:
            self.refreshFromProto()
    
    
    #this function exists so that we can display different stats 
    #to different characters based on their level and stuff
    #like in a trade screen, etc
    def getPenalty(self,mob,forPet = False):
        if not forPet and not self.isUseable(mob):
            return 1.0
        proto = self.itemProto
        
        penalty = 1.0
        repairRatio = 1.0
        
        itemLevel = self.level
        levelCheck = mob.plevel
        delta = 9999
        
        # class recommendation
        for cl in list(proto.classes):
            if not cl.level:
                traceback.print_stack()
                print "AssertionError: no level to class %s recommendation assigned, on item %s!"%(cl.classname,self.name)
                continue
            if forPet:
                if cl.level > itemLevel:
                    itemLevel = cl.level
                continue
            if cl.classname == mob.pclass.name:
                diff = cl.level - mob.plevel
                if diff < delta:
                    delta = diff
                    itemLevel = cl.level
                    levelCheck = mob.plevel
            elif mob.sclass and cl.classname == mob.sclass.name:
                diff = cl.level - mob.slevel
                if diff < delta:
                    delta = diff
                    itemLevel = cl.level
                    levelCheck = mob.slevel
            elif mob.tclass and cl.classname == mob.tclass.name:
                diff = cl.level - mob.tlevel
                if diff < delta:
                    delta = diff
                    itemLevel = cl.level
                    levelCheck = mob.tlevel
        
        # realm recommendation (only for level, usability already checked)
        for r in list(proto.realms):
            if r.level:
                if forPet:
                    if r.level > itemLevel:
                        itemLevel = r.level
                else:
                    diff = r.level - mob.plevel
                    if diff < delta:
                        itemLevel = r.level
                        levelCheck = mob.plevel
        
        # enhanced item penalty code, if user lacks more than 20 levels -> 100% penalty
        if itemLevel > 1:
            if itemLevel < 20:
                penalty = 1.0 - float(levelCheck)/float(itemLevel)
                if penalty < 0.0:
                    penalty = 0.0
            else:
                diff = float(itemLevel - levelCheck) / 20.0
                if diff <= 0.0:
                    penalty = 0.0
                elif diff >= 1.0:
                    penalty = 1.0
                # diminishing penalty the closer the user gets to required level
                else:
                    point = diff*diff
                    penalty = 1.0 - floor(100.0 * (1.0 + point*(point - 2.0))) / 100.0
        else:
            penalty = 0.0
        
        # repair
        if self.repairMax:
            repairRatio = float(self.repair)/float(self.repairMax)
            if repairRatio < .2: #at 20% of repair penalty starts
                penalty+=(.2-repairRatio)*4.0 #up to 80% penalty for repair
            if self.repair == 0:
                penalty = 1.0
        
        if penalty < .01:
            penalty = 0.0
        if penalty > 1.0:
            penalty = 1.0
        
        return penalty
    
    
    def getWorth(self,valueMod = 1.0):
        #todo, repair
        proto = self.itemProto
        mod = RPG_QUALITY_MODS[self.quality]
        
        tin = proto.worthTin
        tin += self.worthIncreaseTin
        
        tin = floor(tin*mod)
        tin = ceil(tin*valueMod)
        
        mod = 1.0
        if self.stackCount:
            if not proto.stackDefault:
                mod = float(self.stackCount)
            else:
                mod = float(self.stackCount)/float(proto.stackDefault)
        tin = ceil(tin*mod)
        
        return long(tin)
    
    
    #this is called when database is recompiled, and when item is first brought into memory
    def refreshFromProto(self,forPet = False):
        self.reuseTimer = 0
        
        #create all the poop from the proto
        proto = self.itemProto
        
        self.spellProto = proto.spellProto
        self.classes = [(cl.classname,cl.level) for cl in proto.classes]
        if self.spellProto:
            for cl in self.spellProto.classes:
                self.classes.append((cl.classname,cl.level))
                
        self.level = proto.level
        if self.levelOverride:
            self.level = self.levelOverride
        
        if not forPet:
            self.penalty = 0
            self.canUse = False
            if self.character:
                self.setCharacter(self.character,False) #sets up some stuff
        
        penalty = 1.0 - self.penalty
        
        self.light = floor(proto.light*penalty)
        self.flags = proto.flags
        
        self.material = proto.material
        # fix borked counts, since we still have the item it doesn't need expunging
        if not self.stackCount:
            self.stackCount = 1
        
        #todo split off wpnDamage/wpnRate into actual columns for quality
        self.wpnDamage = ceil(proto.wpnDamage*penalty)
        self.wpnRate = ceil(proto.wpnRate+self.penalty*proto.wpnRate)
        self.wpnRange = ceil(proto.wpnRange*penalty)
        
        self.model = proto.model
        self.sndProfile = proto.sndProfile
        
        self.dmgType = 0
        if DAMAGELOOKUP.has_key(proto.skill):
            self.dmgType = DAMAGELOOKUP[proto.skill]
        
        self.wpnAmmunitionType = proto.wpnAmmunitionType
        
        self.projectile = proto.projectile
        self.speed = proto.speed
        
        self.weight = proto.weight
        self.desc = proto.desc
        self.effectDesc = proto.effectDesc
        self.armor = floor(proto.armor*penalty)
        
        self.skill = proto.skill
        
        if not self.penalty:
            self.spells = list(proto.spells)
        else:
            self.spells = []
        
        self.stats = []
        for st in proto.stats:
            self.stats.append((st.statname,st.value))
        
        if self.hasVariants:
            self.flags |= RPG_ITEM_ARTIFACT
            numVariants = self.numVariants()
            if numVariants:
                self.quality = RPG_QUALITY_EXCEPTIONAL
                if self.spellEnhanceLevel == 9999:	# hack
                    self.flags |= RPG_ITEM_ENCHANTED
                level = self.level+10
                self.worthIncreaseTin = level**5+500
                self.worthIncreaseTin*=(numVariants*2)+5
            elif self.spellEnhanceLevel == 9999:	# hack
                self.quality = RPG_QUALITY_CRUDDY
        
        mod = RPG_QUALITY_MODS[self.quality]
        #adjust for quality
        self.armor = floor(self.armor*mod)
        self.wpnDamage = floor(self.wpnDamage*mod)
        self.wpnRate = ceil(self.wpnRate+self.wpnRate*(1.0-mod))
        self.wpnRange = floor(self.wpnRange*mod)
        self.light = ceil(self.light*mod)
        
        self.wpnRaceBane = proto.wpnRaceBane
        self.wpnRaceBaneMod = proto.wpnRaceBaneMod
        
        self.wpnResistDebuff = proto.wpnResistDebuff
        self.wpnResistDebuffMod = proto.wpnResistDebuffMod
        
        self.repairMax = proto.repairMax
        
        if self.hasVariants:
            # Always apply enchantments if 'flag' is set.
            # Either to strip normal stats or to give special ones.
            if self.spellEnhanceLevel == 9999:
                from itemvariants import ApplyEnchantment
                ApplyEnchantment(self)
            elif numVariants:
                from itemvariants import ApplyVariants
                ApplyVariants(self)
        
        if self.quality == RPG_QUALITY_NORMAL:
            self.repairMax = floor(self.repairMax*.8)
        elif self.quality == RPG_QUALITY_CRUDDY:
            self.repairMax = floor(self.repairMax*.6)
        elif self.quality == RPG_QUALITY_SHODDY:
            self.repairMax = floor(self.repairMax*.7)
        elif self.quality == RPG_QUALITY_SUPERIOR:
            self.repairMax = floor(self.repairMax*.9)
        # otherwise exceptional, which is already set
        if self.flags & RPG_ITEM_INDESTRUCTIBLE:
            self.repairMax = 0
        elif proto.repairMax > 0 and not self.repairMax:
            self.repairMax = 1
        else:
            self.repairMax = int(self.repairMax)
        
        if self.repair > self.repairMax:
            self.repair = self.repairMax
        
        if penalty < 1.0:
            stats = []
            for st in self.stats:
                if st[1] < 0:
                    stats.append(st)
                else:
                    value = st[1]
                    if value > 1:
                        value = floor(value*penalty)
                    else:
                        value = value*penalty
                    
                    if value:
                        stats.append((st[0],value))
            
            self.stats = stats
        
        self.itemInfo.reset()




class ItemSetStat(Persistent):
    itemSetPower = ForeignKey('ItemSetPower')
    statname = StringCol()
    value = FloatCol()

class ItemSetSpell(Persistent):
    itemSetPower = ForeignKey('ItemSetPower')
    spellProto = ForeignKey('SpellProto')
    # only RPG_ITEM_TRIGGER_WORN, RPG_ITEM_TRIGGER_MELEE or RPG_ITEM_TRIGGER_DAMAGED allowed
    trigger = IntCol(default = RPG_ITEM_TRIGGER_WORN)
    frequency = IntCol(default = RPG_FREQ_ALWAYS) #freq always applies the effect when worn and never rechecks
    duration = IntCol(default=0)

class ItemSetRequirement(Persistent):
    itemSetPower = ForeignKey('ItemSetPower')
    name = StringCol(default = "")
    itemCount = IntCol(default = 1)
    countTest = IntCol(default = RPG_ITEMSET_TEST_GREATEREQUAL)
    
    def makeTest(self,count):
        if self.countTest == RPG_ITEMSET_TEST_GREATEREQUAL:
            if count >= self.itemCount:
                return True
        elif self.countTest == RPG_ITEMSET_TEST_EQUAL:
            if count == self.itemCount:
                return True
        else:
            if count <= self.itemCount:
                return True
        return False

class ItemSetPower(Persistent):
    name = StringCol(alternateID = True)
    
    harmful = BoolCol(default = False)
    
    requirementsInternal = MultipleJoin('ItemSetRequirement')
    statsInternal = MultipleJoin('ItemSetStat')
    # only RPG_ITEM_TRIGGER_WORN, RPG_ITEM_TRIGGER_MELEE or RPG_ITEM_TRIGGER_DAMAGED allowed
    spellsInternal = MultipleJoin('ItemSetSpell')
    
    #message when set power is activated
    message = StringCol(default = "")
    #sound when set power is activated
    sound = StringCol(default="")
    
    itemSetProtos = RelatedJoin("ItemSetProto")
    
    
    def _init(self,*args,**kw):
        Persistent._init(self,*args,**kw)
        self.requirements = self.requirementsInternal[:]
        self.stats = self.statsInternal[:]
        self.spells = self.spellsInternal[:]
    
    def removeMods(self,mob):
        for stat in self.stats:
            if stat.statname == "haste":
                mob.itemSetHastes.remove(stat.value)
                mob.calcItemHaste()
            elif stat.statname in RPG_RESISTSTATS:
                try:                    
                    mob.resists[RPG_RESISTLOOKUP[stat.statname]] -= stat.value
                except KeyError:
                    mob.resists[RPG_RESISTLOOKUP[stat.statname]] = 0
            else:
                setattr(mob,stat.statname,getattr(mob,stat.statname)-stat.value)
        for spell in self.spells:
            if mob.itemSetSpells.has_key(spell.trigger):
                mob.itemSetSpells[spell.trigger].remove(spell)
    
    def updateDerived(self,mob):
        for stat in self.stats:
            if stat.statname in RPG_DERIVEDSTATS:
                setattr(mob,stat.statname,getattr(mob,stat.statname)+stat.value)
    
    def checkAndApply(self,mob,contributions,exists,printMessage=True):
        for req in self.requirements:
            if not contributions.has_key(req.name):
                return False
            if self.harmful:
                if not req.makeTest(contributions[req.name][0]):
                    return False
            # if not harmful check only item count without penalties
            elif not req.makeTest(contributions[req.name][1]):
                return False
        
        if exists:
            return True
        
        # passed all tests, start applying effects
        if mob.simObject and mob.player and printMessage:
            if self.message:
                mob.player.sendGameText(RPG_MSG_GAME_YELLOW,"%s\\n"%(self.message),mob)
            if self.sound:
                mob.playSound(self.sound)
        for stat in self.stats:
            if stat.statname == "haste":
                mob.itemSetHastes.append(stat.value)
                mob.calcItemHaste()
            elif stat.statname in RPG_RESISTSTATS:
                try:                    
                    mob.resists[RPG_RESISTLOOKUP[stat.statname]] += stat.value
                except KeyError:
                    mob.resists[RPG_RESISTLOOKUP[stat.statname]] = stat.value
            else:
                setattr(mob,stat.statname,getattr(mob,stat.statname)+stat.value)
        for spell in self.spells:
            if mob.itemSetSpells.has_key(spell.trigger):
                mob.itemSetSpells[spell.trigger].append(spell)
            else:
                mob.itemSetSpells[spell.trigger] = [spell]
        return True

class ItemSetProto(Persistent):
    name = StringCol(alternateID = True)
    
    powersInternal = RelatedJoin('ItemSetPower')
    
    def _init(self,*args,**kw):
        Persistent._init(self, *args, **kw)
        self.powers = self.powersInternal[:]
    
    def updateDerived(self,mob):
        for power in self.powers:
            if power in mob.equipMods["%s"%self.name]:
                power.updateDerived(mob)
    
    def checkAndApply(self,mob,printMessage=True):
        thisSet = mob.itemSets[self]
        if thisSet[1]:    # something changed
            thisSet[1] = False
            
            if not len(thisSet[0]):
                for power in mob.equipMods["%s"%self.name].iterkeys():
                    power.removeMods(mob)
                del mob.equipMods["%s"%self.name]
                return
            
            if not mob.equipMods.has_key("%s"%self.name):
                mob.equipMods["%s"%self.name] = []
            for power in self.powers:
                exists = power in mob.equipMods["%s"%self.name]
                if power.checkAndApply(mob,thisSet[0],exists,printMessage):
                    if not exists:
                        mob.equipMods["%s"%self.name].append(power)
                elif exists:
                    power.removeMods(mob)
                    mob.equipMods["%s"%self.name].remove(power)
            return
    
    
    
