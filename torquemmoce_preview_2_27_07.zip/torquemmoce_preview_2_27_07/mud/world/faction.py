
from sqlobject import *
from defines import *
from mud.common.persistent import Persistent

class FactionRelation(Persistent):
    faction = ForeignKey('Faction')
    otherFaction = ForeignKey('Faction')
    relation = IntCol(default=RPG_FACTION_UNDECIDED)
    
class Faction(Persistent):
    name = StringCol(alternateID = True)
    level = IntCol(default=1) #level scalar for faction (relative political power)    
    realm  = IntCol(default=-1)
    relations = MultipleJoin('FactionRelation')
    attackMsg = StringCol(default = "")
    enemyMsg = StringCol(default = "")
    spawns = RelatedJoin('Spawn')
    


KOS = {}

def InitKOS():
    from spawn import Spawn
    spawns = list(Spawn.select())
    for s in spawns:
        kos = KOS[s.name]=[]
        for f in s.factions:
            for r in f.relations:
                if r.relation < RPG_FACTION_DISLIKED:
                    for os in r.otherFaction.spawns:
                        if os.name not in kos:
                            kos.append(os.name)
                            
                    
                    
                
        