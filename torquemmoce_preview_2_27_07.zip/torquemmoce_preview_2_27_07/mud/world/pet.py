
from defines import *

def PetCmdAttack(pet,target):
    
    player = pet.master.player
    
    if target == pet:
        if player:
            player.sendGameText(RPG_MSG_GAME_PET_SPEECH,r'Your pet says, \"I will not attack myself master!\"\n')
        return

    if target == pet.master:
        if player:
            player.sendGameText(RPG_MSG_GAME_PET_SPEECH,r'Your pet says, \"I will not attack you master!\"\n')
        return
    
    if target:
        pet.addAggro(target,10)
        pet.zone.setTarget(pet,target)
        if player:
            player.sendGameText(RPG_MSG_GAME_PET_SPEECH,r'Your pet says, \"Attacking master!!!\"\n')

    else:
        if player:
            player.sendGameText(RPG_MSG_GAME_PET_SPEECH,r'Your pet says, \"Are you seeing things again master?\"\n')

        pet.zone.setTarget(pet,None)
        
def PetCmdStandDown(pet):
    player = pet.master.player
    
    pet.aggro = {}
    pet.zone.setTarget(pet,None)
    
    if player:
        player.sendGameText(RPG_MSG_GAME_PET_SPEECH,r'Your pet says, \"Standing down master.\"\n')


def PetCmdStay(pet):
    player = pet.master.player
    mind = pet.zone.simAvatar.mind
    so = pet.simObject
    mind.callRemote("setHomeTransform",so.id,so.position,so.rotation)
    pet.zone.setFollowTarget(pet,None)
    
    if player:
        player.sendGameText(RPG_MSG_GAME_PET_SPEECH,r'Your pet says, \"I will stay here master.\"\n')

            
def PetCmdFollowMe(pet):
    player = pet.master.player
    if pet.followTarget != pet.master:
        pet.zone.setFollowTarget(pet,pet.master)
        
    if player:
        player.sendGameText(RPG_MSG_GAME_PET_SPEECH,r'Your pet says, \"I will follow you master.\"\n')
    
    
    
def PetCmdDismiss(pet):
    player = pet.master.player
    if player:
        player.sendGameText(RPG_MSG_GAME_PET_SPEECH,r'Your pet says, \"Goodbye master.  You know where to find me.\"\n')
        
    pet.zone.removeMob(pet)
    
    