from twisted.internet import reactor
from sqlobject import *
from mud.common.persistent import Persistent
import spawn
from defines import *
from core import *
from mud.world.mob import Mob
import copy

import gc
import time


from random import choice
import string
import traceback
def GenPasswd(length=8, chars=string.letters + string.digits):
    return ''.join([choice(chars) for i in xrange(length)])

from mud.world.weather import Weather

class ZoneInstance:
    instanceCounter = 0
    def __init__(self,zone, ip, port, zonepassword,owningPlayer):
        self.zone = zone
        self.name = zone.name+"_INSTANCE_%i"%ZoneInstance.instanceCounter
        self.xpMod = zone.xpMod
        ZoneInstance.instanceCounter+=1   
        
        self.status = "Launching"
        
        if owningPlayer:
            self.dedicated = False
        else:
            self.dedicated = True
            
        self.owningPlayer = owningPlayer
        
        self.ip = ip
        self.port = port
        self.password = zonepassword
        
        self.time = None
        
        self.simAvatar = None
    
        self.players = []
        #simObject -> mob
        self.mobLookup = {}
        self.spawnpoints = None
        self.live = False
        
        self.activeMobs = []
        self.spawnedMobs = []
        
        #queued players, which have been submitted before zone went live
        self.playerQueue = []
        #publicName -> password (temporary zone connection passwords)
        self.playerPasswords = {}
        
        self.tickRootInfo = None
        #self.charInfoTick()
        self.rootInfoTick()
        
        self.weather = Weather(self.zone)
        
        #tuples of (x,y,z)
        self.bindpoints = []
        
        self.projectiles = {}
        
        self.dialogTriggers = []
        
        self.dynamic = False
        self.timeOut = -1
        self.stopped = False
        
        self.spawnpoints =[]
        
        self.battles = []
        
        self.paused = False
        
        self.charTickCounter = 4
        
        self.pid = None
        self.populatorGroups = {}
        
        self.spawnIndex = 0
        self.allSpawnsTicked = False
        
    def failure(self,error):
        print error
        
    #THE PLAYER IS OFFICIALLY IN THE ZONE AT THIS POINT... whew
    def playerEnterZone(self,player):

        
        
        if not player.world:
            print "WARNING: Player Entering Zone not attached to world... probably lost connection to world while zoning in"
            return
        
        player.zone.simAvatar.setDisplayName(player)
        
        # announce to other players
        if player.enteringWorld:
            player.enteringWorld = False
            for p in self.players:
                p.sendGameText(RPG_MSG_GAME_BLUE,r'%s has entered the zone.\n'%player.charName)
            for p in player.world.activePlayers:
                if p == player:
                    continue
                if p.enteringWorld:
                    continue
                if p in self.players: #already told that we entered zone
                    continue
                p.sendGameText(RPG_MSG_GAME_BLUE,r'%s has entered the world.\n'%player.charName)
        else:
            pmob = player.curChar.mob
            for p in self.players:
                if AllowHarmful(pmob,p.curChar.mob):
                    continue
                p.sendGameText(RPG_MSG_GAME_BLUE,r'%s has entered the zone.\n'%player.charName)
        
        
        #we use queue to keep dynamic zones alive
        nqueue = []
        for p in self.playerQueue:
            if p[0]==player:
                continue
            nqueue.append(p)
            
        self.playerQueue = nqueue
        
        self.players.append(player)
        
        for c in player.party.members:
            self.mobLookup[player.simObject]=c.mob #only one entry in lookup for player mobs
            c.mob.simObject = player.simObject
            self.activeMobs.append(c.mob)
            
            if c.dead:
                self.detachMob(c.mob)
            
        if CoreSettings.MAXPARTY == 1:
            player.world.clearDeathMarker(player)
            player.world.setDeathMarker(player,player.party.members[0])
        if CoreSettings.PGSERVER:
            player.world.sendCharacterInfo(player)
    
    def connectPlayer(self,result,player,zconnect):
        #XXX fixme, we are passing the avatar name (fantasyName) here to client
        #and client is responsible for passing this to simulation zone
        #client shouldn't be responsible for this... 
        player.mind.callRemote("connect",zconnect,player.fantasyName)
        
    def connectQueuedPlayers(self,result):
        for p in self.playerQueue:
            self.connectPlayer(None,p[0],p[1])
        self.playerQueue = []
        
        
    def submitPlayer(self,player,zconnect):
        player.zone = self
        pw = GenPasswd()
        self.playerPasswords[player.publicName]=pw
        zconnect.playerZoneConnectPassword = pw
        if not self.live:
            self.playerQueue.append((player,zconnect))
            if zconnect.ip == '127.0.0.1' and CoreSettings.SINGLEPLAYER:
                #tell client to kick off zone
                player.mind.callRemote('createServer',zconnect)
        else:
            self.playerQueue.append((player,zconnect))
            d = self.simAvatar.setPlayerPasswords(self.playerPasswords)
            #only connect once player passwords are set
            d.addCallback(self.connectPlayer,player,zconnect)
            
    def start(self):
        if not self.simAvatar:
            traceback.print_stack()
            print "AssertionError: simAvatar doesn't exist!"
            return
        self.live = True
        d = self.simAvatar.setPlayerPasswords(self.playerPasswords)
        d.addCallback(self.connectQueuedPlayers)
        
    def stop(self):
        if self.stopped:
            return
        self.stopped = True
        
        print "Stopping Zone"
        self.weather.cancel()
        
        try:
            self.tickRootInfo.cancel()
        except:
            pass
        mlist = copy.copy(self.activeMobs)
        for mob in mlist:
            if not mob.master:  #master will remove
                self.removeMob(mob)
        
        self.simAvatar.stop()
        
    def createSpawnpoints(self,spinfos):
        self.spawnpoints =[]
        for si in spinfos:
            self.spawnpoints.append(spawn.Spawnpoint(self,si.transform,si.group,si.wanderGroup))
            
    def mobBotSpawned(self,simObject,mob):
        
        self.mobLookup[simObject]=mob
        mob.simObject = simObject
        self.activeMobs.append(mob)
        self.spawnedMobs.remove(mob)
        
        mob.spawned()        
        
    def spawnMob(self,spawn,transform,wanderGroup,master = None,sizemod = 1.0):
        #create a bot
        mob = Mob(spawn,self,None,None,master,sizemod)
        self.spawnedMobs.append(mob)
        self.simAvatar.spawnBot(spawn,transform,wanderGroup,mob.mobInfo).addCallback(self.mobBotSpawned,mob)
        self.world.cpuSpawn-=1
        return mob
        
    def tick(self,spawnZone=None):
        #import time
        #tm = time.time()
        self.charTickCounter-=1
        
        try:
        

            if self.world.paused and not self.paused:
                self.paused = True
                self.simAvatar.pause(True)
            if not self.world.paused and self.paused:
                self.simAvatar.pause(False)
                self.paused = False
                
            if self.paused:
                if not self.charTickCounter:
                    self.charTickCounter = 5
                return
            
            
            if not self.allSpawnsTicked and self.spawnpoints and len(self.spawnpoints):                
                self.world.cpuSpawn = 1000000
                self.world.cpuDespawn = 1000000
                self.allSpawnsTicked = True
                for s in self.spawnpoints:
                    try:
                        s.tick()
                    except:
                        traceback.print_exc()
                self.world.cpuSpawn = 0
                self.world.cpuDespawn = 0
                
                
            if spawnZone == self and self.allSpawnsTicked:
                if self.spawnpoints and len(self.spawnpoints)>0:
                    start = self.spawnIndex
                    while self.world.cpuSpawn>0 and self.world.cpuDespawn>0:
                        s = self.spawnpoints[self.spawnIndex]
                            
                        go = True
                        if len(s.activeMobs) and s.activeInfo:
                            if s.activeInfo.startTime == -1 or s.activeInfo.endTime == -1:
                                go = False
                        if go:
                            try:
                                s.tick()                        
                            except:
                                traceback.print_exc()
                        
                        self.spawnIndex+=1
                        if self.spawnIndex == len(self.spawnpoints):
                            self.spawnIndex = 0
                        if start == self.spawnIndex:
                            break
            
            
            for mob in self.mobLookup.itervalues():
                if mob.detached and mob.kingTimer > 0:
                    mob.kingTimer -= 3
            
            #mobs can get detached so use copy of list
            
            for b in self.battles[:]:
                b.tick()
            
            if len(self.players):
                mlist = self.activeMobs[:]
                for mob in mlist: 
                    try:
                        if not mob.detached and not mob.simObject.simZombie:                            
                            mob.tick()
                    except:
                        traceback.print_exc()
                        
                
            if self.weather.dirty and self.simAvatar:
                self.simAvatar.sendWeather(self.weather)
                self.weather.dirty = False
                
            for p in self.players:
                try:
                    p.tick()
                    dirty  = p.cinfoDirty
                    if not self.charTickCounter:
                        if not p.party or not p.party.members or not len(p.party.members):
                            continue
                        for c in p.party.members:
                            if dirty:
                                c.charInfo.refresh()
                            else:
                                c.charInfo.refreshLite(True)
                                

                except:
                    traceback.print_exc()
            
                    
                
        except:
            traceback.print_exc()
            
        
        if not self.charTickCounter:
            self.charTickCounter = 5
            
        
            
    def rootInfoTick(self):
        #import time
        #tm=time.time()
       
        
        for p in self.players:
            try:
                p.rootInfo.tick()
            except:
                traceback.print_exc()
        
        t = .5    
        if self.zone.world.singlePlayer:
            t = .5
        
        self.tickRootInfo = reactor.callLater(t,self.rootInfoTick)
        
        
        
    def setTarget(self,mob,target):
        if target and target.detached:
            target = None
            
        if target == mob.target:
            return
            
        if target and mob.detached:
            return

        mob.setTarget(target)
        
        #tell simulation side for pathfinding
        if not mob.player:
            if target:
                self.simAvatar.setTarget(mob.simObject,target.simObject)
            else:                
                if mob.detached:
                    self.simAvatar.immobilize(mob.simObject)
                else:
                    #when we clear the target we are telling mob to go spawnlocation
                    self.simAvatar.clearTarget(mob.simObject)
                    
        else:
            index = 0
            for c in mob.player.party.members:
                if c.mob == mob:
                    break
                index+=1
            if target:
                self.simAvatar.mind.callRemote("setSelection",mob.simObject.id,target.simObject.id,index)
            else:
                self.simAvatar.mind.callRemote("setSelection",mob.simObject.id,0,index)
                
    def setFollowTarget(self,mob,target):
        if target and target.detached:
            target = None
        if target and mob.detached:
            return

        if mob.player:
            return #nope!
            
        mob.setFollowTarget(target)
        
        #tell simulation side for pathfinding
        if target:
            self.simAvatar.setFollowTarget(mob.simObject,target.simObject)
        else:
            self.simAvatar.setFollowTarget(mob.simObject,None)
                    

            
    def setTargetById(self,mob,mobId):
        if mob.detached:
            return
        if mobId == 0:
            self.setTarget(mob,None)
        for m in self.activeMobs:
            if mobId == m.id:
                self.setTarget(mob,m)
    #player gui selecting
    def select(self,srcSimObject,tgtSimObject,charIndex,doubleClick):
        
        mob = self.mobLookup[srcSimObject]
        if not mob.player:
            traceback.print_stack()
            print "AssertionError: mob is no player mob!"
            return
        mob = mob.player.party.members[charIndex].mob
        
        if mob.detached:
            mob.player.sendGameText(RPG_MSG_GAME_DENIED,r'%s is no longer of this world and cannot interact with it.\n'%mob.name)

        target = self.mobLookup[tgtSimObject]
        if target.detached and not target.player:
            
            try:
                if target.kingKiller and target.kingTimer>0:
                    cmobs = []
                    for m in target.kingKiller.player.party.members:
                        cmobs.append(m.mob)
                        
                    for a in target.kingKiller.player.alliance.members:
                        for m in a.party.members:
                            cmobs.append(m.mob)
                        
                    if mob not in cmobs:
                        mob.player.sendGameText(RPG_MSG_GAME_LOOT,r'You cannot loot this corpse at this time.\n')
                        return
            except:
                traceback.print_exc()
                
            #monsters get flesh and blood, bad place for this
            
            if target.genLoot and target.loot:
                target.genLoot = False
                if not target.loot.generateCorpseLoot():
                    target.loot = None
            
            if mob.player.monster and target.spawn.race not in ("Undead","Golem"):
                if target.loot and not target.loot.fleshDone and len(target.loot.items)<16:
                    from item import ItemProto
                    fproto = ItemProto.byName("Flesh and Blood")
                    flesh = fproto.createInstance()
                    flesh.slot = -1
                    target.loot.items.append(flesh)
                    target.loot.fleshDone = True

            #currently the only reason mobs get detached is due to death
            if not target.loot or not len(target.loot.items):
                if target.loot:
                    target.loot.giveMoney(mob.player)
                mob.player.sendGameText(RPG_MSG_GAME_LOOT,r'The corpse crumbles to dust!\n')
                self.removeMob(target)
                return
            if target.master and target.master.player:
                mob.player.sendGameText(RPG_MSG_GAME_LOOT,r'You cannot loot player pets.\n')
                return
            if target.looter and target.looter != mob.player:
                mob.player.sendGameText(RPG_MSG_GAME_LOOT,r'Someone is already looting the corpse.\n')
                return
            elif target.looter == mob.player:
                return #no reloot
                    
                        
            
            #end current looting
            if mob.player.looting:
                mob.player.looting.looter = None
                mob.player.looting = None
                
            #loot!
            target.looter = mob.player
            mob.player.looting = target
            loot={}
            x = 0
            for item in target.loot.items:
                loot[x]=item.itemInfo
                x+=1
                
            target.loot.giveMoney(mob.player)
                
            mob.player.mind.callRemote("setLoot",loot)
                
            return False
        
        if target.player:
            #find first attached party member
            for c in target.player.party.members:
                if not c.dead:
                    target = c.mob
                    break
        
        self.setTarget(mob,target)
        if doubleClick:
            #holy cow
            mob.player.avatar.perspective_doCommand("INTERACT",[mob.player.curChar.mob.charIndex])
        #send player mob's id for mouse link
        mob.player.mind.callRemote("mouseSelect",charIndex,target.id)
        return True
        

    #mob reattaching (player death and rebirth)
    def reattachMob(self,mob):
        if not mob.detached:
            traceback.print_stack()
            print "AssertionError: mob is not detached!"
            return
        mob.detached = False
        self.activeMobs.append(mob)
    
    
    #mob detaching
    def detachMob(self,mob):
        if mob.detached:
            return
        mob.detachSelf()
        if mob in self.activeMobs:
            self.activeMobs.remove(mob)
        for m in self.activeMobs:
            m.detachMob(mob)
            
        if mob.interacting:
            mob.interacting.endInteraction()
            
        mob.processesPending = []
        mob.processesIn = []
        mob.processesOut = []
        self.setTarget(mob,None)
        if not mob.player:
            mob.setFollowTarget(None)
            if not self.stopped:
                self.simAvatar.setFollowTarget(mob.simObject,None)
    
    #mob removal
    def removeMob(self,mob,despawnTime=0):
        if mob.master and mob.master.player:
            mob.master.character.petHealthBackup = mob.health
            mob.master.character.petHealthTimer = int(time.time())
        mob.kingKiller = None
        if mob.corpseRemoval:
            mob.corpseRemoval.cancel()
            mob.corpseRemoval = None
        if mob.spawnpoint:
            mob.spawnpoint.removeMob(despawnTime)
        if not mob.detached:
            self.detachMob(mob)
        if mob.looter:
            mob.looter.looting = None
            try:
                mob.looter.mind.callRemote("setLoot",{})
            except:
                pass
        if mob.loot:
            mob.loot.mob = None
            for item in mob.loot.items:
                item.destroySelf()
        if not mob.player:
            try:
                self.simAvatar.deleteObject(mob.simObject)
            except:
                pass
            if self.mobLookup.has_key(mob.simObject):
                del self.mobLookup[mob.simObject]
                
        mob.simObject = None
        self.world.cpuDespawn-=1
            
        
    def removePlayer(self,player):
        #todo, fixup for queued but not in zone, etc
        if player in self.players:
            self.players.remove(player)
        for c in player.party.members:
            if self.mobLookup.has_key(c.mob.simObject):
                del self.mobLookup[c.mob.simObject]

            self.detachMob(c.mob)
            self.removeMob(c.mob)
            c.mob.character=None
            c.mob.player=None
            c.mob=None
        
        if self.simAvatar:
            self.simAvatar.removePlayer(player.simObject)
        player.simObject = None
        
    def playerRespawned(self,result,args):
        player = args[0]
        for c in player.party.members:
            if not c.dead and c.mob.detached:
                self.reattachMob(c.mob)
        
    def respawnPlayer(self,player,transform=None):
        self.simAvatar.respawnPlayer(player,transform).addCallback(self.playerRespawned,(player,))
        
        
    def projectileCollision(self,pid,hitObj,hitPos):
        if self.mobLookup.has_key(hitObj):
            proj = self.projectiles[pid]
            proj.dst = self.mobLookup[hitObj]
            proj.onCollision(hitPos)
            
    def onImpact(self,simObject,velocity):
        mob = self.mobLookup.get(simObject,None)
        if mob:
            if not mob.player: #only players
                traceback.print_stack()
                print "AssertionError: mob is no player mob!"
                return
            if mob.player:
                for c in mob.player.party.members:
                    c.mob.onImpact(velocity)
                
            
        
            
        #del self.projectiles[pid] (will be called on simserver projectile delete)
    def deleteProjectile(self,pid):
        del self.projectiles[pid]
        
    def launchProjectile(self,p):
        self.projectiles[p.id]=p
        self.simAvatar.launchProjectile(p)
        
    #dialog triggers
    def setDialogTriggers(self,tinfos):
        
        self.dialogTriggers = []
        from dialog import DialogTrigger
        for t in tinfos:
            self.dialogTriggers.append(DialogTrigger(t))
            
    def kickPlayer(self,player):
        self.simAvatar.kickPlayer(player) 
        
    def setDeathMarker(self,publicName,charName,realm,pos,rot):        
        self.simAvatar.setDeathMarker(publicName,charName,realm,pos,rot)
    
    def clearDeathMarker(self,publicName):
        self.simAvatar.clearDeathMarker(publicName)
    
        
class ZoneLink(Persistent):
    name = StringCol(alternateID = True) 
    dstZoneName = StringCol() 
    dstZoneTransform = StringCol() 

class TempZoneLink:
    def __init__(self,dstZoneName,dstZoneTransform):
        self.dstZoneName = dstZoneName
        self.dstZoneTransform = dstZoneTransform
    
        

class Zone(Persistent):
    name = StringCol(alternateID=True)
    niceName = StringCol()
    missionFile = StringCol()
    climate = IntCol(default = RPG_CLIMATE_TEMPERATE)
    xpMod = FloatCol(default=1.0)
    aggroMod = FloatCol(default = 1.0)
    scaleLimit = FloatCol(default=20.0)
    
    immTransform = StringCol(default="0 0 0 1 0 0 0")
    
    #add src and version info!
    #contentInfo = ForeignKey('ContentInfo')
    allowGuest = BoolCol(default=False)
    spawnGroups = MultipleJoin('SpawnGroup')
    world = ForeignKey('World')
    
    
   
