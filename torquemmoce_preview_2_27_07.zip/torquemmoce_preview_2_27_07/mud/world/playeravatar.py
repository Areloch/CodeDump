
from mud.common.avatar import Avatar
from mud.world.item import ItemInstance
from mud.world.player import Player
from mud.world.character import Character,CharacterSpell,CharacterVaultItem
from mud.world.theworld import World
from mud.world.spawn import Spawn,SpawnResistance,SpawnStat
from mud.world.party import Party
from mud.world.spell import SpellClass,Spell
from mud.world.command import DoCommand
from mud.world.repair import RepairItem,RepairAll,RepairParty
from mud.world.zone import Zone
from mud.world.messages import GameMessage
from defines import *
from core import *
from sqlobject import *
from twisted.internet import reactor
from alliance import Alliance
from traceback import print_stack,print_exc
from time import time
from cPickle import dumps,loads
from base64 import encodestring,decodestring
from mud.worldserver.charutil import ExtractPlayer,InstallCharacterBuffer
from mud.gamesettings import GAMEROOT


#for jelly
from mud.world.shared.worlddata import CharacterInfo,ZoneConnectionInfo
from mud.world.shared.playdata import RootInfo
from mud.world.shared.models import GetModelInfo

#also query
class PlayerAvatar(Avatar):
    
    def __init__(self,username,role,mind):
        Avatar.__init__(self,username,role,mind)
        self.mind = mind
        self.username = username
        self.player = Player.byPublicName(username)
        self.player.role = role
        self.player.reset()
        self.player.mind = mind
        self.world = World.byName("TheWorld")
        self.player.world = self.world
        self.syncTime()
        self.player.avatar = self

        self.world.playerJoinWorld(self.player)
        
        self.charInfos = []
              
        
        
    def logout(self):
        if not self.player:
            return
        
        player = self.player
        
        player.avatar = None
        if player.loggingOut:
            return
        if self.tickSyncTime:
            try:
                self.tickSyncTime.cancel()
            except:
                pass
            self.tickSyncTime = None
        
        player.loggingOut = True
        player.logout()
        player.loggingOut = False    
        
        self.player = None
        
        
            
            
    def syncTime(self):
        self.mind.callRemote("syncTime",self.world.time.hour,self.world.time.minute)
        self.tickSyncTime = reactor.callLater(60,self.syncTime)
        

    def gotCheckCharacterName(self,result,newchar):
        if not result:
            return self.newCharacter(newchar)
        return (-1,"That name is taken, please choose another")
        
    
    def gotCheckCharacterNameError(self,result):
        return (-1,"There was an error creating this character")
        
    def perspective_newCharacter(self,newchar):
        from cserveravatar import AVATAR
        
        if RPG_BUILD_DEMO and not self.player.premium:
            nc = 0
            names = []
            if self.player.cserverInfos:
                for cinfo in self.player.cserverInfos:
                    if cinfo.realm != RPG_REALM_MONSTER:
                        nc+=1
                        names.append(cinfo.name)
                
                
            for c in self.player.characters:
                if c.spawn.realm != RPG_REALM_MONSTER and c.spawn.name not in names:
                    nc+=1
            if nc>=3:
                return (-1,"You may have 3 characters in the Minions of Mirth Free Version.  The Premium Version allows up to 24 characters.  Please see www.prairiegames.com for ordering information.",None)

        if AVATAR:
            d = AVATAR.mind.callRemote("checkCharacterName",newchar.name)
            d.addCallback(self.gotCheckCharacterName,newchar)
            d.addErrback(self.gotCheckCharacterNameError)
            return d
        return self.newCharacter(newchar)
    
    
    def newCharacter(self,newchar):
        if not self.player.world.singlePlayer:
            nc = 0
            if self.player.cserverInfos:
                nc = len(self.player.cserverInfos)

            for c in self.player.characters:
                if c.spawn.realm != RPG_REALM_MONSTER:
                    nc+=1
            if nc >=24:
                return (-1,"The maximum characters on this server is 24.",None)
                
            
        #does character already exist?
        try:
            char = Character.byName(newchar.name)
        except:
            pass
        else:
            return (-1,"That character name is taken.",None)
            
        try:
            s = Spawn.byName(newchar.name)
        except:
            pass
        else:
            return (-1,"That character name is invalid.",None)
        
        #create the spawn, todo check cheating!
        
        size,model,tex,animation = GetModelInfo(newchar.race,newchar.sex,newchar.look)
        
        spawn = Spawn(name=newchar.name,race=newchar.race,pclassInternal = newchar.klass,plevel = 1,model=model,scale=size,radius=2,vocalSet="C")
        spawn.realm = newchar.realm
        
        spawn.sex = newchar.sex

        #fix this BS, score should be coming from world server and only adj being sent
        spawn.strBase = newchar.scores['STR'] + newchar.adjs['STR']
        spawn.dexBase = newchar.scores['DEX'] + newchar.adjs['DEX'] 
        spawn.refBase = newchar.scores['REF'] + newchar.adjs['REF'] 
        spawn.agiBase = newchar.scores['AGI'] + newchar.adjs['AGI'] 
        spawn.wisBase = newchar.scores['WIS'] + newchar.adjs['WIS'] 
        spawn.bdyBase = newchar.scores['BDY'] + newchar.adjs['BDY'] 
        spawn.mndBase = newchar.scores['MND'] + newchar.adjs['MND'] 
        spawn.mysBase = newchar.scores['MYS'] + newchar.adjs['MYS'] 

        
        
        char = Character(player=self.player,name=newchar.name,spawn=spawn,portraitPic = newchar.portraitPic)
        spawn.character = char
        spawn.playerName = self.player.publicName
                    
        if newchar.sex == 'Male':
            ret = (0,"%s has been created.  He awaits your command!"%newchar.name)
        else:
            ret = (0,"%s has been created.  She awaits your command!"%newchar.name)
            
        char.addStartingGear()
        char.backupItems()
        
        #send off the character
        from cserveravatar import AVATAR
        if AVATAR:
            publicName,pbuffer,cbuffer,cvalues = ExtractPlayer(self.player.publicName,self.player.id,char.id,False)                
            pbuffer = encodestring(dumps(pbuffer, 2))
            if cbuffer:
                cbuffer = encodestring(dumps(cbuffer, 2))

            AVATAR.mind.callRemote("savePlayerBuffer",publicName,pbuffer,cbuffer,cvalues)

        return ret


    def gotCheckMonsterName(self,result,mname,mspawn):
        if not result:
            return self.newMonster(mname,mspawn)
        return (-1,"That name is taken, please chose another")
        
    
    def gotCheckMonsterNameError(self,result):
        return (-1,"There was an error creating this monster")
    
    
    def perspective_newMonster(self,mname,mspawn):
        from cserveravatar import AVATAR
        
        if RPG_BUILD_DEMO and not self.player.premium:
            nc = 0
            names = []
            if self.player.cserverInfos:
                for cinfo in self.player.cserverInfos:
                    if cinfo.realm == RPG_REALM_MONSTER:
                        nc+=1
                        names.append(cinfo.name)

            for c in self.player.characters:
                if c.spawn.realm == RPG_REALM_MONSTER and c.spawn.name not in names:
                    nc+=1
            if nc >=1:
                return (-1,"You may have 1 monster in the Minions of Mirth Free Version.  The Premium Version allows up to 10 monsters.  Please see www.prairiegames.com for ordering information.",None)
            
        if RPG_BUILD_DEMO and not self.player.premium:
            try:
                src = Spawn.byName(mspawn)
            except:
                return (-1,"That's odd no spawn.",None)
            
            if src.plevel > 20:
                return (-1,"You may create monsters greater than level 20 with the Minions of Mirth Premium Edition.  Please see www.prairiegames.com for ordering information.",None)
                    

        

        if AVATAR:
            
            level = 0
            if self.player.cserverInfos:
                for cinfo in self.player.cserverInfos:
                    if cinfo.levels[0] > level:
                        level = cinfo.levels[0]
                        
            for c in self.player.characters:
                if c.spawn.plevel > level:
                    level = c.spawn.level

            try:
                src = Spawn.byName(mspawn)
            except:
                return (-1,"That's odd no spawn.",None)
            
            if src.plevel > level:
                return (-1,"You must have a MoD or FoL character of level %i or higher to create this monster."%src.plevel,None)
            
            
            d = AVATAR.mind.callRemote("checkCharacterName",mname)
            d.addCallback(self.gotCheckMonsterName,mname,mspawn)
            d.addErrback(self.gotCheckMonsterNameError)
            return d
        return self.newMonster(mname,mspawn)

    def newMonster(self,mname,mspawn):
        #does character already exist?
        
        if not self.player.world.singlePlayer:
            nc = 0
            for c in self.player.characters:
                if c.spawn.realm == RPG_REALM_MONSTER:
                    nc+=1
                
            if nc >=10:
                return (-1,"The maximum monsters on this server is 10.",None)

        try:
            p = Player.byPublicName(mname)
        except:
            pass
        else:
            return (-1,"That character name is taken.",None)

        try:
            p = Player.byFantasyName(mname)
        except:
            pass
        else:
            return (-1,"That character name is taken.",None)


        try:
            char = Character.byName(mname)
        except:
            pass
        else:
            return (-1,"That character name is taken.",None)
            
        try:
            s = Spawn.byName(mname)
        except:
            pass
        else:
            return (-1,"That character name is invalid.",None)

        try:
            src = Spawn.byName(mspawn)
        except:
            return (-1,"That's odd no spawn.",None)

        spawn = Spawn(name=mname,pclassInternal = src.pclassInternal,plevel = 1,model="")
        for ncol in Spawn.sqlmeta._columns:
            if ncol.name != "id" and ncol.name!="name":
                setattr(spawn,ncol.name,getattr(src,ncol.name))
                
        spawn.difficultyMod = 1.0
                
        char = Character(player=self.player,name=mname,spawn=spawn,portraitPic = "p033")
        spawn.character = char
        spawn.playerName = self.player.publicName
        
        if spawn.sex == 'Male':
            ret = (0,"%s has been created.  He awaits your command!"%mname)
        elif spawn.sex == 'Female':
            ret = (0,"%s has been created.  She awaits your command!"%mname)
        else:
            ret = (0,"%s has been created.  It awaits your command!"%mname)
            
        #char.addMonsterGear()
        
        def SpellSort(a,b):
            if a.level < b.level:
                return -1
            if a.level > b.level:
                return 1
            return 0
        
        #spells
        qspells = list(SpellClass.select(OR(AND(SpellClass.q.classname == spawn.pclassInternal,SpellClass.q.level <= spawn.plevel),AND(SpellClass.q.classname == spawn.sclassInternal,SpellClass.q.level <= spawn.slevel),AND(SpellClass.q.classname == spawn.tclassInternal,SpellClass.q.level <= spawn.tlevel))))
        qspells.sort(SpellSort)
        sprotos = frozenset([sc.spellProto for sc in qspells])
        
        for slot,sproto in enumerate(sprotos):
            CharacterSpell(character=char,spellProto=sproto,slot=slot,recast=0)
        
        #just make sure    
        spawn.realm = RPG_REALM_MONSTER 
        spawn.template = mspawn
       
        pneeded = 0
        sneeded = 0
        tneeded = 0
        if spawn.plevel > 1:
            pneeded = (spawn.plevel-1)*(spawn.plevel-1)*100L*char.pxpMod
        if spawn.slevel > 1:
            sneeded = (spawn.slevel-1)*(spawn.slevel-1)*100L*char.sxpMod
        if spawn.tlevel > 1:
            tneeded = (spawn.tlevel-1)*(spawn.tlevel-1)*100L*char.txpMod
        
        char.xpPrimary = int(pneeded+1)
        char.xpSecondary = int(sneeded+1)
        char.xpTertiary = int(tneeded+1)
        
        base = spawn.plevel*10+100
        spawn.strBase = base
        spawn.dexBase = base
        spawn.refBase = base
        spawn.agiBase = base
        spawn.wisBase = base
        spawn.bdyBase = base
        spawn.mndBase = base
        spawn.mysBase = base
        
        char.advancementLevelPrimary = spawn.plevel
        char.advancementLevelSecondary = spawn.slevel 
        char.advancementLevelTertiary = spawn.tlevel

        
        #spawn stats and resists
        for resist in src.resists:
            SpawnResistance(spawn=spawn,resistType=resist.resistType,resistAmount=resist.resistAmount)
        for stat in src.spawnStats:
            s=SpawnStat(spawn=spawn,statname=stat.statname,value=stat.value)
            spawn.spawnStats.append(s)

        #send off the character
        from cserveravatar import AVATAR
        if AVATAR:
            publicName,pbuffer,cbuffer,cvalues = ExtractPlayer(self.player.publicName,self.player.id,char.id,False)                
            pbuffer = encodestring(dumps(pbuffer, 2))
            if cbuffer:
                cbuffer = encodestring(dumps(cbuffer, 2))
            AVATAR.mind.callRemote("savePlayerBuffer",publicName,pbuffer,cbuffer,cvalues)

        
        return ret       
    
    def gotDeleteCharacter(self,result):
        if result == False:
            return (-1,"There was an error deleting this character")
        
        return (0,"%s has been deleted."%result)
        
    def gotDeleteCharacterError(self,result):
        return (-1,"There was an error deleting this character")
        
        
    def perspective_deleteCharacter(self,cname):
        from cserveravatar import AVATAR
        if not AVATAR:
            #does character already exist?
            try:
                char = Character.byName(cname)
            except:
                return (-1,"No character named %s."%cname)
                
            if char.player != self.player:
                return (-1,"Hack attempt!")
            
            char.destroySelf()
    
            return (0,"%s has been deleted."%cname)
        else:
            try:
                char = Character.byName(cname)
                if char.player != self.player:
                    return (-1,"There was an error deleting %s"%cname)
                char.destroySelf()
            except:
                pass
                    
            self.player.cserverInfos = [n for n in self.player.cserverInfos if n.name != cname]
                
            try:
                d = AVATAR.mind.callRemote("deleteCharacter",self.player.publicName,cname)
                d.addCallback(self.gotDeleteCharacter)
                d.addErrback(self.gotDeleteCharacterError)
                return d
            except:
                return (-1,"There was an error deleting %s"%cname)
                

    def gotCharacterInfos(self,result):
        cinfos = []
        mspawns = []
        for ms in self.player.monsterSpawns:
            mspawns.append(ms.spawn)

        names = []
        for cname,cvalues in result.iteritems():
            names.append(cname)
            name,race,pclass,sclass,tclass,plevel,slevel,tlevel,realm,rename = cvalues
            cinfo = CharacterInfo()
            cinfo.status = "Alive"
            cinfo.name = str(cname)
            cinfo.race = str(race)
            cinfo.realm = realm
            cinfo.klasses.append(str(pclass))
            cinfo.levels.append(plevel)
            cinfo.newCharacter = False
            cinfo.rename = rename
            cinfos.append(cinfo)
            
        self.player.cserverInfos  = cinfos[:]
  
        #any that we have made on the server (new character)
        for c in self.player.characters:
            if c.name not in names:
                cinfo = CharacterInfo(c)
                cinto.newCharacter = True
                cinfos.append(cinfo)

        self.charInfos = cinfos
        return cinfos,mspawns,1
    
    def gotRenameCheckCharacterName(self,result,c,newname):
        if result==0:
            c.rename = 0
            c.name = newname
            return (0,"Character renamed")
        return (-1,"There was a problem renaming this character.  It's possible that the name is taken.  Please try another name or try again later.")
        
    
    def gotRenameCheckCharacterNameError(self,result):
        return (-1,"There was an error renaming this character.")

       
    def perspective_renameCharacter(self,oldname,newname):
        for c in self.charInfos:
            if not c.rename:
                continue
            if c.name == oldname:
                from cserveravatar import AVATAR
                d = AVATAR.mind.callRemote("renameCharacter",oldname,newname)
                d.addCallback(self.gotRenameCheckCharacterName,c,newname)
                d.addErrback(self.gotRenameCheckCharacterNameError)
                return d

        return (-1,"There was an error renaming this character.")        
        
    
    def gotCharacterInfosError(self,result):
        #error!
        return [],[],1
    
    def perspective_queryCharacters(self):
        from cserveravatar import AVATAR
        if not AVATAR:
            cinfos = []
            mspawns = []
            for ms in self.player.monsterSpawns:
                mspawns.append(ms.spawn)
            for c in self.player.characters:
                cinfo = CharacterInfo(c)
                cinfos.append(cinfo)
            return cinfos,mspawns,CoreSettings.MAXPARTY
        else:
            try:
                d = AVATAR.mind.callRemote("getCharacterInfos",self.player.publicName)
                d.addCallback(self.gotCharacterInfos)
                d.addErrback(self.gotCharacterInfosError)
                return d
            except:
                #error!
                print "ERROR!"
                return [],[],1
            
            
    def gotCharacterBuffer(self,cbuffer,party,simPort,simPassword):
        if cbuffer:
            cbuffer = loads(decodestring(cbuffer))
            InstallCharacterBuffer(self.player.id,party[0],cbuffer)
        self.enterWorld(party,simPort,simPassword)
        
    def playerJumped(self,result):        
        try:
            self.mind.broker.transport.loseConnection()
        except:
            pass
        self.logout()
        
        
        
    def playerTransfered(self,result,party):
        wip,wport,wpassword,zport,zpassword = result
        d = self.mind.callRemote("jumpServer",wip,wport,wpassword,zport,zpassword,party)
        d.addCallback(self.playerJumped)
        d.addErrback(self.playerJumped)

    def gotTransferCharacterBuffer(self,cbuffer,party,zoneName):
        from cserveravatar import AVATAR
        self.player.transfering = True
        p = self.player
        guildInfo = (p.guildName,p.guildInfo,p.guildMOTD,p.guildRank)
        d = AVATAR.mind.callRemote("transferPlayer",self.player.publicName,None,party[0],cbuffer,zoneName,None,self.player.publicName,guildInfo)
        d.addCallback(self.playerTransfered,party)
        return d
    
    def perspective_jumpIntoWorld(self,cname):
        self.enterWorld([cname],None,None)
        #fill charInfos
        self.perspective_queryCharacters()
            
    def perspective_enterWorld(self,party,simPort, simPassword):
        from cserveravatar import AVATAR
        if not AVATAR:
            self.enterWorld(party,simPort,simPassword)
            return
        
        #alright, we need to figure out what zone we are going to so we can pick a zone cluster
        cname = party[0]
        newc = False
        player = self.player
        for c in self.charInfos:
            if cname == c.name:
                newc = c.newCharacter
                if c.realm == RPG_REALM_DARKNESS:
                    zone = self.player.darknessLogZone.name
                elif c.realm == RPG_REALM_MONSTER:
                    zone = self.player.monsterLogZone.name
                elif c.realm == RPG_REALM_LIGHT:
                    zone = self.player.logZone.name
                else:
                    raise "Unknown Realm!"
                
        if zone in self.world.staticZoneNames:
            #we're on the right world server already            
            d = AVATAR.mind.callRemote("getCharacterBuffer",self.player.publicName,party[0])
            d.addCallback(self.gotCharacterBuffer,party,simPort,simPassword)
            return d
        
        #we need to transfer to another server
        if newc:
            #this is a new character and so we need to extract the player/character and transfer it
            char = Character.byName(cname)
            publicName,pbuffer,cbuffer,cvalues = ExtractPlayer(player.publicName,player.id,char.id,False)
            self.player.transfering = True
            pbuffer = encodestring(dumps(pbuffer, 2))
            cbuffer = encodestring(dumps(cbuffer, 2))
            p = self.player
            guildInfo = (p.guildName,p.guildInfo,p.guildMOTD,p.guildRank)
            d = AVATAR.mind.callRemote("transferPlayer",player.publicName,pbuffer,cname,cbuffer,zoneName,cvalues,self.player.publicName,guildInfo)
            d.addCallback(self.playerTransfered,party)
        else:
            #we just need to transfer servers
            d = AVATAR.mind.callRemote("getCharacterBuffer",self.player.publicName,party[0])
            d.addCallback(self.gotTransferCharacterBuffer,party,zone)
            return d

        return 
            
    def enterWorld(self,party,simPort,simPassword):
        from cserveravatar import AVATAR
    
        #zone is an instance
        
        #if we are logging in with all dead characters, it's back to our bind point for us
        alldead = True
        
        c = Character.byName(party[0])
        
        self.player.charName = c.name
        
        self.player.realm = c.spawn.realm
        
        #lame, should have gone with realm     
        self.player.darkness = False
        self.player.monster = False
        if c.spawn.realm == RPG_REALM_DARKNESS:
            self.player.darkness = True
        if c.spawn.realm == RPG_REALM_MONSTER:
            self.player.monster = True
        
        chars = []
        for p in party:
            c = Character.byName(p)
            chars.append(c)
            if not c.dead:
                alldead = False
                break
            
                
                
        if alldead:
            for c in chars:
                c.dead = False
                c.health = -999999
                c.stamina = -999999
                c.mana = -999999
            if self.player.darkness:
                self.player.darknessLogTransformInternal = self.player.darknessBindTransformInternal
                self.player.darknessLogZone = self.player.darknessBindZone
            elif self.player.monster:
                self.player.monsterLogTransformInternal = self.player.monsterBindTransformInternal
                self.player.monsterLogZone = self.player.monsterBindZone
            else:
                self.player.logTransformInternal = self.player.bindTransformInternal
                self.player.logZone = self.player.bindZone
                
                

        zone = self.world.playerSelectZone(self,simPort,simPassword)
        print "EnterWorld",zone.ip,self.mind.broker.transport.getPeer().host
        ip = zone.ip
        if zone.owningPlayer == self.player:
            #we are being told to host, what about people sharing an IP?
            ip = '127.0.0.1'
        
        self.player.loggingOut = False
        self.player.cursorItem = None
        self.player.simPort = simPort
        self.player.simPassword = simPassword
            
        zconnect = ZoneConnectionInfo()
        zconnect.ip = ip
        zconnect.password = zone.password
        zconnect.port = zone.port
        zconnect.niceName = zone.zone.niceName
        zconnect.missionFile = zone.zone.missionFile
        zconnect.instanceName = zone.name
        
        zone.submitPlayer(self.player,zconnect)
        
        
        
        #assemble the party in preparation
        self.player.party = Party()
        self.player.party.assemble(self.player,party)
            
        self.player.updateKOS()
        
        if AVATAR:
            if self.masterPerspective.avatars.has_key("ImmortalAvatar"):
                for c in self.player.party.members:
                    c.mob.aggroOff = True
        
        #if we are logging in with all dead character
        
        self.player.rootInfo = RootInfo(self.player,self.player.party.charInfos)
        self.mind.callRemote("setRootInfo",self.player.rootInfo,time()-self.player.world.pauseTime)
        
        if self.player.cursorItem:
            self.mind.callRemote("setCursorItem",self.player.cursorItem.itemInfo)
            
        
        if not Player.remoteLeaderNames.has_key(self.player.publicName):
            self.player.alliance = Alliance(self.player)
        else:
            rln = Player.remoteLeaderNames[self.player.publicName]
            del Player.remoteLeaderNames[self.player.publicName]
        
            #make sure we are still in this alliance 
            found = False
            try:
                a = Alliance.masterAllianceInfo[rln]
                for pname,cname in a:
                    if pname == self.player.publicName:
                        found = True
                        break
            except KeyError:
                pass
            if not found:
                self.player.alliance = Alliance(self.player)
            else:
                found = False
                for p in self.world.activePlayers:
                    if p == self.player:
                        continue
                    if not p.alliance:
                        continue
                    
                    if p.alliance.remoteLeaderName == rln:
                        found = True
                        self.player.alliance = p.alliance
                        if p.alliance.remoteLeaderName == self.player.publicName:
                            p.alliance.leader = self.player
                            p.alliance.members.insert(0,self.player)
                        else:
                            p.alliance.members.append(self.player)
                        self.player.alliance.setupForPlayer(self.player)
                        break
                if not found:
                    self.player.alliance = Alliance(self.player,rln)
        
        #at this time, the player mind takes over
        
        if GAMEROOT == "minions.of.mirth":
            self.player.sendGameText(RPG_MSG_GAME_GLOBAL,r'Welcome to Minions of Mirth!\n')
        else:
            self.player.sendGameText(RPG_MSG_GAME_GLOBAL,r'Welcome to the Starter MMORPG!\n')
            
        
        if CoreSettings.MOTD:
            self.player.sendGameText(RPG_MSG_GAME_GLOBAL,r'Server MOTD: '+CoreSettings.MOTD+r'\n')

        if self.player.guildMOTD:
            self.player.sendGameText(RPG_MSG_GAME_LEVELGAINED,r'Guild MOTD: '+self.player.guildMOTD+r'\n')
    
    
    
    def perspective_doCommand(self,cmd,args):
        index = 0
        if len(args):
            index = int(args[0])
        try:
            char = self.player.party.members[index]
            if not char or char.dead or not char.mob:
                return
            DoCommand(char.mob,cmd,args[1:])
        except:
            print_exc()
    
    
    def perspective_onInvSlotUse(self,cid,slot):
        if slot > RPG_SLOT_CARRY29:
            print "onInvSlotUse: PLAYER ATTEMPTING TO use slot > RPG_SLOT_CARRY29"
            return
        char = Character.get(cid)
        if char not in self.player.party.members:
            print "onInvSlotUse: PLAYER ATTEMPTING TO MANIPULATE NONPARTY CHARACTER"
            return
        if char.dead or not char.mob:
            return
        
        for item in char.items:
            if item.slot == slot:
                item.use(char.mob)
                return
    
    
    #cast or memorize spell, empty spell slot should be caught on client
    def perspective_onSpellSlot(self,cid,slot):
        party = self.player.party
        char = Character.get(cid)
        if char not in party.members:
            print "onSpellSlot: PLAYER ATTEMPTING TO MANIPULATE NONPARTY CHARACTER"
            return
        if char.dead or not char.mob:
            return
        
        cursorItem = self.player.cursorItem
        char.onSpellSlot(slot)
        self.player.updateCursorItem(cursorItem)
    
    def perspective_onSpellSlotSwap(self,cid,src,dest):
        party = self.player.party
        char = Character.get(cid)
        if char not in party.members:
            print "onSpellSlot: PLAYER ATTEMPTING TO MANIPULATE NONPARTY CHARACTER"
            return
        if char.dead or not char.mob:
            return
        
        char.onSpellSlotSwap(src,dest)
    
    
    def perspective_onInvSlot(self,cid,slot):
        party = self.player.party
        char = Character.get(cid)
        if char not in party.members:
            print "onInvSlot: PLAYER ATTEMPTING TO MANIPULATE NONPARTY CHARACTER"
            return
        if char.dead or not char.mob:
            return
        
        cursorItem = self.player.cursorItem
        char.onInvSlot(slot)
        self.player.updateCursorItem(cursorItem)
    
    def perspective_onInvSlotAlt(self,cid,slot):
        party = self.player.party
        char = Character.get(cid)
        if char not in party.members:
            print "onInvSlot: PLAYER ATTEMPTING TO MANIPULATE NONPARTY CHARACTER"
            return
        if char.dead or not char.mob:
            return
            
        char.onInvSlotAlt(slot)
    
    def perspective_onInvSlotCtrl(self,cid,slot):
        party = self.player.party
        char = Character.get(cid)
        if char not in party.members:
            print "onInvSlot: PLAYER ATTEMPTING TO MANIPULATE NONPARTY CHARACTER"
            return
        if char.dead or not char.mob:
            return
        
        char.onInvSlotCtrl(slot)
    
    
    def perspective_endLooting(self):
        if not self.player.looting:
            return
        
        self.player.looting.looter = None
        self.player.looting = None
        
        return True
    
    def perspective_loot(self,cindex,slot,alt = False):
        if not self.player.looting:
            return
        char = self.player.party.members[cindex]
        if char.dead or not char.mob:
            return
        char.onLoot(self.player.looting,slot,alt)
    
    def perspective_destroyCorpse(self):
        if not self.player.looting:
            return
        
        self.player.looting.zone.removeMob(self.player.looting)
    
    
    # only use to expunge cursor item, else use takeItem in player class
    def perspective_expungeItem(self):
        item = self.player.cursorItem
        self.player.cursorItem = None
        if item.character not in self.player.party.members:
            raise ValueError,"Attempting to expunge an item not belonging to player's present party!"
            return
        item.slot = -1
        self.player.updateCursorItem(item)
        item.destroySelf()
        self.player.cinfoDirty = True
    
    def perspective_splitItem(self,newStackSize):
        item = self.player.cursorItem
        if item.character not in self.player.party.members:
            raise "Attempting to split an item not belonging to player's present party!"
            self.player.cursorItem = None
            return
        item.character.splitItem(item,newStackSize)
    
    
    #choice will either be a zoneinstance name or "new" if player wants to launch own zone
    def perspective_chooseZone(self,choice):
        found = False
        zoneInstanceName = ""
        player = self.player
        if player.darkness:
            player.darknessLogTransformInternal = player.triggeredZoneLink.dstZoneTransform
            player.darknessLogZone = Zone.byName(player.triggeredZoneLink.dstZoneName)
        elif player.monster:
            player.monsterLogTransformInternal = player.triggeredZoneLink.dstZoneTransform
            player.monsterLogZone = Zone.byName(player.triggeredZoneLink.dstZoneName)            
        else:
            player.logTransformInternal = player.triggeredZoneLink.dstZoneTransform
            player.logZone = Zone.byName(player.triggeredZoneLink.dstZoneName)
            
        
        self.world.closePlayerZone(player)
        
        if choice == 'new' and player.world.singlePlayer:
            zi = self.world.playerSelectZone(self,self.player.simPort,self.player.simPassword)
            zoneInstanceName = zi.name
            found = True
        else:
            
            for zo in player.triggeredZoneOptions:
                if zo.zoneInstanceName == choice:
                    zoneInstanceName = zo.zoneInstanceName
                    found = True
                    break
                    
        if found:
            zi = self.world.getZoneByInstanceName(zoneInstanceName)
            if not zi:
                print_stack()
                print "AssertionError: zone not found!"
                return
            
            player.zone = zi
            player.party.reassemble()
            
            ip = zi.ip
            if zi.owningPlayer == player:
                #we are being told to host, what about people sharing an IP?
                ip = '127.0.0.1'
                
            zconnect = ZoneConnectionInfo()
            zconnect.ip = ip
            zconnect.password = zi.password
            zconnect.port = zi.port
            zconnect.niceName = zi.zone.niceName
            zconnect.missionFile = zi.zone.missionFile
            zconnect.instanceName = zi.name
            
            zi.submitPlayer(self.player,zconnect)

            
            self.player.rootInfo = RootInfo(self.player,self.player.party.charInfos)            
            self.mind.callRemote("setRootInfo",self.player.rootInfo)
            
            if self.player.cursorItem:
                self.mind.callRemote("setCursorItem",self.player.cursorItem.itemInfo)
                   
    #interaction
    
    #dialog
    def perspective_onInteractionChoice(self,index,pane):
        if not self.player.interacting or not self.player.curDialogLine:
            pane.callRemote("close")
            return
        
        self.player.dialog.handleChoice(self.player,index,pane)
        
    #global
    def perspective_endInteraction(self):
        self.player.endInteraction()
    
    
    def perspective_sellItem(self,charIndex,slot):  # use slot in inventory
        if not self.player.interacting or not self.player.interacting.vendor:
            return
        
        char = self.player.party.members[charIndex]
        if char.dead or not char.mob:
            return
        item = None
        found = False
        for item in char.items:
            if item.slot == slot:
                found = True
                break
        
        if item and found:
            self.player.interacting.vendor.buyItem(self.player,item)
        else:
            print "Warning: Player item selling wackiness!!! Item to be sold not found!"
    
    def perspective_buyItem(self,charIndex,itemIndex):  # use index from vendor list
        if not self.player.interacting or not self.player.interacting.vendor:
            return
        
        char = self.player.party.members[charIndex]
        if char.dead or not char.mob:
            return
        
        self.player.interacting.vendor.sellItem(self.player,char,itemIndex)
    
    
    def perspective_setCurrentCharacter(self,cindex):
        if cindex > len(self.player.party.members) - 1:
            return
        
        cchar = self.player.party.members[cindex]
        
        if self.player.curChar == cchar:
            return
        
        
        self.player.curChar = cchar
        
        if hasattr(self.player,"dialog"):#bah
            if self.player.dialog and self.player.interacting:
                if hasattr(self.player.interacting,"spawn"):
                    name = self.player.interacting.spawn.name
                else:
                    name = self.player.dialog.title
                    
                self.player.dialog.setLine(self.player,self.player.dialog.greeting,name)
        
    def perspective_setXPGain(self,charindex,pvalue,svalue,tvalue):
        
        char = self.player.party.members[charindex]
        
        char.setXPGain(pvalue,svalue,tvalue)
        
    #Alliances

    def perspective_invite(self):
        player = self.player
        alliance = player.alliance
        
        if player.invite:
            player.sendGameText(RPG_MSG_GAME_DENIED,"You must accept or decline an outstanding invitation first.\\n")
            return
        
        #get currently selected player
        target = player.curChar.mob.target
        
        if not target:
            player.sendGameText(RPG_MSG_GAME_DENIED,"You must have a valid target to invite.\\n")
            return
            
        if not target.player:
            player.sendGameText(RPG_MSG_GAME_DENIED,"You cannot invite %s to the alliance.\\n"%target.name)
            return #not a player
            
        if alliance.leader != player or alliance.remoteLeaderName != player.publicName:
            player.sendGameText(RPG_MSG_GAME_DENIED,"You are not the leader of the alliance.\\n")
            return
            
        if alliance.countMembers()>=6:
            player.sendGameText(RPG_MSG_GAME_DENIED,"The alliance is full.\\n")
            return
            
        otherplayer = target.player
        
        if otherplayer == player:
            return
        
        if otherplayer.invite:
            player.sendGameText(RPG_MSG_GAME_DENIED,"%s is already considering an alliance.\\n"%otherplayer.charName)
            return
    
        if otherplayer.alliance.countMembers()>1:
            player.sendGameText(RPG_MSG_GAME_DENIED,"%s is already in an alliance.\\n"%otherplayer.charName)
            return
        
        d = otherplayer.mind.callRemote("checkIgnore",player.charName)
        d.addCallback(self.gotCheckIgnoreAlliance,player,otherplayer)
        d.addErrback(self.gotCheckIgnoreAllianceError)
    
    def gotCheckIgnoreAlliance(self,ignored,player,otherplayer):
        if ignored:
            player.sendGameText(RPG_MSG_GAME_DENIED,"%s is ignoring you.\\n"%otherplayer.charName)
            return
        player.sendGameText(RPG_MSG_GAME_GOOD,"You have invited %s to the alliance.\\n"%otherplayer.charName)
        otherplayer.sendGameText(RPG_MSG_GAME_GOOD,"%s has invited you to form an alliance.\\n"%player.charName)
        player.alliance.invite(otherplayer)
    
    def gotCheckIgnoreAllianceError(self,error):
        print "Error in checkIgnore: %s"%str(error)
    
    def perspective_joinAlliance(self):
        player = self.player
        if not player.invite:
            return False
        
        leader = player.invite.leader
        if player.invite.alliance != leader.alliance: #incase alliance disbanded or something
            player.invite = None
            player.sendGameText(RPG_MSG_GAME_DENIED,"This alliance has disbanded.\\n")
            return False
        
        alliance = leader.alliance
        
        if not alliance.join(player):
            player.sendGameText(RPG_MSG_GAME_DENIED,"You cannot join the alliance at this time.\\n")
            return False
            
        player.sendGameText(RPG_MSG_GAME_GOOD,"You have joined %s's alliance.\\n"%leader.charName)
        
        for m in alliance.members:
            if m == player:
                continue
                
            m.sendGameText(RPG_MSG_GAME_GOOD,"%s has joined your alliance.\\n"%player.charName)
        
        return True
        
    def perspective_leaveDecline(self):
        player = self.player
        
        if player.invite:
            try:
                player.invite.decline()
            except:
                print_exc()
            player.invite = None
            return
            
        if player.alliance.countMembers()>1:
            player.alliance.leave(player)
        
        
    def perspective_disband(self):
        
        player = self.player
        if player.publicName != player.alliance.remoteLeaderName:
            return

        if player.alliance.countMembers()>1:
            player.alliance.disband()
        
        
    def perspective_kick(self,name):
        player = self.player
        if player.publicName != player.alliance.remoteLeaderName:
            return

        if player.alliance.leader == player and player.alliance.countMembers()>1:
            player.alliance.kick(name)
    
    
    # Player trades
    def perspective_onPlayerTradeMoney(self,money):
        player = self.player
        if not player.trade:
            return 0L
        return player.trade.submitMoney(player,money)
    
    def perspective_onPlayerTradeSlot(self,slot):
        player = self.player
        
        if not player.trade:
            return
            
        party = player.party
        char = player.curChar
            
        cursorItem = player.cursorItem

        char.onInvSlot(slot+RPG_SLOT_TRADE0)
        
        player.updateCursorItem(cursorItem)

    def perspective_onPlayerTradeCancel(self):
        player = self.player
        
        if not player.trade:
            return
            
        player.trade.cancel()
            

    def perspective_onPlayerTradeAccept(self):
        player = self.player
        
        if not player.trade:
            return
            
        player.trade.accept(player)
        
        
    #tracking
    
    def perspective_track(self,id):
        self.player.track(id)
        
        
    def perspective_setPortraitPic(self,pic):
        self.player.curChar.portraitPic = pic
        
    #processes
    
    def perspective_cancelProcess(self,cid,pid):
        for c in self.player.party.members:
            if c.id == cid:
                for p in c.mob.processesIn:
                    if isinstance(p,Spell):
                        if pid == p.pid and not p.spellProto.spellType&RPG_SPELL_HARMFUL:
                            p.cancel()
                            return
                
        
    def perspective_chooseAdvancement(self,cname,advancement):
        for c in self.player.party.members:
            if c.name == cname:
                c.chooseAdvancement(advancement)
                return
            
        raise RuntimeWarning,"Player %s attempting to choose advancement %s for %s"%(self.player.name,advancement,cname)
                
                
        
    def perspective_onCraft(self,cindex):
        if cindex > len(self.player.party.members) - 1:
            return
        self.player.party.members[cindex].onCraft()


#REPAIR
    def perspective_repairItem(self,cindex):
        if cindex > len(self.player.party.members) - 1:
            return
        RepairItem(self.player,self.player.party.members[cindex])
    
    def perspective_repairAll(self,cindex):
        if cindex > len(self.player.party.members) - 1:
            return
        RepairAll(self.player,self.player.party.members[cindex])
    
    def perspective_repairParty(self,cindex):
        if cindex > len(self.player.party.members) - 1:
            return
        RepairParty(self.player,self.player.party.members[cindex])


    def perspective_onBankSlot(self,slot):
        player = self.player
        
        cursorItem = player.cursorItem
        
        bankItem = None
        for item in self.player.bankItems:
            if item.slot == slot:
                bankItem = item
                break
        
        if bankItem:
            switched,newBankItem,newCursorItem = bankItem.doStack(cursorItem)
            if switched:
                newCursorItem.setCharacter(player.curChar,False)
                newCursorItem.slot = RPG_SLOT_CURSOR
                newCursorItem.player = None
                newCursorItem.refreshFromProto()
                if newBankItem:
                    newBankItem.setCharacter(None,False)
                    newBankItem.slot = slot
                    newBankItem.player = player
                    if newBankItem not in player.bankItems:
                        player.bankItems.append(newBankItem)
                    newBankItem.refreshFromProto()
            elif not newCursorItem:  # stacked
                player.takeItem(cursorItem)
                cursorItem = None
            player.cursorItem = newCursorItem
            player.updateCursorItem(cursorItem)
            player.rootInfo.forceBankUpdate = True
            return
        
        if cursorItem:
            cursorItem.setCharacter(None,False)
            cursorItem.slot = slot
            cursorItem.player = player
            if cursorItem not in player.bankItems:
                player.bankItems.append(cursorItem)
            cursorItem.refreshFromProto()
            player.cursorItem = None
        
        player.updateCursorItem(cursorItem)

        
    def perspective_onAcceptResurrect(self):
        if not self.player.resurrectionRequest:
            return
        
        t,xp,cname = self.player.resurrectionRequest
        
        if time() - t > 30:
            self.player.sendGameText(RPG_MSG_GAME_DENIED,"This resurrection has expired.\\n")
            return
            
        
        self.player.resurrectionRequest = None
        
        c = self.player.party.members[0]
        
        if c.name != cname:
            return
        if not c.deathZone:
            return
        
        c.playerResurrect(xp)
        
        
        
    def perspective_onResurrect(self,cname):
        if not self.player.resurrection:
            return
        
        t,effect,cnames = self.player.resurrection
        self.player.resurrection = None
        pCharName = self.player.fantasyName
        if self.player.curChar:
            pCharName = self.player.curChar.name
        
        if cname not in cnames:
            self.player.sendGameText(RPG_MSG_GAME_DENIED,"Resurrection error cname not in cnames.\\n")
            return
            
        if time()-t > 30:
            self.player.sendGameText(RPG_MSG_GAME_DENIED,"Resurrection expired.\\n")
            return
        
        for p in self.player.world.activePlayers:
            if p.zone and p in p.zone.players:
                c = p.party.members[0]
                if c.deathZone and c.name == cname:
                    #got it and we are on this cluster
                    if p.resurrectionRequest:
                        t,neffect,cname = p.resurrectionRequest
                        if time()-t < 30:
                            self.player.sendGameText(RPG_MSG_GAME_DENIED,"%s is already being resurrected.\\n"%cname)
                            return
                        
                    p.resurrectionRequest = (time(),effect.resurrectionXP,cname)
                    p.mind.callRemote("resurrectionRequest",pCharName,effect.resurrectionXP)
                    return
        
        self.player.world.daemonPerspective.callRemote("resurrectionRequest",pCharName,effect.resurrectionXP,time(),cname)

#item vault

    def perspective_onRemoveVault(self,id):
        player = self.player
        if player.cursorItem:
            return
        
        char = player.curChar
        
        try:
            vitem = CharacterVaultItem.get(id)
        except:
            print "WARNING: Invalid valid item"
            return
        
        if char!=vitem.character:
            print "WARNING: Player attempting to remove vault item to incorrect character"
            return
        
        item = ItemInstance(vitem.item)
        vitem.destroySelf()
        char.vaultItemsDirty=True
        item.setCharacter(char)
        item.slot = RPG_SLOT_CURSOR
        player.cursorItem = item
        player.updateCursorItem(None)
        
        

    def perspective_onPlaceVault(self):
        player = self.player
        if not player.cursorItem:
            return

        item = player.cursorItem
        
        char = player.curChar
        
        if len(char.vaultItems) >= 300:
            self.player.sendGameText(RPG_MSG_GAME_DENIED,"%s's private vault is full.\\n"%char.name)
            return
        
        item.setCharacter(None)
        item.slot = -1
        player.cursorItem = None
        player.updateCursorItem(item)
        
        item.storeToItem(True)
        CharacterVaultItem(character=char,item=item.item,name=item.name,stackCount=item.stackCount)
        char.vaultItemsDirty=True
        
        #go with something more lightweight?  The whole refresh logic needs to be rewritten in C 
        char.charInfo.refresh()
        
        
    #friends
    def perspective_submitFriends(self,friends):
        self.player.friends = [f.upper() for f in friends]
    
    
    def perspective_setEncounterSetting(self,index):
        if self.player.encounterSetting != index:
            char = self.player.curChar
            mob = char.mob
            if index == RPG_ENCOUNTER_PVE:
                msg = r'%s will cease fighting other players.\n'%char.name
            elif index == RPG_ENCOUNTER_RVR:
                msg = r'Attention: %s is going to engage in realm versus realm player fights!\n'%char.name
            elif index == RPG_ENCOUNTER_GVG:
                msg = r'Attention: %s is going to engage in guild versus guild player fights!\n'%char.name
            else:
                msg = r'WARNING: %s decided to engage in player versus player fights!\n'%char.name
            GameMessage(RPG_MSG_GAME_COMBAT,mob.zone,mob,None,msg,mob.simObject.position,range=30)
            reactor.callLater(10,self.player.applyEncounterSetting,index)  # call 10 seconds later




