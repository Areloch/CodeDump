$Pref::GuiEditor::PreviewResolution = "1024 768";
