//--- OBJECT WRITE BEGIN ---
datablock sgMissionLightingFilterData(Filter1) {
   className = "sgMissionLightingFilterData";
   CinematicFilter = "0";
   LightingIntensity = "0.643678";
   LightingFilter = "1 1 1 1";
   CinematicFilterAmount = "2";
   CinematicFilterReferenceIntensity = "1.74713";
   CinematicFilterReferenceColor = "1 1 1 1";
};
//--- OBJECT WRITE END ---



