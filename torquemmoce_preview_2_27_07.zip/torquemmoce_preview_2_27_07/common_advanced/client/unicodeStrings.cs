﻿//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

$UnicodeTest::Arabic = "مالس";
$UnicodeTest::ANSI = "Peace";
$UnicodeTest::Hebrew = "םולש";
$UnicdoeTest::Greek = "Ειρήνη";