new Material( WarningMaterial )
{
   baseTex[0] = "./data/warnMat";
   emissive[0] = true;
};