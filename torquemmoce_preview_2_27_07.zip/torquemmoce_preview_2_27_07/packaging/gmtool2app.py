from distutils.core import setup
import py2app
import os
import string
import shutil
import findertools

OUTPUT_FOLDER = "gmtool"

if os.path.exists('./dist'):
    shutil.rmtree('./dist')

if os.path.exists('./build'):
    shutil.rmtree('./build')

setup(
    app=['./mud/gmtool/gmtool.py'],options = dict (py2app = {"iconfile":"./packaging/MinionsOfMirth.icns","excludes":["genesis"],"packages":["encodings"]})
)



