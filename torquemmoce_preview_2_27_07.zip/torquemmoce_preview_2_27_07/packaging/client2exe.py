from distutils.core import setup
import py2exe
import shutil
import os,sys
#python 2.5 change
sys.path.append(os.getcwd())

from mud.gamesettings import GAMEROOT

if os.path.exists('./build'):
    shutil.rmtree('./build')

if os.path.exists('./dist'):
    shutil.rmtree('./dist')

from mud.world.defines import *

if RPG_BUILD_DEMO:
    OUTPUT_FOLDER = "demo"
    INPUT_SCRIPT = "Client.pyw"
else:
    if not RPG_BUILD_LIVE:
        OUTPUT_FOLDER = "testing"
    else:
        OUTPUT_FOLDER = "live"
        
    INPUT_SCRIPT = "Client.pyw"
        
#generate the version.py
from sqlite3 import dbapi2 as sqlite
import datetime,pickle

print "Generating ./mud/world/genesistime.py"
con = sqlite.connect("./%s/data/worlds/multiplayer.baseline/world.db"%GAMEROOT)
cur = con.cursor()
cur.execute('select genesis_time from World where name="TheWorld"')
dt = cur.fetchone()[0]

f = file("./mud/world/genesistime.py","w")
f.write("""
#AUTOMATICALLY GENERATED FILE DO NOT EDIT!

GENESISTIME = "%s"
"""%dt)

f.close()

#!!! THERE APPEARS TO BE A BUG WITH DIST_DIR and pyd files!!!
setup(windows=[{"dest_base":"Client","script":INPUT_SCRIPT,"icon_resources": [(1, "packaging/eye.ico")]}],
      options = {"py2exe": { "compressed":True,"dll_excludes": ["wxmsw26uh_vc.dll","netapi32.dll"],"excludes":["genesis"],"packages": ["encodings","twisted.web"]}}
) 

for file in os.listdir("./dist"):
    try:
        os.makedirs("./bin/%s/windows/bin"%OUTPUT_FOLDER)
    except:
        pass
    shutil.copy("./dist/%s"%file,"./bin/%s/windows/bin/%s"%(OUTPUT_FOLDER,file))
    
shutil.copy("./OpenAL32.dll","./bin/%s/windows/bin/OpenAL32.dll"%OUTPUT_FOLDER)
shutil.copy("./wrap_oal.dll","./bin/%s/windows/bin/wrap_oal.dll"%OUTPUT_FOLDER)

from createmanifest import CreateManifest,SaveManifest
import sys
print "Creating Windows Manifest"
wm = CreateManifest("./bin/%s/windows"%OUTPUT_FOLDER,"./bin/%s/windows/"%OUTPUT_FOLDER)
SaveManifest(wm,"./bin/%s/windows/manifest.zip"%OUTPUT_FOLDER,"./bin/%s/windows/manifest.sha"%OUTPUT_FOLDER)







