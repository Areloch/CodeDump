ObjectBuilderGui.newObject = new VolumeLight(www) {
   dataBlock = "sgMountLight";
};
