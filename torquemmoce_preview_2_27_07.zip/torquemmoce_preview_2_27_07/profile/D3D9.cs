// Direct3D 9 Renderer Profile Script
//
// This script is responsible for setting global
// capability strings based on the D3D9 renderer type.