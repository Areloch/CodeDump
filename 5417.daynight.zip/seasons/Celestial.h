#ifndef _DAYCYCLE_H_
#define _DAYCYCLE_H_

#ifndef _NETOBJECT_H_
#include "sim/netObject.h"
#endif
#ifndef _LIGHTMANAGER_H_
#include "sceneGraph/lightManager.h"
#endif
#ifndef _SUN_H_
#include "terrain/sun.h"
#endif
#ifndef _SKY_H_
#include "terrain/sky.h"
#endif

// defines for working with radians and degrees
#ifndef PI
#define PI   (3.141592653589793238462643f)
#endif

#define RADIAN (180/PI)
#define TORADIANS(x) (((x)/360) * (2*PI))
#define TODEGREES(x) (((x)/(2*PI)) * 360)

typedef struct _color_target{
	F32		elevation; // maximum target elevation
	ColorF	color; //normalized 0 = 1.0 ... 
	F32		bandMod;  //6 is max
	ColorF	bandColor;
} COLOR_TARGET, *LPCOLOR_TARGET;
typedef Vector<COLOR_TARGET> COLOR_TARGETS;

/**
	The Celestials class manages the heavens: major lights, minor lights, scene
	lighting effects, celestial object positioning, seasons, and star fields.
*/
class Celestials : public SceneObject
{
public:
	Celestials();
	
	typedef SceneObject Parent;
	
	// Sun position stuff
	void UpdateSunPosition(void);
	// void UpdateSunPosition(fxSunLight *sunLight);
	F32 getAzimuthRads() {return mAzimuth;}
	F32 getElevationRads() {return mElevation;}
	F32 getAzimuthDegrees() {return TODEGREES(mAzimuth);}
	F32 getElevationDegrees() {return TODEGREES(mElevation);}


	// Scene lighting (Adapted from Joshua Ritter's Day/Night cycle code)
	// I changed references to pointers on the basis of principle. ;-)
	void EnableLighting(F32 emissiveScale = 1.0);
	void DisableLighting();
	void GetColor(ColorF& color);
	void InitColors();
	void AddColorTarget(F32 ele, ColorF& color, F32 bandMod, ColorF& bandColor);
	F32 GetIntensity() 
	{ return (mCurrentColor.blue + mCurrentColor.green + mCurrentColor.red) / 3; }

	// Manages scriptable initializations
	static void initPersistFields();

private:
	// Get a pointer to the sun's light object
	Sun* GetSunObject();

	// return Azimuth in radians
	F32 Azimuth(F32 viewerLatitude, F32 objectDecline, F32 medianAngle);
	F32 Elevation(F32 viewerLatitude, F32 objectDecline, F32 medianAngle);

	// return number between 0 and 1 representing color variance
	F32 getColorVariance();

public:
	F32 mAzimuth; // Angle from true north of celestial object in radians
	F32 mElevation; // Angle from horizon of celestial object in radians
	VectorF mSunVector; // the sun vector

private:
	// Date tracking stuff
	SimTime mStartTime; // The time this object was created.
	SimTime mDayLen; // length of day in real world milliseconds
	SimTime mTimeOfDay; // in game milliseconds standard time (one_game_minute = (mDayLen / 24) / 60)	
	U32 mYearLen; // Length of year in virtual days
	U32 mTimeOfYear; // Number of days since the last winter equinox

	// Global positioning stuff
	F32 mLongitude; // longitudinal position of this mission
	F32 mLatitude; // latitudinal position of this missiion
	F32 mAxisTilt; // angle between global equator and tropic

	// color management
	COLOR_TARGETS mColorTargets;

public:
	ColorF mCurrentColor;
	F32 mBandMod;
	ColorF mCurrentBandColor;

private:
	// PersistFields preparation
	bool mConvertedToRads; // initPersist takes arguments in degtrees. Have we converted?

public:
	DECLARE_CONOBJECT(Celestials);
};

extern Celestials *gCelestials;

#endif