//-----------------------------------------------------------------------------
// Torque Game Engine
// 
// Copyright (c) 2001 GarageGames.Com
// Portions Copyright (c) 2001 by Sierra Online, Inc.
//-----------------------------------------------------------------------------
//
// File name: guiBitmapButtonCtrl.h
//
// Purpose:
// This is a BitmapButton control
// It supports 3 states. Button Up (default), Button Down and Active (mouse over it)
//
// Acknowledgements:
//     Micha�l Schoonbrood aka Mad Butch
//     The Butchers Home (www.MadButch.com)
//
// History:
//     Written by: M.F.H. Schoonbrood	Date: 01-02-2002	Version: 1.0
//     Description: Initial version
//
// Mail comments/suggestions/bugs to:
//     GuiBitmapButtonCtrl@MadButch.Com
//-----------------------------------------------------------------------------


#ifndef _GUIBITMAPBUTTONCTRL_H_
#define _GUIBITMAPBUTTONCTRL_H_

#ifndef _GUIBUTTONCTRL_H_
#include "gui/guiButtonCtrl.h"
#endif
#ifndef _GUIBITMAPCTRL_H_
#include "gui/GuiBitmapCtrl.h"
#endif



class GuiBitmapButtonCtrl : public GuiButtonCtrl
{
private:
	typedef GuiButtonCtrl Parent;


protected:
	GuiBitmapCtrl		mBitmapButtonUp;
	GuiBitmapCtrl		mBitmapButtonDown;
	GuiBitmapCtrl		mBitmapButtonActive;

	StringTableEntry	mBitmapNameButtonUp;
	StringTableEntry	mBitmapNameButtonDown;
	StringTableEntry	mBitmapNameButtonActive;
	bool				mWrap;

public:
	// Creation methods
	DECLARE_CONOBJECT(GuiBitmapButtonCtrl);
	GuiBitmapButtonCtrl();

	static void	initPersistFields();

	// Parental methods
	void	resize(const Point2I &newPosition, const Point2I &newExtent);
	bool	onWake();
	void	onSleep();

	void	setBitmap(const int type, const char *name);
	void	setBitmap(const int type, const TextureHandle &handle);

	inline S32	getWidth() const;
	inline S32	getHeight() const;

	void	onRender(Point2I offset, const RectI &updateRect);
	void	setValue(S32 x, S32 y);
};



inline S32	GuiBitmapButtonCtrl::getWidth() const
{
	return mBitmapButtonUp.getWidth();
}

inline S32	GuiBitmapButtonCtrl::getHeight() const
{
	return mBitmapButtonUp.getHeight();
}



#endif
