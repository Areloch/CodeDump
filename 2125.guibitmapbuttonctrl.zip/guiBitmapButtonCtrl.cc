//-----------------------------------------------------------------------------
// Torque Game Engine
// 
// Copyright (c) 2001 GarageGames.Com
// Portions Copyright (c) 2001 by Sierra Online, Inc.
//-----------------------------------------------------------------------------
//
// File name: guiBitmapButtonCtrl.cc
//
// Purpose:
// This is a BitmapButton control
// It supports 3 states. Button Up (default), Button Down and Active (mouse over it)
//
// Acknowledgements:
//     Micha�l Schoonbrood aka Mad Butch
//     The Butchers Home (www.MadButch.com)
//
// History:
//     Written by: M.F.H. Schoonbrood	Date: 01-02-2002	Version: 1.1
//     Description: Fixed the (re)size bug (bitmaps had wrong size)
//
//     Written by: M.F.H. Schoonbrood	Date: 01-02-2002	Version: 1.0
//     Description: Initial version
//
// Mail comments/suggestions/bugs to:
//     GuiBitmapButtonCtrl@MadButch.Com
//-----------------------------------------------------------------------------

//#include "console/console.h"
#include "console/consoleTypes.h"		// Needed for initPersistFields()
//#include "dgl/dgl.h"					// Needed for dglClearBitmapModulation() and dlgDraw...() functions

#include "gui/guiBitmapButtonCtrl.h"



// Make the control known to the GUI
IMPLEMENT_CONOBJECT(GuiBitmapButtonCtrl);

// Define the bitmapTypes
enum bitmapType
{	BITMAP_BUTTON_UP	= 1,		// The normal image (Button is up), default
	BITMAP_BUTTON_DOWN,				// The button is pressed down
	BITMAP_BUTTON_ACTIVE			// The mouse is above the unpressed button
};



// Constructor
GuiBitmapButtonCtrl::GuiBitmapButtonCtrl(void)
{
	// Clear bitmap names
	mBitmapNameButtonUp		= StringTable->insert("");
	mBitmapNameButtonDown	= StringTable->insert("");
	mBitmapNameButtonActive	= StringTable->insert("");
	// Default no wrapping
	mWrap					= false;

	// Adjust all the sizes of the bitmap controls
	// Making sure they have the same size as this control
	mBitmapButtonUp.mBounds.extent.x		= mBounds.extent.x;
	mBitmapButtonUp.mBounds.extent.y		= mBounds.extent.y;
	mBitmapButtonDown.mBounds.extent.x		= mBounds.extent.x;
	mBitmapButtonDown.mBounds.extent.y		= mBounds.extent.y;
	mBitmapButtonActive.mBounds.extent.x	= mBounds.extent.x;
	mBitmapButtonActive.mBounds.extent.y	= mBounds.extent.y;
}



void GuiBitmapButtonCtrl::initPersistFields()
{
	// Add the fields of the parent control
	Parent::initPersistFields();

	// Add our own fields
	addField( "bitmapButtonUp",     TypeFilename, Offset(mBitmapNameButtonUp,     GuiBitmapButtonCtrl ) );
	addField( "bitmapButtonDown",   TypeFilename, Offset(mBitmapNameButtonDown,   GuiBitmapButtonCtrl ) );
	addField( "bitmapButtonActive", TypeFilename, Offset(mBitmapNameButtonActive, GuiBitmapButtonCtrl ) );
	addField( "wrap",               TypeBool,     Offset(mWrap,                   GuiBitmapButtonCtrl ) );
}



void GuiBitmapButtonCtrl::resize(const Point2I &newPosition, const Point2I &newExtent)
{
	// Pass the resize call on to the parent class
	Parent::resize(newPosition, newExtent);

	// Adjust all the sizes of the bitmap controls
	// Making sure they have the same size as this control
	mBitmapButtonUp.resize(newPosition, newExtent);
	mBitmapButtonDown.resize(newPosition, newExtent);
	mBitmapButtonActive.resize(newPosition, newExtent);
}



bool GuiBitmapButtonCtrl::onWake()
{
	// Wake parent
	if( !Parent::onWake() )
	{
		// Wake failed
		return false;
	}
	// Wake succesfull, continue
	setActive(true);

	// Pass the Wrap setting to all bitmap controls
//!!!!!!!!DELETE_ME!!!!!!!!!!!
// If the following setWrap functions generate a compiler error,
// then add the following function to "guiBitmapCtrl.h" under "public:"
//	void setWrap(const bool wrap) { mWrap = wrap; }	
//!!!!!!!!DELETE_ME!!!!!!!!!!!
	mBitmapButtonUp.setWrap(mWrap);
	mBitmapButtonDown.setWrap(mWrap);
	mBitmapButtonActive.setWrap(mWrap);

	// Pass all bitmap names to the bitmap controls
	mBitmapButtonUp.setBitmap(mBitmapNameButtonUp);
	mBitmapButtonDown.setBitmap(mBitmapNameButtonDown);
	mBitmapButtonActive.setBitmap(mBitmapNameButtonActive);

	// Wake all bitmap controls
	mBitmapButtonUp.onWake();
	mBitmapButtonDown.onWake();
	mBitmapButtonActive.onWake();

	// Succes!
	return true;
}



void GuiBitmapButtonCtrl::onSleep()
{
	// Make all bitmap controls doze off
	mBitmapButtonUp.onSleep();
	mBitmapButtonDown.onSleep();
	mBitmapButtonActive.onSleep();

	// Pass function to parent class
	Parent::onSleep();
}



void GuiBitmapButtonCtrl::setBitmap(const int type, const char *name)
{
	// Check if it's ButtonUp
	if( type == BITMAP_BUTTON_UP )
	{
		mBitmapButtonUp.setBitmap(name);
	}
	// Check if it's ButtonDown
	else if( type == BITMAP_BUTTON_DOWN )
	{
		mBitmapButtonDown.setBitmap(name);
	}
	// Check if it's ButtonActive
	else if( type == BITMAP_BUTTON_ACTIVE )
	{
		mBitmapButtonActive.setBitmap(name);
	}
}



void GuiBitmapButtonCtrl::setBitmap(const int type, const TextureHandle &handle)
{
	// Check if it's ButtonUp
	if( type == BITMAP_BUTTON_UP )
	{
		mBitmapButtonUp.setBitmap(handle);
	}
	// Check if it's ButtonDown
	else if( type == BITMAP_BUTTON_DOWN )
	{
		mBitmapButtonDown.setBitmap(handle);
	}
	// Check if it's ButtonActive
	else if( type == BITMAP_BUTTON_ACTIVE )
	{
		mBitmapButtonActive.setBitmap(handle);
	}
}   



void GuiBitmapButtonCtrl::onRender(Point2I offset, const RectI &updateRect)
{
	// Check if the button is pressed (ButtonDown)
	if( mDepressed )
	{
		mBitmapButtonDown.onRender(offset, updateRect);
	}
	// Check if the mouse is above the button (ButtonActive)
	else if( mMouseOver )
	{
		mBitmapButtonActive.onRender(offset, updateRect);
	}
	// Otherwise it's just the normal button (ButtonUp)
	else
	{
		mBitmapButtonUp.onRender(offset, updateRect);
	}
}




void GuiBitmapButtonCtrl::setValue(S32 x, S32 y)
{
	// Pass the function on to all the bitmap controls
	mBitmapButtonUp.setValue(x, y);
	mBitmapButtonDown.setValue(x, y);
	mBitmapButtonActive.setValue(x, y);
}
