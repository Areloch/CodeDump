//--- OBJECT WRITE BEGIN ---
datablock sgMissionLightingFilterData(test) {
   canSaveDynamicFields = "1";
   className = "sgMissionLightingFilterData";
   CinematicFilter = "1";
   LightingIntensity = "1.24138";
   LightingFilter = "1 1 1 1";
   CinematicFilterAmount = "0.735632";
   CinematicFilterReferenceIntensity = "0";
   CinematicFilterReferenceColor = "1 1 1 1";
};
//--- OBJECT WRITE END ---



