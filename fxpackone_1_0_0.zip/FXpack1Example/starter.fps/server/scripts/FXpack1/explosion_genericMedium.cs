//-----------------------------------------------------------------------------
//	Particles
//-----------------------------------------------------------------------------


datablock ParticleData(GenericMediumSubFireball)
{
   textureName          = "~/data/shapes/particles/FXpack1/explosion";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = -5;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 350;
   lifetimeVarianceMS   = 100;
   useInvAlpha =  false;
   spinRandomMin = -280.0;
   spinRandomMax =  280.0;

   colors[0]     = "1.0 0.9 0.8 0.1";
   colors[1]     = "1.0 0.5 0.0 0.3";
   colors[2]     = "0.1 0.1 0.1 0.0";

   sizes[0]      = 1.0;
   sizes[1]      = 6.0;
   sizes[2]      = 8.0;

   times[0]      = 0.0;
   times[1]      = 0.2;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(GenericMediumSubFireballEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 5;
   ejectionVelocity = 3.5;
   velocityVariance = 2.0;
   thetaMin         = 0.0;
   thetaMax         = 120.0;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   ejectionoffset   = 4;
   particles = "GenericMediumSubFireball";
};

datablock ParticleData(GenericMediumSubSmoke)
{
   textureName          = "~/data/shapes/particles/FXpack1/smoke01";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = -1.5;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 800;
   lifetimeVarianceMS   = 200;
   useInvAlpha =  true;
   spinRandomMin = -60.0;
   spinRandomMax =  60.0;

   colors[0]     = "0.8 0.7 0.6 0.2";
   colors[1]     = "0.5 0.5 0.5 0.8";
   colors[2]     = "0.1 0.1 0.1 0.0";

   sizes[0]      = 3.0;
   sizes[1]      = 12.0;
   sizes[2]      = 20.0;

   times[0]      = 0.0;
   times[1]      = 0.25;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(GenericMediumSubSmokeEmitter)
{
   ejectionPeriodMS = 20;
   periodVarianceMS = 10;
   ejectionVelocity = 4.0;
   velocityVariance = 2.0;
   thetaMin         = 0.0;
   thetaMax         = 90.0;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   ejectionoffset   = 3;
   particles = "GenericMediumSubSmoke";
};

datablock ParticleData(GenericMediumSparks)
{
   textureName          = "~/data/shapes/particles/FXpack1/spark";
   gravityCoefficient   = 1.0;
   inheritedVelFactor   = 0.4;
   lifetimeMS           = 200;
   lifetimeVarianceMS   = 50;
   useInvAlpha =  false;
   spinRandomMin = -0.0;
   spinRandomMax =  0.0;

   colors[0]     = "1.0 0.9 0.8 0.2";
   colors[1]     = "1.0 0.9 0.8 0.8";
   colors[2]     = "0.8 0.4 0.0 0.0";

   sizes[0]      = 1.0;
   sizes[1]      = 4.0;
   sizes[2]      = 1.0;

   times[0]      = 0.0;
   times[1]      = 0.35;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(GenericMediumSparksEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 2;
   ejectionVelocity = 60;
   velocityVariance = 4;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   orientParticles  = true;
   orientOnVelocity = true;
   particles = "GenericMediumSparks";
};

datablock ParticleData(GenericMediumSmoke)
{
   textureName          = "~/data/shapes/particles/FXpack1/smoke01";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = -0.4;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 1000;
   lifetimeVarianceMS   = 600;
   useInvAlpha =  true;
   spinRandomMin = -80.0;
   spinRandomMax =  80.0;

   colors[0]     = "0.9 0.8 0.7 0.0";
   colors[1]     = "0.2 0.2 0.2 0.8";
   colors[2]     = "0.4 0.4 0.4 0.0";

   sizes[0]      = 6.0;
   sizes[1]      = 10.0;
   sizes[2]      = 20.0;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(GenericMediumSmokeEmitter)
{
   ejectionPeriodMS = 15;
   periodVarianceMS = 5;
   ejectionVelocity = 4.8;
   velocityVariance = 2.0;
   thetaMin         = 0.0;
   thetaMax         = 180.0;
   ejectionOffset   = 2;
   particles = "GenericMediumSmoke";
};

datablock ParticleData(GenericMediumFireball)
{
   textureName          = "~/data/shapes/particles/FXpack1/explosion";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = -0.5;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 400;
   lifetimeVarianceMS   = 200;
   useInvAlpha =  false;
   spinRandomMin = -180.0;
   spinRandomMax =  180.0;

   colors[0]     = "1.0 0.9 0.8 0.9";
   colors[1]     = "0.8 0.4 0 0.3";
   colors[2]     = "0.0 0.0 0.0 0.0";

   sizes[0]      = 4.5;
   sizes[1]      = 18.0;
   sizes[2]      = 9.5;

   times[0]      = 0.0;
   times[1]      = 0.35;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(GenericMediumFireballEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 5;
   ejectionVelocity = 3;
   velocityVariance = 2;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   particles = "GenericMediumFireball";
};



//-----------------------------------------------------------------------------
//	Explosions
//-----------------------------------------------------------------------------


datablock ExplosionData(GenericMediumSubExplosion1)
{
   lifeTimeMS = 100;
   offset = 0.5;
   emitter[0] = GenericMediumSubFireballEmitter;
};


datablock ExplosionData(GenericMediumSubExplosion2)
{
   lifeTimeMS = 100;
   offset = 1.2;
   emitter[0] = GenericMediumSubFireballEmitter;
   emitter[1] = GenericMediumSubSmokeEmitter;
};



datablock ExplosionData(GenericMediumExplosion)
{
   //soundProfile = CrossbowExplosionSound;
   lifeTimeMS = 100;

   // Volume
   particleEmitter = GenericMediumSmokeEmitter;
   particleDensity = 10;
   particleRadius = 1;

   // Point emission
   emitter[0] = GenericMediumFireballEmitter; 
   emitter[1] = GenericMediumSubFireballEmitter; 
   emitter[2] = GenericMediumSparksEmitter;
   emitter[3] = GenericMediumSparksEmitter;  


   // Sub explosions
   subExplosion[0] = GenericMediumSubExplosion1;
   subExplosion[1] = GenericMediumSubExplosion2;
   
};