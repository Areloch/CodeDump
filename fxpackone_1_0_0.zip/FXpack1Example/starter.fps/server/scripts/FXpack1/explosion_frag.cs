//-----------------------------------------------------------------------------
//	Particles
//-----------------------------------------------------------------------------

datablock ParticleData(FragDebrisTrail)
{
   textureName          = "~/data/shapes/particles/FXpack1/smoke01";
   gravityCoefficient   = 0;
   lifetimeMS           = 1200;
   lifetimeVarianceMS   = 600;
   spinRandomMin = -180.0;
   spinRandomMax =  180.0;
   useInvAlpha   = true;

   colors[0]     = "1.0 0.9 0.8 0.2";
   colors[1]     = "0.8 0.8 0.8 0.3";
   colors[2]     = "0.4 0.4 0.4 0.0";

   sizes[0]      = 0.4;
   sizes[1]      = 2.0;
   sizes[2]      = 4.0;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(FragDebrisTrailEmitter)
{
   ejectionPeriodMS = 6;
   periodVarianceMS = 2;
   ejectionVelocity = 1.0;
   velocityVariance = 0.8;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   particles = "FragDebrisTrail";
};

datablock ParticleData(FragSubFireball)
{
   textureName          = "~/data/shapes/particles/FXpack1/FXpack1/explosion";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = -3;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 300;
   lifetimeVarianceMS   = 100;
   useInvAlpha =  false;
   spinRandomMin = -280.0;
   spinRandomMax =  280.0;

   colors[0]     = "1.0 0.9 0.8 0.1";
   colors[1]     = "1.0 0.5 0.0 0.3";
   colors[2]     = "0.1 0.1 0.1 0.0";

   sizes[0]      = 1.0;
   sizes[1]      = 2.0;
   sizes[2]      = 3.0;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(FragSubFireballEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 5;
   ejectionVelocity = 3.5;
   velocityVariance = 2.0;
   thetaMin         = 0.0;
   thetaMax         = 120.0;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   ejectionoffset   = 2;
   particles = "FragSubFireball";
};

datablock ParticleData(FragSubSmoke)
{
   textureName          = "~/data/shapes/particles/FXpack1/FXpack1/smoke01";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = -0.4;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 700;
   lifetimeVarianceMS   = 200;
   useInvAlpha =  false;
   spinRandomMin = -120.0;
   spinRandomMax =  120.0;

   colors[0]     = "0.8 0.7 0.6 0.3";
   colors[1]     = "0.9 0.9 0.9 0.8";
   colors[2]     = "0.9 0.9 0.9 0.0";

   sizes[0]      = 2.0;
   sizes[1]      = 4.0;
   sizes[2]      = 7.0;

   times[0]      = 0.0;
   times[1]      = 0.25;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(FragSubSmokeEmitter)
{
   ejectionPeriodMS = 30;
   periodVarianceMS = 10;
   ejectionVelocity = 1.5;
   velocityVariance = 0.5;
   thetaMin         = 0.0;
   thetaMax         = 90.0;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   ejectionoffset   = 2;
   particles = "FragSubSmoke";
};

datablock ParticleData(FragSparks)
{
   textureName          = "~/data/shapes/particles/FXpack1/FXpack1/spark";
   gravityCoefficient   = 0.0;
   inheritedVelFactor   = 0.4;
   lifetimeMS           = 100;
   lifetimeVarianceMS   = 10;
   useInvAlpha =  false;
   spinRandomMin = -0.0;
   spinRandomMax =  0.0;

   colors[0]     = "1.0 0.9 0.8 0.2";
   colors[1]     = "1.0 0.9 0.8 0.8";
   colors[2]     = "0.8 0.4 0.0 0.0";

   sizes[0]      = 1.0;
   sizes[1]      = 2.5;
   sizes[2]      = 2.0;

   times[0]      = 0.0;
   times[1]      = 0.35;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(FragSparksEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 2;
   ejectionVelocity = 60;
   velocityVariance = 4;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   orientParticles  = true;
   orientOnVelocity = true;
   particles = "FragSparks";
};

datablock ParticleData(FragSmoke)
{
   textureName          = "~/data/shapes/particles/FXpack1/FXpack1/smoke01";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = -0.1;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 1200;
   lifetimeVarianceMS   = 600;
   useInvAlpha =  true;
   spinRandomMin = -80.0;
   spinRandomMax =  80.0;

   colors[0]     = "0.9 0.8 0.7 0.1";
   colors[1]     = "0.9 0.9 0.9 0.8";
   colors[2]     = "0.9 0.9 0.9 0.0";

   sizes[0]      = 2.0;
   sizes[1]      = 5.0;
   sizes[2]      = 8.0;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(FragSmokeEmitter)
{
   ejectionPeriodMS = 15;
   periodVarianceMS = 5;
   ejectionVelocity = 2.0;
   velocityVariance = 1.0;
   thetaMin         = 0.0;
   thetaMax         = 180.0;
   ejectionOffset   = 1;
   particles = "FragSmoke";
};

datablock ParticleData(FragFireball)
{
   textureName          = "~/data/shapes/particles/FXpack1/FXpack1/explosion";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = -0.5;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 400;
   lifetimeVarianceMS   = 200;
   useInvAlpha =  false;
   spinRandomMin = -180.0;
   spinRandomMax =  180.0;

   colors[0]     = "1.0 0.9 0.8 0.9";
   colors[1]     = "0.8 0.4 0 0.3";
   colors[2]     = "0.0 0.0 0.0 0.0";

   sizes[0]      = 2.0;
   sizes[1]      = 7.0;
   sizes[2]      = 4.0;

   times[0]      = 0.0;
   times[1]      = 0.35;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(FragFireballEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 5;
   ejectionVelocity = 3;
   velocityVariance = 2;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   particles = "FragFireball";
};

//-----------------------------------------------------------------------------
//	Explosion
//-----------------------------------------------------------------------------

// Frag Debris

datablock DebrisData(FragDebris)
{
   shapeFile = "~/data/shapes/explosiondebris/invisible.dts";
   emitters = "FragDebrisTrailEmitter";
   
   elasticity = 0.6;
   friction = 0.5;
   numBounces = 1;
   bounceVariance = 1;
   explodeOnMaxBounce = true;
   staticOnMaxBounce = false;
   snapOnMaxBounce = false;
   minSpinSpeed = 300;
   maxSpinSpeed = 700;
   render2D = false;
   lifetime = 0.15;
   lifetimeVariance = 0.0;
   velocity = 40;
   velocityVariance = 10;
   fade = true;
   useRadiusMass = true;
   baseRadius = 0.3;
   gravModifier = 0;
   terminalVelocity = 40;
   ignoreWater = false;
};

//Frag Sub Explosions

datablock ExplosionData(FragSubExplosion1)
{
   lifeTimeMS = 80;
   offset = 0.2;
   emitter[0] = FragSubFireballEmitter;
};


datablock ExplosionData(FragSubExplosion2)
{
   lifeTimeMS = 80;
   offset = 0.5;
   emitter[0] = FragSubFireballEmitter;
   emitter[1] = FragSubSmokeEmitter;
};



datablock ExplosionData(FragExplosion)
{
   //soundProfile = CrossbowExplosionSound;
   lifeTimeMS = 80;

   // Volume
   particleEmitter = FragSmokeEmitter;
   particleDensity = 10;
   particleRadius = 0.6;

   // Point emission
   emitter[0] = FragFireballEmitter; 
   emitter[1] = FragSubFireballEmitter; 
   emitter[2] = FragSparksEmitter;
   emitter[3] = FragSparksEmitter; 


   // Sub explosions
   subExplosion[0] = FragSubExplosion1;
   subExplosion[1] = FragSubExplosion2;
   

   // Exploding debris
   debris = FragDebris;
   debrisThetaMin = 0;
   debrisThetaMax = 90;
   debrisPhiMin = 0;
   debrisPhiMax = 360;
   debrisNum = 8;
   debrisNumVariance = 2;
   debrisVelocity = 1;
   debrisVelocityVariance = 0.2;
};