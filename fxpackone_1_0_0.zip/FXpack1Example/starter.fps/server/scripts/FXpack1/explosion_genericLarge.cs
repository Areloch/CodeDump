//-----------------------------------------------------------------------------
//	Particles
//-----------------------------------------------------------------------------


datablock ParticleData(GenericLargeSubFireball)
{
   textureName          = "~/data/shapes/particles/FXpack1/explosion";
   gravityCoefficient   = -4;
   lifetimeMS           = 500;
   lifetimeVarianceMS   = 200;
   useInvAlpha =  false;
   spinRandomMin = -280.0;
   spinRandomMax =  280.0;

   colors[0]     = "1.0 0.9 0.8 0.1";
   colors[1]     = "1.0 0.5 0.0 0.3";
   colors[2]     = "0.1 0.1 0.1 0.0";

   sizes[0]      = 8.0;
   sizes[1]      = 16.0;
   sizes[2]      = 12.0;

   times[0]      = 0.0;
   times[1]      = 0.35;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(GenericLargeSubFireballEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 5;
   ejectionVelocity = 5.0;
   velocityVariance = 3.0;
   thetaMin         = 0.0;
   thetaMax         = 120.0;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   ejectionoffset   = 8;
   particles = "GenericLargeSubFireball";
};

datablock ParticleData(GenericLargeSubSmoke)
{
   textureName          = "~/data/shapes/particles/FXpack1/smoke01";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = -1.5;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 1200;
   lifetimeVarianceMS   = 400;
   useInvAlpha =  true;
   spinRandomMin = -60.0;
   spinRandomMax =  60.0;

   colors[0]     = "0.4 0.3 0.2 0.2";
   colors[1]     = "0.5 0.5 0.5 0.8";
   colors[2]     = "0.1 0.1 0.1 0.0";

   sizes[0]      = 4.0;
   sizes[1]      = 16.0;
   sizes[2]      = 24.0;

   times[0]      = 0.0;
   times[1]      = 0.25;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(GenericLargeSubSmokeEmitter)
{
   ejectionPeriodMS = 20;
   periodVarianceMS = 10;
   ejectionVelocity = 6.0;
   velocityVariance = 3.0;
   thetaMin         = 0.0;
   thetaMax         = 120.0;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   ejectionoffset   = 7;
   particles = "GenericLargeSubSmoke";
};

datablock ParticleData(GenericLargeSparks)
{
   textureName          = "~/data/shapes/particles/FXpack1/spark";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = 1.0;
   inheritedVelFactor   = 0.4;
   constantAcceleration = 0.0;
   lifetimeMS           = 200;
   lifetimeVarianceMS   = 100;
   useInvAlpha =  false;
   spinRandomMin = -0.0;
   spinRandomMax =  0.0;

   colors[0]     = "1.0 0.9 0.8 0.0";
   colors[1]     = "1.0 0.9 0.8 0.8";
   colors[2]     = "0.8 0.4 0.0 0.0";

   sizes[0]      = 2.0;
   sizes[1]      = 7.0;
   sizes[2]      = 2.0;

   times[0]      = 0.0;
   times[1]      = 0.35;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(GenericLargeSparksEmitter)
{
   ejectionPeriodMS = 4;
   periodVarianceMS = 2;
   ejectionVelocity = 90;
   velocityVariance = 4;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   orientParticles  = true;
   orientOnVelocity = true;
   particles = "GenericLargeSparks";
};

datablock ParticleData(GenericLargeSmoke)
{
   textureName          = "~/data/shapes/particles/FXpack1/smoke01";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = -0.4;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 1200;
   lifetimeVarianceMS   = 400;
   useInvAlpha =  true;
   spinRandomMin = -80.0;
   spinRandomMax =  80.0;

   colors[0]     = "0.4 0.3 0.2 0.3";
   colors[1]     = "0.2 0.2 0.2 1.0";
   colors[2]     = "0.4 0.4 0.4 0.0";

   sizes[0]      = 12.0;
   sizes[1]      = 24.0;
   sizes[2]      = 36.0;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(GenericLargeSmokeEmitter)
{
   ejectionPeriodMS = 15;
   periodVarianceMS = 5;
   ejectionVelocity = 4.8;
   velocityVariance = 2.0;
   thetaMin         = 0.0;
   thetaMax         = 180.0;
   ejectionOffset   = 3;
   particles = "GenericLargeSmoke";
};

datablock ParticleData(GenericLargeFireball)
{
   textureName          = "~/data/shapes/particles/FXpack1/explosion";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = -0.5;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 500;
   lifetimeVarianceMS   = 200;
   useInvAlpha =  false;
   spinRandomMin = -180.0;
   spinRandomMax =  180.0;

   colors[0]     = "1.0 0.9 0.8 0.9";
   colors[1]     = "0.8 0.4 0 0.3";
   colors[2]     = "0.0 0.0 0.0 0.0";

   sizes[0]      = 15.0;
   sizes[1]      = 30.0;
   sizes[2]      = 10.0;

   times[0]      = 0.0;
   times[1]      = 0.35;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(GenericLargeFireballEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 5;
   ejectionVelocity = 3;
   velocityVariance = 2;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   lifetimeMS       = 250;
   particles = "GenericLargeFireball";
};


//-----------------------------------------------------------------------------
//	Explosions
//-----------------------------------------------------------------------------


datablock ExplosionData(GenericLargeSubExplosion1)
{
   lifeTimeMS = 100;
   offset = 1;
   emitter[0] = GenericLargeSubFireballEmitter;
   emitter[1] = GenericLargeSubSmokeEmitter; 
};


datablock ExplosionData(GenericLargeSubExplosion2)
{
   lifeTimeMS = 100;
   offset = 3;
   emitter[0] = GenericLargeSubFireballEmitter;
   emitter[1] = GenericLargeSubSmokeEmitter;
};



datablock ExplosionData(GenericLargeExplosion)
{
   //soundProfile = CrossbowExplosionSound;
   lifeTimeMS = 100;

   // Volume
   particleEmitter = GenericLargeSmokeEmitter;
   particleDensity = 10;
   particleRadius = 1;

   // Point emission
   emitter[0] = GenericLargeFireballEmitter; 
   emitter[1] = GenericLargeSubFireballEmitter; 
   emitter[2] = GenericLargeSparksEmitter; 
   emitter[3] = GenericLargeSparksEmitter;


   // Sub explosions
   subExplosion[0] = GenericLargeSubExplosion1;
   subExplosion[1] = GenericLargeSubExplosion2;
   
};