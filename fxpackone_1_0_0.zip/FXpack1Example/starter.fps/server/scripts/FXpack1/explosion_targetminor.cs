//-----------------------------------------------------------------------------
//	Particles
//-----------------------------------------------------------------------------

//Primary Explosion

datablock ParticleData(TargetMinorBlast)
{
   textureName          = "~/data/shapes/particles/FXpack1/dirtblast01";
   dragCoefficient      = 5;
   gravityCoefficient   = 0.0;
   inheritedVelFactor   = 0.2;
   windCoefficient      = 0;
   constantAcceleration = 0;
   lifetimeMS           = 800;
   lifetimeVarianceMS   = 300;
   spinRandomMin = -20.0;
   spinRandomMax =  20.0;
   useInvAlpha   = true;

   colors[0]     = "1.0 0.9 0.8 0.5";
   colors[1]     = "0.9 0.8 0.7 1.0";
   colors[2]     = "1.0 1.0 1.0 0.0";

   sizes[0]      = 8.0;
   sizes[1]      = 15.0;
   sizes[2]      = 30.0;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(TargetMinorBlastEmitter)
{
   ejectionPeriodMS = 8;
   periodVarianceMS = 5;
   ejectionVelocity = 80.0;
   velocityVariance = 10;
   ejectionOffset   = 0.4;
   thetaMin         = 10;
   thetaMax         = 55;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   orientParticles  = true;
   orientOnVelocity = true;
   particles = "TargetMinorBlast";
};

datablock ParticleData(TargetMinorSubFireball)
{
   textureName          = "~/data/shapes/particles/FXpack1/explosion";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = -3;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 400;
   lifetimeVarianceMS   = 200;
   useInvAlpha =  false;
   spinRandomMin = -280.0;
   spinRandomMax =  280.0;

   colors[0]     = "1.0 0.9 0.8 0.1";
   colors[1]     = "1.0 0.5 0.0 0.3";
   colors[2]     = "0.1 0.1 0.1 0.0";

   sizes[0]      = 4.0;
   sizes[1]      = 12.0;
   sizes[2]      = 7.0;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(TargetMinorSubFireballEmitter)
{
   ejectionPeriodMS = 20;
   periodVarianceMS = 10;
   ejectionVelocity = 5.0;
   velocityVariance = 3.0;
   thetaMin         = 0.0;
   thetaMax         = 90.0;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   ejectionoffset   = 4;
   particles = "TargetMinorSubFireball";
};

datablock ParticleData(TargetMinorSubSmoke)
{
   textureName          = "~/data/shapes/particles/FXpack1/smoke02";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = -0.5;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 1200;
   lifetimeVarianceMS   = 400;
   useInvAlpha =  true;
   spinRandomMin = -60.0;
   spinRandomMax =  60.0;

   colors[0]     = "1.0 0.9 0.8 0.2";
   colors[1]     = "0.5 0.5 0.5 0.7";
   colors[2]     = "0.1 0.1 0.1 0.0";

   sizes[0]      = 4.0;
   sizes[1]      = 18.0;
   sizes[2]      = 32.0;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(TargetMinorSubSmokeEmitter)
{
   ejectionPeriodMS = 20;
   periodVarianceMS = 10;
   ejectionVelocity = 10.0;
   velocityVariance = 3.0;
   thetaMin         = 0.0;
   thetaMax         = 90.0;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   ejectionoffset   = 7;
   particles = "TargetMinorSubSmoke";
};

datablock ParticleData(TargetMinorSparks)
{
   textureName          = "~/data/shapes/particles/FXpack1/spark";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = 1.0;
   inheritedVelFactor   = 0.4;
   constantAcceleration = 0.0;
   lifetimeMS           = 250;
   lifetimeVarianceMS   = 100;
   useInvAlpha =  false;
   spinRandomMin = -0.0;
   spinRandomMax =  0.0;

   colors[0]     = "1.0 0.9 0.8 0.2";
   colors[1]     = "1.0 0.9 0.8 0.55";
   colors[2]     = "0.8 0.4 0.0 0.0";

   sizes[0]      = 2.0;
   sizes[1]      = 6.0;
   sizes[2]      = 2.0;

   times[0]      = 0.0;
   times[1]      = 0.35;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(TargetMinorSparksEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 2;
   ejectionVelocity = 60;
   velocityVariance = 4;
   thetaMin         = 0;
   thetaMax         = 80;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   orientParticles  = true;
   orientOnVelocity = true;
   particles = "TargetMinorSparks";
};

datablock ParticleData(TargetMinorSmoke)
{
   textureName          = "~/data/shapes/particles/FXpack1/smoke01";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = -0.4;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 1200;
   lifetimeVarianceMS   = 800;
   useInvAlpha =  true;
   spinRandomMin = -80.0;
   spinRandomMax =  80.0;

   colors[0]     = "1.0 0.8 0.6 0.0";
   colors[1]     = "0.3 0.3 0.3 0.9";
   colors[2]     = "1.0 1.0 1.0 0.0";

   sizes[0]      = 12.0;
   sizes[1]      = 18.0;
   sizes[2]      = 24.0;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(TargetMinorSmokeEmitter)
{
   ejectionPeriodMS = 20;
   periodVarianceMS = 10;
   ejectionVelocity = 4.8;
   velocityVariance = 2.0;
   thetaMin         = 0.0;
   thetaMax         = 180.0;
   ejectionOffset   = 5;
   particles = "TargetMinorSmoke";
};

datablock ParticleData(TargetMinorFireball)
{
   textureName          = "~/data/shapes/particles/FXpack1/explosion";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = -0.5;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 500;
   lifetimeVarianceMS   = 200;
   useInvAlpha =  false;
   spinRandomMin = -180.0;
   spinRandomMax =  180.0;

   colors[0]     = "1.0 0.9 0.8 0.9";
   colors[1]     = "0.8 0.4 0 0.3";
   colors[2]     = "0.0 0.0 0.0 0.0";

   sizes[0]      = 12.0;
   sizes[1]      = 20.0;
   sizes[2]      = 8.0;

   times[0]      = 0.0;
   times[1]      = 0.35;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(TargetMinorFireballEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 5;
   ejectionVelocity = 3;
   velocityVariance = 2;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   lifetimeMS       = 250;
   particles = "TargetMinorFireball";
};




//-----------------------------------------------------------------------------
//	Explosions
//-----------------------------------------------------------------------------

datablock DebrisData(TargetMinorDebris)
{
   shapeFile = "~/data/shapes/explosiondebris/invisible.dts";
   emitters[0] = "TargetDebrisFireEmitter";
   emitters[1] = "TargetDebrisSmokeEmitter";
   
   elasticity = 0.6;
   friction = 0.5;
   numBounces = 1;
   bounceVariance = 1;
   explodeOnMaxBounce = true;
   staticOnMaxBounce = false;
   snapOnMaxBounce = false;
   minSpinSpeed = 300;
   maxSpinSpeed = 700;
   render2D = false;
   lifetime = 3.0;
   lifetimeVariance = 0.3;
   velocity = 60;
   velocityVariance = 20;
   fade = false;
   useRadiusMass = true;
   baseRadius = 0.3;
   gravModifier = 6;
   terminalVelocity = 0;
   ignoreWater = false;
};


datablock ExplosionData(TargetMinorSubExplosion1)
{
   lifeTimeMS = 100;
   offset = 0; 
   emitter[0] = TargetMinorBlastEmitter;
};


datablock ExplosionData(TargetMinorSubExplosion2)
{
   lifeTimeMS = 100;
   offset = 2;
   emitter[0] = TargetMinorSubFireballEmitter;
   emitter[1] = TargetMinorSubSmokeEmitter; 
};


datablock ExplosionData(TargetMinorSubExplosion3)
{
   lifeTimeMS = 100;
   offset = 4;
   emitter[0] = TargetMinorSubFireballEmitter;
};



datablock ExplosionData(TargetMinorExplosion)
{
   //soundProfile = CrossbowExplosionSound;
   lifeTimeMS = 100;

   // Volume
   particleEmitter = TargetMinorSmokeEmitter;
   particleDensity = 20;
   particleRadius = 1;

   // Point emission
   emitter[0] = TargetMinorFireballEmitter; 
   emitter[1] = TargetMinorSubFireballEmitter; 
   emitter[2] = TargetMinorSparksEmitter; 
   emitter[3] = TargetMinorSparksEmitter;


   // Sub explosions
   subExplosion[0] = TargetMinorSubExplosion1;
   subExplosion[1] = TargetMinorSubExplosion2;
   subExplosion[2] = TargetMinorSubExplosion3;
   

   // Exploding debris
   debris = TargetMinorDebris;
   debrisThetaMin = 0;
   debrisThetaMax = 60;
   debrisPhiMin = 0;
   debrisPhiMax = 360;
   debrisNum = 5;
   debrisNumVariance = 2;
   debrisVelocity = 1;
   debrisVelocityVariance = 0.5;

};