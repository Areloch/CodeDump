//-----------------------------------------------------------------------------
//	Particles
//-----------------------------------------------------------------------------


datablock ParticleData(GroundMajorBlast1)
{
   textureName          = "~/data/shapes/particles/FXpack1/dirtblast02";
   dragCoefficient      = 5;
   gravityCoefficient   = 0.0;
   inheritedVelFactor   = 0.2;
   windCoefficient      = 0;
   constantAcceleration = 0;
   lifetimeMS           = 1400;
   lifetimeVarianceMS   = 200;
   spinRandomMin = -40.0;
   spinRandomMax =  40.0;
   useInvAlpha   = true;

   colors[0]     = "1.0 0.9 0.8 0.6";
   colors[1]     = "0.9 0.8 0.7 0.4";
   colors[2]     = "1.0 1.0 1.0 0.0";

   sizes[0]      = 10.0;
   sizes[1]      = 25.0;
   sizes[2]      = 40.0;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(GroundMajorBlast1Emitter)
{
   ejectionPeriodMS = 20;
   periodVarianceMS = 10;
   ejectionVelocity = 145.0;
   velocityVariance = 20.0;
   ejectionOffset   = 0.4;
   thetaMin         = 0;
   thetaMax         = 10;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   orientParticles  = true;
   orientOnVelocity = true;
   particles = "GroundMajorBlast1";
};

datablock ParticleData(GroundMajorBlast2)
{
   textureName          = "~/data/shapes/particles/FXpack1/dirtblast01";
   dragCoefficient      = 5;
   gravityCoefficient   = 0.0;
   inheritedVelFactor   = 0.2;
   windCoefficient      = 0;
   constantAcceleration = 0;
   lifetimeMS           = 1600;
   lifetimeVarianceMS   = 300;
   spinRandomMin = -20.0;
   spinRandomMax =  20.0;
   useInvAlpha   = true;

   colors[0]     = "1.0 0.9 0.8 0.9";
   colors[1]     = "0.9 0.8 0.7 0.7";
   colors[2]     = "1.0 1.0 1.0 0.0";

   sizes[0]      = 16.0;
   sizes[1]      = 32.0;
   sizes[2]      = 60.0;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(GroundMajorBlast2Emitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 4;
   ejectionVelocity = 120.0;
   velocityVariance = 20.0;
   ejectionOffset   = 0.4;
   thetaMin         = 10;
   thetaMax         = 30;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   orientParticles  = true;
   orientOnVelocity = true;
   particles = "GroundMajorBlast2";
};

datablock ParticleData(GroundMajorBlast3)
{
   textureName          = "~/data/shapes/particles/FXpack1/dirtblast01";
   dragCoefficient      = 5;
   gravityCoefficient   = 0.0;
   inheritedVelFactor   = 0.2;
   windCoefficient      = 0;
   constantAcceleration = 0;
   lifetimeMS           = 1600;
   lifetimeVarianceMS   = 300;
   spinRandomMin = -20.0;
   spinRandomMax =  20.0;
   useInvAlpha   = true;

   colors[0]     = "1.0 0.9 0.8 0.9";
   colors[1]     = "0.9 0.8 0.7 0.7";
   colors[2]     = "1.0 1.0 1.0 0.0";

   sizes[0]      = 16.0;
   sizes[1]      = 32.0;
   sizes[2]      = 60.0;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(GroundMajorBlast3Emitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 4;
   ejectionVelocity = 100.0;
   velocityVariance = 20.0;
   ejectionOffset   = 0.4;
   thetaMin         = 30;
   thetaMax         = 70;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   orientParticles  = true;
   orientOnVelocity = true;
   particles = "GroundMajorBlast3";
};


datablock ParticleData(GroundMajorRocks)
{
   textureName          = "~/data/shapes/particles/FXpack1/rocks";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = 5.0;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 1200;
   lifetimeVarianceMS   = 400;
   useInvAlpha =  true;
   spinRandomMin = -180.0;
   spinRandomMax =  180.0;

   colors[0]     = "1.0 0.8 0.6 1.0";
   colors[1]     = "0.3 0.3 0.3 0.7";
   colors[2]     = "0.3 0.3 0.3 0.0";

   sizes[0]      = 2.0;
   sizes[1]      = 4.0;
   sizes[2]      = 6.0;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(GroundMajorRocksEmitter)
{
   ejectionPeriodMS = 1;
   periodVarianceMS = 0;
   ejectionVelocity = 50.0;
   velocityVariance = 10.0;
   thetaMin         = 0.0;
   thetaMax         = 20.0;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   particles = "GroundMajorRocks";
};

datablock ParticleData(GroundMajorFireball)
{
   textureName          = "~/data/shapes/particles/FXpack1/explosion";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = -5.5;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 400;
   lifetimeVarianceMS   = 100;
   useInvAlpha =  false;
   spinRandomMin = -280.0;
   spinRandomMax =  280.0;

   colors[0]     = "1.0 0.9 0.8 0.2";
   colors[1]     = "1.0 0.5 0.0 0.5";
   colors[2]     = "0.1 0.1 0.1 0.0";

   sizes[0]      = 6.0;
   sizes[1]      = 18.0;
   sizes[2]      = 10.0;

   times[0]      = 0.0;
   times[1]      = 0.2;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(GroundMajorFireballEmitter)
{
   ejectionPeriodMS = 50;
   periodVarianceMS = 20;
   ejectionVelocity = 5.0;
   velocityVariance = 1.0;
   thetaMin         = 0.0;
   thetaMax         = 60.0;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   ejectionoffset   = 5;
   particles = "GroundMajorFireball";
};

datablock ParticleData(GroundMajorDirt)
{
   textureName          = "~/data/shapes/particles/FXpack1/dirt";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = 4.0;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 1200;
   lifetimeVarianceMS   = 400;
   useInvAlpha =  true;
   spinRandomMin = -60.0;
   spinRandomMax =  60.0;

   colors[0]     = "1.0 0.8 0.6 0.8";
   colors[1]     = "0.3 0.3 0.3 0.5";
   colors[2]     = "0.1 0.1 0.1 0.0";

   sizes[0]      = 10.0;
   sizes[1]      = 20.0;
   sizes[2]      = 30.0;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(GroundMajorDirtEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 5;
   ejectionVelocity = 40.0;
   velocityVariance = 10.0;
   thetaMin         = 0.0;
   thetaMax         = 20.0;
   particles = "GroundMajorDirt";
};


datablock ParticleData(GroundMajorDust)
{
   textureName          = "~/data/shapes/particles/FXpack1/smoke02";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = -0.1;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 3000;
   lifetimeVarianceMS   = 200;
   useInvAlpha =  true;
   spinRandomMin = -40.0;
   spinRandomMax =  40.0;

   colors[0]     = "0.8 0.7 0.6 1.0";
   colors[1]     = "0.5 0.45 0.4 1.0";
   colors[2]     = "1.0 1.0 1.0 0.0";

   sizes[0]      = 10.0;
   sizes[1]      = 20.0;
   sizes[2]      = 50.0;

   times[0]      = 0.0;
   times[1]      = 0.1;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(GroundMajorDustEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 2;
   ejectionVelocity = 8.0;
   velocityVariance = 2.0;
   thetaMin         = 0.0;
   thetaMax         = 20.0;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   particles = "GroundMajorDust";
};

datablock ParticleData(GroundMajorPoint)
{
   textureName          = "~/data/shapes/particles/FXpack1/explosion";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = -0.5;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 500;
   lifetimeVarianceMS   = 200;
   useInvAlpha =  false;
   spinRandomMin = -180.0;
   spinRandomMax =  180.0;

   colors[0]     = "1.0 0.9 0.8 0.9";
   colors[1]     = "0.8 0.4 0 0.5";
   colors[2]     = "0.0 0.0 0.0 0.0";

   sizes[0]      = 10.0;
   sizes[1]      = 18.0;
   sizes[2]      = 0.0;

   times[0]      = 0.0;
   times[1]      = 0.2;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(GroundMajorPointEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 5;
   ejectionVelocity = 3;
   velocityVariance = 2;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   lifetimeMS       = 250;
   particles = "GroundMajorPoint";
};



//-----------------------------------------------------------------------------
//	Explosions
//-----------------------------------------------------------------------------

datablock ExplosionData(GroundMajorSubExplosion1)
{
   lifeTimeMS = 100;
   offset = 0;
   emitter[0] = GroundMajorBlast1Emitter;  
   emitter[1] = GroundMajorBlast2Emitter; 
   emitter[2] = GroundMajorBlast3Emitter; 
   emitter[3] = GroundMajorRocksEmitter;  
};



datablock ExplosionData(GroundMajorSubExplosion2)
{
   lifeTimeMS = 100;
   offset = 2;
   emitter[0] = GroundMajorFireballEmitter; 
   emitter[1] = GroundMajorDirtEmitter;
};



datablock ExplosionData(GroundMajorSubExplosion3)
{
   lifeTimeMS = 100;
   offset = 3;
   emitter[0] = GroundMajorFireballEmitter;  
   emitter[1] = GroundMajorDirtEmitter; 
};



datablock ExplosionData(GroundMajorExplosion)
{
   //soundProfile = CrossbowExplosionSound;
   lifeTimeMS = 120;

   // Volume - body of explosion
   particleEmitter = GroundMajorDustEmitter;
   particleDensity = 20;
   particleRadius = 1;

   // Point emission - effects at the origin of the explosion
   emitter[0] = GroundMajorPointEmitter; // main fireball
   emitter[1] = GroundMajorFireballEmitter; // smaller fireball


   // Sub explosions - secondary explosions
   subExplosion[0] = GroundMajorSubExplosion1;
   subExplosion[1] = GroundMajorSubExplosion2;
   subExplosion[2] = GroundMajorSubExplosion3;

};