//-----------------------------------------------------------------------------
//	Particles
//-----------------------------------------------------------------------------



datablock ParticleData(WaterMajorBlast1)
{
   textureName          = "~/data/shapes/particles/FXpack1/waterblast";
   dragCoefficient      = 5;
   gravityCoefficient   = 0.0;
   inheritedVelFactor   = 0.2;
   windCoefficient      = 0;
   constantAcceleration = 0;
   lifetimeMS           = 600;
   lifetimeVarianceMS   = 100;
   spinRandomMin = -20.0;
   spinRandomMax =  20.0;
   useInvAlpha   = true;

   colors[0]     = "1.0 1.0 1.0 0.3";
   colors[1]     = "1.0 1.0 1.0 0.5";
   colors[2]     = "1.0 1.0 1.0 0.0";

   sizes[0]      = 10.0;
   sizes[1]      = 30.0;
   sizes[2]      = 50.0;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(WaterMajorBlast1Emitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 5;
   ejectionVelocity = 70.0;
   velocityVariance = 0.5;
   ejectionOffset   = 0.4;
   thetaMin         = 10;
   thetaMax         = 50;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   orientParticles  = true;
   orientOnVelocity = true;
   particles = "WaterMajorBlast1";
};

datablock ParticleData(WaterMajorBlast2)
{
   textureName          = "~/data/shapes/particles/FXpack1/waterblast";
   dragCoefficient      = 5;
   gravityCoefficient   = 0.0;
   inheritedVelFactor   = 0.2;
   windCoefficient      = 0;
   constantAcceleration = 0;
   lifetimeMS           = 400;
   lifetimeVarianceMS   = 200;
   spinRandomMin = -20.0;
   spinRandomMax =  20.0;
   useInvAlpha   = false;

   colors[0]     = "1.0 1.0 1.0 0.2";
   colors[1]     = "1.0 1.0 1.0 0.1";
   colors[2]     = "1.0 1.0 1.0 0.0";

   sizes[0]      = 10.0;
   sizes[1]      = 30.0;
   sizes[2]      = 50.0;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(WaterMajorBlast2Emitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 5;
   ejectionVelocity = 95.0;
   velocityVariance = 0.5;
   ejectionOffset   = 0.4;
   thetaMin         = 0;
   thetaMax         = 5;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   orientParticles  = true;
   orientOnVelocity = true;
   particles = "WaterMajorBlast2";
};

datablock ParticleData(WaterMajorSpray1)
{
   textureName          = "~/data/shapes/particles/FXpack1/waterspray";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = 8.0;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 1000;
   lifetimeVarianceMS   = 400;
   useInvAlpha =  true;
   spinRandomMin = -180.0;
   spinRandomMax =  180.0;

   colors[0]     = "1.0 1.0 1.0 0.5";
   colors[1]     = "1.0 1.0 1.0 0.3";
   colors[2]     = "1.0 1.0 1.0 0.0";

   sizes[0]      = 4.0;
   sizes[1]      = 16.0;
   sizes[2]      = 24.0;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(WaterMajorSpray1Emitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 2;
   ejectionVelocity = 50.0;
   velocityVariance = 5.0;
   thetaMin         = 0.0;
   thetaMax         = 10.0;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   particles = "WaterMajorSpray1";
};

datablock ParticleData(WaterMajorSpray2)
{
   textureName          = "~/data/shapes/particles/FXpack1/waterspray";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = 8.0;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 1000;
   lifetimeVarianceMS   = 400;
   useInvAlpha =  true;
   spinRandomMin = -180.0;
   spinRandomMax =  180.0;

   colors[0]     = "1.0 1.0 1.0 0.5";
   colors[1]     = "1.0 1.0 1.0 0.3";
   colors[2]     = "1.0 1.0 1.0 0.0";

   sizes[0]      = 5.0;
   sizes[1]      = 20.0;
   sizes[2]      = 30.0;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(WaterMajorSpray2Emitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 2;
   ejectionVelocity = 45.0;
   velocityVariance = 5.0;
   thetaMin         = 10.0;
   thetaMax         = 40.0;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   particles = "WaterMajorSpray2";
};


datablock ParticleData(WaterMajorVolume)
{
   textureName          = "~/data/shapes/particles/FXpack1/watervapor";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = 2.0;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 1000;
   lifetimeVarianceMS   = 200;
   useInvAlpha =  true;
   spinRandomMin = -80.0;
   spinRandomMax =  80.0;

   colors[0]     = "1.0 1.0 1.0 0.75";
   colors[1]     = "1.0 1.0 1.0 0.4";
   colors[2]     = "1.0 1.0 1.0 0.0";

   sizes[0]      = 5.0;
   sizes[1]      = 20.0;
   sizes[2]      = 30.0;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(WaterMajorVolumeEmitter)
{
   ejectionPeriodMS = 15;
   periodVarianceMS = 5;
   ejectionVelocity = 7.0;
   velocityVariance = 2.0;
   thetaMin         = 0.0;
   thetaMax         = 50.0;
   particles = "WaterMajorVolume";
};



//-----------------------------------------------------------------------------
//	Explosion
//-----------------------------------------------------------------------------

datablock ExplosionData(WaterMajorExplosion)
{
   //soundProfile = CrossbowExplosionSound;
   lifeTimeMS = 100;

   // Volume
   particleEmitter = WaterMajorVolumeEmitter;
   particleDensity = 10;
   particleRadius = 1.5;

   // Point emission
   emitter[0] = WaterMajorBlast1Emitter;
   emitter[1] = WaterMajorBlast2Emitter;
   emitter[2] = WaterMajorSpray1Emitter;
   emitter[3] = WaterMajorSpray2Emitter;
   
};
