//-----------------------------------------------------------------------------
//	Particles
//-----------------------------------------------------------------------------


//Primary Explosion

datablock ParticleData(TargetMajorBlast)
{
   textureName          = "~/data/shapes/particles/FXpack1/dirtblast01";
   dragCoefficient      = 5;
   gravityCoefficient   = 0.0;
   inheritedVelFactor   = 0.2;
   windCoefficient      = 0;
   constantAcceleration = 0;
   lifetimeMS           = 800;
   lifetimeVarianceMS   = 300;
   spinRandomMin = -20.0;
   spinRandomMax =  20.0;
   useInvAlpha   = true;

   colors[0]     = "1.0 0.9 0.8 0.2";
   colors[1]     = "0.9 0.8 0.7 1.0";
   colors[2]     = "1.0 1.0 1.0 0.0";

   sizes[0]      = 16.0;
   sizes[1]      = 30.0;
   sizes[2]      = 60.0;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(TargetMajorBlastEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 5;
   ejectionVelocity = 105.0;
   velocityVariance = 10;
   ejectionOffset   = 0.4;
   thetaMin         = 0;
   thetaMax         = 55;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   orientParticles  = true;
   orientOnVelocity = true;
   particles = "TargetMajorBlast";
};



datablock ParticleData(TargetMajorSubFireball)
{
   textureName          = "~/data/shapes/particles/FXpack1/explosion";
   gravityCoefficient   = -2;
   lifetimeMS           = 600;
   lifetimeVarianceMS   = 200;
   useInvAlpha =  false;
   spinRandomMin = -280.0;
   spinRandomMax =  280.0;

   colors[0]     = "1.0 0.9 0.8 0.7";
   colors[1]     = "1.0 0.5 0.0 0.4";
   colors[2]     = "0.3 0.2 0.1 0.0";

   sizes[0]      = 2.0;
   sizes[1]      = 16.0;
   sizes[2]      = 6.0;

   times[0]      = 0.0;
   times[1]      = 0.35;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(TargetMajorSubFireballEmitter)
{
   ejectionPeriodMS = 25;
   periodVarianceMS = 15;
   ejectionVelocity = 15.0;
   velocityVariance = 3.0;
   thetaMin         = 0.0;
   thetaMax         = 150.0;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   ejectionoffset   = 5;
   particles = "TargetMajorSubFireball";
};


datablock ParticleData(TargetMajorSubSmoke)
{
   textureName          = "~/data/shapes/particles/FXpack1/smoke02";
   gravityCoefficient   = -0.5;
   lifetimeMS           = 1600;
   lifetimeVarianceMS   = 400;
   useInvAlpha =  true;
   spinRandomMin = -60.0;
   spinRandomMax =  60.0;

   colors[0]     = "1.0 0.9 0.8 0.3";
   colors[1]     = "0.45 0.43 0.4 0.9";
   colors[2]     = "0.1 0.1 0.1 0.0";

   sizes[0]      = 4.0;
   sizes[1]      = 20.0;
   sizes[2]      = 30.0;

   times[0]      = 0.0;
   times[1]      = 0.35;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(TargetMajorSubSmokeEmitter)
{
   ejectionPeriodMS = 15;
   periodVarianceMS = 10;
   ejectionVelocity = 8.0;
   velocityVariance = 2.0;
   thetaMin         = 0.0;
   thetaMax         = 90.0;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   ejectionoffset   = 7;
   particles = "TargetMajorSubSmoke";
};

datablock ParticleData(TargetMajorSubDirt)
{
   textureName          = "~/data/shapes/particles/FXpack1/dirt";
   gravityCoefficient   = 4.0;
   lifetimeMS           = 800;
   lifetimeVarianceMS   = 200;
   useInvAlpha =  true;
   spinRandomMin = -60.0;
   spinRandomMax =  60.0;

   colors[0]     = "0.8 0.7 0.6 0.0";
   colors[1]     = "0.3 0.3 0.3 0.5";
   colors[2]     = "0.2 0.2 0.2 0.0";

   sizes[0]      = 10.0;
   sizes[1]      = 20.0;
   sizes[2]      = 30.0;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(TargetMajorSubDirtEmitter)
{
   ejectionPeriodMS = 20;
   periodVarianceMS = 10;
   ejectionVelocity = 35.0;
   velocityVariance = 10.0;
   thetaMin         = 0.0;
   thetaMax         = 15.0;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   particles = "TargetMajorSubDirt";
};

datablock ParticleData(TargetMajorSparks)
{
   textureName          = "~/data/shapes/particles/FXpack1/spark";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = 1.0;
   inheritedVelFactor   = 0.4;
   constantAcceleration = 0.0;
   lifetimeMS           = 200;
   lifetimeVarianceMS   = 100;
   useInvAlpha =  false;
   spinRandomMin = -0.0;
   spinRandomMax =  0.0;

   colors[0]     = "1.0 0.9 0.8 0.2";
   colors[1]     = "1.0 0.9 0.8 0.6";
   colors[2]     = "0.8 0.4 0.0 0.0";

   sizes[0]      = 2.0;
   sizes[1]      = 6.0;
   sizes[2]      = 2.0;

   times[0]      = 0.0;
   times[1]      = 0.35;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(TargetMajorSparksEmitter)
{
   ejectionPeriodMS = 5;
   periodVarianceMS = 2;
   ejectionVelocity = 80;
   velocityVariance = 4;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   orientParticles  = true;
   orientOnVelocity = true;
   particles = "TargetMajorSparks";
};



datablock ParticleData(TargetMajorVolume)
{
   textureName          = "~/data/shapes/particles/FXpack1/smoke01";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = -0.2;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 1300;
   lifetimeVarianceMS   = 400;
   useInvAlpha =  true;
   spinRandomMin = -180.0;
   spinRandomMax =  180.0;

   colors[0]     = "1.0 0.9 0.8 0.9";
   colors[1]     = "0.35 0.3 0.25 0.7";
   colors[2]     = "0.5 0.45 0.4 0.0";

   sizes[0]      = 4.0;
   sizes[1]      = 16.0;
   sizes[2]      = 24.0;

   times[0]      = 0.0;
   times[1]      = 0.4;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(TargetMajorVolumeEmitter)
{
   ejectionPeriodMS = 25;
   periodVarianceMS = 15;
   ejectionVelocity = 4;
   velocityVariance = 2.0;
   thetaMin         = 120.0;
   thetaMax         = 180.0;
   ejectionOffset   = 7;
   particles = "TargetMajorVolume";
};

datablock ParticleData(TargetMajorPoint)
{
   textureName          = "~/data/shapes/particles/FXpack1/explosion";
   gravityCoefficient   = -3;
   lifetimeMS           = 500;
   lifetimeVarianceMS   = 200;
   useInvAlpha =  false;
   spinRandomMin = -180.0;
   spinRandomMax =  180.0;

   colors[0]     = "1.0 0.9 0.8 0.9";
   colors[1]     = "0.8 0.4 0.0 0.2";
   colors[2]     = "0.0 0.0 0.0 0.0";

   sizes[0]      = 2.0;
   sizes[1]      = 25.0;
   sizes[2]      = 12.0;

   times[0]      = 0.0;
   times[1]      = 0.35;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(TargetMajorPointEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 5;
   ejectionVelocity = 6;
   velocityVariance = 2;
   thetaMin         = 0;
   thetaMax         = 120;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   ejectionOffset   = 3;
   particles = "TargetMajorPoint";
};


//-----------------------------------------------------------------------------
//	Explosions
//-----------------------------------------------------------------------------

datablock DebrisData(TargetMajorDebris)
{
   shapeFile = "~/data/shapes/explosiondebris/invisible.dts";
   emitters[0] = "TargetDebrisFireEmitter";
   emitters[1] = "TargetDebrisSmokeEmitter";
   
   elasticity = 0.6;
   friction = 0.5;
   numBounces = 1;
   bounceVariance = 1;
   explodeOnMaxBounce = true;
   staticOnMaxBounce = false;
   snapOnMaxBounce = false;
   minSpinSpeed = 300;
   maxSpinSpeed = 700;
   render2D = false;
   lifetime = 3.0;
   lifetimeVariance = 0.3;
   velocity = 65;
   velocityVariance = 25;
   fade = false;
   useRadiusMass = true;
   baseRadius = 0.3;
   gravModifier = 6;
   terminalVelocity = 0;
   ignoreWater = false;
};


datablock ExplosionData(TargetMajorSubExplosion1)
{
   lifeTimeMS = 100;
   offset = 2;
   emitter[0] = TargetMajorSubFireballEmitter;  
   emitter[1] = TargetMajorSubSmokeEmitter;
   emitter[2] = TargetMajorBlastEmitter;
};


datablock ExplosionData(TargetMajorSubExplosion2)
{
   lifeTimeMS = 100;
   offset = 4;
   emitter[0] = TargetMajorSubFireballEmitter;  
   emitter[1] = TargetMajorSubSmokeEmitter; 
   //emitter[2] = TargetMajorSubSmokeEmitter;
};

datablock ExplosionData(TargetMajorSubExplosion3)
{
   lifeTimeMS = 100;
   offset = 5;
   emitter[0] = TargetMajorSubSmokeEmitter;
   emitter[1] = TargetMajorSubFireballEmitter;
   
};

datablock ExplosionData(TargetMajorSubExplosion4)
{
   lifeTimeMS = 100;
   offset = 0;
   emitter[0] = TargetMajorSubDirtEmitter;
   emitter[1] = TargetMajorVolumeEmitter;

   
};



datablock ExplosionData(TargetMajorExplosion)
{
   //soundProfile = CrossbowExplosionSound;
   lifeTimeMS = 100;

   // Volume
   particleEmitter = TargetMajorVolumeEmitter;
   particleDensity = 15;
   particleRadius = 2;

   // Point emission
   emitter[0] = TargetMajorPointEmitter; 
   emitter[1] = TargetMajorSubFireballEmitter; 
   emitter[2] = TargetMajorSparksEmitter; 
   emitter[3] = TargetMajorSparksEmitter;


   // Sub explosions
   subExplosion[0] = TargetMajorSubExplosion1;
   subExplosion[1] = TargetMajorSubExplosion2;
   subExplosion[2] = TargetMajorSubExplosion3;
   subExplosion[3] = TargetMajorSubExplosion4;
   

   // Exploding debris
   debris = TargetMajorDebris;
   debrisThetaMin = 0;
   debrisThetaMax = 60;
   debrisPhiMin = 0;
   debrisPhiMax = 360;
   debrisNum = 9;
   debrisNumVariance = 3;
   debrisVelocity = 1;
   debrisVelocityVariance = 0.5;

};