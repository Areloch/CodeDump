//-----------------------------------------------------------------------------
//	Particles
//-----------------------------------------------------------------------------

datablock ParticleData(GenericSmallSubFireball)
{
   textureName          = "~/data/shapes/particles/FXpack1/explosion";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = -3;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 300;
   lifetimeVarianceMS   = 100;
   useInvAlpha =  false;
   spinRandomMin = -280.0;
   spinRandomMax =  280.0;

   colors[0]     = "1.0 0.9 0.8 0.1";
   colors[1]     = "1.0 0.5 0.0 0.3";
   colors[2]     = "0.1 0.1 0.1 0.0";

   sizes[0]      = 1.0;
   sizes[1]      = 4.0;
   sizes[2]      = 5.0;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(GenericSmallSubFireballEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 5;
   ejectionVelocity = 3.5;
   velocityVariance = 2.0;
   thetaMin         = 0.0;
   thetaMax         = 120.0;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   ejectionoffset   = 2;
   particles = "GenericSmallSubFireball";
};

datablock ParticleData(GenericSmallSubSmoke)
{
   textureName          = "~/data/shapes/particles/FXpack1/smoke01";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = -1.0;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 700;
   lifetimeVarianceMS   = 200;
   useInvAlpha =  true;
   spinRandomMin = -120.0;
   spinRandomMax =  120.0;

   colors[0]     = "0.8 0.7 0.6 0.3";
   colors[1]     = "0.5 0.5 0.5 0.8";
   colors[2]     = "0.2 0.2 0.2 0.0";

   sizes[0]      = 2.0;
   sizes[1]      = 5.0;
   sizes[2]      = 10.0;

   times[0]      = 0.0;
   times[1]      = 0.25;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(GenericSmallSubSmokeEmitter)
{
   ejectionPeriodMS = 30;
   periodVarianceMS = 10;
   ejectionVelocity = 1.5;
   velocityVariance = 0.5;
   thetaMin         = 0.0;
   thetaMax         = 90.0;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   ejectionoffset   = 2;
   particles = "GenericSmallSubSmoke";
};

datablock ParticleData(GenericSmallSparks)
{
   textureName          = "~/data/shapes/particles/FXpack1/spark";
   gravityCoefficient   = 0.0;
   inheritedVelFactor   = 0.4;
   lifetimeMS           = 100;
   lifetimeVarianceMS   = 10;
   useInvAlpha =  false;
   spinRandomMin = -0.0;
   spinRandomMax =  0.0;

   colors[0]     = "1.0 0.9 0.8 0.2";
   colors[1]     = "1.0 0.9 0.8 0.8";
   colors[2]     = "0.8 0.4 0.0 0.0";

   sizes[0]      = 1.0;
   sizes[1]      = 2.5;
   sizes[2]      = 2.0;

   times[0]      = 0.0;
   times[1]      = 0.35;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(GenericSmallSparksEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 2;
   ejectionVelocity = 60;
   velocityVariance = 4;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   orientParticles  = true;
   orientOnVelocity = true;
   particles = "GenericSmallSparks";
};

datablock ParticleData(GenericSmallSmoke)
{
   textureName          = "~/data/shapes/particles/FXpack1/smoke01";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = -0.3;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 800;
   lifetimeVarianceMS   = 300;
   useInvAlpha =  true;
   spinRandomMin = -80.0;
   spinRandomMax =  80.0;

   colors[0]     = "0.9 0.8 0.7 0.0";
   colors[1]     = "0.2 0.2 0.2 0.7";
   colors[2]     = "0.4 0.4 0.4 0.0";

   sizes[0]      = 2.0;
   sizes[1]      = 6.0;
   sizes[2]      = 10.0;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(GenericSmallSmokeEmitter)
{
   ejectionPeriodMS = 15;
   periodVarianceMS = 5;
   ejectionVelocity = 2.8;
   velocityVariance = 2.0;
   thetaMin         = 0.0;
   thetaMax         = 180.0;
   ejectionOffset   = 1;
   particles = "GenericSmallSmoke";
};

datablock ParticleData(GenericSmallFireball)
{
   textureName          = "~/data/shapes/particles/FXpack1/explosion";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = -0.5;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 400;
   lifetimeVarianceMS   = 200;
   useInvAlpha =  false;
   spinRandomMin = -180.0;
   spinRandomMax =  180.0;

   colors[0]     = "1.0 0.9 0.8 0.9";
   colors[1]     = "0.8 0.4 0 0.3";
   colors[2]     = "0.0 0.0 0.0 0.0";

   sizes[0]      = 2.0;
   sizes[1]      = 7.0;
   sizes[2]      = 4.0;

   times[0]      = 0.0;
   times[1]      = 0.35;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(GenericSmallFireballEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 5;
   ejectionVelocity = 3;
   velocityVariance = 2;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   particles = "GenericSmallFireball";
};


//-----------------------------------------------------------------------------
//	Explosions
//-----------------------------------------------------------------------------


datablock ExplosionData(GenericSmallSubExplosion1)
{
   lifeTimeMS = 80;
   offset = 0.2;
   emitter[0] = GenericSmallSubFireballEmitter;
};


datablock ExplosionData(GenericSmallSubExplosion2)
{
   lifeTimeMS = 80;
   offset = 0.5;
   emitter[0] = GenericSmallSubFireballEmitter;
   emitter[1] = GenericSmallSubSmokeEmitter;
};



datablock ExplosionData(GenericSmallExplosion)
{
   //soundProfile = CrossbowExplosionSound;
   lifeTimeMS = 80;

   // Volume
   particleEmitter = GenericSmallSmokeEmitter;
   particleDensity = 10;
   particleRadius = 0.6;

   // Point emission
   emitter[0] = GenericSmallFireballEmitter; 
   emitter[1] = GenericSmallSubFireballEmitter; 
   emitter[2] = GenericSmallSparksEmitter;
   emitter[3] = GenericSmallSparksEmitter; 


   // Sub explosions
   subExplosion[0] = GenericSmallSubExplosion1;
   subExplosion[1] = GenericSmallSubExplosion2;
   
};