//-----------------------------------------------------------------------------
//	Particles
//-----------------------------------------------------------------------------

datablock ParticleData(TargetDebrisFire)
{
   textureName          = "~/data/shapes/particles/FXpack1/flame02";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = -1;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 300;
   lifetimeVarianceMS   = 100;
   useInvAlpha =  false;
   spinRandomMin = -280.0;
   spinRandomMax =  280.0;

   colors[0]     = "1.0 0.9 0.8 0.2";
   colors[1]     = "1.0 0.5 0.0 0.6";
   colors[2]     = "0.1 0.1 0.1 0.0";

   sizes[0]      = 1.0;
   sizes[1]      = 2.0;
   sizes[2]      = 1.0;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(TargetDebrisFireEmitter)
{
   ejectionPeriodMS = 8;
   periodVarianceMS = 4;
   ejectionVelocity = 5.0;
   velocityVariance = 3.0;
   thetaMin         = 0.0;
   thetaMax         = 180.0;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   ejectionoffset   = 0.3;
   particles = "TargetDebrisFire";
};

datablock ParticleData(TargetDebrisSmoke)
{
   textureName          = "~/data/shapes/particles/FXpack1/smoke02";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = -1.5;
   inheritedVelFactor   = 0.0;
   constantAcceleration = 0.0;
   lifetimeMS           = 800;
   lifetimeVarianceMS   = 400;
   useInvAlpha =  true;
   spinRandomMin = -60.0;
   spinRandomMax =  60.0;

   colors[0]     = "1.0 0.9 0.8 0.1";
   colors[1]     = "0.5 0.5 0.5 0.4";
   colors[2]     = "0.3 0.3 0.3 0.0";

   sizes[0]      = 2.0;
   sizes[1]      = 7.0;
   sizes[2]      = 12.0;

   times[0]      = 0.0;
   times[1]      = 0.5;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(TargetDebrisSmokeEmitter)
{
   ejectionPeriodMS = 30;
   periodVarianceMS = 10;
   ejectionVelocity = 5.0;
   velocityVariance = 3.0;
   thetaMin         = 0.0;
   thetaMax         = 180.0;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   ejectionOffset   = 0.3;
   particles = "TargetDebrisSmoke";
};

