//-----------------------------------------------------------------------------
//	Particles
//-----------------------------------------------------------------------------


datablock ParticleData(FlakSmoke)
{
   textureName          = "~/data/shapes/particles/FXpack1/flame01";
   dragCoeffiecient     = 100.0;
   gravityCoefficient   = 0;
   inheritedVelFactor   = 0.25;
   constantAcceleration = -0.30;
   lifetimeMS           = 2400;
   lifetimeVarianceMS   = 800;
   useInvAlpha =  true;
   spinRandomMin = -80.0;
   spinRandomMax =  80.0;

   colors[0]     = "0.9 0.7 0.4 0.9";
   colors[1]     = "0.2 0.2 0.2 0.9";
   colors[2]     = "0.1 0.1 0.1 0.0";

   sizes[0]      = 2.5;
   sizes[1]      = 5.0;
   sizes[2]      = 7.5;

   times[0]      = 0.0;
   times[1]      = 0.1;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(FlakSmokeEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 0;
   ejectionVelocity = 1;
   velocityVariance = 0.5;
   thetaMin         = 0.0;
   thetaMax         = 180.0;
   ejectionOffset   = 1;
   particles = "FlakSmoke";
};

datablock ParticleData(FlakSmoke2)
{
   textureName          = "~/data/shapes/particles/FXpack1/flame01";
   dragCoeffiecient     = 100.0;
   gravityCoefficient   = 0;
   inheritedVelFactor   = 0.25;
   constantAcceleration = -0.30;
   lifetimeMS           = 2400;
   lifetimeVarianceMS   = 800;
   useInvAlpha =  true;
   spinRandomMin = -80.0;
   spinRandomMax =  80.0;

   colors[0]     = "0.9 0.6 0.2 1.0";
   colors[1]     = "0.2 0.2 0.2 0.9";
   colors[2]     = "0.1 0.1 0.1 0.0";

   sizes[0]      = 2.0;
   sizes[1]      = 4.0;
   sizes[2]      = 6.0;

   times[0]      = 0.0;
   times[1]      = 0.1;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(FlakSmoke2Emitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 0;
   ejectionVelocity = 1;
   velocityVariance = 0.5;
   thetaMin         = 0.0;
   thetaMax         = 180.0;
   ejectionOffset   = 1.5;
   particles = "FlakSmoke2";
};

datablock ParticleData(FlakSparks)
{
   textureName          = "~/data/shapes/particles/FXpack1/spark";
   dragCoeffiecient     = 0.0;
   gravityCoefficient   = 1.0;
   inheritedVelFactor   = 0.4;
   constantAcceleration = 0.0;
   lifetimeMS           = 100;
   lifetimeVarianceMS   = 50;
   useInvAlpha =  false;
   spinRandomMin = -0.0;
   spinRandomMax =  0.0;

   colors[0]     = "1.0 0.9 0.8 0.2";
   colors[1]     = "1.0 0.9 0.8 0.55";
   colors[2]     = "0.8 0.4 0.0 0.0";

   sizes[0]      = 2.0;
   sizes[1]      = 5.0;
   sizes[2]      = 2.0;

   times[0]      = 0.0;
   times[1]      = 0.35;
   times[2]      = 1.0;
};

datablock ParticleEmitterData(FlakSparksEmitter)
{
   ejectionPeriodMS = 3;
   periodVarianceMS = 1;
   ejectionVelocity = 60;
   velocityVariance = 4;
   thetaMin         = 0;
   thetaMax         = 180;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   orientParticles  = true;
   orientOnVelocity = true;
   particles = "FlakSparks";
};

//-----------------------------------------------------------------------------
//	Explosion
//-----------------------------------------------------------------------------


//Flak Explosion

datablock ExplosionData(FlakExplosion)
{
   //soundProfile = CrossbowExplosionSound;
   lifeTimeMS = 50;

   // Volume particles
   particleEmitter = FlakSmokeEmitter;
   particleDensity = 15;
   particleRadius = 0.7;

   // Point emission
   emitter[0] = FlakSparksEmitter;
   emitter[1] = FlakSmoke2Emitter;
   
   
};