// Skinned Button Control
// by Rob Parton

#include "console/console.h"
#include "dgl/dgl.h"
#include "console/consoleTypes.h"
#include "platform/platformAudio.h"
#include "gui/core/guiCanvas.h"
#include "gui/core/guiDefaultControlRender.h"
#include "gui/controls/guiSkinnedButtonCtrl.h"

//////////////////////////////////////////////////////

IMPLEMENT_CONOBJECT(GuiSkinnedButtonCtrl);

GuiSkinnedButtonCtrl::GuiSkinnedButtonCtrl()
{
	mButtonText = StringTable->insert("Button");
}

void GuiSkinnedButtonCtrl::onSleep()
{
	mTextureHandle = NULL;
	Parent::onSleep();
}

bool GuiSkinnedButtonCtrl::onWake()
{
   // if the parent control didn't wake up, what am I doing up?
   if (! Parent::onWake())
      return false;

   //get the texture for the button.
   mTextureHandle = mProfile->mTextureHandle;
   bool result = mProfile->constructBitmapArray() >= NumBitmaps;
   AssertFatal(result, "Failed to create the bitmap array");
   if(!result)
      return false;

   // set bitmap bounds
   mBitmapBounds = mProfile->mBitmapArrayRects.address();

   // this sets the button so the height is never higher than the actual bitmap
   // because vertical stretching of a skinned button is hideous.
   // TODO: Make this optional
   mBounds.extent.y = mBitmapBounds[0].extent.y;

   return true;
}

void GuiSkinnedButtonCtrl::onRender(Point2I offset, const RectI &updateRect)
{
	bool bHighlight = mMouseOver;
	bool bDepressed = mDepressed;

	ColorI fontColor = mActive ? (bHighlight ? mProfile->mFontColorHL : mProfile->mFontColor) : mProfile->mFontColorNA;

	RectI ctrlRect(offset, mBounds.extent);

	// Figure out which bitmap index we start on
	int idm = mActive ? (bHighlight ? (bDepressed ? ButtonStateDepressed: ButtonStateHilite) : ButtonStateNormal) : ButtonStateNotActive;
	idm *= 3;

	// Draw Background dependant on mode
	dglClearBitmapModulation();

	// Left Backing
	dglDrawBitmapSR(mTextureHandle,offset,mBitmapBounds[0+idm]);

	// Right Backing
	dglDrawBitmapSR(mTextureHandle, Point2I(offset.x+mBounds.extent.x-mBitmapBounds[2+idm].extent.x,offset.y), mBitmapBounds[2+idm]);

	// Background Span
	RectI destRect;
	destRect.point.x = offset.x + mBitmapBounds[0+idm].extent.x;
	destRect.point.y = offset.y;
	destRect.extent.x = mBounds.extent.x - mBitmapBounds[0+idm].extent.x - mBitmapBounds[2+idm].extent.x;
	destRect.extent.y = mBitmapBounds[1+idm].extent.y;

	RectI stretchRect = mBitmapBounds[1+idm];
	stretchRect.inset(1,0);
	dglDrawBitmapStretchSR(mTextureHandle,destRect, stretchRect);

	// text!
	dglSetBitmapModulation(fontColor);
	renderJustifiedText(offset, mBounds.extent, mButtonText);

	// render child controls
	renderChildControls(offset, updateRect);
}
