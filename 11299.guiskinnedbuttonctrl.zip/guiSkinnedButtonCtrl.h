// Skinned Button Control for TGE
// by Rob Parton

#ifndef _GUISKINNEDBUTTONCTRL_H_
#define _GUISKINNEDBUTTONCTRL_H_

#ifndef _GUIBUTTONBASECTRL_H_
#include "gui/controls/guiButtonBaseCtrl.h"
#endif

///////////////////////////////////////////////////////////
class GuiSkinnedButtonCtrl: public GuiButtonBaseCtrl
{

  typedef GuiButtonBaseCtrl Parent;
  RectI *mBitmapBounds;

protected:
    TextureHandle mTextureHandle;

	enum {
      ButtonStateNormal,
      ButtonStateHilite,
      ButtonStateNotActive,
	  ButtonStateDepressed
    };

    static const int NumBitmaps = 12;

  public:
	// Declare a console object in Torque
    DECLARE_CONOBJECT(GuiSkinnedButtonCtrl);
    GuiSkinnedButtonCtrl();

    void onSleep();
    bool onWake();
	// rendering
    void onRender(Point2I offset, const RectI &updateRect);

};

#endif