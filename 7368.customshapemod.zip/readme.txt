The pdf contains all the individual changes to source code and scripts, guis etc.   

Read the last section of the pdf to see how to pass the character information to the server and other clients

The guiplayerview.cc source is not stock standard but in addition to the character mod, it contains a thread animation addition I saw in Realmwars from 2002.  If you want to use the mod with a "standard" guiplayerview.cc then read the pdf and copy/paste the changes to the "standard" guiplayerview source file and header.

TGE 1.3
The sourceCode.zip file [[[ TGE 1.3 ]]] can be unzipped in your torque folder and it will place the files in the correct folders, but BEWARE it will overwrite your existing relevant files so make backups if you want to keep them.

The optionsDlg.cs and gui files etc should be placed in your client/scripts folder


TGE 1.4 Notes

THe included source is for TGE 1.3.  However if you just copy paste the changes from the pdf into TGE 1.4, it works just fine.  Yeah I know its hard work, but if you pay me, I'll do it for you.

You will also have to add #include <stdlib.h> to guiPlayerView.cc and perhaps to ShapeBase.cc as well.  Check the 1.3 versions I included in the zip.

IMPORTANT - TGE 1.4 has changed the $usermods path which is unfortunate as this affects the optionsDlg.cs file where it passes the dts and dsq names to the guiplayerview class.

To correct it, search for the following in optionsDlg.cs:
 
%playerModel = $userMods @"/data/shapes/player";
PlayerView.setModel(%playerModel @ "/player.dts", "", %playerModel @ "/player_forward.dsq" );

Now set $usermods to the name of your mod folder i.e starter.fps or starter.racing or mygreategame

There is no error checking in guiPlayerView.setModel(), so if you get the path wrong, it will crash hard.

SOMETHING TO BE CAREFULL OF:

When you scale a character, the bounding box of the character does not get scaled which means your character may appear to float above ground if you scaled its body way down etc.  The placer bounding box is artificially created in player.cc.  You may have to add some code to change its size in relation to any scale changes you made to player legs and spine etc. I have not tried this so it won't help to ask me about it.  If you have found a solution, I would be happy to add it to this resource. 


HOW THIS MOD WORKS

I will try and explain the inner workings of this mod so that it may reduce some of the questions in the forums.

Console method shapebase::setDNA takes a string of format "n x y z n x y z"etc, where n=node or bone and x,y,z are the scales 0-1 (float), and passes it ShapeBase::setDNA. ShapeBase::setDNA then sets the network skinmask flag, causing the server to pass the the above string to all its clients. When the client receives the data, it calls uploadScalePerBoneList which updates the particular shape instance with the new values.

The DNA string is stored in TSShapeInstance in an array of xyz values per node. When initialized or reset, all xyz values are set to 1. The scaling occurs during the shape instance render cycle. It simple checks the array and applies the scales. 

The above is all you need to get the scale per bone part to work over a network. ALL the other console methods in the resource operate on the local copy of TSShapeInstance and were created as a convenient means of getting the various sliders in optiondlg.cs to affect changes to the scales. You don't actually need them if you don't want a gui interface for setting scales per bone.

Which of course means that if you use the sliders to affect the scales, you still need to tell the server about it so that it can replicate the changes to the other clients. For this purpose, the optiondlg.cs OptClose() function was used to create a string of scales and send them to the server.

function OptClose()
{    
   PlayerView.getDNA(); // this will set the $pref::Player::DNA variable with the DNA string    
   commandToServer('SendDNA',$pref::Player::DNA, $pref::Player::skin); //tell the server
}

In order to minimise network traffic, ONLY the altered scales are passed between client and server.

getDNA is a console method which calls void TSShapeInstance::getScalePerBoneList() which in turn goes through the local array and checks for any scales which are not 1 and adds them to the DNA string in the above format. The string is then used to set the $pref::Player::DNAvariable because all prefs are conveniently saved between games.

Be aware that there is another console method called setDNA, but it is a guiPlayerView method which only updates the local TSShapeInstance and not the server so make sure you use the correct setDNA in the correct place. The guiPlayerView version uses the saved $pref::Player::DNA values to set the shape scale when the optionDlg.cs onWake function is invoked so that you see what you last scale choices look like.

There are other console methods for setting and getting individual bone scales, namely setScalePerBone and getScalePerBone. All these 'local' console methods are stored in guiplayerview.cc as they are used there and only affect the client.

I hope that clears things up a bit.



