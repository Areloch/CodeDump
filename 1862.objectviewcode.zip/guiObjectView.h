//-----------------------------------------------------------------------------
// V12 Engine
// 
// Copyright (c) 2001 GarageGames.Com
// Portions Copyright (c) 2001 by Sierra Online, Inc.
//-----------------------------------------------------------------------------

#ifndef _GUIOBJECTVIEW_H_
#define _GUIOBJECTVIEW_H_

#ifndef _GUITSCONTROL_H_
#include "gui/guiTSControl.h"
#endif
#ifndef _TSSHAPEINSTANCE_H_
#include "ts/tsShapeInstance.h"
#endif
#ifndef _GAMEBASE_H_
#include "game/gameBase.h"
#endif
#ifndef _CAMERA_H_
#include "game/camera.h"
#endif

class TSThread;

class GuiObjectView : public GuiTSCtrl
{
   private:
      typedef GuiTSCtrl Parent;
 

   protected:
      enum MouseState
      {
         None,
         Rotating,
         Zooming
      };

      MouseState  mMouseState;

      TSShapeInstance*  mModel;
      U32   mSkinTag;

      Point3F  mCameraPos;
      MatrixF  mCameraMatrix;
      EulerF   mCameraRot;
      Point3F  mOrbitPos;
      F32      mMinOrbitDist;
      F32      mOrbitDist;
      
      TSThread *runThread;
      S32      lastRenderTime;

      Point2I  mLastMousePoint;

   public:
      DECLARE_CONOBJECT( GuiObjectView );
      GuiObjectView();
      ~GuiObjectView();

      static void consoleInit();
      bool onWake();

      void onMouseDown( const GuiEvent &event );
      void onMouseUp( const GuiEvent &event );
      void onMouseDragged( const GuiEvent &event );
      void onRightMouseDown( const GuiEvent &event );
      void onRightMouseUp( const GuiEvent &event );
      void onRightMouseDragged( const GuiEvent &event );

      void setObjectModel( const char* shape, const char* skin );

      bool processCameraQuery( CameraQuery *query );
      void renderWorld( const RectI &updateRect );

	  void setEmpty();
};

#endif // _GUI_PLAYERVIEW_H
