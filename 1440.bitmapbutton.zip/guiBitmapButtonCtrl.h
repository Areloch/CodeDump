//-----------------------------------------------------------------------------
// V12 Engine
// 
// Copyright (c) 2001 GarageGames.Com
// Portions Copyright (c) 2001 by Sierra Online, Inc.
//-----------------------------------------------------------------------------

#ifndef _GuiBitmapButtonCTRL_H_
#define _GuiBitmapButtonCTRL_H_

#ifndef _GUICONTROL_H_
#include "gui/guiControl.h"
#endif

#ifndef _GTEXMANAGER_H_
#include "dgl/gTexManager.h"
#endif

class GuiBitmapButtonCtrl : public GuiControl
{
  private:
   typedef GuiControl Parent;

  protected: 
   enum State {
      Normal,
      MouseDown
   };

   enum eState
   {
       eNormal = 0,
       eHighlight,
       ePressed,
       eDisabled,
       eDefault
   };

   bool             mMouseInControl;
   State            mButtonState;
   StringTableEntry mButtonText;
   StringTableEntry mBitmapNames[5];
   TextureHandle mTextureHandles[5];

  public:   
   DECLARE_CONOBJECT(GuiBitmapButtonCtrl);
   GuiBitmapButtonCtrl();

   static void consoleInit();
   static void initPersistFields();

   void AcceleratorKeyPress(void);

   bool onKeyDown(const GuiEvent&);

   void onMouseUp(const GuiEvent&);
   void onMouseDown(const GuiEvent&);
   void onMouseEnter(const GuiEvent&);
   void onMouseLeave(const GuiEvent&);

   const char * getScriptValue();
   void setScriptValue(const char *);

   void onSleep();
   bool onWake();

   void setBitmap(const char *name,S32 index);

   void onRender(Point2I offset, const RectI &updateRect, GuiControl *firstResponder);
   void drawBorder(const RectI &r, const ColorI &color);
};

#endif //_GUI_BUTTON_CTRL_H
