//ShapeBase.h:

struct bvhJoint
{
	char name[40];
	Point3F offset;
	U32 channels;
	S32 parent;
};

//----------------------------------------------------------------------------

/// ShapeBase is the renderable shape from which most of the scriptable objects
/// are derived, including the player, vehicle and items classes.  ShapeBase
/// provides basic shape loading, audio channels, and animation as well as damage
/// (and damage states), energy, and the ability to mount images and objects.
///
/// @nosubgrouping
class ShapeBase : public GameBase
{
   ...

   void cleanupBvh(const char *bvhFile);
   void importBvh(const char *bvhFile);
   /// @}

   DECLARE_CONOBJECT(ShapeBase);
};
////////////////////////////////////////

//ShapeBase.cpp:


void ShapeBase::cleanupBvh(const char *bvhFile)
{
	/////////////////////////////////////////
	//TEMP: When setting up a new model, helpful to print out node names and indices, and then quit.
	//for (U32 i=0;i<mShapeInstance->mShape->nodes.size();i++)
	//{
	//	Con::errorf("nodes[%d] = %s",i,mShapeInstance->mShape->getName(mShapeInstance->mShape->nodes[i].nameIndex));
	//}
	//return;
	/////////////////////////////////////////

	U32 i = 0;
	U32 pc,rc,jc,jloop,loopDepth;
	pc = 0; rc = 0; jc = 0; jloop = 0; loopDepth = 0;
	U32 sampleRate = 3;//3
	S32 newParent = -1;
	S32 numFrames = 0;
	S32 numSamples = 0;
	F32 frameTime = 0.0;
	F32 v;
	QuatF rot;
	QuatF rots[20000]; 
	U32 numRots = 0; 
							
	Point3F trans[1000];
	U32 numTrans = 0; 
	//Point3F rotsByPart[20][300];//while we're temporarily hogging memory...

	Point3F p;
	Point3F r;
	Point3F pos3[200];
	Point3F rot3[200];
	bvhJoint joints[200];
	EulerF armsDownRots[200];//allow for two later, if we need it
	EulerF unwrapRots[200];
	bool keepGoing,loadingJoints;
	char filename[255],writename[255],buf[2500];
	char line[2500], rotation[40], tempStr[40],name[40];
	char *bufp;
	FILE *fp = NULL;
	FILE *fpw = NULL;

	sprintf(filename,"%s/bvh/%s.bvh",mShapeInstance->getShape()->mSourceResource->path,bvhFile);
	fp = fopen(filename,"r");
	
	if (fp==NULL) 
	{
		Con::errorf("ERROR: can't open bvh file");
		return;
	}

	sprintf(writename,"%s/bvh/%s.new.bvh",mShapeInstance->getShape()->mSourceResource->path,bvhFile);
	fpw = fopen(writename,"w");

	U32 numChannels;

	fgets(buf,250,fp); fprintf(fpw,"%s",buf);// HIERARCHY
	fgets(buf,250,fp); fprintf(fpw,"%s",buf);// ROOT
	dSscanf(buf,"%s %s",&tempStr,&name);

	joints[0].parent = -1;
	dStrcpy(joints[0].name,name);
	fgets(buf,250,fp); fprintf(fpw,"%s",buf);// {
	fgets(buf,250,fp); fprintf(fpw,"%s",buf);// OFFSET x y z
	dSscanf(buf,"  OFFSET %f %f %f",&p.x,&p.y,&p.z);
	//fprintf(fpw,"  OFFSET %f %f %f",p.x,p.y,p.z);
	joints[0].offset = p;
	fgets(buf,250,fp); fprintf(fpw,"%s",buf);// CHANNELS n ...
	dSscanf(buf,"  CHANNELS %d ",&numChannels);
	joints[0].channels = numChannels;

	loopDepth = 0;

	fgets(buf,250,fp); fprintf(fpw,"%s",buf);
	bufp = dStrtok(buf," \t\n");

	loadingJoints = true;
	while (loadingJoints)
	{
		keepGoing = true;
		while (keepGoing)
		{
			sprintf(tempStr,"JOINT");
			if (!dStrstr(bufp,tempStr)) 
			{ 
				keepGoing = false; //End Site
				fgets(buf,250,fp); fprintf(fpw,"%s",buf);//{
				fgets(buf,250,fp); fprintf(fpw,"%s",buf);//terminal OFFSET x y z, ignore it
				fgets(buf,250,fp); fprintf(fpw,"%s",buf);//}
				break; 
			}
			jc++;  loopDepth++;

			if (newParent>=0) {
				joints[jc].parent = newParent;
				newParent = -1;
			} else joints[jc].parent = jc-1;

			bufp = dStrtok(NULL, " \t\n");
			dSscanf(bufp,"%s",name);				
			dStrcpy(joints[jc].name,name);
			fgets(buf,250,fp); fprintf(fpw,"%s",buf);//{
			fgets(buf,250,fp); fprintf(fpw,"%s",buf);//OFFSET x y z
			bufp = dStrtok(buf," \t\n");//"OFFSET"
			bufp = dStrtok(NULL, " \t\n"); dSscanf(bufp,"%f",&joints[jc].offset.x);//X
			bufp = dStrtok(NULL, " \t\n"); dSscanf(bufp,"%f",&joints[jc].offset.y);//Y
			bufp = dStrtok(NULL, " \t\n"); dSscanf(bufp,"%f",&joints[jc].offset.z);//Z
			

			fgets(buf,250,fp);//CHANNELS n s s s s s s
			bufp = dStrtok(buf," \t\n");//"CHANNELS"
			bufp = dStrtok(NULL, " \t\n"); dSscanf(bufp,"%d",&joints[jc].channels);
			//ignore the rest

			//FIX: here we need to write out "CHANNELS 3 Zrotation Xrotation Yrotation"  no matter what it said before.
			//Problem is we need to indent it properly, which is a PITA.  Have to track level of nesting and add 
			//correct number of tabs, use dStrcat in a loop.
			//ALSO need to track whether the original file was made with tabs or spaces.  This could get ridiculous, though.

			dStrcpy(line,"\t");
			for (U32 k=0;k<loopDepth;k++) dStrcat(line,"\t");
			dStrcat(line,"CHANNELS 3 Zrotation Xrotation Yrotation\n");
			fprintf(fpw,"%s",line);


			Con::printf("JOINT %d: %s %d %3.2f %3.2f %3.2f",jc,joints[jc].name,joints[jc].channels,
				joints[jc].offset.x,joints[jc].offset.y,joints[jc].offset.z);
			
			fgets(buf,250,fp); fprintf(fpw,"%s",buf);
			bufp = dStrtok(buf," \t\n");
		}
		//fgets(buf,250,fp);// JOINT?


		//HERE: back out of the nested curly braces, checking for new JOINTs and decrementing jloop each time.

		keepGoing = true;
		while (keepGoing)
		{
			fgets(buf,250,fp); fprintf(fpw,"%s",buf);
			bufp = dStrtok(buf," \t\n");
			char tempOne[40],tempTwo[40],tempThree[40];
			sprintf(tempOne,"}");
			sprintf(tempTwo,"JOINT");
			sprintf(tempThree,"MOTION");
			if (dStrstr(bufp,tempOne))//"}"
			{
				jloop++; loopDepth--;
			} else if (dStrstr(bufp,tempTwo)) {//"JOINT"
				newParent = joints[jc-(jloop-1)].parent;
				keepGoing = false;
			} else if (dStrstr(bufp,tempThree)) {//"MOTION"
				Con::printf("BVH -- loaded schema, proceeding to motion frames.");
				keepGoing = false;
				loadingJoints = false;
			} else {
				Con::errorf("BVH -- problem, found no frames.");
				fclose(fp);
				fclose(fpw);
				return;
			}
		}
	}
	U32 numJoints = jc+1;

	////////////////////////////////////////////////////////////////////////////////////////////////////////
	//NOW: all done loading joints.  Array is filled up and available.  Next step is loading all the motion
	//frames, after picking up the numFrames and frameLength variables.

	fgets(buf,250,fp); fprintf(fpw,"%s",buf);//Frames: n

	dSscanf(bufp,"Frames:\t%d",&numFrames);
	//bufp = dStrtok(buf," \t\n");//"Frames:"
	//bufp = dStrtok(NULL, " \t\n"); dSscanf(bufp,"%d",&numFrames);

	fgets(buf,250,fp); fprintf(fpw,"%s",buf);//Frame Time: f
	dSscanf(bufp,"Frame Time:\t%f",&frameTime);
	//bufp = dStrtok(buf," \t\n");//"Frame Time:"
	//bufp = dStrtok(NULL, " \t\n"); dSscanf(bufp,"%f",&frameTime);

	if (!numFrames || (numFrames<=0)) 
	{
		Con::errorf("BVH -- couldn't read numFrames, bailing.");
		fclose(fp);
		fclose(fpw);
		return;
	}

	for (U32 c=0;c<numFrames;c++)
	{
		if (!fgets(buf,2500,fp)) 
		{
			Con::errorf("BVH -- not enough frames, bailing out.");
			fclose(fp);
			fclose(fpw);
			return;
		}

		//fprintf(fpw,"%s",buf);

		pc=0;

		for (U32 d=0; d < numJoints;d++)
		{
			if (d==0) 
				bufp = dStrtok(buf," \t\n");
			else 
				bufp = dStrtok(NULL, " \t\n");

			if (joints[d].channels == 3)
			{
				dSscanf(bufp,"%f",&p.z);
				bufp = dStrtok(NULL, " \t\n");
				dSscanf(bufp,"%f",&p.x);
				bufp = dStrtok(NULL, " \t\n");
				dSscanf(bufp,"%f",&p.y);
				rot3[d] = p;
			}
			else
			{
				dSscanf(bufp,"%f",&p.x);
				bufp = dStrtok(NULL, " \t\n");
				dSscanf(bufp,"%f",&p.y);
				bufp = dStrtok(NULL, " \t\n");
				dSscanf(bufp,"%f",&p.z);
				pos3[d] = p;

				//HERE: note that this is loading z,x,y order.
				bufp = dStrtok(NULL, " \t\n");
				dSscanf(bufp,"%f",&p.z);
				bufp = dStrtok(NULL, " \t\n");
				dSscanf(bufp,"%f",&p.x);
				bufp = dStrtok(NULL, " \t\n");
				dSscanf(bufp,"%f",&p.y);
				rot3[d] = p;
			}
		}
		

		dSprintf(rotation,40,"%3.2f %3.2f %3.2f ",pos3[0].x,pos3[0].y,pos3[0].z);
		//dSprintf(line,dStrlen(rotation),rotation);
		U32 len = dStrlen(rotation);
		dSprintf(line,40,rotation);
		for (U32 j=0; j<numJoints;j++)
		{
			dSprintf(rotation,40,"%3.2f %3.2f %3.2f ",rot3[j].z,rot3[j].x,rot3[j].y);
			//dSprintf(line,dStrlen(rotation),rotation);
			//dSprintf(line,40,rotation);
			dStrcat(line,rotation);
		}

		fprintf(fpw,"%s\n",line);
	}

	fclose(fp);
	fclose(fpw);

}

void ShapeBase::importBvh(const char *bvhFile)
{
	U32 i = 0;
	U32 pc,rc,jc,jloop;
	pc = 0; rc = 0; jc = 0; jloop = 0;
	U32 sampleRate = 1;//3
	S32 newParent = -1;
	S32 numFrames = 0;
	S32 numSamples = 0;
	F32 frameTime = 0.0;
	F32 v;
	QuatF rot,q;
	Quat16 q16;
	QuatF rots[20000]; 
	U32 numRots = 0; 
							
	Point3F trans[1000];
	U32 numTrans = 0; 
	//Point3F rotsByPart[20][300];//while we're temporarily hogging memory...

	Point3F p;
	Point3F r;

	Point3F pos3[200];
	Point3F rot3[200];
	bvhJoint joints[200];
	S32 bvhNodes[200];
	S32 dtsNodes[200];
	S32 sortNodes[200];
	S32 orderNodes[200];//from initial order to shape order
	EulerF bvhPoseRotsA[200],bvhPoseRotsB[200];//allow for two later, if we need it
	EulerF axesFixRotsA[200],axesFixRotsB[200];

	bool keepGoing,loadingJoints;
	char filename[255],configfile[255],buf[2500];
	char line[2500], rotation[40], tempStr[40];
	char *bufp;
	FILE *fp = NULL;
	FILE *fpc = NULL;

	
	TSShape *kShape = mShapeInstance->getShape();

	

	sprintf(filename,"%s/bvh/%s.bvh",mShapeInstance->getShape()->mSourceResource->path,bvhFile);
	fp = fopen(filename,"r");
	if (fp==NULL) 
	{
		Con::errorf("ERROR: can't open bvh file");
		return;
	}


	sprintf(configfile,"%s/bvh/%s.cfg",mShapeInstance->getShape()->mSourceResource->path,bvhFile);
	fpc = fopen(configfile,"r");
	if (fpc==NULL) 
	{
		sprintf(configfile,"%s/bvh/default.cfg",mShapeInstance->getShape()->mSourceResource->path);
		fpc = fopen(configfile,"r");
		if (fpc==NULL)
		{
			Con::errorf("ERROR: can't open config file");
			return;
		}
	}

	//HERE: loop through cfg file, and load up bvhNodes[], bvhPoseRots[], and axesFixRots[]
	jc = 0;
	S32 temp=0;
	F32 PAx,PAy,PAz,PBx,PBy,PBz,FAx,FAy,FAz,FBx,FBy,FBz;
	Point3F worldTrans;

	//fgets(buf,2500,fpc);
	//dSscanf(buf,"WORLD: (%f,%f,%f);",&worldTrans.x,&worldTrans.y,&worldTrans.z);
	
	fgets(buf,2500,fpc);
	dSscanf(buf,"SAMPLE RATE = %d;",&sampleRate);
	while  (fgets(buf,2500,fpc))
	{
		//if (buf[0]=='#') continue;

		dSscanf(buf,"%d;%d;(%f,%f,%f);(%f,%f,%f);(%f,%f,%f);(%f,%f,%f);",
			&temp,&bvhNodes[jc],
			&PAx,&PAy,&PAz,&PBx,&PBy,&PBz,&FAx,&FAy,&FAz,&FBx,&FBy,&FBz);

		bvhPoseRotsA[jc].x = mDegToRad(PAx); bvhPoseRotsB[jc].x = mDegToRad(PBx);
		bvhPoseRotsA[jc].y = mDegToRad(PAy); bvhPoseRotsB[jc].y = mDegToRad(PBy);
		bvhPoseRotsA[jc].z = mDegToRad(PAz); bvhPoseRotsB[jc].z = mDegToRad(PBz);
		axesFixRotsA[jc].x = mDegToRad(FAx); axesFixRotsB[jc].x = mDegToRad(FBx);
		axesFixRotsA[jc].y = mDegToRad(FAy); axesFixRotsB[jc].y = mDegToRad(FBy);
		axesFixRotsA[jc].z = mDegToRad(FAz); axesFixRotsB[jc].z = mDegToRad(FBz);

		//Con::errorf("%s",buf);
		if (jc++ != temp) Con::errorf("WARNING nodes unmatched in %s",configfile);
	}

	//Now, sort: inefficient bubble sort, but who cares, it's trivial anyway.
	for (U32 i=0; i<jc; i++) sortNodes[i] = bvhNodes[i];
	for (U32 i=0; i<jc; i++)
	{
		for (U32 j=0; j<jc-1; j++)
		{
			S32 temp;
			if (sortNodes[j] > sortNodes[j+1]) 
			{
				temp = sortNodes[j];
				sortNodes[j] = sortNodes[j+1];
				sortNodes[j+1] = temp;
			}
		}
	}
	for (U32 i=0; i<jc; i++)
		for (U32 j=0; j<jc; j++)
			if (bvhNodes[j] == sortNodes[i]) orderNodes[i] = j;

	fclose(fpc);

	jc=0;
	char name[40], tempc[40];
	U32 numChannels;

	fgets(buf,250,fp); // HIERARCHY
	fgets(buf,250,fp); // ROOT
	dSscanf(buf,"%s %s",&tempc,&name);

	joints[0].parent = -1;
	dStrcpy(joints[0].name,name);
	fgets(buf,250,fp); // {
	fgets(buf,250,fp);// OFFSET x y z
	dSscanf(buf,"  OFFSET %f %f %f",&p.x,&p.y,&p.z);
	joints[0].offset = p;
	fgets(buf,250,fp);// CHANNELS n ...
	dSscanf(buf,"  CHANNELS %d ",&numChannels);
	joints[0].channels = numChannels;


	fgets(buf,250,fp); 
	bufp = dStrtok(buf," \t\n");

	loadingJoints = true;
	while (loadingJoints)
	{
		keepGoing = true;
		while (keepGoing)
		{
			char tempOne[40];
			sprintf(tempOne,"JOINT");
			if (!dStrstr(bufp,tempOne)) 
			{ 
				keepGoing = false; //End Site
				fgets(buf,250,fp);//{
				fgets(buf,250,fp);//terminal OFFSET x y z, ignore it
				fgets(buf,250,fp);//}
				break; 
			}
			jc++;
			if (newParent>=0) {
				joints[jc].parent = newParent;
				newParent = -1;
			} else joints[jc].parent = jc-1;

			bufp = dStrtok(NULL," \t\n");
			dSscanf(bufp,"%s",name);				
			dStrcpy(joints[jc].name,name);
			fgets(buf,250,fp);//{
			fgets(buf,250,fp);//OFFSET x y z
			bufp = dStrtok(buf," \t\n");//"OFFSET"
			bufp = dStrtok(NULL," \t\n"); dSscanf(bufp,"%f",&joints[jc].offset.x);//X
			bufp = dStrtok(NULL, " \t\n"); dSscanf(bufp,"%f",&joints[jc].offset.y);//Y
			bufp = dStrtok(NULL, " \t\n"); dSscanf(bufp,"%f",&joints[jc].offset.z);//Z

			fgets(buf,250,fp);//CHANNELS n s s s s s s
			bufp = dStrtok(buf," \t\n");//"CHANNELS"
			bufp = dStrtok(NULL," \t\n"); dSscanf(bufp,"%d",&joints[jc].channels);
			//ignore the rest
			//Con::printf("JOINT %d: %s %d %3.2f %3.2f %3.2f",jc,joints[jc].name,joints[jc].channels,
			//	joints[jc].offset.x,joints[jc].offset.y,joints[jc].offset.z);
			Con::printf("JOINT %d: %s ",jc,joints[jc].name);
			
			fgets(buf,250,fp);
			bufp = dStrtok(buf," \t\n");
		}
		//fgets(buf,250,fp);// JOINT?


		//HERE: back out of the nested curly braces, checking for new JOINTs and decrementing jloop each time.

		keepGoing = true;
		while (keepGoing)
		{
			fgets(buf,250,fp);
			bufp = dStrtok(buf," \n\t");
			char tempOne[40],tempTwo[40],tempThree[40];
			sprintf(tempOne,"}");
			sprintf(tempTwo,"JOINT");
			sprintf(tempThree,"MOTION");
			if (dStrstr(bufp,tempOne))
			{
				jloop++;
			} else if (dStrstr(bufp,tempTwo)) {
				newParent = joints[jc-(jloop-1)].parent;
				keepGoing = false;
			} else if (dStrstr(bufp,tempThree)) {
				Con::printf("BVH -- loaded schema, proceeding to motion frames.");
				keepGoing = false;
				loadingJoints = false;
			} else {
				Con::errorf("BVH -- problem, found no frames.");
				fclose(fp);
				return;
			}
		}
	}
	U32 numJoints = jc+1;

	////////////////////////////////////////////////////////////////////////////////////////////////////////
	//NOW: all done loading joints.  Array is filled up and available.  Next step is loading all the motion
	//frames, after picking up the numFrames and frameLength variables.

	fgets(buf,250,fp);//Frames: n
	dSscanf(bufp,"Frames:\t%d",&numFrames);

	fgets(buf,250,fp);//Frame Time: f
	dSscanf(bufp,"Frame Time:\t%f",&frameTime);

	if (!numFrames || (numFrames<=0)) 
	{
		Con::errorf("BVH -- couldn't read numFrames, bailing.");
		fclose(fp);
		return;
	}

	for (U32 c=0;c<numFrames;c++)
	{
		if (!fgets(buf,2500,fp)) 
		{
			Con::errorf("BVH -- not enough frames, bailing out.");
			fclose(fp);
			return;
		}

		pc=0;
		for (U32 d=0; d < numJoints;d++)
		{
			if (d==0) 
				bufp = dStrtok(buf," \t\n");
			else 
				bufp = dStrtok(NULL, " \t\n");

			if (joints[d].channels == 3)
			{
				dSscanf(bufp,"%f",&p.z);
				bufp = dStrtok(NULL, " \t\n");
				dSscanf(bufp,"%f",&p.x);
				bufp = dStrtok(NULL, " \t\n");
				dSscanf(bufp,"%f",&p.y);
				rot3[d] = p;
			}
			else
			{
				dSscanf(bufp,"%f",&p.x);
				bufp = dStrtok(NULL, " \t\n");
				dSscanf(bufp,"%f",&p.y);
				bufp = dStrtok(NULL, " \t\n");
				dSscanf(bufp,"%f",&p.z);
				pos3[d] = p;

				//HERE: note that this is loading z,x,y order, bvh rule.
				bufp = dStrtok(NULL, " \t\n");
				dSscanf(bufp,"%f",&p.z);
				bufp = dStrtok(NULL, " \t\n");
				dSscanf(bufp,"%f",&p.x);
				bufp = dStrtok(NULL, " \t\n");
				dSscanf(bufp,"%f",&p.y);
				rot3[d] = p;
			}
		}
		if (c % sampleRate == 0)
		{
			numSamples++;
			MatrixF m,matX,matY,matZ,matDef,matBvhPose,matBvhPoseA,matBvhPoseB;
			MatrixF matAxesFix,matAxesFixA,matAxesFixB;
			MatrixF matAxesUnfix,matWorldFix,matWorldUnfix;
			EulerF eulX,eulY,eulZ,eulFix,eulWorldFix;

			Point3F temp[4];

			//ASSUMPTION: only root node has translation data.  
			trans[numTrans].x = -pos3[0].x;//do some sign flipping and coord swapping to 
			trans[numTrans].y = pos3[0].z;//get from right-handed to left-handed system.
			trans[numTrans].z = pos3[0].y;
			F32 transScale = kShape->defaultTranslations[0].z / pos3[0].y;
			trans[numTrans] *= transScale;
			numTrans++;

			for (U32 j=0; j<numJoints;j++)
			{
				matBvhPoseA.set(bvhPoseRotsA[j]);
				matBvhPoseB.set(bvhPoseRotsB[j]);
				matBvhPose.mul(matBvhPoseA,matBvhPoseB);

				matAxesFixA.set(axesFixRotsA[j]);
				matAxesFixB.set(axesFixRotsB[j]);
				matAxesFix.mul(matAxesFixA,matAxesFixB);

				matAxesUnfix = matAxesFix;
				matAxesUnfix.inverse();

				eulX.set(mDegToRad(rot3[j].x),0.0,0.0);
				matX.set(eulX);
				eulY.set(0.0,mDegToRad(-rot3[j].z),0.0);
				matY.set(eulY);
				eulZ.set(0.0,0.0,mDegToRad(-rot3[j].y));
				matZ.set(eulZ);

				m.identity();
				m.mul(matBvhPose);
				m.mul(matAxesFix);
				m.mul(matY);//(matZ);
				m.mul(matX);
				m.mul(matZ);//(matY);
				m.mul(matAxesUnfix);

				//BLEND WAY:
				//q.set(m);

				//NON-BLEND WAY:
				q16 = kShape->defaultRotations[bvhNodes[j]];
				q16.getQuatF(&q);

				q.setMatrix(&matDef);
				matDef.mul(m);
				QuatF qFinal(matDef);
				rots[numRots++] = qFinal;

				if (j==0) temp[0] = rot3[j];
				else if (j==1) temp[1] = rot3[j];
				else if (j==2) temp[2] = rot3[j];
				else if (j==3) temp[3] = rot3[j];
			}
		}
		

		dSprintf(rotation,40,"%3.2f %3.2f %3.2f ",pos3[0].x,pos3[0].y,pos3[0].z);
		U32 len = dStrlen(rotation);
		dSprintf(line,40,rotation);
		for (U32 j=0; j<numJoints;j++)
		{
			dSprintf(rotation,40,"%3.2f %3.2f %3.2f ",rot3[j].z,rot3[j].x,rot3[j].y);
			dStrcat(line,rotation);
		}
	}

	fclose(fp);

	
	//NOW, time to make a new sequence,
	//and add it to the stack!

	//for (U32 i=0;i<200;i++) dtsNodes[i] = -1;
	//... and the reverse mapping, just in case I need it.
	//for (U32 i=0;i<numJoints;i++) dtsNodes[bvhNodes[i]] = i;

	
	//DANGER: can you do this while you have an existing shapeInstance?  Change your underlying mShape in realtime?
	//I bet not.  Maybe so, though.
	kShape->sequences.increment();
	TSShape::Sequence & seq = kShape->sequences.last();
	constructInPlace(&seq);

	seq.numKeyframes = numSamples;
	seq.duration = (F32)numFrames * frameTime;
	seq.baseRotation = kShape->nodeRotations.size();
	seq.baseTranslation = kShape->nodeTranslations.size();
	seq.baseScale = 0;
	seq.baseObjectState = 0;
	seq.baseDecalState = 0;
	seq.firstGroundFrame = kShape->groundTranslations.size();
	seq.numGroundFrames = 0;//numSamples;//numSamples?
	seq.firstTrigger = kShape->triggers.size();
	seq.numTriggers = 0;
	seq.toolBegin = 0.0;
	seq.flags = TSShape::Cyclic;// | TSShape::Blend;// | TSShape::MakePath;
	seq.priority = 6;
	

	seq.rotationMatters.clearAll();
	for (U32 i=0;i<numJoints;i++) seq.rotationMatters.set(bvhNodes[i]);

	seq.translationMatters.clearAll();
	seq.translationMatters.set(0);//ASSUMPTION: only root node has position data

	seq.scaleMatters.clearAll();
	seq.visMatters.clearAll();
	seq.frameMatters.clearAll();
	seq.matFrameMatters.clearAll();
	seq.decalMatters.clearAll();
	seq.iflMatters.clearAll();

   kShape->names.increment();
   kShape->names.last() = StringTable->insert(bvhFile);

	seq.nameIndex = kShape->findName(bvhFile);

	for (U32 i=0;i<numSamples;i++)
	{

		kShape->nodeTranslations.increment();
		kShape->nodeTranslations[kShape->nodeTranslations.size()-1] = trans[i];

		//(Not too sure about the ground frames yet.)
		//Quat16 q;
		//q.identity();
		//kShape->groundRotations.increment();
		//kShape->groundRotations[kShape->groundRotations.size()-1] = q;
		//kShape->groundTranslations.increment();
		//kShape->groundTranslations[kShape->groundTranslations.size()-1] = trans[i];
		//Con::errorf("ground translation: %3.2f %3.2f %3.2f",trans[i].x,trans[i].y,trans[i].z);
	}

	for(U32 j=0;j<numJoints;j++)
	{

		for (U32 i=0;i<numSamples;i++)
		{
			q16.set(rots[(i*numJoints)+orderNodes[j]]);
			kShape->nodeRotations.increment();
			kShape->nodeRotations[kShape->nodeRotations.size()-1] = q16;
		}
	}


	//Now, what I will have to do is add all these new rotations to nodeRotations.  And fill in rotationMatters, 
	//translationMatters 
	Con::printf("BVH -- nodes %d nodeTranslations %d nodeRotations %d sequences: %d",kShape->nodes.size(),
		kShape->nodeTranslations.size(),kShape->nodeRotations.size(),kShape->sequences.size());
	for (U32 i=0;i<kShape->sequences.size();i++)
	{
		TSShape::Sequence & seq = kShape->sequences[i];

		Con::printf("Seq[%d] %s frames: %d duration %3.2f baseObjectState %d baseScale %d baseDecalState %d toolbegin %f",
			i,kShape->getName(seq.nameIndex),seq.numKeyframes,
			seq.duration,kShape->sequences[i].baseObjectState,kShape->sequences[i].baseScale,
			kShape->sequences[i].baseDecalState,seq.toolBegin);
		Con::printf("   groundFrames %d isBlend %d isCyclic %d flags %d",
			seq.numGroundFrames,seq.isBlend(),seq.isCyclic(),seq.flags);
	}
}
	
ConsoleMethod( ShapeBase, importBvh, void,  3, 3,"(char filename)")
{
	object->importBvh(argv[2]);
	return;
}

ConsoleMethod( ShapeBase, bvh, void,  3, 3,"(char filename)")
{
	object->importBvh(argv[2]);
	return;
}

ConsoleMethod( ShapeBase, cleanupBvh, void,  3, 3,"(char filename)")
{
	object->cleanupBvh(argv[2]);
	return;
}

ConsoleMethod( ShapeBase, play, void,  3, 3,"(char filename)")
{

	S32 seq = object->getShape()->findSequence(argv[2]);
	if (seq<0) 
	{
		Con::errorf("can't find sequence %s",argv[2]);
		return;
	}
	object->stopThread(0);
	object->setThreadSequence(0,seq);
	return;
}

//ConsoleMethod( ShapeBase, saveOut, void,  3, 3,"(char filename)")
ConsoleMethod( ShapeBase, saveOut, void,  2, 2,"")
{
	FileStream outstream;
	char filename[255];

	sprintf(filename,"%s/allSeq.dsq",object->getShapeInstance()->getShape()->mSourceResource->path);//,argv[2]);

	if (!ResourceManager->openFileForWrite(outstream,filename)) {
		Con::printf("whoops, name no good!"); 
	} else {
		object->getShapeInstance()->getShape()->exportSequences((Stream *)&outstream);
		outstream.close();
	}
}

ConsoleMethod( ShapeBase, showSeq, void, 2, 2, "")
{
	
	TSShape *kShape = object->getShapeInstance()->getShape();

	for (U32 i=0;i<kShape->sequences.size();i++)
	{
		TSShape::Sequence & seq = kShape->sequences[i];

		Con::printf("Seq[%d] %s frames: %d duration %3.2f baseObjectState %d baseScale %d baseDecalState %d toolbegin %f",
			i,kShape->getName(seq.nameIndex),seq.numKeyframes,
			seq.duration,kShape->sequences[i].baseObjectState,kShape->sequences[i].baseScale,
			kShape->sequences[i].baseDecalState,seq.toolBegin);
		Con::printf("   groundFrames %d isBlend %d isCyclic %d flags %d",
			seq.numGroundFrames,seq.isBlend(),seq.isCyclic(),seq.flags);
	}
}

ConsoleMethod( ShapeBase, showNodes, void, 2, 2, "")
{
	TSShape *kShape = object->getShapeInstance()->getShape();
	for (U32 i=0;i<kShape->nodes.size();i++)
		Con::printf("nodes[%d] %s",i,kShape->getName(kShape->nodes[i].nameIndex));
}


ConsoleMethod( ShapeBase, showNodeRots, void, 3, 3, "showNodeRots(seq)")
{
	S32 seq,node;
	dSscanf(argv[2],"%d",&seq);
	TSShape *kShape = object->getShapeInstance()->getShape();
	for (U32 i=0;i<kShape->sequences[seq].numKeyframes;i++)
	{
		node=0;
		Con::errorf("////////////////////////////////////////////");
		for (U32 j=0;j<kShape->nodes.size();j++)
		{
			if (kShape->sequences[seq].rotationMatters.test(j))
			{
				Quat16 q16 = kShape->nodeRotations[i+kShape->sequences[seq].baseRotation+node];
				QuatF q;
				q16.getQuatF(&q);
				Con::printf("frame %d nodes[%d] %3.2f %3.2f %3.2f %3.2f",i,j,q.x,q.y,q.z,q.w);
				node++;
			}
		}
	}
}


ConsoleMethod( ShapeBase, showDefRots, void, 2, 2, "showDefRots()")
{

	TSShape *kShape = object->mShapeInstance->mShape;
	for (U32 j=0;j<kShape->nodes.size();j++)
	{
		if (kShape->sequences[13].rotationMatters.test(j))
		//if (1)
		{
			QuatF q; MatrixF m; EulerF e, ei;
			kShape->defaultRotations[j].getQuatF(&q);
			q.setMatrix(&m);
			e = m.toEuler();
			e.x = mRadToDeg(e.x); e.y = mRadToDeg(e.y); e.z = mRadToDeg(e.z); 
			m.inverse();
			ei = m.toEuler();
			ei.x = mRadToDeg(ei.x); ei.y = mRadToDeg(ei.y); ei.z = mRadToDeg(ei.z); 
			Con::printf("defRots[%d] %3.2f %3.2f %3.2f %3.2f, euler %3.2f %3.2f %3.2f,inverse %3.2f %3.2f %3.2f",
				j,q.x,q.y,q.z,q.w,e.x,e.y,e.z,ei.x,ei.y,ei.z);
		}
	}

}
