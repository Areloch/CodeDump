//-----------------------------------------------------------------------------
// Copyright (c) 2003 Phil Carlisle
//
//-----------------------------------------------------------------------------

#include "dgl/dgl.h"
#include "console/consoleTypes.h"
#include "core/bitStream.h"
#include "math/mathIO.h"
#include "game/gameConnection.h"
#include "console/simBase.h"
#include "sceneGraph/sceneGraph.h"
#include "sceneGraph/sgUtil.h"
#include "fxRenderSphere.h"

//------------------------------------------------------------------------------
//
//	Put the function in /example/common/editor/ObjectBuilderGui.gui [around line 458] ...
//
//	function ObjectBuilderGui::buildfxRenderSphere(%this)
//	{
//		%this.className = "fxRenderSphere";
//		%this.process();
//	}
//
//------------------------------------------------------------------------------
//
//	Put this in /example/common/editor/EditorGui.cs in [function Creator::init( %this )]
//
//   %Environment_Item[ next free entry ] = "fxRenderSphere";  <-- ADD THIS.
//
//------------------------------------------------------------------------------
extern bool gEditingMission;

//------------------------------------------------------------------------------

IMPLEMENT_CO_NETOBJECT_V1(fxRenderSphere);


//------------------------------------------------------------------------------
// Class: fxRenderSphere
//------------------------------------------------------------------------------

fxRenderSphere::fxRenderSphere()
{
    bUseTextureAsSphereColours = false;
    mColour.set(1.0f,1.0f,1.0f,1.0f);
	VertexPositions = NULL;
	VertexColors    = NULL;
	Triangles       = NULL;
	
	NorthFan = NULL;
	SouthFan = NULL;
	Strips   = NULL;

    bOptimizeTris = true;
	slices = 16;
	// Setup NetObject.
	mTypeMask |= StaticObjectType | StaticTSObjectType | StaticRenderedObjectType;
	mNetFlags.set(Ghostable);

	// Reset Last Render Time.
	mLastRenderTime = 0;

	// Texture Handle.
	mTextureHandle = NULL;
	// Flare Texture Name.
	mTextureName = StringTable->insert("");

	// Reset Size.
	mSize = 300.0f;
	// Reset Rotate Speed.
	mRotateSpeed = 0.0f;

	// Reset Current Angle.
	mCurrentAngle = 0.0f;
}

//------------------------------------------------------------------------------

fxRenderSphere::~fxRenderSphere()
{
}

//------------------------------------------------------------------------------

void fxRenderSphere::initPersistFields()
{
	// Initialise parents' persistent fields.
	Parent::initPersistFields();

	// Add out own persistent fields.
	//addGroup( "MyFirstGroup1" );
    addField( "Size",			TypeF32,		Offset( mSize,				fxRenderSphere ) );
    addField( "RotateSpeed",	TypeF32,		Offset( mRotateSpeed,		fxRenderSphere ) );
    addField( "Texture",		TypeFilename,	Offset( mTextureName,		fxRenderSphere ) );
    addField( "Colour",         TypeColorF,     Offset( mColour,            fxRenderSphere ) );
    addField( "UseTextureAsColourMap", TypeBool, Offset (bUseTextureAsSphereColours,fxRenderSphere) );
	//enddGroup( "MyFirstGroup1" );
}

//------------------------------------------------------------------------------

bool fxRenderSphere::onAdd()
{
	if(!Parent::onAdd()) return(false);

	// Calculate Quad Radius.
	F32 HalfSize = mSize / 2.0f;

	// Set initial bounding box.
	//
	// NOTE:-	Set this box to completely encapsulate your object.
	//			You must reset the world box and set the render transform
	//			after changing this.
	mObjBox.min.set( -HalfSize, -HalfSize, -HalfSize );
	mObjBox.max.set(  HalfSize, HalfSize,  HalfSize );
	// Reset the World Box.
	resetWorldBox();
	// Set the Render Transform.
	setRenderTransform(mObjToWorld);

	// Add to Scene.
	addToScene();

	// Return OK.
	return(true);
}

//------------------------------------------------------------------------------

void fxRenderSphere::onRemove()
{
	// Remove from Scene.
	removeFromScene();

	// Do Parent.
	Parent::onRemove();
}

//------------------------------------------------------------------------------

void fxRenderSphere::inspectPostApply()
{
	// Set Parent.
	Parent::inspectPostApply();

	// Set fxPortal Mask.
	setMaskBits(fxRenderSphereMask);

    //Cleanup();
    //GenerateNewSphere();
}

//------------------------------------------------------------------------------

void fxRenderSphere::onEditorEnable()
{
}

//------------------------------------------------------------------------------

void fxRenderSphere::onEditorDisable()
{
}

//------------------------------------------------------------------------------

bool fxRenderSphere::prepRenderImage(	SceneState* state, const U32 stateKey, const U32 startZone,
										const bool modifyBaseZoneState)
{
	// Return if last state.
	if (isLastState(state, stateKey)) return false;
	// Set Last State.
	setLastState(state, stateKey);

   // Is Object Rendered?
   if (state->isObjectRendered(this))
   {	   
		// Yes, so get a SceneRenderImage.
		SceneRenderImage* image = new SceneRenderImage;
		// Populate it.
		image->obj = this;
		image->isTranslucent = false;
		image->sortType = SceneRenderImage::Normal;
		
		// Insert it into the scene images.
		state->insertRenderImage(image);
   }

   return false;
}

//------------------------------------------------------------------------------

void fxRenderSphere::renderObject(SceneState* state, SceneRenderImage*)
{
	// Check we are in Canonical State.
	AssertFatal(dglIsInCanonicalState(), "Error, GL not in canonical state on entry");

	// Calculate Elapsed Time and take new Timestamp.
	S32 Time = Platform::getVirtualMilliseconds();
	F32 ElapsedTime = (Time - mLastRenderTime) * 0.001f;
	mLastRenderTime = Time;

	// Return if we don't have a texture.
	

	// Save state.
	RectI viewport;

	// Save Projection Matrix so we can restore Canonical state at exit.
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();

	// Save Viewport so we can restore Canonical state at exit.
	dglGetViewport(&viewport);

	// Setup the projection to the current frustum.
	//
	// NOTE:-	You should let the SceneGraph drive the frustum as it
	//			determines portal clipping etc.
	//			It also leaves us with the MODELVIEW current.
	//
	state->setupBaseProjection();

	// Save ModelView Matrix so we can restore Canonical state at exit.
	glPushMatrix();

	// Transform by the objects' transform e.g move it.
	dglMultMatrix(&getTransform());

	// Rotate by Rotate Speed.
	//
	// NOTE:-	We use the elapsed time as a coeficient,
	//			that way we get consistent rotational speed
	//			independant of frame-rate.
	//
	mCurrentAngle += mFmod(mRotateSpeed * ElapsedTime, 360);

	// Rotate Quad by current roation.
	glRotatef(mCurrentAngle, 0,0,1);

	// Setup our rendering state (alpha blending).
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    glEnable(GL_ALPHA);
    glEnable(GL_COLOR_MATERIAL);
    
    glEnable(GL_LIGHTING);

	// Select the objects' texture.
    if (mTextureHandle)
    {
	    // Enable Texturing.
	    glEnable(GL_TEXTURE_2D);
	    glBindTexture(GL_TEXTURE_2D, mTextureHandle.getGLName());
    }
	// Set Colour/Alpha.
	glColor4f(1,1,1,0.1f);

	// Calculate Quad Radius.
	F32 HalfSize = mSize / 2.0f;

	// Draw a Quad.
	//
	// NOTE:-	We draw in object space here and *not* world-space.
	//			Notice that Z is UP in this system and XY lie on the terrain plane.
	//
    //glScalef(mSize,mSize,mSize);

	//Render();
    if (bUseTextureAsSphereColours)
    {
        glDisable(GL_TEXTURE_2D);
        RenderColourSphere();
    }
    else
    {
        RenderSphere( 0.0f,0.0f,0.0f, HalfSize, 32 );
    }


    glDisable(GL_LIGHTING);
    glDisable(GL_COLOR_MATERIAL);
	// Restore our canonical rendering state.
	glDisable(GL_BLEND);
	glDisable(GL_TEXTURE_2D);
	// Restore our canonical matrix state.
	glPopMatrix();
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
	// Restore our canonical viewport state.
	dglSetViewport(viewport);

	// Check we have restored Canonical State.
	AssertFatal(dglIsInCanonicalState(), "Error, GL not in canonical state on exit");
}


//-----------------------------------------------------------------------------
// Name: RenderSphere()
// Desc: Render a sphere centered at c_y, c_x, c_z with radius r, and 
//       precision n
//-----------------------------------------------------------------------------
void fxRenderSphere::RenderSphere( F32 c_x, F32 c_y, F32 c_z, F32 r, S32 n )
{
   S32 i = 0;
   S32 j = 0;

   F32 theta1 = 0.0;
   F32 theta2 = 0.0;
   F32 theta3 = 0.0;

   F32 e_x = 0.0f;
   F32 e_y = 0.0f;
   F32 e_z = 0.0f;

   F32 p_x = 0.0f;
   F32 p_y = 0.0f;
   F32 p_z = 0.0f;

   if( r < 0 )
      r = -r;

   if( n < 0 )
      n = -n;

   if( n < 4 || r <= 0 ) 
   {
      glBegin(GL_POINTS);
      glVertex3f( c_x, c_y, c_z );
      glEnd();
      return;
   }

   for( j = 0; j < n/2; ++j )
   {
      theta1 = j * TWOPI / n - PIDIV2;
      theta2 = (j + 1) * TWOPI / n - PIDIV2;

      glBegin(GL_QUAD_STRIP);

      for( i = 0; i <= n; i++ ) 
      {
         theta3 = i * TWOPI / n;

         e_x = cos(theta2) * cos(theta3);
         e_y = sin(theta2);
         e_z = cos(theta2) * sin(theta3);
         p_x = c_x + r * e_x;
         p_y = c_y + r * e_y;
         p_z = c_z + r * e_z;

         glColor4f( mColour.red * cos(theta2), mColour.green * cos(theta2),mColour.blue * cos(theta2), mColour.alpha );
         glNormal3f( e_x, e_y, e_z );
         glTexCoord2f( i/(F32)n,2*(j+1)/(F32)n );
         glVertex3f( p_x, p_y, p_z );

         e_x = cos(theta1) * cos(theta3);
         e_y = sin(theta1);
         e_z = cos(theta1) * sin(theta3);
         p_x = c_x + r * e_x;
         p_y = c_y + r * e_y;
         p_z = c_z + r * e_z;

         glColor4f( mColour.red * cos(theta1), mColour.green * cos(theta1),mColour.blue * cos(theta1), mColour.alpha );
         glNormal3f( e_x, e_y, e_z );
         glTexCoord2f( i/(F32)n,2*j/(F32)n );
         glVertex3f( p_x, p_y, p_z );
      }
      glEnd();
   }
}

//-----------------------------------------------------------------------------
// Name: RenderColourSphere()
// Desc: Render a sphere centered at c_y, c_x, c_z with radius r, and 
//       precision n
//-----------------------------------------------------------------------------
void fxRenderSphere::RenderColourSphere() 
{
    ColorI mColour;
    // ensure we have a valid texture to use,
    if (!mTextureHandle) return;
    GBitmap *pBitmap = mTextureHandle.getBitmap();
    if (pBitmap == NULL)
    {
        mTextureHandle.set(mTextureName, BitmapKeepTexture, true);
        pBitmap = mTextureHandle.getBitmap();
        if (pBitmap == NULL) return;
    }
    // note: the user is responsible for ensuring the bitmap provided is actually
    // usable for this purpose!!!


    U32 longsegs = pBitmap->getWidth();
    U32 latsegs = pBitmap->getHeight();
    if (longsegs < 2) return;
    if (latsegs < 2) return;
    if (longsegs > 20) return; // change this if you want a more fine detailed sphere.
    if (latsegs > 20) return; // likewise.

   S32 i = 0;
   S32 j = 0;

   F32 theta1 = 0.0;
   F32 theta2 = 0.0;
   F32 theta3 = 0.0;

   F32 e_x = 0.0f;
   F32 e_y = 0.0f;
   F32 e_z = 0.0f;

   F32 p_x = 0.0f;
   F32 p_y = 0.0f;
   F32 p_z = 0.0f;

    F32 r = mSize / 2.0f;
 
   F32 c_x = 0.0f; 
   F32 c_y = 0.0f; 
   F32 c_z = 0.0f; 

   S32 n = longsegs;
   
   


   for( j = 0; j < n/2; ++j )
   {
      theta1 = j * TWOPI / n - PIDIV2;
      theta2 = (j + 1) * TWOPI / n - PIDIV2;

      glBegin(GL_QUAD_STRIP);

      for( i = 0; i <= n; i++ ) 
      {
         theta3 = i * TWOPI / n;

         e_x = cos(theta2) * cos(theta3);
         e_y = sin(theta2);
         e_z = cos(theta2) * sin(theta3);
         p_x = c_x + r * e_x;
         p_y = c_y + r * e_y;
         p_z = c_z + r * e_z;

         
         pBitmap->getColor(i,2*(j+1),mColour);
         glColor4ub( mColour.red, mColour.green,mColour.blue,mColour.alpha);
         //glColor4i( 255,255,255,0);   
         //glColor4f(1,1,1,1);
         glNormal3f( e_x, e_y, e_z );
         glVertex3f( p_x, p_y, p_z );

         e_x = cos(theta1) * cos(theta3);
         e_y = sin(theta1);
         e_z = cos(theta1) * sin(theta3);
         p_x = c_x + r * e_x;
         p_y = c_y + r * e_y;
         p_z = c_z + r * e_z;

         //pBitmap->getColor(i,j,mColour);
         pBitmap->getColor(i,2*j,mColour);

         glColor4ub( mColour.red, mColour.green,mColour.blue,mColour.alpha);
         //glColor4i( 255,255,255,255);   
         //glColor4f(1,1,1,1);
         glNormal3f( e_x, e_y, e_z );
         glVertex3f( p_x, p_y, p_z );
      }
      glEnd();
   }
}


//------------------------------------------------------------------------------

U32 fxRenderSphere::packUpdate(NetConnection * con, U32 mask, BitStream * stream)
{
	// Pack Parent.
	U32 retMask = Parent::packUpdate(con, mask, stream);

	// Write fxPortal Mask Flag.
	if (stream->writeFlag(mask & fxRenderSphereMask))
	{
		// Write Object Transform.
		stream->writeAffineTransform(mObjToWorld);
		// Write Texture Name.
		stream->writeString(mTextureName);
		// Write Quad Size.
		stream->write(mSize);
		// Write Quad Rotate Speed.
		stream->write(mRotateSpeed);
      
        stream->write(mColour.red);
        stream->write(mColour.green);
        stream->write(mColour.blue);
        stream->write(mColour.alpha);

        stream->write(bUseTextureAsSphereColours);
	}

	// Were done ...
	return(retMask);
}

//------------------------------------------------------------------------------

void fxRenderSphere::unpackUpdate(NetConnection * con, BitStream * stream)
{
	// Unpack Parent.
	Parent::unpackUpdate(con, stream);

	// Read fxPortal Mask Flag.
	if(stream->readFlag())
	{
		MatrixF		ObjectMatrix;

		// Read Object Transform.
		stream->readAffineTransform(&ObjectMatrix);
		// Read Texture Name.
		mTextureName = StringTable->insert(stream->readSTString());
		// Read Quad Size.
		stream->read(&mSize);
		// Read Quad Rotate Speed.
		stream->read(&mRotateSpeed);


        stream->read(&mColour.red);
        stream->read(&mColour.green);
        stream->read(&mColour.blue);
        stream->read(&mColour.alpha);

        stream->read(&bUseTextureAsSphereColours);
		// Set Transform.
		setTransform(ObjectMatrix);

		// Reset our previous texture handle.
		mTextureHandle = NULL;    
		// Load the texture (if we've got one)
		if (*mTextureName) mTextureHandle = TextureHandle(mTextureName, BitmapTexture, true);

		// Calculate Quad Radius.
		F32 HalfSize = mSize / 2.0f;

		// Set bounding box.
		//
		// NOTE:-	Set this box to completely encapsulate your object.
		//			You must reset the world box and set the render transform
		//			after changing this.
		mObjBox.min.set( -HalfSize, -HalfSize, -HalfSize );
		mObjBox.max.set(  HalfSize, HalfSize,  HalfSize );
		// Reset the World Box.
		resetWorldBox();
		// Set the Render Transform.
		setRenderTransform(mObjToWorld);
	}
}

