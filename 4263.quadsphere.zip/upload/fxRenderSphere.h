//-----------------------------------------------------------------------------
// Copyright 2003 (c) Phil Carlisle
// 
// Portions Copyright (c) Garagegames
//-----------------------------------------------------------------------------

#ifndef _FXRENDERSPHERE_H_
#define _FXRENDERSPHERE_H_

#ifndef _SCENESPHERE_H_
#include "sim/sceneObject.h"
#endif


//------------------------------------------------------------------------------
// Class: fxRenderSphere
//------------------------------------------------------------------------------
class fxRenderSphere : public SceneObject
{
private:
	typedef SceneObject		Parent;

protected:

	// Create and use these to specify custom events.
	//
	// NOTE:-	Using these allows you to group the changes into related
	//			events.  No need to change everything if something minor
	//			changes.  Only really important if you have *lots* of these
	//			objects at start-up or you send alot of changes whilst the
	//			game is in progress.
	//
	//			Use "setMaskBits(fxRenderSphereMask)" to signal.

	enum {	fxRenderSphereMask		= (1 << 0),
			fxRenderSphereAnother	= (1 << 1) };

	S32								mLastRenderTime;
	TextureHandle					mTextureHandle;
	F32								mCurrentAngle;

	// Fields.
	F32								mSize;
	F32								mRotateSpeed;
    StringTableEntry				mTextureName;
	bool							bRenderOutside; // true render sphere with normals facing out
													// false makes normals face inwards.
	U32								mVerticalSegments;
	U32								mHorizontalSegments;
	bool							bUseMaterial;
	U32								mBlendSource;
	U32								mBlendDest;
    ColorF							mColour;	

    //-----------------------------------------------------------------------------
    // DEFINES
    //-----------------------------------------------------------------------------

    #define PI     3.14159265358979
    #define TWOPI  6.28318530717958
    #define PIDIV2 1.57079632679489
	
	//-----------------------------------------------------------------------------
	// GLOBALS
	//-----------------------------------------------------------------------------
	
	F32 **VertexPositions;
	F32 **VertexColors;
	S32 **Triangles;
	
	S32  *NorthFan;
	S32  *SouthFan;
	S32  **Strips;
	
	S32 numVertices;
	S32 numTriangles;
	S32 slices;
	
	F32 heading; //these are for rotating the sphere
	F32 pitch;
	
	bool bOptimizeTris;
    bool bUseTextureAsSphereColours;

public:
	fxRenderSphere();
	~fxRenderSphere();

	// SceneObject
	void renderObject(SceneState*, SceneRenderImage*);
	virtual bool prepRenderImage(SceneState*, const U32 stateKey, const U32 startZone,
								const bool modifyBaseZoneState = false);

	// PC functions
    void RenderSphere( F32 c_x, F32 c_y, F32 c_z, F32 r, S32 n );
    void RenderColourSphere();
	// SimObject      
	bool onAdd();
	void onRemove();
	void onEditorEnable();
	void onEditorDisable();
	void inspectPostApply();

	// NetObject
	U32 packUpdate(NetConnection *, U32, BitStream *);
	void unpackUpdate(NetConnection *, BitStream *);

	// ConObject.
	static void initPersistFields();

	// Declare Console Object.
	DECLARE_CONOBJECT(fxRenderSphere);
};

#endif // _FXRENDERSPHERE_H_
