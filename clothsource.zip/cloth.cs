datablock ClothItemData(Cloth)
{
  category = "Cloth";
  shapeFile = "~/data/shapes/cloth/cloth.dts";
};

function ClothItemData::Create(%data)
{
   %obj = new ClothItem()
{
      datablock = %data;
};
}