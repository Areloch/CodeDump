//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#ifndef _ITEM_H_
#define _ITEM_H_

#ifndef _SHAPEBASE_H_
#include "game/shapeBase.h"
#endif
#ifndef _LIGHTMANAGER_H_
#include "lightingSystem/sgLightManager.h";
#endif
#ifndef _BOXCONVEX_H_
#include "collision/boxConvex.h"
#endif

//fxCloth
#define CLOTH_SIZE 3.0f
#define CONSTRAINT_UPDATE 3
#define TEXTURE_SIZE 8
#define CLOTH_RESOLUTION 20
#define TIME_STEP 0.01f
#define TIME_FACTOR TIME_STEP*TIME_STEP
#define TIME_CONSTANT 1000

struct CLOTH_CONSTRAINT
{
       int particle1, particle2;
       float restlength;
};

//fxCloth

//----------------------------------------------------------------------------

struct ClothItemData: public ShapeBaseData {
  typedef ShapeBaseData Parent;

  F32 friction;
  F32 elasticity;

  bool sticky;
  F32  gravityMod;
  F32  maxVelocity;

  S32 dynamicTypeField;

  StringTableEntry pickUpName;

  bool        lightOnlyStatic;
  S32         lightType;
  ColorF      lightColor;
  S32         lightTime;
  F32         lightRadius;

       //fxCloth
       Point3F massCenter;        ///< Center of mass for rigid body
       Point3F massBox;           ///< Size of inertial box
       //fxCloth

  ClothItemData();
  DECLARE_CONOBJECT(ClothItemData);
  static void initPersistFields();
  virtual void packData(BitStream* stream);
  virtual void unpackData(BitStream* stream);

};


//----------------------------------------------------------------------------

class ClothItem: public ShapeBase
{
  typedef ShapeBase Parent;

  // Client interpolation data
  struct StateDelta {
     Point3F pos;
     VectorF posVec;
     S32 warpTicks;
     Point3F warpOffset;
     F32     dt;
  };
  StateDelta delta;

  // Static attributes
  ClothItemData* mDataBlock;
  static F32 mGravity;
  bool mCollideable;
  bool mStatic;
  bool mRotate;

   //fxCloth

   S32 mSimulationtime;

       enum {    ClothObjectMask  = (1 << 0),
           ClothObjectAnother = (1 << 1) };
           TextureHandle mTextureHandle;

   //int mNumparticles;
   float mForces[CLOTH_RESOLUTION * CLOTH_RESOLUTION * 3];
   float mNormals[CLOTH_RESOLUTION * CLOTH_RESOLUTION * 3];
   float mCloth1[CLOTH_RESOLUTION * CLOTH_RESOLUTION * 4];
   int mPointA;
   float mCloth2[CLOTH_RESOLUTION * CLOTH_RESOLUTION * 4];
   float *mCurrentcloth;
   float *mPreviouscloth;
   const static int mNumparticles = CLOTH_RESOLUTION * CLOTH_RESOLUTION;
   const static int mNumconstraints = 2 * CLOTH_RESOLUTION * (CLOTH_RESOLUTION - 1) + (CLOTH_RESOLUTION - 1) * (CLOTH_RESOLUTION - 1);
   CLOTH_CONSTRAINT mConstraints[2 * CLOTH_RESOLUTION * (CLOTH_RESOLUTION - 1) + (CLOTH_RESOLUTION - 1) * (CLOTH_RESOLUTION - 1)];
   float mSphere[4];
   float mGravityforce;
   float mWinddirection[3];
   float mWindspeed;
   float mWindvector[3];

   StringTableEntry  mTextureName;
   bool  mShowParticles;

       //fxCloth

  //
  VectorF mVelocity;
  bool mAtRest;
  S32 mAtRestCounter;
  static const S32 csmAtRestTimer;

  bool mInLiquid;

  ShapeBase* mCollisionObject;
  U32 mCollisionTimeout;

 public:

  void registerLights(LightManager *lightManager, bool lightingScene);
  enum LightType
  {
     NoLight = 0,
     ConstantLight,
     PulsingLight,

     NumLightTypes,
  };

 private:
  S32         mDropTime;
  LightInfo   mLight;

 public:

  Point3F mStickyCollisionPos;
  Point3F mStickyCollisionNormal;

  //
 private:
  OrthoBoxConvex mConvex;
  Box3F          mWorkingQueryBox;

  void updateVelocity(const F32 dt);
  void updatePos(const U32 mask, const F32 dt);
  void updateWorkingCollisionSet(const U32 mask, const F32 dt);
  bool buildPolyList(AbstractPolyList* polyList, const Box3F &box, const SphereF &sphere);
  void buildConvex(const Box3F& box, Convex* convex);
  void onDeleteNotify(SimObject*);

  bool prepRenderImage(SceneState *state, const U32 stateKey, const U32 startZone, const bool modifyBaseZoneState);

       //fxCloth
       void accumulateforces(void);
       void verlet(void);
       void satisfyconstraints(void);
       void calculatenormals(void);
       void initializecloth(int setuptype);
       void updatecloth(void);
       //fxCloth



 public:
  DECLARE_CONOBJECT(ClothItem);

  enum MaskBits {
     HiddenMask   = Parent::NextFreeMask,
     ThrowSrcMask = Parent::NextFreeMask << 1,
     PositionMask = Parent::NextFreeMask << 2,
     RotationMask = Parent::NextFreeMask << 3,
     NextFreeMask = Parent::NextFreeMask << 4
  };

  ClothItem();
  ~ClothItem();
  static void initPersistFields();
  static void consoleInit();

  bool onAdd();
  void onRemove();
  bool onNewDataBlock(GameBaseData* dptr);

  void sphere(int x, int y, int z);
  void pointA(F32 pointA);
  bool isStatic()   { return mStatic; }
  bool isRotating() { return mRotate; }
  Point3F getVelocity() const;
  void setVelocity(const VectorF& vel);
  void applyImpulse(const Point3F& pos,const VectorF& vec);
  void setCollisionTimeout(ShapeBase* obj);
  ShapeBase* getCollisionObject()   { return mCollisionObject; };

  void processTick(const Move *move);
  void interpolateTick(F32 delta);
  void setTransform(const MatrixF &mat);
  void renderImage(SceneState *state, SceneRenderImage *image);

  U32  packUpdate  (NetConnection *conn, U32 mask, BitStream *stream);
  void unpackUpdate(NetConnection *conn,           BitStream *stream);
};

#endif