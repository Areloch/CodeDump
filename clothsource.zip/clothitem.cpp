// Credits include Robert Stewart, Johan Carlsson and other members of the GarageGames community.
//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#include "platform/platform.h"
#include "dgl/dgl.h"
#include "core/bitStream.h"
#include "game/game.h"
#include "math/mMath.h"
#include "console/simBase.h"
#include "console/console.h"
#include "console/consoleTypes.h"
#include "sim/netConnection.h"
#include "clothitem.h"
#include "collision/boxConvex.h"
#include "game/shadow.h"
#include "collision/earlyOutPolyList.h"
#include "collision/extrudedPolyList.h"
#include "math/mathIO.h"


//----------------------------------------------------------------------------

const F32 sRotationSpeed = 3.0;        // Secs/Rotation
const F32 sAtRestVelocity = 0.15;      // Min speed after collision
const S32 sCollisionTimeout = 15;      // Timout value in ticks

// Client prediction
static F32 sMinWarpTicks = 0.5;        // Fraction of tick at which instant warp occures
static S32 sMaxWarpTicks = 3;          // Max warp duration in ticks

F32 ClothItem::mGravity = 0;

const U32 sClientCollisionMask = (TerrainObjectType     | InteriorObjectType |
                                 StaticShapeObjectType | VehicleObjectType  |
                                 PlayerObjectType      | StaticTSObjectType);

const U32 sServerCollisionMask = (sClientCollisionMask);

const S32 ClothItem::csmAtRestTimer = 64;

static const U32 sgAllowedDynamicTypes = DamagableItemObjectType;

//----------------------------------------------------------------------------

IMPLEMENT_CO_DATABLOCK_V1(ClothItemData);

ClothItemData::ClothItemData()
{
  friction = 0;
  elasticity = 0;

  sticky = false;
  gravityMod = 1.0;
  maxVelocity = -1;

  density = 2;
  drag = 0.5;

  genericShadowLevel = Item_GenericShadowLevel;
  noShadowLevel = Item_NoShadowLevel;
  dynamicTypeField     = 0;
  pickUpName = StringTable->insert("an ClothItem");

  lightOnlyStatic = false;
  lightType = ClothItem::NoLight;
  lightColor.set(1.f,1.f,1.f,1.f);
  lightTime = 1000;
  lightRadius = 10.f;

  //fxCloth
  massCenter.set(0,0,0);
  massBox.set(0,0,0);
  //fxCloth

}

static EnumTable::Enums itemLightEnum[] =
{
  { ClothItem::NoLight,           "NoLight" },
  { ClothItem::ConstantLight,     "ConstantLight" },
  { ClothItem::PulsingLight,      "PulsingLight" }
};
static EnumTable gItemLightTypeTable(ClothItem::NumLightTypes, &itemLightEnum[0]);

void ClothItemData::initPersistFields()
{
  Parent::initPersistFields();

  addField("pickUpName",  TypeString, Offset(pickUpName,         ClothItemData));

  addField("friction",    TypeF32,    Offset(friction,           ClothItemData));
  addField("elasticity",  TypeF32,    Offset(elasticity,         ClothItemData));
  addField("sticky",      TypeBool,   Offset(sticky,             ClothItemData));
  addField("gravityMod",  TypeF32,    Offset(gravityMod,         ClothItemData));
  addField("maxVelocity", TypeF32,    Offset(maxVelocity,        ClothItemData));
  addField("dynamicType", TypeS32,    Offset(dynamicTypeField,   ClothItemData));

  addField("lightType",   TypeEnum,   Offset(lightType,          ClothItemData), 1, &gItemLightTypeTable);
  addField("lightColor",  TypeColorF, Offset(lightColor,         ClothItemData));
  addField("lightTime",   TypeS32,    Offset(lightTime,          ClothItemData));
  addField("lightRadius", TypeF32,    Offset(lightRadius,        ClothItemData));
  addField("lightOnlyStatic", TypeBool, Offset(lightOnlyStatic,  ClothItemData));
}

void ClothItemData::packData(BitStream* stream)
{
  Parent::packData(stream);
  stream->writeFloat(friction, 10);
  stream->writeFloat(elasticity, 10);
  stream->writeFlag(sticky);
  if(stream->writeFlag(gravityMod != 1.0))
     stream->writeFloat(gravityMod, 10);
  if(stream->writeFlag(maxVelocity != -1))
     stream->write(maxVelocity);

  if(stream->writeFlag(lightType != ClothItem::NoLight))
  {
     AssertFatal(ClothItem::NumLightTypes < (1 << 2), "ClothItemData: light type needs more bits");
     stream->writeInt(lightType, 2);
     stream->writeFloat(lightColor.red, 7);
     stream->writeFloat(lightColor.green, 7);
     stream->writeFloat(lightColor.blue, 7);
     stream->writeFloat(lightColor.alpha, 7);
     stream->write(lightTime);
     stream->write(lightRadius);
     stream->writeFlag(lightOnlyStatic);
  }
}

void ClothItemData::unpackData(BitStream* stream)
{
  Parent::unpackData(stream);
  friction = stream->readFloat(10);
  elasticity = stream->readFloat(10);
  sticky = stream->readFlag();
  if(stream->readFlag())
     gravityMod = stream->readFloat(10);
  else
     gravityMod = 1.0;

  if(stream->readFlag())
     stream->read(&maxVelocity);
  else
     maxVelocity = -1;

  if(stream->readFlag())
  {
     lightType = stream->readInt(2);
     lightColor.red = stream->readFloat(7);
     lightColor.green = stream->readFloat(7);
     lightColor.blue = stream->readFloat(7);
     lightColor.alpha = stream->readFloat(7);
     stream->read(&lightTime);
     stream->read(&lightRadius);
     lightOnlyStatic = stream->readFlag();
  }
  else
     lightType = ClothItem::NoLight;
}


//----------------------------------------------------------------------------

IMPLEMENT_CO_NETOBJECT_V1(ClothItem);

ClothItem::ClothItem()
{
  mTypeMask |= ItemObjectType;
  mDataBlock = 0;
  mCollideable = false;
  mStatic = false;
  mRotate = false;
  mVelocity = VectorF(0,0,0);
  mAtRest = true;
  mAtRestCounter = 0;
  mInLiquid = false;
  delta.warpTicks = 0;
  delta.dt = 1;
  mCollisionObject = 0;
  mCollisionTimeout = 0;
//   mGenerateShadow = true;

  mConvex.init(this);
  mWorkingQueryBox.min.set(-1e9, -1e9, -1e9);
  mWorkingQueryBox.max.set(-1e9, -1e9, -1e9);

   //fxCloth
   mSimulationtime = 0;

   // Texture Handle.
   mTextureHandle = NULL;
   mTextureName = StringTable->insert("starter.fps/data/shapes/bot/flag.jpg");
   mShowParticles = false;

   mForces;
   mNormals;
   mCloth1;
   mPointA;
   mCloth1[3] = 0.0f;
   mCloth2;
   *mCurrentcloth;
   *mPreviouscloth;
   //mSphere[4] = (0.0f, 0.0f, 0.0f, 1.0f);
       mSphere[0]=0.0f;
       mSphere[1]=0.0f;
       mSphere[2]=0.0f;
       mSphere[3]=0.0f;
   mGravityforce = -9.8f;
   //mWinddirection[3] = (1.0f, 0.75f, 0.0f);
       mWinddirection[0]=1.0f;
       mWinddirection[1]=0.75f;
       mWinddirection[2]=0.0f;
       mWindspeed = 10.5f;
   //mWindvector[3] = (0.0f, 0.0f, 0.0f);
       mWindvector[0] = 0.0f;
       mWindvector[1] = 0.0f;
       mWindvector[2] = 0.0f;
   //fxCloth
}

ClothItem::~ClothItem()
{
}


//----------------------------------------------------------------------------

bool ClothItem::onAdd()
{
  if (!Parent::onAdd() || !mDataBlock)
     return false;

  mTypeMask |= (mDataBlock->dynamicTypeField & sgAllowedDynamicTypes);

  if (mStatic)
     mAtRest = true;
  mObjToWorld.getColumn(3,&delta.pos);

  // Setup the box for our convex object...
  mObjBox.getCenter(&mConvex.mCenter);
  mConvex.mSize.x = mObjBox.len_x() / 2.0;
  mConvex.mSize.y = mObjBox.len_y() / 2.0;
  mConvex.mSize.z = mObjBox.len_z() / 2.0;
  mWorkingQueryBox.min.set(-1e9, -1e9, -1e9);
  mWorkingQueryBox.max.set(-1e9, -1e9, -1e9);


  addToScene();

  if (isServerObject())
  {
     scriptOnAdd();
  }
  else if (mDataBlock->lightType != NoLight)
  {
     Sim::getLightSet()->addObject(this);
     mDropTime = Sim::getCurrentTime();
  }

  //fxCloth
  initializecloth(0);
  resetWorldBox();
  //fxCloth
  return true;
}

bool ClothItem::onNewDataBlock(GameBaseData* dptr)
{
  mDataBlock = dynamic_cast<ClothItemData*>(dptr);
  if (!mDataBlock || !Parent::onNewDataBlock(dptr))
     return false;

  scriptOnNewDataBlock();
  return true;
}

void ClothItem::onRemove()
{
  mWorkingQueryBox.min.set(-1e9, -1e9, -1e9);
  mWorkingQueryBox.max.set(-1e9, -1e9, -1e9);

  scriptOnRemove();
  removeFromScene();
  Parent::onRemove();
}

void ClothItem::onDeleteNotify(SimObject* obj)
{
  if (obj == mCollisionObject) {
     mCollisionObject = 0;
     mCollisionTimeout = 0;
  }
}

// Lighting: -----------------------------------------------------------------
void ClothItem::registerLights(LightManager * lightManager, bool lightingScene)
{
  if(lightingScene)
     return;

  if(mDataBlock->lightOnlyStatic && !mStatic)
     return;

  F32 intensity;
  switch(mDataBlock->lightType)
  {
     case ConstantLight:
        intensity = mFadeVal;
        break;

     case PulsingLight:
     {
        F32 delta = Sim::getCurrentTime() - mDropTime;
        intensity = 0.5f + 0.5f * mSin(M_PI * delta / F32(mDataBlock->lightTime));
        intensity = 0.15f + intensity * 0.85f;
        intensity *= mFadeVal;  // fade out light on flags
        break;
     }

     default:
        return;
  }

  mLight.mColor = mDataBlock->lightColor * intensity;
  mLight.mColor.clamp();
  mLight.mType = LightInfo::Point;
  mLight.mRadius = mDataBlock->lightRadius;

  mLight.mPos = getBoxCenter();

  //lightManager->addLight(&mLight);
}

//----------------------------------------------------------------------------

Point3F ClothItem::getVelocity() const
{
  return mVelocity;
}

void ClothItem::setVelocity(const VectorF& vel)
{
  mVelocity = vel;
  setMaskBits(PositionMask);
  mAtRest = false;
  mAtRestCounter = 0;
}

void ClothItem::applyImpulse(const Point3F&,const VectorF& vec)
{
  // Items ignore angular velocity
  VectorF vel;
  vel.x = vec.x / mDataBlock->mass;
  vel.y = vec.y / mDataBlock->mass;
  vel.z = vec.z / mDataBlock->mass;
  setVelocity(vel);
}

void ClothItem::setCollisionTimeout(ShapeBase* obj)
{
  if (mCollisionObject)
     clearNotify(mCollisionObject);
  deleteNotify(obj);
  mCollisionObject = obj;
  mCollisionTimeout = sCollisionTimeout;
  setMaskBits(ThrowSrcMask);
}


//----------------------------------------------------------------------------

void ClothItem::processTick(const Move* move)
{
  Parent::processTick(move);

  //
  if (mCollisionObject && !--mCollisionTimeout)
     mCollisionObject = 0;

  // Warp to catch up to server
  if (delta.warpTicks > 0) {
     delta.warpTicks--;

     // Set new pos.
     MatrixF mat = mObjToWorld;
     mat.getColumn(3,&delta.pos);
     delta.pos += delta.warpOffset;
     mat.setColumn(3,delta.pos);
     Parent::setTransform(mat);

     // Backstepping
     delta.posVec.x = -delta.warpOffset.x;
     delta.posVec.y = -delta.warpOffset.y;
     delta.posVec.z = -delta.warpOffset.z;
  }
  else {
     if (isServerObject() && mAtRest && (mStatic == false && mDataBlock->sticky == false))
     {
        if (++mAtRestCounter > csmAtRestTimer)
        {
           mAtRest = false;
           mAtRestCounter = 0;
        }
     }

     if (!mStatic && !mAtRest && isHidden() == false)
     {
        updateVelocity(TickSec);
        updateWorkingCollisionSet(isGhost() ? sClientCollisionMask : sServerCollisionMask, TickSec);
        updatePos(isGhost() ? sClientCollisionMask : sServerCollisionMask, TickSec);
        //fxCloth
        updatecloth();
        //fxCloth

     }
     else {
        // Need to clear out last updatePos or warp interpolation
        delta.posVec.set(0,0,0);
     }
  }
}

void ClothItem::interpolateTick(F32 dt)
{
  // Client side interpolation
  Parent::interpolateTick(dt);
  Point3F pos = delta.pos + delta.posVec * dt;
  MatrixF mat = mObjToWorld;
  mat.setColumn(3,pos);
  Parent::setRenderTransform(mat);
  delta.dt = dt;
}


//----------------------------------------------------------------------------

void ClothItem::setTransform(const MatrixF& mat)
{
  Point3F pos;
  mat.getColumn(3,&pos);
  MatrixF tmat;
  if (!mRotate) {
     // Forces all rotation to be around the z axis
     VectorF vec;
     mat.getColumn(1,&vec);
     tmat.set(EulerF(0,0,-mAtan(-vec.x,vec.y)));
  }
  else
     tmat.identity();
  tmat.setColumn(3,pos);
  Parent::setTransform(tmat);
  if (!mStatic)
  {
     mAtRest = false;
     mAtRestCounter = 0;
  }
  setMaskBits(RotationMask | PositionMask | NoWarpMask);
}


//----------------------------------------------------------------------------
void ClothItem::updateWorkingCollisionSet(const U32 mask, const F32 dt)
{
  // It is assumed that we will never accelerate more than 10 m/s for gravity...
  //
  Point3F scaledVelocity = mVelocity * dt;
  F32 len    = scaledVelocity.len();
  F32 newLen = len + (10 * dt);

  // Check to see if it is actually necessary to construct the new working list,
  //  or if we can use the cached version from the last query.  We use the x
  //  component of the min member of the mWorkingQueryBox, which is lame, but
  //  it works ok.
  bool updateSet = false;

  Box3F convexBox = mConvex.getBoundingBox(getTransform(), getScale());
  F32 l = (newLen * 1.1) + 0.1;  // from Convex::updateWorkingList
  convexBox.min -= Point3F(l, l, l);
  convexBox.max += Point3F(l, l, l);

  // Check containment
  {
     if (mWorkingQueryBox.min.x != -1e9)
     {
        if (mWorkingQueryBox.isContained(convexBox) == false)
        {
           // Needed region is outside the cached region.  Update it.
           updateSet = true;
        }
        else
        {
           // We can leave it alone, we're still inside the cached region
        }
     }
     else
     {
        // Must update
        updateSet = true;
     }
  }

  // Actually perform the query, if necessary
  if (updateSet == true)
  {
     mWorkingQueryBox = convexBox;
     mWorkingQueryBox.min -= Point3F(2 * l, 2 * l, 2 * l);
     mWorkingQueryBox.max += Point3F(2 * l, 2 * l, 2 * l);

     disableCollision();
     if (mCollisionObject)
        mCollisionObject->disableCollision();

     mConvex.updateWorkingList(mWorkingQueryBox, mask);

     if (mCollisionObject)
        mCollisionObject->enableCollision();
     enableCollision();
  }
}

void ClothItem::updateVelocity(const F32 dt)
{
  // Acceleration due to gravity
  mVelocity.z += (mGravity * mDataBlock->gravityMod) * dt;
  F32 len;
  if (mDataBlock->maxVelocity > 0 && (len = mVelocity.len()) > (mDataBlock->maxVelocity * 1.05)) {
     Point3F excess = mVelocity * (1.0 - (mDataBlock->maxVelocity / len ));
     excess *= 0.1;
     mVelocity -= excess;
  }

  // Container buoyancy & drag
  mVelocity.z -= mBuoyancy * (mGravity * mDataBlock->gravityMod * mGravityMod) * dt;
  mVelocity   -= mVelocity * mDrag * dt;
}


void ClothItem::updatePos(const U32 /*mask*/, const F32 dt)
{
  // Try and move
  Point3F pos;
  mObjToWorld.getColumn(3,&pos);
  delta.posVec = pos;

  bool contact = false;
  bool nonStatic = false;
  bool stickyNotify = false;
  CollisionList collisionList;
  F32 time = dt;

  static Polyhedron sBoxPolyhedron;
  static ExtrudedPolyList sExtrudedPolyList;
  static EarlyOutPolyList sEarlyOutPolyList;
  MatrixF collisionMatrix(true);
  Point3F end = pos + mVelocity * time;
  U32 mask = isServerObject() ? sServerCollisionMask : sClientCollisionMask;

  // Part of our speed problem here is that we don't track contact surfaces, like we do
  //  with the player.  In order to handle the most common and performance impacting
  //  instance of this problem, we'll use a ray cast to detect any contact surfaces below
  //  us.  This won't be perfect, but it only needs to catch a few of these to make a
  //  big difference.  We'll cast from the top center of the bounding box at the tick's
  //  beginning to the bottom center of the box at the end.
  Point3F startCast((mObjBox.min.x + mObjBox.max.x) * 0.5,
                    (mObjBox.min.y + mObjBox.max.y) * 0.5,
                    mObjBox.max.z);
  Point3F endCast((mObjBox.min.x + mObjBox.max.x) * 0.5,
                  (mObjBox.min.y + mObjBox.max.y) * 0.5,
                  mObjBox.min.z);
  collisionMatrix.setColumn(3, pos);
  collisionMatrix.mulP(startCast);
  collisionMatrix.setColumn(3, end);
  collisionMatrix.mulP(endCast);
  RayInfo rinfo;
  bool doToughCollision = true;
  if (mCollisionObject)
     mCollisionObject->disableCollision();
  if (getContainer()->castRay(startCast, endCast, mask, &rinfo))
  {
     F32 bd = -mDot(mVelocity, rinfo.normal);

     if (bd >= 0.0)
     {
        // Contact!
        if (mDataBlock->sticky && rinfo.object->getType() & (InteriorObjectType|TerrainObjectType)) {
           mVelocity.set(0, 0, 0);
           mAtRest = true;
           mAtRestCounter = 0;
           stickyNotify = true;
           mStickyCollisionPos    = rinfo.point;
           mStickyCollisionNormal = rinfo.normal;
           doToughCollision = false;;
        } else {
           // Subtract out velocity into surface and friction
           VectorF fv = mVelocity + rinfo.normal * bd;
           F32 fvl = fv.len();
           if (fvl) {
              F32 ff = bd * mDataBlock->friction;
              if (ff < fvl) {
                 fv *= ff / fvl;
                 fvl = ff;
              }
           }
           bd *= 1 + mDataBlock->elasticity;
           VectorF dv = rinfo.normal * (bd + 0.002);
           mVelocity += dv;
           mVelocity -= fv;

           // Keep track of what we hit
           contact = true;
           U32 typeMask = rinfo.object->getTypeMask();
           if (!(typeMask & StaticObjectType))
              nonStatic = true;
           if (isServerObject() && (typeMask & ShapeBaseObjectType)) {
              ShapeBase* col = static_cast<ShapeBase*>(rinfo.object);
              queueCollision(col,mVelocity - col->getVelocity());
           }
        }
     }
  }
  if (mCollisionObject)
     mCollisionObject->enableCollision();

  if (doToughCollision)
  {
     U32 count;
     for (count = 0; count < 3; count++)
     {
        // Build list from convex states here...
        end = pos + mVelocity * time;


        collisionMatrix.setColumn(3, end);
        Box3F wBox = getObjBox();
        collisionMatrix.mul(wBox);
        Box3F testBox = wBox;
        Point3F oldMin = testBox.min;
        Point3F oldMax = testBox.max;
        testBox.min.setMin(oldMin + (mVelocity * time));
        testBox.max.setMin(oldMax + (mVelocity * time));

        sEarlyOutPolyList.clear();
        sEarlyOutPolyList.mNormal.set(0,0,0);
        sEarlyOutPolyList.mPlaneList.setSize(6);
        sEarlyOutPolyList.mPlaneList[0].set(wBox.min,VectorF(-1,0,0));
        sEarlyOutPolyList.mPlaneList[1].set(wBox.max,VectorF(0,1,0));
        sEarlyOutPolyList.mPlaneList[2].set(wBox.max,VectorF(1,0,0));
        sEarlyOutPolyList.mPlaneList[3].set(wBox.min,VectorF(0,-1,0));
        sEarlyOutPolyList.mPlaneList[4].set(wBox.min,VectorF(0,0,-1));
        sEarlyOutPolyList.mPlaneList[5].set(wBox.max,VectorF(0,0,1));

        CollisionWorkingList& eorList = mConvex.getWorkingList();
        CollisionWorkingList* eopList = eorList.wLink.mNext;
        while (eopList != &eorList) {
           if ((eopList->mConvex->getObject()->getType() & mask) != 0)
           {
              Box3F convexBox = eopList->mConvex->getBoundingBox();
              if (testBox.isOverlapped(convexBox))
              {
                 eopList->mConvex->getPolyList(&sEarlyOutPolyList);
                 if (sEarlyOutPolyList.isEmpty() == false)
                    break;
              }
           }
           eopList = eopList->wLink.mNext;
        }
        if (sEarlyOutPolyList.isEmpty())
        {
           pos = end;
           break;
        }

        collisionMatrix.setColumn(3, pos);
        sBoxPolyhedron.buildBox(collisionMatrix, mObjBox);

        // Build extruded polyList...
        VectorF vector = end - pos;
        sExtrudedPolyList.extrude(sBoxPolyhedron, vector);
        sExtrudedPolyList.setVelocity(mVelocity);
        sExtrudedPolyList.setCollisionList(&collisionList);

        CollisionWorkingList& rList = mConvex.getWorkingList();
        CollisionWorkingList* pList = rList.wLink.mNext;
        while (pList != &rList) {
           if ((pList->mConvex->getObject()->getType() & mask) != 0)
           {
              Box3F convexBox = pList->mConvex->getBoundingBox();
              if (testBox.isOverlapped(convexBox))
              {
                 pList->mConvex->getPolyList(&sExtrudedPolyList);
              }
           }
           pList = pList->wLink.mNext;
        }

        if (collisionList.t < 1.0)
        {
           // Set to collision point
           F32 dt = time * collisionList.t;
           pos += mVelocity * dt;
           time -= dt;

           // Pick the most resistant surface
           F32 bd = 0;
           Collision* collision = 0;
           for (int c = 0; c < collisionList.count; c++) {
              Collision &cp = collisionList.collision[c];
              F32 dot = -mDot(mVelocity,cp.normal);
              if (dot > bd) {
                 bd = dot;
                 collision = &cp;
              }
           }

           if (collision && mDataBlock->sticky && collision->object->getType() & (InteriorObjectType|TerrainObjectType)) {
              mVelocity.set(0, 0, 0);
              mAtRest = true;
              mAtRestCounter = 0;
              stickyNotify = true;
              mStickyCollisionPos    = collision->point;
              mStickyCollisionNormal = collision->normal;
              break;
           } else {
              // Subtract out velocity into surface and friction
              if (collision) {
                 VectorF fv = mVelocity + collision->normal * bd;
                 F32 fvl = fv.len();
                 if (fvl) {
                    F32 ff = bd * mDataBlock->friction;
                    if (ff < fvl) {
                       fv *= ff / fvl;
                       fvl = ff;
                    }
                 }
                 bd *= 1 + mDataBlock->elasticity;
                 VectorF dv = collision->normal * (bd + 0.002);
                 mVelocity += dv;
                 mVelocity -= fv;

                 // Keep track of what we hit
                 contact = true;
                 U32 typeMask = collision->object->getTypeMask();
                 if (!(typeMask & StaticObjectType))
                    nonStatic = true;
                 if (isServerObject() && (typeMask & ShapeBaseObjectType)) {
                    ShapeBase* col = static_cast<ShapeBase*>(collision->object);
                    queueCollision(col,mVelocity - col->getVelocity());
                 }
              }
           }
        }
        else
        {
           pos = end;
           break;
        }
     }
     if (count == 3)
     {
        // Couldn't move...
        mVelocity.set(0, 0, 0);
     }
  }

  // If on the client, calculate delta for backstepping
  if (isGhost()) {
     delta.pos     = pos;
     delta.posVec -= pos;
     delta.dt = 1;
  }

  // Update transform
  MatrixF mat = mObjToWorld;
  mat.setColumn(3,pos);
  Parent::setTransform(mat);
  enableCollision();
  if (mCollisionObject)
     mCollisionObject->enableCollision();
  updateContainer();

  //
  if (contact) {
     // Check for rest condition
     if (!nonStatic && mVelocity.len() < sAtRestVelocity) {
        mVelocity.x = mVelocity.y = mVelocity.z = 0;
        mAtRest = true;
        mAtRestCounter = 0;
     }

     // Only update the client if we hit a non-static shape or
     // if this is our final rest pos.
     if (nonStatic || mAtRest)
        setMaskBits(PositionMask);
  }

  // Collision callbacks. These need to be processed whether we hit
  // anything or not.
  if (!isGhost())
  {
     SimObjectPtr<ClothItem> safePtr(this);
     if (stickyNotify)
     {
        notifyCollision();
        if(bool(safePtr))
           Con::executef(mDataBlock, 2, "onStickyCollision", scriptThis());
     }
     else
        notifyCollision();

     // water
     if(bool(safePtr))
     {
        if(!mInLiquid && mWaterCoverage != 0.0f)
        {
           Con::executef(mDataBlock,4,"onEnterLiquid",scriptThis(), Con::getFloatArg(mWaterCoverage), Con::getIntArg(mLiquidType));
           mInLiquid = true;
        }
        else if(mInLiquid && mWaterCoverage == 0.0f)
        {
           Con::executef(mDataBlock,3,"onLeaveLiquid",scriptThis(), Con::getIntArg(mLiquidType));
           mInLiquid = false;
        }
     }
  }
}


//----------------------------------------------------------------------------

static MatrixF IMat(1);

bool ClothItem::buildPolyList(AbstractPolyList* polyList, const Box3F&, const SphereF&)
{
  // Collision with the item is always against the ClothItem's object
  // space bounding box axis aligned in world space.
  Point3F pos;
  mObjToWorld.getColumn(3,&pos);
  IMat.setColumn(3,pos);
  polyList->setTransform(&IMat, mObjScale);
  polyList->setObject(this);
  polyList->addBox(mObjBox);
  return true;
}


//----------------------------------------------------------------------------

U32 ClothItem::packUpdate(NetConnection *connection, U32 mask, BitStream *stream)
{
  U32 retMask = Parent::packUpdate(connection,mask,stream);

  if (stream->writeFlag(mask & InitialUpdateMask)) {
     stream->writeFlag(mRotate);
     stream->writeFlag(mStatic);
     stream->writeFlag(mCollideable);
     if (stream->writeFlag(getScale() != Point3F(1, 1, 1)))
        mathWrite(*stream, getScale());
  }
  if (mask & ThrowSrcMask && mCollisionObject) {
     S32 gIndex = connection->getGhostIndex(mCollisionObject);
     if (stream->writeFlag(gIndex != -1))
        stream->writeInt(gIndex,NetConnection::GhostIdBitSize);
  }
  else
     stream->writeFlag(false);
  if (stream->writeFlag(mask & RotationMask && !mRotate)) {
     // Assumes rotation is about the Z axis
     AngAxisF aa(mObjToWorld);
     stream->writeFlag(aa.axis.z < 0);
     stream->write(aa.angle);
  }
  if (stream->writeFlag(mask & PositionMask)) {
     Point3F pos;
     mObjToWorld.getColumn(3,&pos);
     mathWrite(*stream, pos);
     if (!stream->writeFlag(mAtRest)) {
        mathWrite(*stream, mVelocity);
     }
     stream->writeFlag(!(mask & NoWarpMask));
  }

   //fxCloth
   // Write fxPortal Mask Flag.
   if (stream->writeFlag(mask & ClothObjectMask))
   {
       // Write Object Transform.
       stream->writeAffineTransform(mObjToWorld);
       // Write Texture Name.
       stream->writeString(mTextureName);

   }
   //fxCloth

  return retMask;
}

void ClothItem::unpackUpdate(NetConnection *connection, BitStream *stream)
{
  Parent::unpackUpdate(connection,stream);
  if (stream->readFlag()) {
     mRotate = stream->readFlag();
     mStatic = stream->readFlag();
     mCollideable = stream->readFlag();
     if (stream->readFlag())
        mathRead(*stream, &mObjScale);
     else
        mObjScale.set(1, 1, 1);
  }
  if (stream->readFlag()) {
     S32 gIndex = stream->readInt(10);
     setCollisionTimeout(static_cast<ShapeBase*>(connection->resolveGhost(gIndex)));
  }
  MatrixF mat = mObjToWorld;
  if (stream->readFlag()) {
     // Assumes rotation is about the Z axis
     AngAxisF aa;
     aa.axis.set(0,0,stream->readFlag()? -1: 1);
     stream->read(&aa.angle);
     aa.setMatrix(&mat);
     Point3F pos;
     mObjToWorld.getColumn(3,&pos);
     mat.setColumn(3,pos);
  }
  if (stream->readFlag()) {
     Point3F pos;
     mathRead(*stream, &pos);
     F32 speed = mVelocity.len();
     if ((mAtRest = stream->readFlag()) == true)
        mVelocity.set(0,0,0);
     else
        mathRead(*stream, &mVelocity);

     if (stream->readFlag() && isProperlyAdded()) {
        // Determin number of ticks to warp based on the average
        // of the client and server velocities.
        delta.warpOffset = pos - delta.pos;
        F32 as = (speed + mVelocity.len()) * 0.5 * TickSec;
        F32 dt = (as > 0.00001f) ? delta.warpOffset.len() / as: sMaxWarpTicks;
        delta.warpTicks = (S32)((dt > sMinWarpTicks)? getMax(mFloor(dt + 0.5), 1.0f): 0.0f);

        if (delta.warpTicks) {
           // Setup the warp to start on the next tick, only the
           // object's position is warped.
           if (delta.warpTicks > sMaxWarpTicks)
              delta.warpTicks = sMaxWarpTicks;
           delta.warpOffset /= delta.warpTicks;
        }
        else {
           // Going to skip the warp, server and client are real close.
           // Adjust the frame interpolation to move smoothly to the
           // new position within the current tick.
           Point3F cp = delta.pos + delta.posVec * delta.dt;
           VectorF vec = delta.pos - cp;
           F32 vl = vec.len();
           if (vl) {
              F32 s = delta.posVec.len() / vl;
              delta.posVec = (cp - pos) * s;
           }
           delta.pos = pos;
           mat.setColumn(3,pos);
        }
     }
     else {
        // Set the ClothItem to the server position
        delta.warpTicks = 0;
        delta.posVec.set(0,0,0);
        delta.pos = pos;
        delta.dt = 0;
        mat.setColumn(3,pos);
     }
  }

   //fxCloth
   // Read fxPortal Mask Flag.
   if(stream->readFlag())
   {
       MatrixF     ObjectMatrix;

       // Read Object Transform.
       stream->readAffineTransform(&ObjectMatrix);
       // Read Texture Name.
       mTextureName = StringTable->insert(stream->readSTString());

       // Set Transform.
       setTransform(ObjectMatrix);
       // Reset our previous texture handle.
       mTextureHandle = NULL;
       // Load the texture (if we've got one)
       if (*mTextureName) mTextureHandle = TextureHandle(mTextureName, BitmapTexture, true);

       // Reset the World Box.
       resetWorldBox();
       // Set the Render Transform.
       setRenderTransform(mObjToWorld);
   }
   //fxCloth

  Parent::setTransform(mat);
}

ConsoleMethod(ClothItem, isStatic, bool, 2, 2, "()"
             "Is the object static (ie, non-movable)?")
{
  return object->isStatic();
}

ConsoleMethod(ClothItem, isRotating, bool, 2, 2, "()"
             "Is the object still rotating?")
{
  return object->isRotating();
}

ConsoleMethod(ClothItem, setCollisionTimeout, bool, 3, 3, "(ShapeBase obj)"
             "Temporarily disable collisions against obj.")
{
  ShapeBase* source;
  if (Sim::findObject(dAtoi(argv[2]),source)) {
     object->setCollisionTimeout(source);
     return true;
  }
  return false;
}

ConsoleMethod( ClothItem, getLastStickyPos, const char *, 2, 2, "()"
             "Get the position on the surface on which the object is stuck.")
{
  char* ret = Con::getReturnBuffer(256);
  if (object->isServerObject())
     dSprintf(ret, 255, "%g %g %g",
              object->mStickyCollisionPos.x,
              object->mStickyCollisionPos.y,
              object->mStickyCollisionPos.z);
  else
     dStrcpy(ret, "0 0 0");

  return ret;
}

ConsoleMethod( ClothItem, getLastStickyNormal, const char *, 2, 2, "()"
             "Get the normal of the surface on which the object is stuck.")
{
  char* ret = Con::getReturnBuffer(256);
  if (object->isServerObject())
     dSprintf(ret, 255, "%g %g %g",
              object->mStickyCollisionNormal.x,
              object->mStickyCollisionNormal.y,
              object->mStickyCollisionNormal.z);
  else
     dStrcpy(ret, "0 0 0");

  return ret;
}

//----------------------------------------------------------------------------

void ClothItem::initPersistFields()
{
  Parent::initPersistFields();

  addGroup("ClothItemMisc");   // MM: Added Group Header.
  addField("collideable", TypeBool, Offset(mCollideable, ClothItem));
  addField("static",      TypeBool, Offset(mStatic, ClothItem));
  addField("rotate",      TypeBool, Offset(mRotate, ClothItem));
  addField("sphere",      TypeBool, Offset(mSphere[0], ClothItem));
  addField("sphere1",      TypeBool, Offset(mSphere[1], ClothItem));
  addField("sphere2",      TypeBool, Offset(mSphere[2], ClothItem));
  addField("pointA",      TypeBool, Offset(mPointA, ClothItem));

   //fxCloth
   addField( "Texture",        TypeFilename, Offset( mTextureName,   ClothItem ) );
   addField( "ShowParticles", TypeBool,     Offset( mShowParticles, ClothItem ) );
   //fxCloth

  endGroup("ClothItemMisc");   // MM: Added Group Footer.
}

void ClothItem::consoleInit()
{
  Con::addVariable("ClothItem::minWarpTicks",TypeF32,&sMinWarpTicks);
  Con::addVariable("ClothItem::maxWarpTicks",TypeS32,&sMaxWarpTicks);
}

//----------------------------------------------------------------------------

bool ClothItem::prepRenderImage(SceneState* state,
                          const U32   stateKey,
                          const U32   startZone,
                          const bool  modifyBaseState)
{
   bool result;

   // Return if last state.
   //if (isLastState(state, stateKey))
   //    return false;
   //setLastState(state, stateKey);

   // Items do NOT render if destroyed
   //if (getDamageState() == Destroyed)
   //   return false;

   result = Parent::prepRenderImage(state, stateKey, startZone, modifyBaseState);
   if (state->isObjectRendered(this))
   {
       SceneRenderImage* image = new SceneRenderImage;
       image->obj = this;
       image->isTranslucent = false;
       image->sortType = SceneRenderImage::Normal;
       state->insertRenderImage(image);
   }

   return result;
}


void ClothItem::renderImage(SceneState* state, SceneRenderImage* image)
{
   //AssertFatal(dglIsInCanonicalState(), "Error, GL not in canonical state on exit");

  // Client side rotation
  /*
  if (mRotate) {
     F32 t = Sim::getCurrentTime() * F32(1)/1000;
     F32 r = (t / sRotationSpeed) * M_2PI;
     Point3F pos;
     mRenderObjToWorld.getColumn(3,&pos);
     MatrixF mat = mRenderObjToWorld;
     mat.set(Point3F(0,0,r));
     mat.setColumn(3,pos);
     Parent::setRenderTransform(mat);
  }
  */

  Parent::renderImage(state, image);

   //fxCloth
       int i, j;
   if (mShowParticles) {
       glDisable(GL_LIGHTING);
       glDisable(GL_DEPTH_TEST);
       glPushMatrix();
       dglMultMatrix(&getRenderTransform());

       // Box for the center of Mass
       glColor3f(1, 0, 0);
       glLineWidth(2.f);
       glPointSize(6.f);
       glBegin(GL_POINTS);
       for(i = 0; i < CLOTH_RESOLUTION - 1; i++)
       {
           for(j = 0; j < CLOTH_RESOLUTION; j++)
           {
               //glColor3f(mCurrentcloth[4 * ((i + 1) * CLOTH_RESOLUTION + j) +3], 0.0,1.0f-mCurrentcloth[4 * ((i + 1) * CLOTH_RESOLUTION + j) +3]);
               glNormal3fv(&(mNormals[3 * ((i + 1) * CLOTH_RESOLUTION + j)]));
               glVertex3fv(&(mCurrentcloth[4 * ((i + 1) * CLOTH_RESOLUTION + j)]));
           }
       }
       glEnd();
       glPointSize(.1f);
       glLineWidth(.1f);

       glPopMatrix();
       glEnable(GL_DEPTH_TEST);
       glEnable(GL_LIGHTING);
   }


       // Return if we don't have a texture.
       if (!mTextureHandle) return;


       // Save state.
       RectI viewport;

       // Save Projection Matrix so we can restore Canonical state at exit.
       glMatrixMode(GL_PROJECTION);
       glPushMatrix();

       // Save Viewport so we can restore Canonical state at exit.
       dglGetViewport(&viewport);

       // Setup the projection to the current frustum.
       //
       // NOTE:-       You should let the SceneGraph drive the frustum as it
       //                      determines portal clipping etc.
       //                      It also leaves us with the MODELVIEW current.
       //
       state->setupBaseProjection();

       // Save ModelView Matrix so we can restore Canonical state at exit.
       glPushMatrix();

       // Transform by the objects' transform e.g move it.
       dglMultMatrix(&getTransform());

       // Enable Texturing.
       glEnable(GL_TEXTURE_2D);

       // Select the objects' texture.
       glBindTexture(GL_TEXTURE_2D, mTextureHandle.getGLName());

       // Set Colour/Alpha.
       glColor4f(1,1,1,1);

       // Calculate Quad Radius.

       // Draw a Quad.
       //
       // NOTE:-       We draw in object space here and *not* world-space.
       //                      Notice that Z is UP in this system and XY lie on the terrain plane.
       //

       //Draw a series of triangle strips for the cloth
       for(i = 0; i < CLOTH_RESOLUTION - 1; i++)
       {
               glBegin(GL_TRIANGLE_STRIP);
               for(j = 0; j < CLOTH_RESOLUTION; j++)
               {
                       glNormal3fv(&(mNormals[3 * ((i + 1) * CLOTH_RESOLUTION + j)]));
                       glTexCoord2f(((float)j) / (CLOTH_RESOLUTION - 1), ((float)(i + 1)) / (CLOTH_RESOLUTION - 1));
                       glVertex3fv(&(mCurrentcloth[4 * ((i + 1) * CLOTH_RESOLUTION + j)]));
                       glNormal3fv(&(mNormals[3 * (i * CLOTH_RESOLUTION + j)]));
                       glTexCoord2f(((float)j) / (CLOTH_RESOLUTION - 1), ((float)i) / (CLOTH_RESOLUTION - 1));
                       glVertex3fv(&(mCurrentcloth[4 * (i * CLOTH_RESOLUTION + j)]));
               }
               glEnd();
       }

       // Restore our canonical rendering state.
       //glDisable(GL_BLEND);
       glDisable(GL_TEXTURE_2D);
       // Restore our canonical matrix state.
       glPopMatrix();
       glMatrixMode(GL_PROJECTION);
       glPopMatrix();
       glMatrixMode(GL_MODELVIEW);
       // Restore our canonical viewport state.
       dglSetViewport(viewport);

   //fxCloth

  //if (mShadow)
  //{
  //   mShadow->setMoving(!mAtRest);
  //   mShadow->setAnimating(!mAtRest && !mRotate);
  //}
}


void ClothItem::buildConvex(const Box3F& box, Convex* convex)
{
  if (mShapeInstance == NULL)
     return;

  // These should really come out of a pool
  mConvexList->collectGarbage();

  if (box.isOverlapped(getWorldBox()) == false)
     return;

  // Just return a box convex for the entire shape...
  Convex* cc = 0;
  CollisionWorkingList& wl = convex->getWorkingList();
  for (CollisionWorkingList* itr = wl.wLink.mNext; itr != &wl; itr = itr->wLink.mNext) {
     if (itr->mConvex->getType() == BoxConvexType &&
         itr->mConvex->getObject() == this) {
        cc = itr->mConvex;
        break;
     }
  }
  if (cc)
     return;

  // Create a new convex.
  BoxConvex* cp = new BoxConvex;
  mConvexList->registerObject(cp);
  convex->addToWorkingList(cp);
  cp->init(this);

  mObjBox.getCenter(&cp->mCenter);
  cp->mSize.x = mObjBox.len_x() / 2.0f;
  cp->mSize.y = mObjBox.len_y() / 2.0f;
  cp->mSize.z = mObjBox.len_z() / 2.0f;
}

//fxCloth

void ClothItem::accumulateforces(void)
{
   int i;
   float windforce;

   //Determine the wind force vector
   mWindvector[0] = mWinddirection[0] * mWindspeed;
   mWindvector[1] = mWinddirection[1] * mWindspeed;
   mWindvector[2] = mWinddirection[2] * mWindspeed;

   for(i = 0; i < mNumparticles; i++)
   {
       //Initialize forces
       mForces[3 * i] = 0.0f;
       mForces[3 * i + 1] = 0.0f;
       mForces[3 * i + 2] = 0.0f;

       //Gravity force
       mForces[3 * i + 2] += mGravityforce;

       //Wind force
       windforce = mWindvector[0] * mNormals[3 * i]
                   + mWindvector[1] * mNormals[3 * i + 1]
                   + mWindvector[2] * mNormals[3 * i + 2];
       mForces[3 * i] += mNormals[3 * i] * windforce;
       mForces[3 * i + 1] += mNormals[3 * i + 1] * windforce;
       mForces[3 * i + 2] += mNormals[3 * i + 2] * windforce;

       //Dampening force
       windforce = (mPreviouscloth[4 * i] - mCurrentcloth[4 * i]) * mNormals[3 * i]
                   + (mPreviouscloth[4 * i + 1] - mCurrentcloth[4 * i + 1]) * mNormals[3 * i + 1]
                   + (mPreviouscloth[4 * i + 2] - mCurrentcloth[4 * i + 2]) * mNormals[3 * i + 2];
       mForces[3 * i] += 80.0f * mNormals[3 * i] * windforce;
       mForces[3 * i + 1] += 80.0f * mNormals[3 * i + 1] * windforce;
       mForces[3 * i + 2] += 80.0f * mNormals[3 * i + 2] * windforce;
   }
}
void ClothItem::verlet(void)
{
   float *tempfloatptr;

   //Update each particle via verlet integration
   for(int i = 0; i < mNumparticles; i++)
   {
       mPreviouscloth[4 * i] =  2.0 * mCurrentcloth[4 * i]
                           -  mPreviouscloth[4 * i]
                           + mForces[3 * i] * mCurrentcloth[4 * i + 3] * TIME_FACTOR;
       mPreviouscloth[4 * i + 1] = 2.0 * mCurrentcloth[4 * i + 1]
                           -  mPreviouscloth[4 * i + 1]
                           + mForces[3 * i + 1] * mCurrentcloth[4 * i + 3] * TIME_FACTOR;
       mPreviouscloth[4 * i + 2] = 2.0 * mCurrentcloth[4 * i + 2]
                           - mPreviouscloth[4 * i + 2]
                           + mForces[3 * i + 2] * mCurrentcloth[4 * i + 3] * TIME_FACTOR;
   }

   //Update the current and previous cloth pointers
   tempfloatptr = mPreviouscloth;
   mPreviouscloth = mCurrentcloth;
   mCurrentcloth = tempfloatptr;
}

void ClothItem::satisfyconstraints(void)
{
   int i;
   float deltalength;
   float delta[3];
   float diff;
   float invmass1, invmass2, invmasssum;



   //Satisfy stick constraints within cloth
   for(i = 0; i < mNumconstraints; i++)
   {
       delta[0] = mCurrentcloth[4 * mConstraints[i].particle1]
                   - mCurrentcloth[4 * mConstraints[i].particle2];
       delta[1] = mCurrentcloth[4 * mConstraints[i].particle1 + 1]
                   - mCurrentcloth[4 * mConstraints[i].particle2 + 1];
       delta[2] = mCurrentcloth[4 * mConstraints[i].particle1 + 2]
                   - mCurrentcloth[4 * mConstraints[i].particle2 + 2];

       invmass1 = mCurrentcloth[4 * mConstraints[i].particle1 + 3];
       invmass2 = mCurrentcloth[4 * mConstraints[i].particle2 + 3];

       deltalength = (float)sqrt(delta[0] * delta[0] + delta[1] * delta[1] + delta[2] * delta[2]);
       invmasssum = invmass1 + invmass2;
               if (deltalength!=0.0f&&invmasssum!=0.0f)
               {
           diff = (deltalength - mConstraints[i].restlength) / (deltalength * (invmass1 + invmass2));
                       mCurrentcloth[4 * mConstraints[i].particle1] -= invmass1 * delta[0] * diff;
                       mCurrentcloth[4 * mConstraints[i].particle1 + 1] -= invmass1 * delta[1] * diff;
                       mCurrentcloth[4 * mConstraints[i].particle1 + 2] -= invmass1 * delta[2] * diff;

                       mCurrentcloth[4 * mConstraints[i].particle2] += invmass2 * delta[0] * diff;
                       mCurrentcloth[4 * mConstraints[i].particle2 + 1] += invmass2 * delta[1] * diff;
                       mCurrentcloth[4 * mConstraints[i].particle2 + 2] += invmass2 * delta[2] * diff;
               }

   }

   //Satisfy constraint that cloth points can't enter the sphere
   float sphereradius;
   sphereradius = 1.05;//mSphere[3] + 0.05;
   for(i = 0; i < mNumparticles; i++)
   {
       delta[0] = mCurrentcloth[4 * i] - mSphere[0];
       delta[1] = mCurrentcloth[4 * i + 1] - mSphere[1];
       delta[2] = mCurrentcloth[4 * i + 2] - mSphere[2];

       deltalength = delta[0] * delta[0] + delta[1] * delta[1] + delta[2] * delta[2];

       //If the particle is in the sphere, move it to outside the sphere
       if(deltalength < sphereradius * sphereradius)
       {
           deltalength = (float)sqrt(deltalength);
           mCurrentcloth[4 * i] += delta[0] * (sphereradius - deltalength) / sphereradius;
           mCurrentcloth[4 * i + 1] += delta[1] * (sphereradius - deltalength) / sphereradius;
           mCurrentcloth[4 * i + 2] += delta[2] * (sphereradius - deltalength) / sphereradius;
       }
   }
}

void ClothItem::calculatenormals(void)
{
   int i, j;
   float vectorlength;
   float trianglenormal[3];
   float v1[3], v2[3];

   //Set all normals to 0
   for(i = 0; i < mNumparticles; i++)
   {
       mNormals[3 * i] = 0.0f;
       mNormals[3 * i + 1] = 0.0f;
       mNormals[3 * i + 2] = 0.0f;
   }

   //Calculate the normal of each triangle
   //in the mesh and factor it into all the vertices
   //that are a part of it
   for(i = 0; i < CLOTH_RESOLUTION - 1; i++)
   {
       for(j = 0; j < CLOTH_RESOLUTION - 1; j++)
       {
           v1[0] = mCurrentcloth[4 * (i * CLOTH_RESOLUTION + j)]
                   - mCurrentcloth[4 * ((i + 1) * CLOTH_RESOLUTION + j)];
           v1[1] = mCurrentcloth[4 * (i * CLOTH_RESOLUTION + j) + 1]
                   - mCurrentcloth[4 * ((i + 1) * CLOTH_RESOLUTION + j) + 1];
           v1[2] = mCurrentcloth[4 * (i * CLOTH_RESOLUTION + j) + 2]
                   - mCurrentcloth[4 * ((i + 1) * CLOTH_RESOLUTION + j) + 2];

           v2[0] = mCurrentcloth[4 * (i * CLOTH_RESOLUTION + j + 1)]
                   - mCurrentcloth[4 * (i * CLOTH_RESOLUTION + j)];
           v2[1] = mCurrentcloth[4 * (i * CLOTH_RESOLUTION + j + 1) + 1]
                   - mCurrentcloth[4 * (i * CLOTH_RESOLUTION + j) + 1];
           v2[2] = mCurrentcloth[4 * (i * CLOTH_RESOLUTION + j + 1) + 2]
                   - mCurrentcloth[4 * (i * CLOTH_RESOLUTION + j) + 2];

           trianglenormal[0] = v1[1] * v2[2] - v1[2] * v2[1];
           trianglenormal[1] = v1[2] * v2[0] - v1[0] * v2[2];
           trianglenormal[2] = v1[0] * v2[1] - v1[1] * v2[0];

           mNormals[3 * (i * CLOTH_RESOLUTION + j)] += trianglenormal[0];
           mNormals[3 * (i * CLOTH_RESOLUTION + j) + 1] += trianglenormal[1];
           mNormals[3 * (i * CLOTH_RESOLUTION + j) + 2] += trianglenormal[2];

           mNormals[3 * (i * CLOTH_RESOLUTION + j + 1)] += trianglenormal[0];
           mNormals[3 * (i * CLOTH_RESOLUTION + j + 1) + 1] += trianglenormal[1];
           mNormals[3 * (i * CLOTH_RESOLUTION + j + 1) + 2] += trianglenormal[2];

           mNormals[3 * ((i + 1) * CLOTH_RESOLUTION + j)] += trianglenormal[0];
           mNormals[3 * ((i + 1) * CLOTH_RESOLUTION + j) + 1] += trianglenormal[1];
           mNormals[3 * ((i + 1) * CLOTH_RESOLUTION + j) + 2] += trianglenormal[2];

           v1[0] = mCurrentcloth[4 * ((i + 1) * CLOTH_RESOLUTION + j + 1)]
                   - mCurrentcloth[4 * (i * CLOTH_RESOLUTION + j + 1)];
           v1[1] = mCurrentcloth[4 * ((i + 1) * CLOTH_RESOLUTION + j + 1) + 1]
                   - mCurrentcloth[4 * (i * CLOTH_RESOLUTION + j + 1) + 1];
           v1[2] = mCurrentcloth[4 * ((i + 1) * CLOTH_RESOLUTION + j + 1) + 2]
                   - mCurrentcloth[4 * (i * CLOTH_RESOLUTION + j + 1) + 2];

           v2[0] = mCurrentcloth[4 * ((i + 1) * CLOTH_RESOLUTION + j)]
                   - mCurrentcloth[4 * ((i + 1) * CLOTH_RESOLUTION + j + 1)];
           v2[1] = mCurrentcloth[4 * ((i + 1) * CLOTH_RESOLUTION + j) + 1]
                   - mCurrentcloth[4 * ((i + 1) * CLOTH_RESOLUTION + j + 1) + 1];
           v2[2] = mCurrentcloth[4 * ((i + 1) * CLOTH_RESOLUTION + j) + 2]
                   - mCurrentcloth[4 * ((i + 1) * CLOTH_RESOLUTION + j + 1) + 2];

           trianglenormal[0] = v1[1] * v2[2] - v1[2] * v2[1];
           trianglenormal[1] = v1[2] * v2[0] - v1[0] * v2[2];
           trianglenormal[2] = v1[0] * v2[1] - v1[1] * v2[0];

           mNormals[3 * ((i + 1) * CLOTH_RESOLUTION + j + 1)] += trianglenormal[0];
           mNormals[3 * ((i + 1) * CLOTH_RESOLUTION + j + 1) + 1] += trianglenormal[1];
           mNormals[3 * ((i + 1) * CLOTH_RESOLUTION + j + 1) + 2] += trianglenormal[2];

           mNormals[3 * (i * CLOTH_RESOLUTION + j + 1)] += trianglenormal[0];
           mNormals[3 * (i * CLOTH_RESOLUTION + j + 1) + 1] += trianglenormal[1];
           mNormals[3 * (i * CLOTH_RESOLUTION + j + 1) + 2] += trianglenormal[2];

           mNormals[3 * ((i + 1) * CLOTH_RESOLUTION + j)] += trianglenormal[0];
           mNormals[3 * ((i + 1) * CLOTH_RESOLUTION + j) + 1] += trianglenormal[1];
           mNormals[3 * ((i + 1) * CLOTH_RESOLUTION + j) + 2] += trianglenormal[2];
       }
   }


   //Normalize vertex normals
   for(i = 0; i < mNumparticles; i++)
   {
       vectorlength = 1.0f / (float)sqrt(mNormals[3 * i] * mNormals[3 * i]
                           + mNormals[3 * i + 1] * mNormals[3 * i + 1]
                           + mNormals[3 * i + 2] * mNormals[3 * i + 2]);
       mNormals[3 * i] *= vectorlength;
       mNormals[3 * i + 1] *= vectorlength;
       mNormals[3 * i + 2] *= vectorlength;
   }
}

//------------------------------------------------------------------------------
void ClothItem::updatecloth(void)
{

   S32 Time = Platform::getVirtualMilliseconds();

   if(mSimulationtime < Time)
   {
       //Accumulate forces on the particles
       accumulateforces();
       //Do verlet integration
       verlet();
       //Attempt to satisfy all the constraints on the system
       for(int i = 0; i < CONSTRAINT_UPDATE; i++)
           satisfyconstraints();
       //Calculate the triangle normals
       calculatenormals();

       mSimulationtime = Time + TIME_STEP * TIME_CONSTANT;
       //Con::printf("Time: %d", Time);
       //Con::printf("mSimulationtime: %d", Time);
   }
}


void ClothItem::initializecloth(int setuptype)
{
   int i, j, currentconstraint = 0;
   float restlength;
   float diagonallength;

   //Initialize cloth position and point weights
   if(setuptype == 0)
   {
       for(i = 0; i < CLOTH_RESOLUTION; i++)
       {
           for(j = 0; j < CLOTH_RESOLUTION; j++)
           {
                               mCloth1[4 * (CLOTH_RESOLUTION * i + j)] = -CLOTH_SIZE / 2.0f + j * CLOTH_SIZE / CLOTH_RESOLUTION;
                               mCloth1[4 * (CLOTH_RESOLUTION * i + j) + 1] = -0.0f;
                               mCloth1[4 * (CLOTH_RESOLUTION * i + j) + 2] = -i * CLOTH_SIZE / CLOTH_RESOLUTION;
                               mCloth1[4 * (CLOTH_RESOLUTION * i + j) + 3] = 1.0f;

           }
       }
   }

   ////Initialize 2 corner points to infinite weight
   mCloth1[3] = 0.0f;

       mCloth1[4 * (CLOTH_RESOLUTION - 1) + 0] -= 0.1f;
       mCloth1[4 * (CLOTH_RESOLUTION - 1) + 1] -= 0.1f;
       mCloth1[4 * (CLOTH_RESOLUTION - 1) + 2] -= 0.0f;
       mCloth1[4 * (CLOTH_RESOLUTION - 1) + 3] = 0.0f;

   //Make to row rigid by setting it's weights to inifinite (0.0f)
   //for(j = 0; j < CLOTH_RESOLUTION; j++)
   //{
   //    mCloth1[(4 * j)+3] = 0.0f;
   //}

   for(i = 0; i < 4 * CLOTH_RESOLUTION * CLOTH_RESOLUTION; i++)
       mCloth2[i] = mCloth1[i];

   //Set up pointers for the previous frame and the current frame for the cloth
   mCurrentcloth = mCloth1;
   mPreviouscloth = mCloth2;

       //Init mNormals and mForces
   for(i = 0; i < mNumparticles; i++)
   {
       //Initialize forces
       mForces[3 * i] = 0.0f;
       mForces[3 * i + 1] = 0.0f;
       mForces[3 * i + 2] = 0.0f;
       }
       calculatenormals();

   restlength = CLOTH_SIZE / CLOTH_RESOLUTION;

   //Initialize cloth constraints
   //Constraints in the horizontal direction along the cloth
   for(i = 0; i < CLOTH_RESOLUTION; i++)
   {
       for(j = 0; j < CLOTH_RESOLUTION - 1; j++)
       {
           mConstraints[currentconstraint].particle1 = i * CLOTH_RESOLUTION + j;
           mConstraints[currentconstraint].particle2 = i * CLOTH_RESOLUTION + j + 1;
           mConstraints[currentconstraint].restlength = restlength;
           currentconstraint++;
       }
   }
   //Constraints in the vertical direction along the cloth
   for(i = 0; i < CLOTH_RESOLUTION - 1; i++)
   {
       for(j = 0; j < CLOTH_RESOLUTION; j++)
       {
           mConstraints[currentconstraint].particle1 = i * CLOTH_RESOLUTION + j;
           mConstraints[currentconstraint].particle2 = (i + 1) * CLOTH_RESOLUTION + j;
           mConstraints[currentconstraint].restlength = restlength;
           currentconstraint++;
       }
   }

   //A single diagonal constraint across every square in the cloth grid
   diagonallength = (float) sqrt(2.0f * restlength * restlength);
   for(i = 0; i < CLOTH_RESOLUTION - 1; i++)
   {
       for(j = 0; j < CLOTH_RESOLUTION - 1; j++)
       {
           mConstraints[currentconstraint].particle1 = i * CLOTH_RESOLUTION + j;
           mConstraints[currentconstraint].particle2 = (i + 1) * CLOTH_RESOLUTION + j + 1;
           mConstraints[currentconstraint].restlength = diagonallength;
           currentconstraint++;
       }
   }
}

void ClothItem::sphere(int x, int y, int z)
{
	mSphere[0] = x;
	mSphere[1] = y;
	mSphere[2] = z;
}

void ClothItem::pointA(F32 pointA)
{
	//if (pointA != 0)
	//mCloth1[3] = this->mPointA;
}
/*
ConsoleMethod( ClothItem, sphere, void, 5, 5, "(x, y, z)")
{
  int x = dAtoi(argv[2]);
  int y = dAtoi(argv[3]);
  int z = dAtoi(argv[4]);
  object->sphere(x,y,z);
}

ConsoleMethod( ClothItem, pointA, void, 2, 2, "(pointA)")
{
  F32 pointA = dAtoi(argv[2]);
  object->pointA(pointA);
}*/