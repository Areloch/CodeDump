// phdana droids ->
// code adapted from xXX given to me by vinci_smurf

//
//
//
//	Filename : Turret.h

#ifndef _TURRET_H_
#define _TURRET_H_

#ifndef _SHAPEBASE_H_
#include "game/shapeBase.h"
#endif
#ifndef _BOXCONVEX_H_
#include "collision/boxConvex.h"
#endif



struct TurretData: public ShapeBaseData 
{
	typedef ShapeBaseData Parent;

   Resource<TSShape> shapeResource;
   S32 turretNode;
   S32 weaponNode;

   // persist fields
   F32 activateTime;  // seconds to activate/deactivate
   F32 maxPitchSpeed; // degrees/sec for AI moves (or deactivating moves or manually set "next move"
   F32 maxYawSpeed;   // degrees/sec for AI moves (or deactivating moves or manually set "next move"
   F32 minPitch,maxPitch;
   F32 minYaw,maxYaw;

	static	void		consoleInit();
	static	void		initPersistFields();
	virtual	void		packData(BitStream* stream);
	virtual void		unpackData(BitStream* stream);
	bool				preload(bool server, char errorBuffer[256]);

						DECLARE_CONOBJECT(TurretData);
						TurretData();
						~TurretData();
};

class Turret : public ShapeBase
{

	typedef ShapeBase			Parent;
protected:
	
	// One thread for Turret
	// Activate to turn it on and off
   // The old Elevate and Turn threads have been
   // done away with in favor of codeTurret and codeWeapon 
	void updateLookAnimation();
	TSThread* mActivateThread;

   // Client interpolation/warp data
   struct StateDelta {
      Move move;                    // Last move from server
      F32 dt;                       // Last interpolation time
      // Interpolation data
      Point3F rot;
      VectorF rotVec;

      // Warp data
      S32 warpTicks;
      Point3F rotOffset;
   };
   StateDelta delta;
   S32 mPredictionCount;            // Number of ticks to predict
   MatrixF LastTransform;

   // Current pos, vel etc.
   Point3F mRot;                    // Turret rotation, uses only x & z (right now y...must update)
   VectorF mVelocity;
   Point3F mAnchorPoint;            // Pos compression anchor
   F32 lastPitch;
   F32 lastYaw;
   U32 lastTickTime, lastInterpolateTime,elapsedTickTime;
   Point3F Rotation, LastRotation;

   // is active?
   bool isActive;

   // time of activation/deactivation (mounting/unmounting)
   U32 startActive;

   // aiming params...initialized from the datablocks
   // but can be set via methods at run time
   F32 mMaxPitchSpeed; // radians/server-tick
   F32 mMaxYawSpeed;   // radians/server-tick
   F32 mActivateTime;  // milliseconds to activate/deactivate
   F32 mMinPitch,mMaxPitch; // radians...we give limits in terms of yaw going from
   F32 mMinYaw,mMaxYaw; // -PI/+PI even tho mTTurn.z is stored from 0..2PI
   S32 weaponSlot;

   // for "next moves" that have been set "manually"
   Move *nextSetMove;               // if non-null then this is our next move
   Move nextSetMoveBuffer;          // space to hold values for abovv
   bool vehicleControled;

protected:

	enum MaskBits {
		  ActionMask            = Parent::NextFreeMask << 0,
		  MoveMask              = Parent::NextFreeMask << 1,
		  OptionsMask           = Parent::NextFreeMask << 2,
		  ControlMask           = Parent::NextFreeMask << 3,
		  ImageMask           = Parent::NextFreeMask << 4,
		  NextFreeMask          = Parent::NextFreeMask << 5
	   };   

private:
	TurretData	            *mDataBlock;
	SimObjectPtr<ShapeBase>	mControlObject;
public:
								DECLARE_CONOBJECT(Turret);
   void							updateMove(const Move* move);								
   static void					initPersistFields();
   static void					consoleInit();

   void                 setActive(bool activeFlag);
   void setWeaponSlot(U32 slot){weaponSlot = slot;}
   U32 getWeaponSlot(){ return weaponSlot;}
   bool                 getActive();

   bool                 isActivating();
   bool                 isActivated();
   bool                 isDeactivating();
   bool                 isDeactivated();

	void						setTransform(const MatrixF& netMat);
	bool						onAdd();
	void						onRemove();
	bool						onNewDataBlock(GameBaseData* dptr);
	bool						onAdd(bool callScript);
	void						onRemove(bool callScript);
	bool						onNewDataBlock(GameBaseData* dptr, bool callScript);
    virtual bool                getAIMove(Move*);
	void						processTick(const Move*);
	void						interpolateTick(F32 dt);
	void						advanceTime(F32 dt);
	void                        getMoveResults(F32 &tPitch, F32 & tYaw);
	void                        setMoveResults(const F32 &tPitch, const F32 & tYaw);
	void						setVehicleControled();
	bool                        isVehicleControled(){return vehicleControled;}

   TurretData* getDataBlock()  { return mDataBlock; }

	void						onCameraScopeQuery(NetConnection *cr, CameraScopeQuery *);
	void						writePacketData(GameConnection *, BitStream *stream);
	void						readPacketData(GameConnection *, BitStream *stream);
	U32							packUpdate(NetConnection *, U32 mask, BitStream *stream);
	void						unpackUpdate(NetConnection *, BitStream *stream);
	void						enableCollision();
	void						disableCollision();
	bool						mountImage(ShapeBaseImageData* imageData,U32 imageSlot,bool loaded,StringHandle &skinNameHandle);
	
	void						mountObject(ShapeBase* obj, U32 node);
	void						unmountObject(ShapeBase* obj);
	void						onUnmount(ShapeBase* obj);
   void                 unmount();
	bool						buildPolyList(AbstractPolyList* polyList, const Box3F &box, const SphereF &sphere);
	void						buildConvex(const Box3F& box, Convex* convex);									

	void						setPosition(const Point3F& pos,const Point3F& rot);
	void						setRenderPosition(const Point3F& pos, const Point3F& rot);

   // for manually feeding this turret moves
   void                 setNextMove(const Move *move);

   // for limiting moves for AI (or deactivating moves or manually set "next" moves)
   bool                 takeClosestYaw(F32 currYaw, F32 newYaw);
   void                 limitMoveAngles(Move* move, bool clientControlled = false);

   // options
   void                 resetTurretOptions();
   void                 setTurretOptions(F32 maxYawSpeed, F32 maxPitchSpeed, F32 activateTime, F32 minYaw, F32 maxYaw, F32 minPitch, F32 maxPitch);
   void					setMaxYawSpeed(F32 maxYawSpeed);
   void					setMaxPitchSpeed(F32 maxPitchSpeed);
   void					setMinYaw(F32 minYaw);
   void					setMaxYaw(F32 maxYaw);
   void					setMinPitch(F32 minPitch);
   void					setMaxPitch(F32 maxPitch);
   // firing
   void fire( U32 imageSlot );

	// Object control			
	void						setControllingClient(GameConnection* client);
	void						setControlObject(ShapeBase*);
	ShapeBase	         *getControlObject();
								
								Turret();
								~Turret();

   void setRotZ(F32 angle){mRot.z = angle;}
};

#endif //_TURRET_H_
// <- phdana droids