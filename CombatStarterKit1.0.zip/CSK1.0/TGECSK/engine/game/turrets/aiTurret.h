// phdana droids ->
//-----------------------------------------------------------------------------
// Torque Game Engine
// 
// Copyright (c) 2001 GarageGames.Com
// Portions Copyright (c) 2001 by Sierra Online, Inc.
//-----------------------------------------------------------------------------

#ifndef _AI_TURRET_H_
#define _AI_TURRET_H_

#ifndef _TURRET_H_
#include "game/turrets/turret.h"
#endif

#ifndef _TRIGGER_H_
#include "game/trigger.h"
#endif

struct AITurretData: public TurretData {
   typedef TurretData Parent;

  public:
   S32  triggerPeriodMS;
   F32  triggerRadius;
   S32  thinkPeriodMS;

   // aiming params
   F32 missRadius;   // randomly jitter aim location +/- this amount
   F32 projectileInheritVelocity;
	F32 projectileVelocity, projectileGravityMod;
	bool projectileBallistic, imageSeeks;

   AITurretData();
   DECLARE_CONOBJECT(AITurretData);
   static void consoleInit();
   static void initPersistFields();
   virtual void packData(BitStream* stream);
   virtual void unpackData(BitStream* stream);
};

class AITurret : public Turret {

	typedef Turret Parent;

   AITurretData*      mDataBlock;

   Vector<GameBase*> mObjects;
   U32               mLastTriggerThink;
   U32               mCurrTriggerTick;
   U32               mLastThinkingThink;
   U32               mCurrThinkingTick;

   Trigger          *mTrigger;

   // aiming params...initialized from the datablocks
   // but can be set via methods at run time
   F32 mMissRadius;
   F32 mProjectileInheritVelocity;
	F32 mProjectileVelocity, mProjectileGravityMod;
	bool mProjectileBallistic, mImageSeeks;

protected:

   bool onAdd();
   void onRemove();
   bool onNewDataBlock(GameBaseData* dptr);
   void onDeleteNotify(SimObject*);

   void removeAllObjects();
   void setHidden(bool hidden);
   bool testObject(GameBase* enter);
   void processTick(const Move*);


public:
	DECLARE_CONOBJECT( AITurret );
   static void initPersistFields();
   static void consoleInit();
	void						writePacketData(GameConnection *, BitStream *stream);
	void						readPacketData(GameConnection *, BitStream *stream);
	U32						packUpdate(NetConnection *, U32 mask, BitStream *stream);
	void						unpackUpdate(NetConnection *, BitStream *stream);

	AITurret();
   ~AITurret();

   void      preDelete();
   void      potentialEnterObject(GameBase*);

	SimObjectPtr<GameBase> mAimObject; // Object to point at, overrides location
	bool mAimLocationSet;               // Has an aim location been set?
	Point3F mAimLocation;               // Point to look at
   bool mTargetInLOS;                  // Is target object visible?

   void setTrigger(Trigger *trigger);
   Trigger *getTrigger();

   // move calc stuff
   bool isInLOS(GameBase *obj);
   void getAnglesFromAimLocation(Point3F &loc, VectorF &velocity, F32 &newYaw, F32 &newPitch);
   bool isReachableAngle(GameBase *obj);
	bool getAIMove( Move *move );

   // Utility Methods
   void throwCallback( const char *name );

   // firing
   void fire( U32 imageSlot );

   // triggering
   U32       getNumTriggeringObjects() const;
   GameBase* getObject(const U32);

   //Aiming params
   void resetAITurretOptions();
   void setAITurretOptions(F32 missRadius, F32 inheritVelocity, F32 velocity, F32 gravityMod, bool ballistic, bool imageSeeks);

	// Aiming
	void setAimObject( GameBase *targetObject );
	GameBase* getAimObject() const  { return mAimObject; }
	void setAimLocation( const Point3F &location );
	Point3F getAimLocation() const { return mAimLocation; }
	void clearAim();

   // Targeting
   void setTarget( GameBase *targetObject )  { setAimObject(targetObject); }
   GameBase * getTarget() const { return mAimObject; }
   bool isTarget( GameBase *targetObject ) const { return targetObject == mAimObject; }
   bool hasTarget() const { return mAimObject != NULL; } 
   void clearTarget() { clearAim(); }
   bool pickTarget();

};

inline U32 AITurret::getNumTriggeringObjects() const
{
   return mObjects.size();
}

inline GameBase* AITurret::getObject(const U32 index)
{
   AssertFatal(index < getNumTriggeringObjects(), "Error, out of range object index");

   return mObjects[index];
}

#endif
// <- phdana droids
