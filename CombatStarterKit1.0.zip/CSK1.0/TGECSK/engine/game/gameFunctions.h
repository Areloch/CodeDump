//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#ifndef _GAMEFUNCTIONS_H_
#define _GAMEFUNCTIONS_H_

void RegisterGameFunctions();

#endif
