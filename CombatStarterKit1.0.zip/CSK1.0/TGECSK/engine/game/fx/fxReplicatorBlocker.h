//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
// Modified by Thomas "Man of Ice" Lund, 21. September 2004
//-----------------------------------------------------------------------------

#ifndef _FXREPLICATORBLOCKER_H_
#define _FXREPLICATORBLOCKER_H_

#ifndef _SCENEOBJECT_H_
#include "sim/sceneObject.h"
#endif
#ifndef _BOXCONVEX_H_
#include "collision/boxConvex.h"
#endif

//--------------------------------------------------------------------------
class fxReplicatorBlocker : public SceneObject
{
   typedef SceneObject Parent;

  protected:
   Convex* mConvexList;

   Point3F mDimensions;
   
  public:
   fxReplicatorBlocker();
   ~fxReplicatorBlocker();

   bool onAdd();
   void onRemove();

   // Collision
   void buildConvex(const Box3F& box, Convex* convex);

   DECLARE_CONOBJECT(fxReplicatorBlocker);
   static void initPersistFields();

   U32  packUpdate  (NetConnection *conn, U32 mask, BitStream *stream);
   void unpackUpdate(NetConnection *conn,           BitStream *stream);
};

#endif // _FXREPLICATORBLOCKER_H_
