//-----------------------------------------------------------------------------
// Torque Game Engine
// 
// Mesh Line Tracer
// Max Robinson
//
// V1
//
// Portions of the code are Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------
// Files that are altered to get this to work:
// - sky.cc (so it can update the engine on the wind thing)
// - !! main.cc !! - for initializing the engine
// In addition to that, every object that uses these needs to be modified.

// copied from particleEngine.cc, I'm not sure if it's necessary
#if defined(TORQUE_OS_MAC)
#if __MWERKS__ && (__MWERKS__ < 0x2430) // this should be safe for CW Pro 7.0
// this file crashes the CW6.3 compiler if opimizations greater than 1.
#if __option(global_optimizer)
// don't know which sub-area of the compiler it is as yet, so just set to 1.
#pragma optimization_level 1
#endif
#endif
#endif

#ifndef _H_3DLINETRACER
#define _H_3DLINETRACER

#ifndef _GAMEBASE_H_
#include "game/gameBase.h"
#endif
#ifndef _LLIST_H_
#include "core/llist.h"
#endif
#ifndef _TSSHAPEINSTANCE_H_
#include "ts/tsShapeInstance.h"
#endif

namespace TracerEngine
{
	void init();
	void destroy();

	extern Point3F windVelocity;
	inline void setWindVelocity(const Point3F & vel) { windVelocity = vel; }
	inline Point3F getWindVelocity() { return windVelocity; }
}

//--------------------------------------------------------------------------
// Point in back ring
//--------------------------------------------------------------------------
struct LineTracerRingPoint
{
   Point3F  position;			 // absolute world position used when rendering
	Point3F	outwardsVector;	 // offset vector so the ring can position it correctly

	LineTracerRingPoint * next;
	LineTracerRingPoint * nextInEngine;	/// next point in world (handled by TEngine class)

	LineTracerRingPoint()
	{
		position.set(0,0,0);
		outwardsVector.set(0,0,1);
	}
};

//--------------------------------------------------------------------------
// the back ring
//--------------------------------------------------------------------------
struct LineTracerRing
{
	LineTracerRing * next;					// next ring in list
	LineTracerRing * nextInEngine;		// next ring in world (handled by TEngine class)
	LineTracerRingPoint * pointsHead;	// head of points list

	F32		elapsedTime;			// elapsed time - used to delete ring, and to pick color and radius

	ColorF	color;					// color to render

	F32		radius;					// amount to push out points
	F32		twistVelocity;			// transverse push on ring

	Point3F	inheritedVelocity;	// movement applied based on movement (from last to current position)

	Point3F	centralVector;			// central vector for backwardsVelocity
	Point3F	twistVector;			// transverse vector

	Point3F	totalDrift;				// amount ring has been pushed during its lifetime
	Point3F	position;				// original position


   LineTracerRing()
   {
		pointsHead = NULL;
		next = NULL;

		elapsedTime = 0.0f;

      color.set( 0.0, 0.0, 0.0, 1.0 );

      radius = 0.0f;
		twistVelocity = 0.0f;

		inheritedVelocity.set(0,0,0);

		position.set(0,0,0);
		totalDrift.set(0,0,0);

      centralVector.set(0,0,1);
		twistVector.set(1,0,0);
   }
};

//--------------------------------------------------------------------------
// Datablock
//--------------------------------------------------------------------------
class LineTracerData : public GameBaseData
{
   typedef GameBaseData Parent;

  public:

   enum Constants
   {
      NUM_COLOR_KEYS = 4,
		NUM_SIZE_KEYS = 12,
      NUM_TEX = 4,
		NUM_POINTS = 32,
   }; // NOTE: IF YOU RAISE NUM_POINTS, YOU WILL HAVE TO CHANGE THE NUMBER OF BITS FOR PACKING AND UNPACKING!

  public:

	// BASIC RING CHARACTERISTICS ----------------------------------------------------------------------------------------------------------
	F32               trailLifetimeMS;	// per ring lifetime
   F32               newRingMS;			// time inbetween new ring creation
   U32               numSegments;		// number of points per ring
	F32					killDistance;		// if we move more than this much, clear list (lag/teleport)

	// RENDER-TIME -------------------------------------------------------------------------------------------------------------------------
	bool              perRenderRing;				// render the "temp" ring for a closer "stick" - uses a bit more operations, but looks nicer
	bool					dontRenderConeOnImpact;	// should we not render cone after hit? a good idea on effects with high twist pushing
	bool					faceCamera;					// if we have 2 segments, should they be oriented for the camera?
					// MCRTODO: make it so if you say ring size is 1, then it automatically does face camera. remove face camera
	bool					renderWithTarget;			// all rings will be stored relative to source instead of using absolute coordinates


	// POINT POSITIONING -------------------------------------------------------------------------------------------------------------------
	//		keyed radius
   F32					sizes[NUM_SIZE_KEYS];					// sizes (from front to back)
	U32					sizeCurveQuadrant[NUM_SIZE_KEYS];	// part of sine graph to use as a curve
   F32					sizeTimes[NUM_SIZE_KEYS];				// sizing time percentages
	//		float array
	bool					useCustomShape;							// use custom dimensions?
	F32					shapeDim[NUM_POINTS];					// dimensions array
	//			nodes
	bool					useNodeTracking;							// track target obj nodes?
	bool					useAssignedNodes;							// let target object specify nodes to use?
	S32					numTargetNodes;							// num target shape nodes to track
	const char*			targetNodes[NUM_POINTS];				// dimensions array

	// POINT & RING MOVEMENT ---------------------------------------------------------------------------------------------------------------
	//			internal
	F32					backwardsVelocity;			// velocity along central axis
	F32					overheadRotation;				// initial rotation of transverse axis on central axis
	F32					twistSpeed;						// per second rotation of transverse axis on central axis
	F32					twistPushVelocity;			// base speed of push on transverse axis
	F32					twistPushAcceleration;		// acceleration along transverse axis
	//			external
	F32					ringVelocityInheritance;	// drags ring along delta position over each time advance
	F32					gravityMod;						// amount of fall from gravity
	F32					windMod;							// amount of push from the wind

	// REMOVING/DELETING -------------------------------------------------------------------------------------------------------------------
	bool					fastRemove;						// remove instantly when setDead is called? (instead of waiting for rings to timeout)

	// COLORS ------------------------------------------------------------------------------------------------------------------------------
	bool					useInvAlpha;					// use inverse alpha method?
   ColorF            colors[NUM_COLOR_KEYS];		// color (from front to back)
   F32					times[NUM_COLOR_KEYS];		// time percentages

	// TEXTURES ----------------------------------------------------------------------------------------------------------------------------
   StringTableEntry  textureName[NUM_TEX];		//	texture paths
   TextureHandle     textureHandle[NUM_TEX];		// texture IDs

   F32               horizontalTexWrap[NUM_TEX];		// # of times to repeat texture around sides
   F32               verticalTexWrap[NUM_TEX];			// # of times to repeat texture going up the sides

   F32               horizontalTexMovementBase[NUM_TEX];	// base speed at which this texture should move around sides
   F32               verticalTexMovementBase[NUM_TEX];	// base speed at which this texture should up the sides

   LineTracerData();
   DECLARE_CONOBJECT(LineTracerData);
   bool onAdd();
   bool preload(bool server, char errorBuffer[256]);
   static void  initPersistFields();
   virtual void packData(BitStream* stream);
   virtual void unpackData(BitStream* stream);
};

DECLARE_CONSOLETYPE(LineTracerData)

//--------------------------------------------------------------------------
// Splash
//--------------------------------------------------------------------------
class LineTracer : public GameBase
{
   typedef GameBase Parent;
	friend class TEngine;

  private:
   LineTracerData*    mDataBlock;

	GameBase*	mTarget;

   F32         mElapsedTime;

	LineTracerRing* mRingHead;
	U32			mRingCount;
   F32         mLastRingMS;

	F32			mOverheadRot;

//	F32			mScale; // MCRTODO: make it so this dynamically scales the entire tracer

	F32			horizontalTextureShift[LineTracerData::NUM_TEX];
	F32			verticalTextureShift[LineTracerData::NUM_TEX];

   bool        mDead;

	bool			mActive;

	bool			useTargetNodes;
	const char* shapeName;
	TSShapeInstance *  shape;
	S32			targetNodes[LineTracerData::NUM_POINTS];	// Because the possible targets aren't limited to a single possible shape, node targets are 
																			// acquired when the target object is recieved, as this is the earliest possible time for this.
	S32			assignedNodes;

	Point3F		mLastPosition;
	Point3F     mCurrentPosition;
	Point3F		mLastNormal;
   Point3F     mCurrentNormal;

   void        updateWBox( );

	void			emitRings(F32 dt);
   LineTracerRing * createRing(F32 , F32);
   void        updateRings( F32 dt );
   void        updateRing( F32 dt , LineTracerRing *ring);

	void			freeRings();

  protected:

   F32         mFade;
   F32         mFog;

  protected:
   bool        onAdd();
   void        onRemove();

   void        processTick(const Move*);
   void        advanceTime(F32 dt);

   void        render();
	void			renderSegment(LineTracerRing *top,LineTracerRing *bottom,int ttex);

   // Rendering
  protected:
   bool prepRenderImage(SceneState*, const U32, const U32, const bool);
   void renderObject(SceneState*, SceneRenderImage*);

  public:
   LineTracer();
   ~LineTracer();

	bool wantsShape();                                                      // returns true if this is supposed to track nodes on a model
	void setTargetShape(const char* targetShapeName);                       // tells the tracer which model is working with
	void addTargetNode(S32 index);                                          // forces the tracer to use this node
	void setTrackTransform(const Point3F& point, const Point3F& normal);    // updates the tracer's position. you probably don't need to use this function.
   void setTarget(GameBase* target);                                       // attaches the tracer to this object
	void setDead();                                                         // tracer will stop emitting and delete itself when it is empty
	void setActive(bool);                                                   // turns the tracer on and off
	bool isActive() { return mActive; };                                    // returns true if the tracer is on, false if off
	void setFade(F32);                                                      // only pass values between 0 and 1 . This fades the tracer. Good for projectiles that are fading out.

	void renderImage(SceneState* state, SceneRenderImage*);
   bool onNewDataBlock(GameBaseData* dptr);
   static void initPersistFields();

protected:
   static const F32 initialWaitMS;
};


#endif
