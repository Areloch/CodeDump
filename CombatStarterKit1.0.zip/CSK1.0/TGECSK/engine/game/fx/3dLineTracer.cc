//-----------------------------------------------------------------------------
// Torque Game Engine
//
// Mesh Line Tracer
// Max Robinson
//
// V1
//
// Portions of the code are Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// Includes...
#include "game/fx/3dLineTracer.h"

#include "console/consoleTypes.h"
#include "dgl/dgl.h"
#include "sceneGraph/sceneGraph.h"
#include "sceneGraph/sceneState.h"
#include "core/bitStream.h"
#include "math/mathUtils.h"
#include "math/mathIO.h"

// Some initialization
const F32 LineTracer::initialWaitMS = 64/1000.0f;

namespace {
	TEngine * sgTracerEngine = NULL;
}

//----------------------------------------------------------------------------
// "Tracer Engine"
// This is basically a copy of the particle engine.
class TEngine
{
	static const U32  csmPointBlockSize;
	static const U32  csmRingBlockSize;
	
	U32 numRings;

	Vector<LineTracerRingPoint*>	mAllocatedPointBlocks;
	Vector<LineTracerRing*>			mAllocatedRingBlocks;
	LineTracerRingPoint*				mFreePointList;
	LineTracerRing*					mFreeRingList;

public:
	LineTracerRingPoint*		allocatePoint();
	LineTracerRing*			allocateRing();
	
	void      releasePoint(LineTracerRingPoint*);
	void      releaseRing(LineTracerRing*);

public:
	TEngine();
	~TEngine();
};

// These are used by the TEngine class to decide how big of an array to create for keeping track of these objects
const U32 TEngine::csmPointBlockSize = 2048;//2048;
const U32 TEngine::csmRingBlockSize = 512;//1024;

//--------------------------------------
// Con init
IMPLEMENT_CO_DATABLOCK_V1(LineTracerData);

//--------------------------------------------------------------------------
// THE DATABLOCK
//--------------------------------------------------------------------------
LineTracerData::LineTracerData()
{
	// BASIC RING CHARACTERISTICS ----------------------------------------------------------------------------------------------------------
	trailLifetimeMS			= 1.0f;
   newRingMS					= 0.01f;
   numSegments					= 4;
	killDistance				= 0;

	// RENDER-TIME -------------------------------------------------------------------------------------------------------------------------
	perRenderRing				= false;
	dontRenderConeOnImpact	= false;
	faceCamera					= false;
	renderWithTarget			= false;

	// POINT POSITIONING -------------------------------------------------------------------------------------------------------------------
	//		keyed radius
   sizes[0] = 0.0;
   sizes[1] = 2.0;
	sizes[2] = 3.0;
   sizeTimes[0] = 0.0;
   sizeTimes[1] = 0.5;
	sizeTimes[2] = 1.0;
	for( int i=3; i<NUM_SIZE_KEYS; i++ )
	{
		sizes[i] = 3.0;
		sizeTimes[i] = 1.0;
	}
   dMemset( sizeCurveQuadrant, 0, sizeof( sizeCurveQuadrant ) );
	//		float array
	useCustomShape				= false;
   dMemset( shapeDim,		0, sizeof( shapeDim ) );
	//			nodes
	useNodeTracking			= false;
	useAssignedNodes			= false;
	numTargetNodes				= 0;
   dMemset( targetNodes,	-1, sizeof( targetNodes ) );

	// POINT & RING MOVEMENT ---------------------------------------------------------------------------------------------------------------
	//			internal
	backwardsVelocity			= 0;
	overheadRotation			= 0;
	twistSpeed					= 0;
	twistPushVelocity			= 0;
	twistPushAcceleration	= 0;
	//			external
	ringVelocityInheritance = 0;
	gravityMod					= 0;
	windMod						= 0;

	// REMOVING/DELETING -------------------------------------------------------------------------------------------------------------------
	fastRemove					= false;

	// COLORS ------------------------------------------------------------------------------------------------------------------------------
	useInvAlpha					= false;
   for( int i=0; i<NUM_COLOR_KEYS; i++ )
      colors[i].set( 1.0, 1.0, 1.0, 1.0 );
   times[0] = 0.0f;
   times[1] = 1.0f;
   times[2] = 2.0f;
   times[3] = 2.0f;

	// TEXTURES ----------------------------------------------------------------------------------------------------------------------------
   dMemset( textureName,	0, sizeof( textureName ) );
   dMemset( textureHandle,	0, sizeof( textureHandle ) );

   dMemset( horizontalTexWrap,	1, sizeof( horizontalTexWrap ) );
   dMemset( verticalTexWrap,		1, sizeof( verticalTexWrap ) );

   dMemset( horizontalTexMovementBase, 0, sizeof( horizontalTexMovementBase ) );
   dMemset( verticalTexMovementBase,	0, sizeof( verticalTexMovementBase ) );
}

IMPLEMENT_CONSOLETYPE(LineTracerData)
IMPLEMENT_SETDATATYPE(LineTracerData)
IMPLEMENT_GETDATATYPE(LineTracerData)

//--------------------------------------------------------------------------
// Init fields
//--------------------------------------------------------------------------
void LineTracerData::initPersistFields()
{
   Parent::initPersistFields();

	// BASIC RING CHARACTERISTICS ----------------------------------------------------------------------------------------------------------
   addField("trailLifetimeMS",			TypeF32,                      Offset(trailLifetimeMS,				LineTracerData));
   addField("newRingMS",					TypeF32,                      Offset(newRingMS,						LineTracerData));
   addField("numSegments",					TypeS32,                      Offset(numSegments,					LineTracerData));
   addField("resetDistance",				TypeF32,                      Offset(killDistance,					LineTracerData));

	// RENDER-TIME -------------------------------------------------------------------------------------------------------------------------
   addField("makeFrontRingAtRender",	TypeBool,                     Offset(perRenderRing,				LineTracerData));
	addField("dontRenderFrontAfterHit",	TypeBool,							Offset(dontRenderConeOnImpact,	LineTracerData));
   addField("alwaysFaceCamera",			TypeBool,							Offset(faceCamera,					LineTracerData));
   addField("relativeCoordinates",		TypeBool,							Offset(renderWithTarget,			LineTracerData));

	// POINT POSITIONING -------------------------------------------------------------------------------------------------------------------
	//		keyed radius
   addField("sizes",							TypeF32,								Offset(sizes,							LineTracerData), NUM_SIZE_KEYS);
	addField("sizeCurveQuadrant",			TypeS32,								Offset(sizeCurveQuadrant,			LineTracerData), NUM_SIZE_KEYS);
   addField("sizeTimes",					TypeF32,								Offset(sizeTimes,						LineTracerData), NUM_SIZE_KEYS);
	//		float array
   addField("useCustomShape",				TypeBool,							Offset(useCustomShape,				LineTracerData));
   addField("shapeDim",						TypeF32,								Offset(shapeDim,						LineTracerData), NUM_POINTS);
	//			nodes
   addField("useNodeTracking",			TypeBool,							Offset(useNodeTracking,				LineTracerData));
	addField("useAssignedNodes",			TypeBool,							Offset(useAssignedNodes,				LineTracerData));
   addField("targetNodes",					TypeCaseString,					Offset(targetNodes,					LineTracerData), NUM_POINTS);

	// POINT & RING MOVEMENT ---------------------------------------------------------------------------------------------------------------
	//			internal
	addField("backwardsVelocity",			TypeF32,								Offset(backwardsVelocity,	LineTracerData));
   addField("overheadRotation",			TypeF32,								Offset(overheadRotation,			LineTracerData));
	addField("twistSpeed",					TypeF32,								Offset(twistSpeed,					LineTracerData));
   addField("twistPushVelocity",			TypeF32,                      Offset(twistPushVelocity,			LineTracerData));
	addField("twistPushAcceleration",	TypeF32,                      Offset(twistPushAcceleration,		LineTracerData));
	//			external
   addField("ringVelocityInheritance",	TypeF32,                      Offset(ringVelocityInheritance,	LineTracerData));
	addField("gravityMod",					TypeF32,								Offset(gravityMod,					LineTracerData));
	addField("windMod",						TypeF32,								Offset(windMod,						LineTracerData));

	// REMOVING/DELETING -------------------------------------------------------------------------------------------------------------------
	addField("deleteInstantly",			TypeBool,							Offset(fastRemove,	LineTracerData));

	// COLORS ------------------------------------------------------------------------------------------------------------------------------
	addField("useInvAlpha",					TypeBool,							Offset(useInvAlpha,					LineTracerData));
   addField("colors",						TypeColorF,							Offset(colors,							LineTracerData), NUM_COLOR_KEYS);
   addField("times",							TypeF32,								Offset(times,							LineTracerData), NUM_COLOR_KEYS);

	// TEXTURES ----------------------------------------------------------------------------------------------------------------------------
   addField("texture",						TypeString,                   Offset(textureName,					LineTracerData), NUM_TEX);
   addField("verticalTexWrap",			TypeF32,								Offset(verticalTexWrap,				LineTracerData), NUM_TEX);
	addField("horizontalTexWrap",			TypeF32,								Offset(horizontalTexWrap,			LineTracerData), NUM_TEX);
   addField("horizontalTexMovementBase",	TypeF32,							Offset(horizontalTexMovementBase,LineTracerData), NUM_TEX);
	addField("verticalTexMovementBase",		TypeF32,							Offset(verticalTexMovementBase,	LineTracerData), NUM_TEX);
}

//--------------------------------------------------------------------------
// On add - verify data settings
//--------------------------------------------------------------------------
bool LineTracerData::onAdd()
{
   if (Parent::onAdd() == false)
      return false;

   return true;
}

//--------------------------------------------------------------------------
// Pack data
//--------------------------------------------------------------------------
void LineTracerData::packData(BitStream* stream)
{
   Parent::packData(stream);

   stream->writeFloat( trailLifetimeMS,	16 );
	stream->writeFloat( newRingMS,			16 );

	if(numSegments > NUM_POINTS)
		numSegments = NUM_POINTS;

   stream->writeInt(numSegments,5);
		
	stream->write(killDistance);
	stream->write(backwardsVelocity);
	stream->write(ringVelocityInheritance);
	stream->write(twistPushAcceleration);
	stream->write(twistPushVelocity);
   stream->write(overheadRotation );
	stream->write(twistSpeed );
	stream->write(gravityMod);
	stream->write(windMod);

   stream->writeFlag(perRenderRing);
	stream->writeFlag(useInvAlpha);
	stream->writeFlag(faceCamera);
	stream->writeFlag(dontRenderConeOnImpact);
	stream->writeFlag(useNodeTracking);
	stream->writeFlag(useAssignedNodes);
	stream->writeFlag(useCustomShape);
	stream->writeFlag(fastRemove);
	stream->writeFlag(renderWithTarget);

	int i = 0;
   do
   {
		stream->writeFlag(true);

		// 24 bit
		stream->write(sizes[i]);
		stream->writeFloat(sizeTimes[i],14);
		stream->writeInt(sizeCurveQuadrant[i],2);
		
		i++;
   } while(i < NUM_SIZE_KEYS && sizeTimes[i-1] != 1.0f);
	stream->writeFlag(false);

	i = 0;
   do
   {
		stream->writeFlag(true);

		// 36 bit
      stream->writeFloat( colors[i].red,	7 );
		stream->writeFloat( colors[i].green,7 );
		stream->writeFloat( colors[i].blue,	7 );
		stream->writeFloat( colors[i].alpha,7 );
      stream->writeFloat( times[i],			8 );
		
		i++;
   } while(i < NUM_COLOR_KEYS && times[i-1] != 1.0f);
	stream->writeFlag(false);

	if(useCustomShape)
	{
		for(i = 0; i < numSegments; i++)
			stream->write(shapeDim[i]);
	}

	if(useNodeTracking && !useAssignedNodes)
	{
		i = 0;
		do
		{
			if( targetNodes[i] != NULL )
			{
				stream->writeFlag(true);
				stream->writeString(targetNodes[i]);
			}
			i++;
		} while(i<numSegments);
		stream->writeFlag(false);
	}

	i = 0;
	do
	{
      if( textureName[i] != NULL )
		{
			stream->writeFlag(true);
			stream->writeFloat(horizontalTexWrap[i],8);
			stream->writeFloat(verticalTexWrap[i],8);
			stream->writeFloat(horizontalTexMovementBase[i],8);
			stream->writeFloat(verticalTexMovementBase[i],8);
			stream->writeString(textureName[i]);
		}
		i++;
   } while(i<NUM_TEX);
	stream->writeFlag(false);
}

//--------------------------------------------------------------------------
// Unpack data
//--------------------------------------------------------------------------
void LineTracerData::unpackData(BitStream* stream)
{
   Parent::unpackData(stream);

   trailLifetimeMS	= stream->readFloat(16);
	newRingMS			= stream->readFloat(16);

	numSegments = stream->readInt(5);
	
	stream->read(&killDistance);
	stream->read(&backwardsVelocity);
	stream->read(&ringVelocityInheritance);
   stream->read(&twistPushAcceleration);
	stream->read(&twistPushVelocity);
   stream->read(&overheadRotation );
	stream->read(&twistSpeed );
	stream->read(&gravityMod);
	stream->read(&windMod);

   perRenderRing				= stream->readFlag();
	useInvAlpha					= stream->readFlag();
	faceCamera					= stream->readFlag();
	dontRenderConeOnImpact	= stream->readFlag();
	useNodeTracking			= stream->readFlag();
	useAssignedNodes			= stream->readFlag();
	useCustomShape				= stream->readFlag();
	fastRemove					= stream->readFlag();
	renderWithTarget			= stream->readFlag();

   int i	= 0;
	while(stream->readFlag() != false)
	{
		stream->read(&sizes[i]);
		sizeTimes[i] = stream->readFloat(14);
		sizeCurveQuadrant[i] = stream->readInt(2);
		Con::warnf(ConsoleLogEntry::General,"%f %f %d",sizes[i],sizeTimes[i],sizeCurveQuadrant[i]);
		i++;
   }

	i	= 0;
	while(stream->readFlag() != false)
	{
      colors[i].red		= stream->readFloat(7);
		colors[i].green	= stream->readFloat(7);
		colors[i].blue		= stream->readFloat(7);
		colors[i].alpha	= stream->readFloat(7);
      times[i]				= stream->readFloat(8);
		i++;
   }

	if(useCustomShape)
	{
		for(i = 0; i < numSegments; i++)
			stream->read(&shapeDim[i]);
	}

	if(useNodeTracking && !useAssignedNodes)
	{
		i = 0;
		while(stream->readFlag() != false)
		{
			targetNodes[i] = stream->readSTString();
			i++;
		}
		numTargetNodes = i;
	}

	i = 0;
	while(stream->readFlag() != false)
	{
		horizontalTexWrap[i]				= stream->readFloat(8);
		verticalTexWrap[i]				= stream->readFloat(8);
		horizontalTexMovementBase[i]	= stream->readFloat(8);
		verticalTexMovementBase[i]		= stream->readFloat(8);
		textureName[i]						= stream->readSTString();
		i++;
   }
}

//--------------------------------------------------------------------------
// Preload data - load resources
//--------------------------------------------------------------------------
bool LineTracerData::preload(bool server, char errorBuffer[256])
{
   if (Parent::preload(server, errorBuffer) == false)
      return false;

   if (!server)
	{
      S32 i;

      for( i=0; i<NUM_TEX; i++ )
      {
         if (textureName[i] && textureName[i][0])
         {
            textureHandle[i] = TextureHandle(textureName[i], MeshTexture );
         }
      }
   }

   return true;
}


//--------------------------------------------------------------------------
// THE OBJECT
//--------------------------------------------------------------------------
LineTracer::LineTracer()
{
	mTarget = NULL;
   mElapsedTime = 0.0;

	mRingHead = NULL;
	mRingCount = 0;
	mLastRingMS = initialWaitMS;

	mOverheadRot = 0;

	mDead = false;

	mActive = false;

	useTargetNodes = false;
   shape = NULL;
   shapeName = NULL;

	assignedNodes = -1;

   mLastPosition.set( 0.0, 0.0, 1.0 );
   mCurrentPosition.set( 0.0, 0.0, 1.0 );
   mLastNormal.set( 0.0, 0.0, 1.0 );
	mCurrentNormal.set( 0.0, 0.0, 1.0 );

   mFade            = 1.0f;
   mFog             = 0.0f;
}

LineTracer::~LineTracer()
{
}

//--------------------------------------------------------------------------
// Shape related
//--------------------------------------------------------------------------
bool LineTracer::wantsShape()
{
	return mDataBlock->useNodeTracking;
}

void LineTracer::setTargetShape(const char* targetShapeName)
{
	if(mDataBlock->useNodeTracking)
	{
		shapeName = targetShapeName;

		Resource<TSShape> tempShape;
		if( shapeName && shapeName[0] != '\0' )//&& !bool(shape) )
		{
			useTargetNodes = true;
			tempShape = ResourceManager->load(shapeName);
			if( bool(tempShape) == false )
				useTargetNodes = false;
			else
			{
				useTargetNodes = true;
				shape = new TSShapeInstance(tempShape,false);
				if(!mDataBlock->useAssignedNodes)
				{
					for(int i = 0; i < mDataBlock->numTargetNodes; i++)
						targetNodes[i] = tempShape->findNode(mDataBlock->targetNodes[i]);
				}
			}
		}
   }
}

void LineTracer::addTargetNode(S32 index)
{
	if(assignedNodes == -1)
	{
		assignedNodes = 0;
		useTargetNodes = true;
	}

	targetNodes[assignedNodes] = index;

	assignedNodes++;
}

void LineTracer::setFade(F32 v)
{
	mFade = v;
}

//--------------------------------------------------------------------------
// Basic stuff
//--------------------------------------------------------------------------
void LineTracer::setTarget(GameBase* target)
{
	if(mDead == false)
	{
		mTarget = target;
		processAfter(target);
	}
}

void LineTracer::setDead()
{
   if(!mDead)
	{
		mDead = true;
		mActive = false;
	}
}

void LineTracer::setActive(bool val)
{
	if(mTarget == NULL)
		return;

	if(!mDead && mSceneManager == NULL)
	{
		gClientSceneGraph->addObjectToScene(this);
		gClientContainer.addObject(this);
		gClientProcessList.addObject(this);
	}

	if(!val)
	{
		if(mDataBlock->fastRemove)
			freeRings();
		mActive  = false;
	}
	else
	{
		mLastRingMS = mElapsedTime;

		MatrixF mat = mTarget->getRenderTransform();
		Point3F dir,pos;
		mat.getColumn(3,&pos);

		if(useTargetNodes && (mDataBlock->numTargetNodes == 1 || assignedNodes == 1))
			mat.mul(mat,shape->mNodeTransforms[targetNodes[0]]);

		mat.getColumn(1,&dir);

		setTrackTransform(pos,dir);
		mActive = true;
	}
}

void LineTracer::setTrackTransform(const Point3F& point, const Point3F& normal)
{
	Point3F dir = normal;

	if(dir.isZero())
		dir.set(0,0,1);
	else
      dir.normalize();

	mCurrentPosition	= point;
	mLastNormal			= mCurrentNormal;
	mCurrentNormal		= dir;

	setPosition( point );

   MatrixF xform(true);
	xform = MathUtils::createOrientFromDir(dir);

	xform.setPosition(mCurrentPosition);
	setRenderTransform(xform);
}

//--------------------------------------------------------------------------
// Handlers for really simple stuff - remove/add,/init
//--------------------------------------------------------------------------
void LineTracer::initPersistFields()
{
   Parent::initPersistFields();
}

bool LineTracer::onAdd()
{
   if(!Parent::onAdd())
      return false;

	removeFromProcessList();

	mOverheadRot = mDataBlock->overheadRotation;

   mObjBox.min = Point3F( -1.0f, -1.0f, -1.0f );
   mObjBox.max = Point3F( 1.0f,  1.0f,  1.0f );
   resetWorldBox();

/*	for(int i = 0; i < LineTracerData::NUM_TEX; i++)
	{
		horizontalTextureShift[i]			= 0;
		verticalTextureShift[i]				= 0;
	}*/

   return true;
}

void LineTracer::onRemove()
{
	freeRings();

	if (mSceneManager != NULL)
	{
	   mSceneManager->removeObjectFromScene(this);
		getContainer()->removeObject(this);
	}

   Parent::onRemove();
}

bool LineTracer::onNewDataBlock(GameBaseData* dptr)
{
   mDataBlock = dynamic_cast<LineTracerData*>(dptr);
   if (!mDataBlock || !Parent::onNewDataBlock(dptr))
      return false;

   scriptOnNewDataBlock();
   return true;
}

//--------------------------------------------------------------------------
// Process tick
//--------------------------------------------------------------------------
void LineTracer::processTick(const Move*)
{
	if( mDead && mRingHead == NULL )
		deleteObject();
}

//--------------------------------------------------------------------------
// Advance time
//--------------------------------------------------------------------------

void LineTracer::advanceTime(F32 dt)
{
	// Move time!
   if (dt == 0.0)
      return;
   mElapsedTime += dt;

	// Let the parent object get oriented first...
	if(mElapsedTime < initialWaitMS)
	   return;

	// If we are going, but are empty, we should still track to avoid up messy lines
	if(mRingHead == NULL && mActive)
	{
		MatrixF mat = mTarget->getRenderTransform();
		Point3F dir,pos;
		mat.getColumn(3,&pos);

		if(useTargetNodes && (mDataBlock->numTargetNodes == 1 || assignedNodes == 1))
			mat.mul(mat,shape->mNodeTransforms[targetNodes[0]]);

		mat.getColumn(1,&dir);

		setTrackTransform(pos,dir);
	}

	// Update everything
	if(mRingHead != NULL)
	{
		for(int ttex = 0; ttex < LineTracerData::NUM_TEX; ttex++)
		{
			if(bool(mDataBlock->textureHandle[ttex]))
			{
				horizontalTextureShift[ttex] += (mDataBlock->horizontalTexMovementBase[ttex] * dt);
				verticalTextureShift[ttex] += (mDataBlock->verticalTexMovementBase[ttex] * dt);
			}
		}

		if(dt > mDataBlock->trailLifetimeMS)
			freeRings(); // lag protection
		else
		{
			updateRings( dt ); // apply movement to rings
			updateWBox();
		}
	}

	// If active, track & emit
	if(mActive)
	{
		Point3F vel = mTarget->getPosition() - getPosition();

		if(!vel.isZero() && mDataBlock->killDistance > 0)
		{
			if(vel.len() > mDataBlock->killDistance)
				freeRings();
		}

		emitRings(dt);

		MatrixF mat = mTarget->getRenderTransform();
		Point3F dir,pos;
		mat.getColumn(3,&pos);

		if(useTargetNodes && (mDataBlock->numTargetNodes == 1 || assignedNodes == 1))
			mat.mul(mat,shape->mNodeTransforms[targetNodes[0]]);

		mat.getColumn(1,&dir);
		setTrackTransform(pos,dir);

		mOverheadRot += mDataBlock->twistSpeed * dt;
	}

}

//----------------------------------------------------------------------------
// Box update
//----------------------------------------------------------------------------
void LineTracer::updateWBox( )
{
	// MCRTODO: renderWithTarget should do the math here
	// if nothing is here, it's not rendering, so just screw it
	if(mRingHead != NULL && !mDataBlock->renderWithTarget)
	{
		mObjBox.min.set( 1e10,  1e10,  1e10);
		mObjBox.max.set(-1e10, -1e10, -1e10);

	   LineTracerRing* nRing = mRingHead; // from front

		Point3F relRingPosition;
		while (nRing != NULL)
		{
			relRingPosition = nRing->position - mCurrentPosition;

			mObjBox.min.setMin( relRingPosition ); 
			mObjBox.max.setMax( relRingPosition );

			nRing = nRing->next;
		}
		mObjBox.min.setMin( Point3F( -1.0f, -1.0f, -1.0f ) );
		mObjBox.max.setMax( Point3F(  1.0f,  1.0f,  1.0f ) ); // to back

	   MatrixF xform = getTransform();
		setTransform(xform);

		resetWorldBox();
	}
	else
	{
		mObjBox.min.setMin( Point3F( -1.0f, -1.0f, -1.0f ) );
		mObjBox.max.setMax( Point3F(  1.0f,  1.0f,  1.0f ) );

		resetWorldBox();
	}
}

//--------------------------------------------------------------------------
// Rendering
//--------------------------------------------------------------------------
bool LineTracer::prepRenderImage(SceneState* state, const U32 stateKey,
                             const U32 /*startZone*/, const bool /*modifyBaseState*/)
{
   if (isLastState(state, stateKey))
      return false;
   setLastState(state, stateKey);

   // This should be sufficient for most objects that don't manage zones, and
   //  don't need to return a specialized RenderImage...
   if (state->isObjectRendered(this)) {
      mFog = 0.0;

      SceneRenderImage* image = new SceneRenderImage;
      image->obj = this;
      image->isTranslucent = true;
      image->sortType = SceneRenderImage::Point;
      image->textureSortKey = U32(mDataBlock);
      state->setImageRefPoint(this, image);
      state->insertRenderImage(image);
   }

   return false;
}

void LineTracer::renderObject(SceneState* state, SceneRenderImage*)
{
   AssertFatal(dglIsInCanonicalState(), "Error, GL not in canonical state on entry");

	RectI viewport;
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	dglGetViewport(&viewport);

   state->setupObjectProjection(this);

/*	if(mDataBlock->renderWithTarget)
	{
		glMatrixMode(GL_MODELVIEW);
		glPushMatrix();
		dglMultMatrix(&mTarget->getRenderTransform());
	}*/

   render();

/*	if(mDataBlock->renderWithTarget)
	{
		glMatrixMode(GL_MODELVIEW);
		glPopMatrix();
	}*/

   glMatrixMode(GL_PROJECTION);
   glPopMatrix();
   glMatrixMode(GL_MODELVIEW);
   dglSetViewport(viewport);

   AssertFatal(dglIsInCanonicalState(), "Error, GL not in canonical state on exit");
}

void LineTracer::render()
{
/*	glBegin( GL_LINES);
	{
		glColor4f( 0.0f,0.0f,1.0f,1.0f );
		glVertex3fv( mCurrentPosition);
		glVertex3fv( mCurrentPosition + mLastNormal *  10.0f);
		glVertex3fv( mCurrentPosition);
		glVertex3fv( mCurrentPosition + mCurrentNormal *  10.0f);
	}
	glEnd();*/

	if( mRingHead == NULL)
		return;	// OOPS! Nevermind...

	LineTracerRing *cRing;
	LineTracerRing *nRing;

	glDisable(GL_CULL_FACE);
	glDepthMask(GL_FALSE);
	glEnable(GL_BLEND);

	if( mDataBlock->useInvAlpha )
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	else
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);

	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	glEnable(GL_TEXTURE_2D);

	for(int ttex = 0; ttex < LineTracerData::NUM_TEX; ttex++)
	{
		if(bool(mDataBlock->textureHandle[ttex]) || ttex == 0)
		{
			glBindTexture( GL_TEXTURE_2D, mDataBlock->textureHandle[ttex].getGLName() );

			cRing = mRingHead;

			// fakey "front" ring
			if(mDataBlock->perRenderRing && mActive && (!mDead && mDataBlock->dontRenderConeOnImpact))
			{
				nRing = createRing(0,1);
				renderSegment( nRing, cRing, ttex );
				sgTracerEngine->releaseRing(nRing);
			}

			// render the tracer
			nRing = cRing->next;
			if( nRing )
			{
				while(nRing != NULL)
				{
					renderSegment( nRing, cRing, ttex );
					cRing = cRing->next;
					nRing = nRing->next;
				}
			}
		}
	}
	glDisable(GL_TEXTURE_2D);

/*	glBegin( GL_LINES);
	{
		glColor4f( 0.0f,0.0f,1.0f,1.0f );
		glVertex3fv( mCurrentPosition);
		glVertex3fv( mCurrentPosition + mLastNormal *  10.0f);
		glVertex3fv( mCurrentPosition);
		glVertex3fv( mCurrentPosition + mCurrentNormal *  10.0f);
	}
	glEnd();

	glBegin( GL_LINES);
	{
		glColor4f( 0.0f,1.0f,0.0f,1.0f );
		glVertex3fv( mCurrentPosition);
		glVertex3fv( mTarget->getPosition());
	}
	glEnd();*/

   glDisable(GL_BLEND);
   glDepthMask(GL_TRUE);
   glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
}

void LineTracer::renderSegment(LineTracerRing *top,LineTracerRing *bottom, int ttex)
{
   glBegin( GL_QUAD_STRIP );
   {
		LineTracerRingPoint *ptT = top->pointsHead;
		LineTracerRingPoint *ptB = bottom->pointsHead;
		int i = 0;	
      while(ptT != NULL && ptB != NULL)
      {
         F32 t = F32(i) / F32(mDataBlock->numSegments);
         
			glTexCoord2f(	mDataBlock->horizontalTexWrap[ttex] * (horizontalTextureShift[ttex] + t),
								mDataBlock->verticalTexWrap[ttex] * (verticalTextureShift[ttex] + (top->elapsedTime / mDataBlock->trailLifetimeMS)) );
         glColor4f( top->color.red, top->color.green, top->color.blue, top->color.alpha * mFade );

			if(mDataBlock->renderWithTarget)
			{
				Point3F pt;
				mTarget->getRenderTransform().mulP(ptT->position,&pt);
	         glVertex3fv(pt);
			}
			else
	         glVertex3fv( ptT->position );
         
			glTexCoord2f(	mDataBlock->horizontalTexWrap[ttex] * (horizontalTextureShift[ttex] + t),
								mDataBlock->verticalTexWrap[ttex] * (verticalTextureShift[ttex] + (bottom->elapsedTime / mDataBlock->trailLifetimeMS)) );
         glColor4f( bottom->color.red, bottom->color.green, bottom->color.blue, bottom->color.alpha * mFade );

			if(mDataBlock->renderWithTarget)
			{
				Point3F pt;
				mTarget->getRenderTransform().mulP(ptB->position,&pt);
	         glVertex3fv(pt);
			}
			else
	         glVertex3fv( ptB->position );

			ptT = ptT->next;
			ptB = ptB->next;
			i++;
      }
		
		// finish the loop if its not a flat tracer
      if(mDataBlock->numSegments > 2)
		{
			ptT = top->pointsHead;
			ptB = bottom->pointsHead;

			glTexCoord2f(	mDataBlock->horizontalTexWrap[ttex] * (horizontalTextureShift[ttex] + 1),
								mDataBlock->verticalTexWrap[ttex] * (verticalTextureShift[ttex] + (top->elapsedTime / mDataBlock->trailLifetimeMS)) );
         glColor4f( top->color.red, top->color.green, top->color.blue, top->color.alpha * mFade );

			if(mDataBlock->renderWithTarget)
			{
				Point3F pt;
				mTarget->getRenderTransform().mulP(ptT->position,&pt);
	         glVertex3fv(pt);
			}
			else
	         glVertex3fv( ptT->position );
      
			glTexCoord2f(	mDataBlock->horizontalTexWrap[ttex] * (horizontalTextureShift[ttex] + 1),
								mDataBlock->verticalTexWrap[ttex] * (verticalTextureShift[ttex] + (bottom->elapsedTime / mDataBlock->trailLifetimeMS)) );
         glColor4f( bottom->color.red, bottom->color.green, bottom->color.blue, bottom->color.alpha * mFade );

			if(mDataBlock->renderWithTarget)
			{
				Point3F pt;
				mTarget->getRenderTransform().mulP(ptB->position,&pt);
	         glVertex3fv(pt);
			}
			else
	         glVertex3fv( ptB->position );
		}
   }
   glEnd();

/*	glBegin( GL_LINES);
	{
		glColor4f( 1.0f,0.0f,0.0f,0.6f );
		glVertex3fv( bottom->position + bottom->totalDrift- Point3F(0,0,1));
		glVertex3fv( bottom->position + bottom->totalDrift+ Point3F(0,0,1));
	}
	glEnd();
	glBegin( GL_LINES);
	{
		glColor4f( 1.0f,0.0f,0.0f,0.6f );
		glVertex3fv( bottom->position + bottom->totalDrift- Point3F(1,0,0));
		glVertex3fv( bottom->position + bottom->totalDrift+ Point3F(1,0,0));
	}
	glEnd();
	glBegin( GL_LINES);
	{
		glColor4f( 1.0f,0.0f,0.0f,0.6f );
		glVertex3fv( bottom->position + bottom->totalDrift- Point3F(0,1,0));
		glVertex3fv( bottom->position + bottom->totalDrift+ Point3F(0,1,0));
	}
	glEnd();*/
/*	glBegin( GL_LINES);
	{
		glColor4f( 1.0f,0.0f,0.0f,0.1f );
		glVertex3fv( bottom->position );
		glVertex3fv( bottom->position + bottom->totalDrift);// + bottom->centralVector * 10.0f );
	}
	glEnd();*/
}

//----------------------------------------------------------------------------
// Ring management
//----------------------------------------------------------------------------
void LineTracer::emitRings(F32 dt)
{

	F32 timeElapsedSinceLastCheck = mElapsedTime - mLastRingMS;
	if(timeElapsedSinceLastCheck >= mDataBlock->newRingMS)
	{
		F32 oldHeadET;
	   if(mRingHead!= NULL)
			oldHeadET = mRingHead->elapsedTime;
		else
			oldHeadET = 9999.9f;

		LineTracerRing * firstCreated = NULL;

		if(timeElapsedSinceLastCheck > mDataBlock->trailLifetimeMS)
			timeElapsedSinceLastCheck = mDataBlock->trailLifetimeMS;

		F32 timeElapsedSinceLastEmit = timeElapsedSinceLastCheck;
		while(timeElapsedSinceLastEmit >= mDataBlock->newRingMS)
		{
			LineTracerRing * ring = createRing(timeElapsedSinceLastEmit,timeElapsedSinceLastCheck);

			timeElapsedSinceLastEmit -= mDataBlock->newRingMS;

			mRingCount++;

			ring->next = mRingHead;
			mRingHead = ring;

			if(firstCreated == NULL)
				firstCreated = ring;
		}
		mLastRingMS = mElapsedTime - timeElapsedSinceLastEmit;
	}
}

LineTracerRing * LineTracer::createRing(F32 interpolationMS, F32 numMilliseconds)
{
	LineTracerRing * ring = sgTracerEngine->allocateRing();

	Point3F pointAxis;
	Point3F offset;

	Point3F start;
	Point3F end;

	if(mDataBlock->renderWithTarget)
	{
		start = mTarget->getRenderPosition() - getRenderPosition();
		end.set(0.0f,0.0f,0.0f);
	}
	else
	{
		start = getRenderPosition();
		end = mTarget->getRenderPosition();
	}

	Point3F center;
	center.interpolate(end, start, interpolationMS / numMilliseconds);

	Point3F central;
	central.interpolate(mCurrentNormal, mLastNormal, interpolationMS / numMilliseconds);

	if(useTargetNodes && (mDataBlock->numTargetNodes > 1 || assignedNodes > 1))
	{
		if(mDataBlock->renderWithTarget)
			shape->mNodeTransforms[targetNodes[0]].getColumn(1,&central);

		Point3F nodeCenter(0,0,0);
		MatrixF cpmat;
		if(mDataBlock->renderWithTarget)
			cpmat.identity();
		else
			cpmat = mTarget->getRenderTransform();

		cpmat.setColumn(3,center);

		U32 maxNodes = assignedNodes > -1 ? assignedNodes : mDataBlock->numTargetNodes;
		for( U32 i=0; i<mDataBlock->numSegments && i < maxNodes; i++ )
		{
         MatrixF mat;
			mat.mul(cpmat,shape->mNodeTransforms[targetNodes[i]]);
         mat.getColumn(3,&pointAxis);
			nodeCenter += pointAxis;

			LineTracerRingPoint * point = sgTracerEngine->allocatePoint();
			point->outwardsVector = pointAxis;

			point->next = ring->pointsHead;
			ring->pointsHead = point;
		}

		nodeCenter.set(nodeCenter.x / maxNodes,nodeCenter.y / maxNodes, nodeCenter.z / maxNodes);

		LineTracerRingPoint * pt = ring->pointsHead;
		while(pt != NULL)
		{
			pt->position = nodeCenter;
			pt->outwardsVector -= nodeCenter;
			pt = pt->next;
		}

		ring->centralVector = central;
		ring->position = nodeCenter;
	}
	else if(useTargetNodes && (mDataBlock->numTargetNodes == 1 || assignedNodes == 1))
	{
		Point3F nodeCenter;
      MatrixF mat;
		if(mDataBlock->renderWithTarget)
		{
			mat = shape->mNodeTransforms[targetNodes[0]];
		}
		else
		{
			mat = mTarget->getRenderTransform();
			mat.setColumn(3,center);
			mat.mul(mat,shape->mNodeTransforms[targetNodes[0]]);
		}

		mat.getColumn(3,&nodeCenter);
		if(mDataBlock->renderWithTarget)
			mat.getColumn(1,&central);

		Point3F axisx;
		Point3F nodeDir;
		mat.getColumn(1,&nodeDir);
		mat.getColumn(0,&axisx);

		F32 t = 0;
		AngAxisF phiRot;
		MatrixF temp;

		for( U32 i=0; i<mDataBlock->numSegments; i++ )
		{
			t = F32(i) / F32(mDataBlock->numSegments);

			phiRot.set( nodeDir, t * M_2PI + (M_PI/180 * mOverheadRot));

			pointAxis = axisx;

	      phiRot.setMatrix(&temp);

		   temp.mulP(pointAxis);

			LineTracerRingPoint * point = sgTracerEngine->allocatePoint();

			point->position = nodeCenter;
			point->outwardsVector = pointAxis;

			point->next = ring->pointsHead;
			ring->pointsHead = point;
			//ring->pointList.push_back(point);//ring->pointList.link(point);
		}
		ring->centralVector = central;
		ring->position = nodeCenter;
	}
	else
	{
		Point3F axisx;
		if (mFabs(central.z) < 0.999f)
			mCross(central, Point3F(0, 0, 1), &axisx);
		else
			mCross(central, Point3F(0, 1, 0), &axisx);
		axisx.normalize();

		F32 t = 0;
		AngAxisF phiRot;
		MatrixF temp;

		for( U32 i=0; i<mDataBlock->numSegments; i++ )
		{
			t = F32(i) / F32(mDataBlock->numSegments);

			phiRot.set( mCurrentNormal, t * M_2PI + (M_PI/180 * mOverheadRot));

			pointAxis = axisx;

	      phiRot.setMatrix(&temp);

		   temp.mulP(pointAxis);

			LineTracerRingPoint * point = sgTracerEngine->allocatePoint();

			point->position = center;
			point->outwardsVector = pointAxis;

			point->next = ring->pointsHead;
			ring->pointsHead = point;
		}
		ring->position = center;
		ring->centralVector = central;
   }
	ring->twistVector = ring->pointsHead->outwardsVector;
	ring->twistVelocity = mDataBlock->twistPushVelocity;

	ring->inheritedVelocity = (end-start) * mDataBlock->ringVelocityInheritance;

	// apply interpolation
	if(interpolationMS > 0)
		updateRing(  interpolationMS, ring);
	else
	{
		ring->radius = mDataBlock->sizes[0];
		ring->color = mDataBlock->colors[0];

		LineTracerRingPoint * pt = ring->pointsHead;
		if( mDataBlock->useCustomShape )
		{
			int i = 0;
			while(pt != NULL)
			{
				pt->position = ring->position + pt->outwardsVector * ring->radius * mDataBlock->shapeDim[i];
				pt = pt->next;
				i++;
			}
		}
		else
		{
			while(pt != NULL)
			{
				pt->position = ring->position + pt->outwardsVector * ring->radius;
				pt = pt->next;
			}
		}
	}

	return ring;
}

void LineTracer::updateRings( F32 dt )
{
	// we have to fake out a double link list style thingamajig here
	LineTracerRing *pRing = NULL;
	LineTracerRing **cRing = &(mRingHead);
   while((*cRing) != NULL)
	{
		if((*cRing)->elapsedTime > mDataBlock->trailLifetimeMS)
		{
			LineTracerRing * RTD = *cRing;
			*cRing = (*cRing)->next;
			
			if(pRing == NULL)
				mRingHead = *cRing;
			else
				pRing->next = *cRing;

			RTD->next = NULL;
			sgTracerEngine->releaseRing(RTD);
			mRingCount--;
		}
		else
		{
			updateRing( dt, (*cRing) );
			pRing = *cRing;
			cRing = &((*cRing)->next);
		}
	}
}

void LineTracer::updateRing( F32 dt , LineTracerRing *ring )
{
	// RING LIFETIME
	ring->elapsedTime += dt;

	// RING TEXTURE CO-ORDS
   F32 t = ring->elapsedTime / mDataBlock->trailLifetimeMS;
	if(t > 1.0f)
		t = 1.0f;

	// RING COLOR
   for( U32 i = 1; i < LineTracerData::NUM_COLOR_KEYS; i++ )
   {
      if( mDataBlock->times[i] >= t )
      {
         F32 firstPart =   t - mDataBlock->times[i-1];
         F32 total     =   (mDataBlock->times[i] - mDataBlock->times[i-1]);
         firstPart /= total;

         ring->color.interpolate( mDataBlock->colors[i-1],
                                  mDataBlock->colors[i],
                                  firstPart);
         break;
      }
   }

	// RING DRIFT
	if(mDataBlock->twistPushAcceleration + mDataBlock->twistPushVelocity != 0 )
	{
		ring->twistVelocity += mDataBlock->twistPushAcceleration * dt;
		ring->totalDrift += ring->twistVelocity * ring->twistVector * dt;
	}
	if(mDataBlock->ringVelocityInheritance != 0)
		ring->totalDrift += ring->inheritedVelocity * dt;

   ring->totalDrift += Point3F( 0.0, 0.0, -9.8 ) * mDataBlock->gravityMod * dt;
	ring->totalDrift -= TracerEngine::windVelocity * mDataBlock->windMod * dt;

	ring->totalDrift += -ring->centralVector * mDataBlock->backwardsVelocity * dt;

	// RING RADIUS CALCULATION
   for( U32 i = 1; i < LineTracerData::NUM_SIZE_KEYS; i++ )
   {
      if( mDataBlock->sizeTimes[i] >= t )
      { 
			// find how far into this key we are
         F32 firstPart =   t - mDataBlock->sizeTimes[i-1];
         F32 total     =   mDataBlock->sizeTimes[i] - mDataBlock->sizeTimes[i-1];
         firstPart /= total;
 
			if(mDataBlock->sizeCurveQuadrant[i] > 0)
			{
				if(mDataBlock->sizes[i] > mDataBlock->sizes[i - 1])
					ring->radius = mSin((firstPart + mDataBlock->sizeCurveQuadrant[i] - 1) * (M_PI / 2)) * (mDataBlock->sizes[i]-mDataBlock->sizes[i-1]) + mDataBlock->sizes[i-1];
				else
					ring->radius = mSin((firstPart + mDataBlock->sizeCurveQuadrant[i] - 1) * (M_PI / 2)) * (mDataBlock->sizes[i-1]-mDataBlock->sizes[i]) + mDataBlock->sizes[i];
			}
			else
				ring->radius = (mDataBlock->sizes[i-1] * (1.0 - firstPart)) + (mDataBlock->sizes[i] * firstPart);

			break;
		}
	}

	// UPDATE RING POINTS
	LineTracerRingPoint * pt = ring->pointsHead;
	if( mDataBlock->useCustomShape )
	{
		int i = 0;
		while(pt != NULL)
		{
			pt->position = ring->position + ring->totalDrift;
			pt->position += pt->outwardsVector * ring->radius * mDataBlock->shapeDim[i];
			pt = pt->next;
			i++;
		}
	}
	else
	{
		while(pt != NULL)
		{
			pt->position = ring->position + ring->totalDrift;
			pt->position += pt->outwardsVector * ring->radius;
			pt = pt->next;
		}
	}
}

void LineTracer::freeRings()
{
	LineTracerRing ** cRing = &mRingHead;
	LineTracerRing * tRing;
	while((*cRing) != NULL)
	{
		tRing = *cRing;
		*cRing = tRing->next;
		tRing->next = NULL;
		sgTracerEngine->releaseRing(tRing);
	}
	mRingHead = NULL;
	mRingCount = 0;
}

// ---------------------------------------------------------------------
// Memory management & other TracerEngine stuff
// ---------------------------------------------------------------------

namespace TracerEngine {

	Point3F windVelocity(0.f, 0.f, 0.f);

	void init()
	{
		AssertFatal(sgTracerEngine == NULL, "TracerEngine::init: engine already initialized");

		sgTracerEngine = new TEngine;
	}

	void destroy()
	{
		AssertFatal(sgTracerEngine != NULL, "TracerEngine::destroy: engine not initialized");

		delete sgTracerEngine;
		sgTracerEngine = NULL;
	}

}

//--------------------------------------------------------------------------
TEngine::TEngine()
{
	mFreePointList = NULL;
	mFreeRingList = NULL;
	numRings = 0;
}


TEngine::~TEngine()
{
	mFreePointList = NULL;
	mFreeRingList = NULL;
	for (U32 i = 0; i < mAllocatedPointBlocks.size(); i++)
	{
		delete [] mAllocatedPointBlocks[i];
		mAllocatedPointBlocks[i] = NULL;
	}
	for (U32 i = 0; i < mAllocatedRingBlocks.size(); i++)
	{
		delete [] mAllocatedRingBlocks[i];
		mAllocatedRingBlocks[i] = NULL;
	}
}

//--------------------------------------------------------------------------
LineTracerRingPoint* TEngine::allocatePoint()
{
	if (mFreePointList == NULL)
	{
		// Add a new block to the free list...
		mAllocatedPointBlocks.push_back(new LineTracerRingPoint[csmPointBlockSize]);
		LineTracerRingPoint* pArray = mAllocatedPointBlocks.last();
		for (U32 i = 0; i < csmPointBlockSize - 1; i++)
			pArray[i].nextInEngine = &pArray[i + 1];
		pArray[csmPointBlockSize - 1].nextInEngine = NULL;
		mFreePointList = &pArray[0];

//		Con::warnf(ConsoleLogEntry::General,"Tracer Engine: Made a new block! #=%d, #*s=%d n=%d",mAllocatedPointBlocks.size(),mAllocatedPointBlocks.size() * csmPointBlockSize,numPoints);
	}
	AssertFatal(mFreePointList != NULL, "TracerEngine::allocatePoint - Error, must have a free list here!");

	LineTracerRingPoint* newPoint = mFreePointList;
	mFreePointList = newPoint->nextInEngine;

//	if(mFreePointList == NULL)
//		Con::warnf(ConsoleLogEntry::General,"Tracer Engine: Hit end of free block, will need to make a new one on next alloc");

	dMemset(newPoint, 0, sizeof(LineTracerRingPoint));
	newPoint->nextInEngine = NULL;

	return newPoint;
}

void TEngine::releasePoint(LineTracerRingPoint* release)
{
	release->nextInEngine = mFreePointList;
	mFreePointList = release;
}

LineTracerRing* TEngine::allocateRing()
{
	if (mFreeRingList == NULL)
	{
		// Add a new block to the free list...
		mAllocatedRingBlocks.push_back(new LineTracerRing[csmRingBlockSize]);
		LineTracerRing* pArray = mAllocatedRingBlocks.last();
		for (U32 i = 0; i < csmRingBlockSize - 1; i++)
			pArray[i].nextInEngine = &pArray[i + 1];
		pArray[csmRingBlockSize - 1].nextInEngine = NULL;
		mFreeRingList = &pArray[0];

		Con::warnf(ConsoleLogEntry::General,"Rings: Made a new block! #=%d, #*s=%d n=%d",mAllocatedRingBlocks.size(),mAllocatedRingBlocks.size() * csmRingBlockSize,numRings);
	}
	AssertFatal(mFreeRingList != NULL, "TracerEngine::allocateRing - Error, must have a free list here!");

	LineTracerRing* newRing = mFreeRingList;
	mFreeRingList = newRing->nextInEngine;

	if(mFreeRingList == NULL)
		Con::warnf(ConsoleLogEntry::General,"Rings: Hit end of free block, will need to make a new one on next alloc");

	dMemset(newRing, 0, sizeof(LineTracerRing));
	newRing->nextInEngine = NULL;

	numRings++;

	return newRing;
}

void TEngine::releaseRing(LineTracerRing* release)
{
	numRings--;

	LineTracerRingPoint ** cPoint = &(release->pointsHead);
	LineTracerRingPoint * tPoint;
	while((*cPoint) != NULL)
	{
		tPoint = (*cPoint);
		*cPoint = tPoint->next;
		tPoint->next = NULL;
		sgTracerEngine->releasePoint(tPoint);
	}

	release->nextInEngine = mFreeRingList;
	mFreeRingList = release;
}