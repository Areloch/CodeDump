//-----------------------------------------------------------------------------
// GuiVehicleGaugeCtrl.h
// based on Matt "CaptFallout" Webster code
// changed by Frank Bignone, 2002
// changed by Brett Fattori, 2003
// changed by Erik Madison   2007
//-----------------------------------------------------------------------------

#include "console/console.h"
#include "console/consoleTypes.h"
#include "dgl/dgl.h"
#include "game/game.h"
#include "GuiVehicleGaugeCtrl.h"
#include "gui/core/guiTSControl.h"

#include "math/mQuat.h"

#include "game/gameConnection.h"


IMPLEMENT_CONOBJECT(GuiVehicleGaugeCtrl);

GuiVehicleGaugeCtrl::GuiVehicleGaugeCtrl(void)
{
	GuiBitmapCtrl::GuiBitmapCtrl();
	mBitmapSpin = StringTable->insert("");
	mBitmapBackground = StringTable->insert("");
	mBitmapForeground = StringTable->insert("");
	mBitmapVelocity = StringTable->insert("");
	mBitmapCompass = StringTable->insert("");
	mAngle = 0;
	mAngle2 = 0;
	mCompassAngle = 0;
	mColor.set(1,1,1,1);
	mSpinAng.set(0,360);
	mSpinOffset.set(0,0);
	mVelocityPos.set(0,0);
	mInvert = false;
	mSpinKeepAspect = false;
	mShowVelocity = false;
	mShowCompass = false;
	mShowPitch = false;
	mShowRoll = false;
	mInvertRoll = false;
    mValue = 0;
    mMaxValue = 100;
    mModifier = 1.0;
    mValueType = GuiGaugeTypeDefault;
}

static EnumTable::Enums ValueTypeEnums[] = 
{
    { GuiVehicleGaugeCtrl::GuiGaugeTypeDefault, "Default" },
    { GuiVehicleGaugeCtrl::GuiGaugeTypeManual, "Manual" },
    { GuiVehicleGaugeCtrl::GuiGaugeTypeSpeed, "Speed" },
    { GuiVehicleGaugeCtrl::GuiGaugeTypeEnergy, "Fuel" },
    { GuiVehicleGaugeCtrl::GuiGaugeTypeRPM, "RPM" },
    { GuiVehicleGaugeCtrl::GuiGaugeTypeAltitude, "Altitude" },
};

static EnumTable gTypeTable(6, &ValueTypeEnums[0]); 

void GuiVehicleGaugeCtrl::initPersistFields()
{
	Parent::initPersistFields();

	// Misc stuff
	addField( "color", TypeColorF, Offset( mColor, GuiVehicleGaugeCtrl ) );

	// Bitmaps
	addGroup("Bitmaps");
	addField( "backgroundBitmap", TypeFilename, Offset(mBitmapBackground, GuiVehicleGaugeCtrl));
	addField( "foregroundBitmap", TypeFilename, Offset(mBitmapForeground, GuiVehicleGaugeCtrl));
	addField( "spinnerBitmap", TypeFilename, Offset(mBitmapSpin, GuiVehicleGaugeCtrl));
	addField( "compassBitmap", TypeFilename, Offset(mBitmapCompass, GuiVehicleGaugeCtrl));
	addField( "velocityBitmap", TypeFilename, Offset(mBitmapVelocity, GuiVehicleGaugeCtrl));
	endGroup("Bitmaps");
	
	// Attitude controllers
	addGroup("Attitude");
	addField( "attitudeRoll", TypeF32, Offset(mAngle, GuiVehicleGaugeCtrl));
	addField( "compassAngle", TypeF32, Offset(mCompassAngle, GuiVehicleGaugeCtrl));
	addField( "spinAngle", TypePoint2F, Offset( mSpinAng, GuiVehicleGaugeCtrl ) );
	addField( "attitudePitch", TypePoint2F, Offset( mSpinOffset, GuiVehicleGaugeCtrl ) );	
	addField( "velocityPos", TypePoint2F, Offset( mVelocityPos, GuiVehicleGaugeCtrl ) );
	endGroup("Attitude");

	// Visibility of parts
	addGroup("Visibility");
	addField( "invertBitmap", TypeBool, Offset( mInvert, GuiVehicleGaugeCtrl ) );	
	addField( "spinKeepAspect", TypeBool, Offset( mSpinKeepAspect, GuiVehicleGaugeCtrl ) );
	addField( "showVelocity", TypeBool, Offset( mShowVelocity, GuiVehicleGaugeCtrl ) );
	addField( "showCompass", TypeBool, Offset( mShowCompass, GuiVehicleGaugeCtrl ) );
	addField( "showPitch", TypeBool, Offset( mShowPitch, GuiVehicleGaugeCtrl ) );
	addField( "showRoll", TypeBool, Offset( mShowRoll, GuiVehicleGaugeCtrl ) );
	addField( "invertRoll", TypeBool, Offset( mInvertRoll, GuiVehicleGaugeCtrl ) );
	endGroup("Visibility");

    addGroup("AnglesForDials");
    addField("maxvalue", TypeF32, Offset(mMaxValue, GuiVehicleGaugeCtrl));
    addField("modifier", TypeF32, Offset(mModifier, GuiVehicleGaugeCtrl));
    addField("spinAngle", TypePoint2F, Offset( mSpinAng, GuiVehicleGaugeCtrl ) );
    addField("spinOffset", TypePoint2F, Offset( mSpinOffset, GuiVehicleGaugeCtrl ) );
    addField("valuetype", TypeEnum, Offset(mValueType, GuiVehicleGaugeCtrl), 1, &gTypeTable);
    endGroup("AnglesForDials");
}

ConsoleMethod( GuiVehicleGaugeCtrl, setForegroundBitmap, void, 3, 3, "(name)")
{
    object->setForegroundBitmap(argv[2]);
}

ConsoleMethod( GuiVehicleGaugeCtrl, setBackgroundBitmap, void, 3, 3, "(name)")
{
    object->setBackgroundBitmap(argv[2]);
}

ConsoleMethod( GuiVehicleGaugeCtrl, setSpinnerBitmap, void, 3, 3, "(name)")
{
    object->setSpinnerBitmap(argv[2]);
}

ConsoleMethod( GuiVehicleGaugeCtrl, setCompassBitmap, void, 3, 3, "(name)")
{
    object->setCompassBitmap(argv[2]);
}

ConsoleMethod( GuiVehicleGaugeCtrl, setVelocityBitmap, void, 3, 3, "(name)")
{
    object->setVelocityBitmap(argv[2]);
}

ConsoleMethod( GuiVehicleGaugeCtrl, setRoll, void, 3, 3, "(value)")
{
    object->setAngle(dAtof(argv[2]));
}

ConsoleMethod( GuiVehicleGaugeCtrl, setCompassAngle, void, 3, 3, "(value)")
{
    object->setCompassAngle(dAtof(argv[2]));
}

ConsoleMethod( GuiVehicleGaugeCtrl, setPitch, void, 3, 3, "(value)")
{
    object->setOffset(dAtof(argv[2]));
}

ConsoleMethod( GuiVehicleGaugeCtrl, setValue, void, 3, 3, "(value)")
{
    object->setValue(dAtof(argv[2]));
}

ConsoleMethod( GuiVehicleGaugeCtrl, setMaxValue, void, 3, 3, "(value)")
{
    object->setMaxValue(dAtof(argv[2]));
}

void GuiVehicleGaugeCtrl::setForegroundBitmap(const char *name)
{
   mBitmapForeground = StringTable->insert(name);
   if (*mBitmapForeground) mMeterForeground = TextureHandle(mBitmapForeground, BitmapTexture, true);
   else mMeterForeground = NULL;
   setUpdate();
}

void GuiVehicleGaugeCtrl::setBackgroundBitmap(const char *name)
{
    mBitmapBackground = StringTable->insert(name);
    if (*mBitmapBackground) mMeterBackground = TextureHandle(mBitmapBackground, BitmapTexture, true);
    else mMeterBackground = NULL;
    setUpdate();
}

void GuiVehicleGaugeCtrl::setSpinnerBitmap(const char *name)
{
	mBitmapSpin = StringTable->insert(name);
	if( mBitmapSpin ) mMeterSpin = TextureHandle(mBitmapSpin, BitmapTexture, true);
	setUpdate();
}

void GuiVehicleGaugeCtrl::setVelocityBitmap(const char *name)
{
	mBitmapVelocity = StringTable->insert(name);
	if( mBitmapVelocity ) mMeterVelocity = TextureHandle(mBitmapVelocity, BitmapTexture, true);
	setUpdate();
}

void GuiVehicleGaugeCtrl::setCompassBitmap(const char *name)
{
	mBitmapCompass = StringTable->insert(name);
	if( mBitmapCompass ) mMeterCompass = TextureHandle(mBitmapCompass, BitmapTexture, true);
	setUpdate();
}

bool GuiVehicleGaugeCtrl::onWake()
{   
	if (! Parent::onWake())	return false;
	setActive(true);
	setForegroundBitmap(mBitmapForeground);
	setBackgroundBitmap(mBitmapBackground);
	setSpinnerBitmap( mBitmapSpin);
	setVelocityBitmap( mBitmapVelocity);
	setCompassBitmap( mBitmapCompass);
	return true;
}

void GuiVehicleGaugeCtrl::onSleep()
{
	mMeterSpin = NULL;
    mMeterBackground = NULL;
    mMeterForeground = NULL;
	mMeterVelocity = NULL;
	mMeterCompass = NULL;
	Parent::onSleep();
}

void GuiVehicleGaugeCtrl::onRender(Point2I offset, const RectI &updateRect) 
{ 
	// Must have a connection and player control object
   GameConnection* conn = GameConnection::getConnectionToServer();
   if (!conn)
      return;
   ShapeBase* player = conn->getControlObject();
   if (!player) 
       return;

   ShapeBase* control;
   if (player->isMounted())
       control = player->getObjectMount();
   else
       control = player;

   // Get current object transform matrix
   MatrixF objTx = control->getTransform();

   // Get rotations from transform matrix
   VectorF vec;
   objTx.getColumn(1,&vec);

   // Get X velocity for roll calculation
   Point3F xv;
   objTx.getColumn(0,&xv);

   // Calculate PRH (x = pitch, y = roll, z = heading)
   Point3F rot(-mAtan(vec.z, mSqrt(vec.x*vec.x + vec.y*vec.y)), mDot(xv,Point3F(0,0,1)), -mAtan(-vec.x,vec.y) );
   
   // Set up vars
   F32 pitch = mRadToDeg(rot.x);	 // Pitch
   F32 yaw = mRadToDeg(rot.z);		 // Heading
   F32 roll = mRadToDeg(rot.y);		 // Roll

   // Invert roll if so desired
   if (mInvertRoll)
      roll = -roll;

   // Zero out if not displaying pitch or roll
   if (!mShowPitch)
      pitch = 0;

   if (!mShowRoll)
      roll = 0;

    // Setups for dial style gauge
    if ( mValueType == GuiGaugeTypeEnergy )
        mValue = control->getEnergyLevel();
    if ( mValueType == GuiGaugeTypeAltitude )
        mValue = control->getAltitudeOffSeaLevel();    
    if ( mValueType == GuiGaugeTypeSpeed )
    {
        mValue = control->getVelocity().len();
        //mValue /= mModifier;  // miles (mph) to knots (1.15 = mph, 1.85 = kph (to knots))
        mValue /= 1.15;
    }
    if  ( ( mValueType == GuiGaugeTypeSpeed ) || ( mValueType == GuiGaugeTypeEnergy )  || ( mValueType == GuiGaugeTypeAltitude ))
    {
        mValue = mClampF (mValue, 0, mMaxValue);        
        //mAngle = mAngle * (mSpinAng.y - mSpinAng.x) / 100.0 + mSpinAng.x;
        if ( mInvert ) // needs to be a different invert. invertAngle or some such.        
            mAngle = mSpinAng.x + (mSpinAng.y - mSpinAng.x) * (mValue / mMaxValue);        
        else        
            mAngle = mSpinAng.y - (mSpinAng.y - mSpinAng.x) * (mValue / mMaxValue);

        if ( mValueType == GuiGaugeTypeAltitude )
        {
            if ( mInvert ) // needs to be a different invert. invertAngle or some such.        
                mAngle2 = mSpinAng.x + (mSpinAng.y - mSpinAng.x) * (mValue / (mMaxValue / 10));        
            else        
                mAngle2 = mSpinAng.y - (mSpinAng.y - mSpinAng.x) * (mValue / (mMaxValue / 10));
        }
    }

    else 
    {	
        mAngle = roll;
        mSpinOffset.y = pitch;
        mCompassAngle = -yaw;
    }

	// Center of widget
	Point2F half(mBounds.extent.x / 2  - 1,mBounds.extent.y / 2 - 1); 

	// Make center the UI object's coordinate center 
	half.x += offset.x; 
	half.y += offset.y; 

	// Take back the texture handles
	TextureObject* spin = (TextureObject *) mMeterSpin;	
	TextureObject* background = (TextureObject *) mMeterBackground;
	TextureObject* foreground = (TextureObject *) mMeterForeground;
	TextureObject* velo = (TextureObject *) mMeterVelocity;
	TextureObject* compass = (TextureObject *) mMeterCompass;

    // Inversion draws frame before spinner
    if (!mInvert) 
    {
	    // Draw frame
	    if(foreground) {
		    dglSetBitmapModulation(mColor);
		    Point2I texSize(foreground->bitmapWidth, foreground->bitmapHeight );
		    Point2I corner(half.x-foreground->bitmapWidth/2, half.y-foreground->bitmapHeight/2); 
		    RectI srcRegion(0,0,foreground->bitmapWidth,foreground->bitmapHeight); 
			RectI dstRect(offset, mBounds.extent);
			dglDrawBitmapStretchSR(foreground, dstRect, srcRegion, false);
	    }

	    // Draw Spin
	    if(spin) {
		    Point2I texSize(spin->bitmapWidth, spin->bitmapHeight );
		    Point2I corner(half.x-spin->bitmapWidth/2, half.y-spin->bitmapHeight/2); 
		    RectI srcRegion(0,0,spin->bitmapWidth,spin->bitmapHeight); 
		    if (!mSpinKeepAspect) {
			    RectI dstRect(corner, texSize);
			    dglDrawBitmapRotatedSR(spin, dstRect, srcRegion, false, mAngle, mSpinOffset);
		    } else {
			    RectI dstRect(offset, mBounds.extent);
			    dglDrawBitmapRotatedSR(spin, dstRect, srcRegion, false, mAngle, mSpinOffset);
		    }
            // Draw Spin2 (as needed)
            if ( mValueType == GuiGaugeTypeAltitude ) {
                Point2I texSize2(spin->bitmapWidth, spin->bitmapHeight );
                Point2I corner2(half.x-spin->bitmapWidth/2, half.y-spin->bitmapHeight/2); 
                RectI srcRegion2(0,0,spin->bitmapWidth,spin->bitmapHeight); 
                if (!mSpinKeepAspect) {
                    RectI dstRect2(corner2, texSize2);
                    dglDrawBitmapRotatedSR(spin, dstRect2, srcRegion2, false, mAngle2, mSpinOffset);
                } else {
                    RectI dstRect2(offset, mBounds.extent);
                    dglDrawBitmapRotatedSR(spin, dstRect2, srcRegion2, false, mAngle2, mSpinOffset);
                }
            }
        }
	    // Show velocity indicator
	    if (mShowVelocity && velo)
	    {   			
		    dglSetBitmapModulation(mColor);
		    RectI srcVelRegion(0,0,velo->bitmapWidth,velo->bitmapHeight); 

		    // Get velocity offset
		    Point2I velOffset; //, newExtent;
		    const VectorF& vel = control->getVelocity();
		    velOffset.set(offset.x-vel.x,offset.y+vel.y);
  	  
            RectI dstVelRect(velOffset, mBounds.extent);
		    dglDrawBitmapStretchSR(velo, dstVelRect, srcVelRegion, false);
	    }
    } 
    else 
    {
	    // Draw Spin
	    if(spin) {
		    Point2I texSize(spin->bitmapWidth, spin->bitmapHeight );
		    Point2I corner(half.x-spin->bitmapWidth/2, half.y-spin->bitmapHeight/2); 
		    RectI srcRegion(0,0,spin->bitmapWidth,spin->bitmapHeight); 
		    if (!mSpinKeepAspect) {
			    RectI dstRect(corner, texSize);
			    dglDrawBitmapRotatedSR(spin, dstRect, srcRegion, false, mAngle, mSpinOffset);
		    } else {
			    RectI dstRect(offset, mBounds.extent);
			    dglDrawBitmapRotatedSR(spin, dstRect, srcRegion, false, mAngle, mSpinOffset);
		    }
            // Draw Spin2 (as needed)
            if ( mValueType == GuiGaugeTypeAltitude ) {
                Point2I texSize2(spin->bitmapWidth, spin->bitmapHeight );
                Point2I corner2(half.x-spin->bitmapWidth/2, half.y-spin->bitmapHeight/2); 
                RectI srcRegion2(0,0,spin->bitmapWidth,spin->bitmapHeight); 
                if (!mSpinKeepAspect) {
                    RectI dstRect2(corner2, texSize2);
                    dglDrawBitmapRotatedSR(spin, dstRect2, srcRegion2, false, mAngle2, mSpinOffset);
                } else {
                    RectI dstRect2(offset, mBounds.extent);
                    dglDrawBitmapRotatedSR(spin, dstRect2, srcRegion2, false, mAngle2, mSpinOffset);
                }
            }
        }
	    // Show velocity indicator
	    if (mShowVelocity && velo)
	    {
		    dglSetBitmapModulation(mColor);
		    RectI srcVelRegion(0,0,velo->bitmapWidth,velo->bitmapHeight); 

		    // Get velocity offset
		    Point2I velOffset; //, newExtent;
		    const VectorF& vel = control->getVelocity();
		    velOffset.set(offset.x-vel.x,offset.y+vel.y);

		    RectI dstVelRect(velOffset, mBounds.extent);
		    dglDrawBitmapStretchSR(velo, dstVelRect, srcVelRegion, false);
	    }

	    // Draw frame
	    if(foreground) {
		    dglSetBitmapModulation(mColor);
		    Point2I texSize(foreground->bitmapWidth, foreground->bitmapHeight );
		    Point2I corner(half.x-foreground->bitmapWidth/2, half.y-foreground->bitmapHeight/2); 
		    RectI srcRegion(0,0,foreground->bitmapWidth,foreground->bitmapHeight); 
		    RectI dstRect(offset, mBounds.extent);
		    dglDrawBitmapStretchSR(foreground, dstRect, srcRegion, false);		    
	    }
    } // mInvert, frame before guts, or guts before frame

	
    // Show compass heading
    if (mShowCompass && compass)
    {
	    F32 compassAng = mCompassAngle;
        Point2F mCompassOffset;

	    mCompassOffset.set(0,0);
		
	    RectI srcCompRegion(0,0,compass->bitmapWidth,compass->bitmapHeight); 
	    RectI dstCompRect(offset, mBounds.extent);
	    dglDrawBitmapRotatedSR(compass, dstCompRect, srcCompRegion, false, compassAng, mCompassOffset);	    
    }
    // Draw background
    if(background) {
        dglSetBitmapModulation(mColor);
        Point2I texSize(background->bitmapWidth, background->bitmapHeight );
        Point2I corner(half.x-background->bitmapWidth/2, half.y-background->bitmapHeight/2); 
        RectI srcRegion(0,0,background->bitmapWidth,background->bitmapHeight); 
        RectI dstRect(offset, mBounds.extent);
        dglDrawBitmapStretchSR(background, dstRect, srcRegion, false);        
    }
   dglSetBitmapModulation(mColor);

   //// Uncomment to see raw X, Y, Z values on control

   //// Display X Y and Z values
   //char buf[256];

   //// Center the text
   //Point2I pos;

   //if ( mValueType == GuiGaugeTypeEnergy )
   //{
   //    dSprintf(buf,sizeof(buf), "mVal:%3.1f",mValue);
   //    pos.x = offset.x + 2;
   //    pos.y = offset.y + mBounds.extent.y - mProfile->mFont->getHeight();
   //    dglDrawText(mProfile->mFont, pos, buf);
   //}
   //dSprintf(buf,sizeof(buf), "X:%3.1f",pitch);
   //pos.x = offset.x + 2;
   //pos.y = offset.y + mBounds.extent.y - mProfile->mFont->getHeight();
   //dglDrawText(mProfile->mFont, pos, buf);
   //
   //dSprintf(buf,sizeof(buf), "Y:%3.1f",yaw);
   //pos.x += mProfile->mFont->getStrWidth(buf) + 8;
   //pos.y = offset.y + mBounds.extent.y - mProfile->mFont->getHeight();
   //dglDrawText(mProfile->mFont, pos, buf);

   //dSprintf(buf,sizeof(buf), "Z:%3.3f",roll);
   //pos.x += mProfile->mFont->getStrWidth(buf) + 8;
   //pos.y = offset.y + mBounds.extent.y - mProfile->mFont->getHeight();
   //dglDrawText(mProfile->mFont, pos, buf);

   
   dglClearBitmapModulation();

  renderChildControls(offset, updateRect); 
} 
