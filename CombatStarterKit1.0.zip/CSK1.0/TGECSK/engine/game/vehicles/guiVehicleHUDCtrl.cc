//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#include "console/console.h"
#include "console/consoleTypes.h"
#include "dgl/dgl.h"
#include "game/game.h"
#include "gui/core/guiTSControl.h"
#include "math/mQuat.h"
#include "game/gameConnection.h"
#include "GuiVehicleHUDCtrl.h"

IMPLEMENT_CONOBJECT(GuiVehicleHUDCtrl);

GuiVehicleHUDCtrl::GuiVehicleHUDCtrl(void)
{
    mBitmapName = StringTable->insert("");
    mRocketName = StringTable->insert("");
    mAmmoName   = StringTable->insert("");
    startPoint.set(0, 0);
    for (S32 i = 0; i < MAXROCKETS; i++) {
        rocketState[i] = -1;
        rocketOffset[i].set(0.0, 0.0);
    }
    mShowDamage = 1;
    mNoDamageFillColor.set(0, 1, 0, 0.8);
    mMinorDamageFillColor.set(0.5, 0.5, 0, 0.8);
    mMajorDamageFillColor.set(1, 0, 0, 0.5);
    mMinorDamageThreshold = 0.8f;
    mMajorDamageThreshold = 0.4f;
    mPulseRate = 0;
    mPulseThreshold = 0.3f;
    mValue = 0.2f;
    mAmmoValue = 0;
}

bool GuiVehicleHUDCtrl::setBitmapName( void *obj, const char *data )
{
    // Prior to this, you couldn't do bitmap.bitmap = "foo.jpg" and have it work.
    // With protected console types you can now call the setBitmap function and
    // make it load the image.
    static_cast<GuiVehicleHUDCtrl *>( obj )->setBitmap( data );

    // Return false because the setBitmap method will assign 'mBitmapName' to the
    // argument we are specifying in the call.
    return false;
}

bool GuiVehicleHUDCtrl::setRocketName( void *obj, const char *data )
{
    static_cast<GuiVehicleHUDCtrl *>( obj )->setRocket( data );

    return false;
}

bool GuiVehicleHUDCtrl::setAmmoName( void *obj, const char *data )
{
    static_cast<GuiVehicleHUDCtrl *>( obj )->setAmmo( data );

    return false;
}

void GuiVehicleHUDCtrl::initPersistFields()
{
    Parent::initPersistFields();
    addGroup("Bitmaps");		
    addProtectedField( "BitmapBack", TypeFilename, Offset( mBitmapName, GuiVehicleHUDCtrl ), &setBitmapName, &defaultProtectedGetFn, "" );
    addProtectedField( "BitmapRocket", TypeFilename, Offset( mRocketName, GuiVehicleHUDCtrl ), &setRocketName, &defaultProtectedGetFn, "" );
    addProtectedField( "BitmapAmmo", TypeFilename, Offset( mAmmoName, GuiVehicleHUDCtrl ), &setAmmoName, &defaultProtectedGetFn, "" );
    endGroup("Bitmaps");

    addGroup("Damage");
    addField("showDamage",   TypeBool,     Offset(mShowDamage,       GuiVehicleHUDCtrl));
    addField( "noDmgColor", TypeColorF, Offset( mNoDamageFillColor, GuiVehicleHUDCtrl ) );
    addField( "MinorDmgThreshold",  TypeF32, Offset( mMinorDamageThreshold, GuiVehicleHUDCtrl ) );
    addField( "MinorDmgColor", TypeColorF, Offset( mMinorDamageFillColor, GuiVehicleHUDCtrl ) );
    addField( "MajorDmgThreshold",  TypeF32, Offset( mMajorDamageThreshold, GuiVehicleHUDCtrl ) );
    addField( "MajorDmgColor", TypeColorF, Offset( mMajorDamageFillColor, GuiVehicleHUDCtrl ) );
    addField( "pulseRate",       TypeS32, Offset( mPulseRate, GuiVehicleHUDCtrl ) );
    addField( "pulseThreshold",  TypeF32, Offset( mPulseThreshold, GuiVehicleHUDCtrl ) );
    endGroup("Damage");

    addGroup("Rockets");
    // Why can't I do this? Isn't there some way possible?
    //for (S32 i = 0; i < MAXROCKETS; i++) {    
        addField("ArocketState",   TypeS32,     Offset(rocketState[0],       GuiVehicleHUDCtrl));
        addField("ArocketOffset",  TypePoint2F, Offset(rocketOffset[0],      GuiVehicleHUDCtrl));
        addField("BrocketState",   TypeS32,     Offset(rocketState[1],       GuiVehicleHUDCtrl));
        addField("BrocketOffset",  TypePoint2F, Offset(rocketOffset[1],      GuiVehicleHUDCtrl));
        addField("CrocketState",   TypeS32,     Offset(rocketState[2],       GuiVehicleHUDCtrl));
        addField("CrocketOffset",  TypePoint2F, Offset(rocketOffset[2],      GuiVehicleHUDCtrl));
        addField("DrocketState",   TypeS32,     Offset(rocketState[3],       GuiVehicleHUDCtrl));
        addField("DrocketOffset",  TypePoint2F, Offset(rocketOffset[3],      GuiVehicleHUDCtrl));
        addField("ErocketState",   TypeS32,     Offset(rocketState[4],       GuiVehicleHUDCtrl));
        addField("ErocketOffset",  TypePoint2F, Offset(rocketOffset[4],      GuiVehicleHUDCtrl));
        addField("FrocketState",   TypeS32,     Offset(rocketState[5],       GuiVehicleHUDCtrl));
        addField("FrocketOffset",  TypePoint2F, Offset(rocketOffset[5],      GuiVehicleHUDCtrl));
        addField("GrocketState",   TypeS32,     Offset(rocketState[6],       GuiVehicleHUDCtrl));
        addField("GrocketOffset",  TypePoint2F, Offset(rocketOffset[6],      GuiVehicleHUDCtrl));
        addField("HrocketState",   TypeS32,     Offset(rocketState[7],       GuiVehicleHUDCtrl));
        addField("HrocketOffset",  TypePoint2F, Offset(rocketOffset[7],      GuiVehicleHUDCtrl));
        addField("IrocketState",   TypeS32,     Offset(rocketState[8],       GuiVehicleHUDCtrl));
        addField("IrocketOffset",  TypePoint2F, Offset(rocketOffset[8],      GuiVehicleHUDCtrl));
        addField("JrocketState",   TypeS32,     Offset(rocketState[9],       GuiVehicleHUDCtrl));
        addField("JrocketOffset",  TypePoint2F, Offset(rocketOffset[9],      GuiVehicleHUDCtrl));
    endGroup("Rockets");
    //}
		
}

ConsoleMethod( GuiVehicleHUDCtrl, setValue, void, 4, 4, "(int xAxis, int yAxis)"
              "Set the offset of the bitmap.")
{
    object->setValue(dAtoi(argv[2]), dAtoi(argv[3]));
}

ConsoleMethod( GuiVehicleHUDCtrl, setRocketState, void, 3, 3, "(S32)"
              "-1 = none 1 = activate 0 = used up")
{
    object->setRocketState(dAtoi(argv[2]));
}

ConsoleMethod( GuiVehicleHUDCtrl, setBitmap, void, 3, 3, "(string filename)"
              "Set the bitmap displayed in the control. Note that it is limited in size, to 256x256.")
{
    object->setBitmap(argv[2]);
}

ConsoleMethod( GuiVehicleHUDCtrl, setRocket, void, 3, 3, "(string filename)"
              "Set the bitmap displayed in the control. Note that it is limited in size, to 256x256.")
{
    object->setRocket(argv[2]);
}

ConsoleMethod( GuiVehicleHUDCtrl, setAmmo, void, 3, 3, "(string filename)"
              "Set the bitmap displayed in the control. Note that it is limited in size, to 256x256.")
{
    object->setAmmo(argv[2]);
}

bool GuiVehicleHUDCtrl::onWake()
{
    if (! Parent::onWake())
        return false;
    setActive(true);
    setBitmap(mBitmapName);
    setRocket(mRocketName);
    setAmmo(mAmmoName);
    return true;
}

void GuiVehicleHUDCtrl::onSleep()
{
    mTextureHandle = NULL;
    mTextureRocket = NULL;
    mTextureAmmo   = NULL;
    Parent::onSleep();
}

//-------------------------------------
void GuiVehicleHUDCtrl::inspectPostApply()
{
    // if the extent is set to (0,0) in the gui editor and apply is hit, this control will
    // set it's extent to be exactly the size of the bitmap (if present)
    Parent::inspectPostApply();

    if ((mBounds.extent.x == 0) && (mBounds.extent.y == 0) && mTextureHandle)
    {
        TextureObject *texture = (TextureObject *) mTextureHandle;
        mBounds.extent.x = texture->bitmapWidth;
        mBounds.extent.y = texture->bitmapHeight;
    }
}

void GuiVehicleHUDCtrl::setBitmap(const char *name, bool resize)
{
    mBitmapName = StringTable->insert(name);
    if (*mBitmapName) {
        mTextureHandle = TextureHandle(mBitmapName, BitmapTexture, true);

        // Resize the control to fit the bitmap
        if (resize) {
            TextureObject* texture = (TextureObject *) mTextureHandle;
            mBounds.extent.x = texture->bitmapWidth;
            mBounds.extent.y = texture->bitmapHeight;
            Point2I extent = getParent()->getExtent();
            parentResized(extent,extent);
        }
    }
    else
        mTextureHandle = NULL;
    setUpdate();
}


void GuiVehicleHUDCtrl::setBitmap(const TextureHandle &handle, bool resize)
{
    mTextureHandle = handle;

    // Resize the control to fit the bitmap
    if (resize) {
        TextureObject* texture = (TextureObject *) mTextureHandle;
        mBounds.extent.x = texture->bitmapWidth;
        mBounds.extent.y = texture->bitmapHeight;
        Point2I extent = getParent()->getExtent();
        parentResized(extent,extent);
    }
}

void GuiVehicleHUDCtrl::setRocket(const char *name)
{
    mRocketName = StringTable->insert(name);
    if (*mRocketName)
        mTextureRocket = TextureHandle(mRocketName, BitmapTexture, true);
    else
        mTextureRocket = NULL;
    setUpdate();
}

void GuiVehicleHUDCtrl::setRocket(const TextureHandle &handle)
{
    mTextureRocket = handle;
}

void GuiVehicleHUDCtrl::setAmmo(const char *name)
{
    mAmmoName = StringTable->insert(name);
    if (*mAmmoName)
        mTextureAmmo = TextureHandle(mAmmoName, BitmapTexture, true);
    else
        mTextureAmmo = NULL;
    setUpdate();
}

void GuiVehicleHUDCtrl::setAmmo(const TextureHandle &handle)
{
    mTextureAmmo = handle;
}

const char* GuiVehicleHUDCtrl::getScriptValue()
{
    char * ret = Con::getReturnBuffer(64);
    dSprintf(ret, 64, "%g", mAmmoValue);
    return ret;
}

void GuiVehicleHUDCtrl::setScriptValue(const char *value)
{
    //set the value
    if (!value)
        mAmmoValue = 0.0f;
    else
        mAmmoValue = dAtof(value);

    //validate the value
    mAmmoValue = mClampF(mAmmoValue, 0.f, 10000.f);
    setUpdate();
}

void GuiVehicleHUDCtrl::onPreRender()
{
    const char * var = getVariable();
    if(var)
    {
        F32 value = mClampF(dAtof(var), 0.f, 10000.f);
        if(value != mAmmoValue)
        {
            mAmmoValue = value;
            setUpdate();
        }
    }
}

void GuiVehicleHUDCtrl::onRender(Point2I offset, const RectI &updateRect)
{        
    // Must have a connection and player control object
    GameConnection* conn = GameConnection::getConnectionToServer();
    if (!conn)
        return;
    ShapeBase* player = conn->getControlObject();
    if (!player) 
        return;

    ShapeBase* control;
    if (player->isMounted())
        control = player->getObjectMount();
    else
        control = player;

    TextureObject* rocket = (TextureObject *) mTextureRocket;
    TextureObject* ammo = (TextureObject *) mTextureAmmo;
    // Center of widget
    Point2F half(mBounds.extent.x / 2  - 1,mBounds.extent.y / 2 - 1); 

    // Make center the UI object's coordinate center 
    half.x += offset.x; 
    half.y += offset.y; 

    if (mShowDamage)
        mValue = 1 - control->getDamageValue();

    if (mTextureHandle)
    {
        dglClearBitmapModulation();
        if (mShowDamage)
        {
            ColorF DamageColor = mNoDamageFillColor;
              
            if (mValue <= mPulseThreshold && mPulseRate != 0)
            {
                F32 time = Platform::getVirtualMilliseconds();
                F32 alpha = mFmod(time,mPulseRate) / (mPulseRate / 2.0);
                mMajorDamageFillColor.alpha = (alpha > 1.0)? 2.0 - alpha: alpha;
                DamageColor = mMajorDamageFillColor;
            }
            else if (mValue <= mMajorDamageThreshold)              
                DamageColor = mMajorDamageFillColor;
            else if (mValue <= mMinorDamageThreshold)          
                DamageColor = mMinorDamageFillColor; 

            dglSetBitmapModulation(DamageColor);
        }
        RectI rect(offset, mBounds.extent);
        dglDrawBitmapStretch(mTextureHandle, rect);
    }
    if (rocket)
    {
        dglClearBitmapModulation();
        Point2I texSize(rocket->bitmapWidth, rocket->bitmapHeight );
        Point2I corner(half.x-rocket->bitmapWidth/2, half.y-rocket->bitmapHeight/2); 
        RectI srcRegion(0,0,rocket->bitmapWidth,rocket->bitmapHeight);
        RectI dstRect(corner, texSize);
        for (S32 i = 0; i < MAXROCKETS; i++)
            if (rocketState[i] > -1) 
            {
                dglSetBitmapModulation (rocketState[i] ? ColorF(0, 0, 0, 1) : ColorF(0, 0, 0, 0.3));
                dglDrawBitmapRotatedSR(rocket, dstRect, srcRegion, false, 0, rocketOffset[i]);        
            }
    }
    //if(ammo && mAmmoValue > 0.0f)
    //{
    //    //dglClearBitmapModulation();
    //    //RectI rect(offset, mBounds.extent);
    //    //dglDrawBitmapStretch(ammo, rect);
    //}

    // No background, outline the control in a thin line
    if (mProfile->mBorder || !mTextureHandle)
    {
        RectI rect(offset, mBounds.extent);
        dglDrawRect(rect, mProfile->mBorderColor);
    }

    dglClearBitmapModulation();    
    // Uncomment to see raw X, Y, Z values on control

    // Display X Y and Z values
    char buf[256];

    // Center the text
    Point2I pos;

    if ( mShowDamage )
    {
        dSprintf(buf,sizeof(buf), "Health:%1.3f",mValue);
        pos.x = offset.x + 5;
        pos.y = offset.y + 10/*mBounds.extent.y - mProfile->mFont->getHeight()*/;
        dglDrawText(mProfile->mFont, pos, buf);
    }
    if ( ammo )
    {
        dSprintf(buf,sizeof(buf), "ChainAmmo:%3.0f",mAmmoValue);
        pos.x = offset.x;
        pos.y = offset.y + mBounds.extent.y - mProfile->mFont->getHeight();
        dglDrawText(mProfile->mFont, pos, buf);
    }
    renderChildControls(offset, updateRect);
}

void GuiVehicleHUDCtrl::setValue(S32 x, S32 y)
{
    if (mTextureHandle)
    {
        TextureObject* texture = (TextureObject *) mTextureHandle;
        x+=texture->bitmapWidth/2;
        y+=texture->bitmapHeight/2;
    }
    while (x < 0)
        x += 256;
    startPoint.x = x % 256;

    while (y < 0)
        y += 256;
    startPoint.y = y % 256;
}

void GuiVehicleHUDCtrl::setRocketState(S32 state)
{
    //Con::errorf("setting state to %d", state);
    if (state == 1)  // Loading ammo, start from top
        for (S32 i = 0; i < MAXROCKETS; i++) 
        { 
            if (rocketState[i] == 0) { // used up slot, that means its valid
                rocketState[i] = 1;
                //Con::errorf("new state is %d[%d]", rocketState[i], i);
                return;  // gotta call this once per rocket. I could add another variable, but I don't yet see a reason.
            }
        }
    if (state == 0)  // Used a rocket, start from bottom
        for (S32 i = MAXROCKETS; i >= 0; i--) 
        { 
            if (rocketState[i] == 1) { // used up slot, that means its valid
                rocketState[i] = 0;
                //Con::errorf("new state is %d[%d]", rocketState[i], i);
                return;  // gotta call this once per rocket. I could add another variable, but I don't yet see a reason.
            }
        }
     return;  // only other option available is -1, which means this vehicle _can't_ hold a rocket in that slot. Max capacity, et al.
}