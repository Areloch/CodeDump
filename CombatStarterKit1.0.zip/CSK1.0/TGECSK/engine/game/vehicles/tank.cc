//-----------------------------------------------------------
// TankShape Object
//
// Copyright (c) 2004 BraveTree Productions
//-----------------------------------------------------------

#include "tank.h"

#include "platform/platform.h"
#include "dgl/dgl.h"
#include "game/game.h"
#include "math/mMath.h"
#include "math/mathUtils.h"
#include "console/simBase.h"
#include "console/console.h"
#include "console/consoleTypes.h"
#include "collision/clippedPolyList.h"
#include "collision/planeExtractor.h"
#include "collision/OptimizedPolyList.h"
#include "game/moveManager.h"
#include "sceneGraph/sceneState.h"
#include "sceneGraph/detailManager.h"
#include "core/bitStream.h"
#include "core/dnet.h"
#include "game/gameConnection.h"
#include "ts/tsShapeInstance.h"
#include "game/fx/particleEngine.h"
#include "audio/audio.h"
#include "game/missionArea.h"

#include "collision/boxConvex.h"
#include "collision/earlyOutPolyList.h"
#include "collision/extrudedPolyList.h"
#include "collision/planeExtractor.h"

static F32 sVerticalStepDot = 0.173;   // 80
static F32 sMinFaceDistance = 0.01;
static U32 sMoveRetryCount = 5;

extern bool gEditingMission;

//-----------------------------------------------------------
//-----------------------------------------------------------

namespace
{
   const F32 sCameraWarpDistance = 50.0f;
   const U32 sCameraWarpTime = 100;
   const F64 sCameraSmoothTime = 100.0f;
   const U32 sCameraCollisionMask = TerrainObjectType|InteriorObjectType;
   const U32 sSpecialCollisionMask = ItemObjectType;
   const U32 sTankCollisionMask = PlayerObjectType|StaticTSObjectType|ItemObjectType;
   const F32 sTankCollisionSlack = 0.1f;
   const F32 sZFudgeForCastRay = 10000;
   const F32 sGravity = -10.0f;
   const F32 sWheelDropSmoothTwist = 0.1f;
   const F32 sDebugTurretLen = 2.0f;
   const F32 sDebugTurretGirth = 0.5f;
   const F32 sDebugWheelThickness = 0.25f;
   Vector<SceneObject*> sStaticShapeCollisions;
   Vector<SceneObject*> sTankCollisions;
   OptimizedPolyList sPolyList;

   const U32 LOS_CHECK_TICKS = 15;
   const U32 COLLIDE_COUNT = 30;
}  // namespace {}

const U32 sConformToMask = TerrainObjectType | InteriorObjectType;

const U32 sClientCollisionMask = (InteriorObjectType |
                                  StaticShapeObjectType | VehicleObjectType  |
                                  PlayerObjectType      | StaticTSObjectType);

const U32 sServerCollisionMask = (sClientCollisionMask |
                                  TriggerObjectType);


F32 TankShape::DeltaHelper::smMinWarpTicks = 0.5f;

// track tank collisions for making sounds -- client side only
U32 TankShape::smCollisionMask;
Point3F TankShape::smStartVelocity;

namespace
{
   // movement step parameters for collision checking
   const U32 MOVE_STEP_SHIFT = 3;
   const U32 MOVE_STEP = 1<<MOVE_STEP_SHIFT;

   // constants for network protocol
   const U32 ROT_ANGLE_BITS = 16;
   const U32 ROT_Z_BITS = 14;
   const U32 ROT_W_BITS = 16;
   const U32 VEL_MAG_BITS = 16;
   const U32 VEL_ANGLE_BITS = 16;
   const U32 VEL_Z_BITS = 10;
   const U32 THOR_BITS = 8;
   const U32 TVER_BITS = 6;
   const U32 THOR_OWN_BITS = 14;
   const U32 TVER_OWN_BITS = 12;
   const F32 MIN_NET_VEL = 0.01f;
   const F32 MAX_VEL_RATIO = 2.0f;
   const U32 BOOST_VEL_BITS = 12;
   const U32 MAX_BOOST_VEL = 100.0f;
   const U32 BOOST_VEL_ANGLE_BITS = 20;
   const U32 BOOST_VEL_Z_BITS = 14;
   const F32 MAX_WHEEL_DROP_MAG = 100.0f;
   const U32 WHEEL_DROP_BITS = 16;
};


//-----------------------------------------------------------
// Function name:  tankCollisionCallback
// Summary:        Called when tank is moving and encounters
//                 another object's bounding box.
//-----------------------------------------------------------
void tankCollisionCallback(SceneObject* object,void *key)
{
   if (object->getType() & PlayerObjectType && key!=(void *)object)
      sTankCollisions.push_back(object);
   else if (object->getType() & StaticTSObjectType)
      sStaticShapeCollisions.push_back(object);
}

//-----------------------------------------------------------
//-----------------------------------------------------------
//                              TankShapeData
//-----------------------------------------------------------
//-----------------------------------------------------------

// This automagically hooks the class up to the console
// script interface.
IMPLEMENT_CO_DATABLOCK_V1(TankShapeData);
IMPLEMENT_CONSOLETYPE(TankCameraData)
IMPLEMENT_GETDATATYPE(TankCameraData)
IMPLEMENT_SETDATATYPE(TankCameraData)
IMPLEMENT_CO_DATABLOCK_V1(TankCameraData);
IMPLEMENT_CONSOLETYPE(TankFxData)
IMPLEMENT_GETDATATYPE(TankFxData)
IMPLEMENT_SETDATATYPE(TankFxData)
IMPLEMENT_CO_DATABLOCK_V1(TankFxData);
IMPLEMENT_CONSOLETYPE(TankMiscData)
IMPLEMENT_GETDATATYPE(TankMiscData)
IMPLEMENT_SETDATATYPE(TankMiscData)
IMPLEMENT_CO_DATABLOCK_V1(TankMiscData);
//-----------------------------------------------------------
// Function name:  TankShapeData::TankShapeData
// Summary:        Constructor.  Start out with some
//                 reasonable default values.
//-----------------------------------------------------------
TankShapeData::TankShapeData()
{
   camera = NULL;
   cameraId = 0;
   fx = NULL;
   fxId = 0;
   misc = NULL;
   miscId = 0;

   maxStepHeight = 1;
   friction = 0;
   elasticity = 0;

   turnRate = 30.0f;
   accelRate = 10.0f;
   deccelRate = 20.0f;
   coastDeccelRate = 10.0f;
   antiSlideRate = 30.0f;
   maxSpeed = 15.0f;

   height = 5.0f;
   width = 5.0f;
   length = 8.0f;

   turretVerCenter = 30.0f;
   turretHorRange =30.0f;
   turretVerRange = 30.0f;
   turretAutoLevel = 0.0f;

   groundTransform = 0.0f;

   primaryRecoil     = 10.0f;
   secondaryRecoil   = 7.0f;
   tertiaryRecoil    = 7.0f;

   suspensionRange = 0.1f;

   numInnerWheelsPerSide = 2;

   springRangeX = 0.06f;
   springRangeY = 0.06f;
   springRangeZ = 0.0f;
   springVelScale = 1.0f;
   springLooseness = 0.999f;

   genericShadowLevel = Vehicle_GenericShadowLevel;
   noShadowLevel = Vehicle_NoShadowLevel;
}

//-----------------------------------------------------------
// Function name:  TankShapeData::initPersistFields
// Summary:        Declare this static function in a class
//                 to register dynamic fields.  Must call
//                 parent method.
//-----------------------------------------------------------
void TankShapeData::initPersistFields()
{
   Parent::initPersistFields();

   addField("shapeFile", TypeFilename, Offset(shapeName,TankShapeData));

   addField("camera", TypeTankCameraDataPtr, Offset(camera,TankShapeData));
   addField("fx", TypeTankFxDataPtr, Offset(fx,TankShapeData));
   addField("misc", TypeTankMiscDataPtr, Offset(misc,TankShapeData));

   addField("maxStepHeight", TypeF32, Offset(maxStepHeight, TankShapeData));
   addField("friction",    TypeF32,    Offset(friction,           TankShapeData));
   addField("elasticity",  TypeF32,    Offset(elasticity,         TankShapeData));

   addField("turnRate", TypeF32, Offset(turnRate,TankShapeData));
   addField("accelRate", TypeF32, Offset(accelRate,TankShapeData));
   addField("deccelRate", TypeF32, Offset(deccelRate,TankShapeData));
   addField("coastDeccelRate", TypeF32, Offset(coastDeccelRate,TankShapeData));
   addField("antiSlideRate", TypeF32, Offset(antiSlideRate,TankShapeData));
   addField("maxSpeed", TypeF32, Offset(maxSpeed,TankShapeData));

   addField("turretVerCenter", TypeF32, Offset(turretVerCenter,TankShapeData));
   addField("turretHorRange", TypeF32, Offset(turretHorRange,TankShapeData));
   addField("turretVerRange", TypeF32, Offset(turretVerRange,TankShapeData));
   addField("turretAutoLevel", TypeF32, Offset(turretAutoLevel,TankShapeData));

   addField("groundTransform", TypeF32, Offset(groundTransform,TankShapeData));

   addField("primaryRecoil", TypeF32, Offset(primaryRecoil,TankShapeData));
   addField("secondaryRecoil", TypeF32, Offset(secondaryRecoil,TankShapeData));
   addField("tertiaryRecoil", TypeF32, Offset(tertiaryRecoil,TankShapeData));

   addField("suspensionRange", TypeF32, Offset(suspensionRange,TankShapeData));

   addField("numInnerWheelsPerSide", TypeS32, Offset(numInnerWheelsPerSide,TankShapeData));

   addField("springRangeX", TypeF32, Offset(springRangeX,TankShapeData));
   addField("springRangeY", TypeF32, Offset(springRangeY,TankShapeData));
   addField("springRangeZ", TypeF32, Offset(springRangeZ,TankShapeData));
   addField("springVelScale", TypeF32, Offset(springVelScale,TankShapeData));
   addField("springLooseness", TypeF32, Offset(springLooseness,TankShapeData));
}

//-----------------------------------------------------------
// Function name:  TankShapeData::preload
// Summary:        Implement this function to receive a
//                 callback before mission starts in order to
//                 load any additional data associated with this
//                 object.  Parameter 'server' is true if
//                 callback is happening on the server.
//-----------------------------------------------------------
bool TankShapeData::preload(bool server, char errorBuffer[256])
{

   // NOTE: dependency here and tankShape.h where MaxInnerWheelsPerSide is defined...
   static char *leftSideNames[MaxInnerWheelsPerSide] = 
   {
      "inner_L_A",
      "inner_L_B",
      "inner_L_C",
      "inner_L_D",
      "inner_L_E",
      "inner_L_F",
      "inner_L_G",
      "inner_L_H",
      "inner_L_I",
   };
   static char *rightSideNames[MaxInnerWheelsPerSide] = 
   {
      "inner_R_A",
      "inner_R_B",
      "inner_R_C",
      "inner_R_D",
      "inner_R_E",
      "inner_R_F",
      "inner_R_G",
      "inner_R_H",
      "inner_R_I",
   };

   static char *leftSideRotNames[MaxInnerWheelsPerSide] = 
   {
      "inner_L_A_rot",
      "inner_L_B_rot",
      "inner_L_C_rot",
      "inner_L_D_rot",
      "inner_L_E_rot",
      "inner_L_F_rot",
      "inner_L_G_rot",
      "inner_L_H_rot",
      "inner_L_I_rot",
   };
   static char *rightSideRotNames[MaxInnerWheelsPerSide] = 
   {
      "inner_R_A_rot",
      "inner_R_B_rot",
      "inner_R_C_rot",
      "inner_R_D_rot",
      "inner_R_E_rot",
      "inner_R_F_rot",
      "inner_R_G_rot",
      "inner_R_H_rot",
      "inner_R_I_rot",
   };


   if (!Parent::preload(server,errorBuffer))
      return false;

   if (server && !(fx && misc && camera))
   {
      dSprintf(errorBuffer, 256, "TankShapeData: Incomplete data");
      return false;
   }
   if (server)
      cameraId = camera->getId();
   else
      Sim::findObject(cameraId,camera);
   if (server)
      fxId = fx->getId();
   else
      Sim::findObject(fxId,fx);
   if (server)
      miscId = misc->getId();
   else
      Sim::findObject(miscId,misc);

   if (!fx || !camera || !misc)
   {
      dSprintf(errorBuffer, 256, "TankShapeData: Incomplete data");
      return false;
   }

   // load shape resource...
   if (shapeName && shapeName[0])
   {
      // Resolve shapename
      shapeResource = ResourceManager->load(shapeName,false);
      if (!bool(shapeResource))
      {
         dSprintf(errorBuffer, 256, "TankShapeData: Couldn't load shape \"%s\"",shapeName);
         return false;
      }
      if(!server && !shapeResource->preloadMaterialList() && NetConnection::filesWereDownloaded())
         return false;
   }

   S32 i, j;

   // get size data from shape
   objectBox = shapeResource->bounds;
   width  = objectBox.max.x - objectBox.min.x;
   length  = objectBox.max.y - objectBox.min.y;
   height = objectBox.max.z - objectBox.min.z;
   collRadius = 0.5f * mSqrt(width*width + length*length + height*height);
   collRadius += sTankCollisionSlack;
   tankCollRadius = 0.5f * mSqrt(width*width + length*length);

   // get nodes from shape
   turretNode     = shapeResource->findNode("codeTurret");
   weaponNode     = shapeResource->findNode("codeWeapon");
   muzzleNode     = shapeResource->findNode("mount0");
   suspensionNode = shapeResource->findNode("codeSuspension");
   seatNode       = shapeResource->findNode("codeSeat");

   lTreadSeq = shapeResource->findSequence("ltread");
   rTreadSeq = shapeResource->findSequence("rtread");
   flipNode = shapeResource->findNode("codeFlip");
   flipCenterNode = shapeResource->findNode("tankall");
   AssertFatal(turretNode>=0,"TankShapeData::preload: missing node codeTurret");
   AssertFatal(weaponNode>=0,"TankShapeData::preload: missing node codeWeapon");
   AssertFatal(suspensionNode>=0,"TankShapeData::preload: missing node codeSuspension");
   AssertWarn(lTreadSeq>=0,"TankShapeData::preload: missing sequence ltread");
   AssertWarn(rTreadSeq>=0,"TankShapeData::preload: missing sequence rtread");

   // get wheel nodes from shape

   // old way...
   bool oldWay = false;
   if (numInnerWheelsPerSide == 2 && shapeResource->findNode("inner_RF") >= 0)
      oldWay = true;

   // inner
   if (oldWay)
   {
      wheelNode[0]  = shapeResource->findNode("inner_RF");
      wheelNode[1]  = shapeResource->findNode("inner_RR");
      wheelNode[2]  = shapeResource->findNode("inner_LR");
      wheelNode[3]  = shapeResource->findNode("inner_LF");
   }
   else
   {
      for (i=0; i<numInnerWheelsPerSide; i++)
         wheelNode[i] = shapeResource->findNode(rightSideNames[i]);
      for (i=0; i<numInnerWheelsPerSide; i++)
         wheelNode[numInnerWheelsPerSide+i] = shapeResource->findNode(leftSideNames[i]);
   }

   // outer
   wheelNode[numInnerWheels()+0]  = shapeResource->findNode("outer_RF");
   wheelNode[numInnerWheels()+1]  = shapeResource->findNode("outer_RR");
   wheelNode[numInnerWheels()+2]  = shapeResource->findNode("outer_LR");
   wheelNode[numInnerWheels()+3]  = shapeResource->findNode("outer_LF");

   // inner
   if (oldWay)
   {
      wheelRotNode[0]  = shapeResource->findNode("inner_RF_rot");
      wheelRotNode[1]  = shapeResource->findNode("inner_RR_rot");
      wheelRotNode[2]  = shapeResource->findNode("inner_LR_rot");
      wheelRotNode[3]  = shapeResource->findNode("inner_LF_rot");
   }
   else
   {
      for (i=0; i<numInnerWheelsPerSide; i++)
         wheelRotNode[i] = shapeResource->findNode(rightSideRotNames[i]);
      for (i=0; i<numInnerWheelsPerSide; i++)
         wheelRotNode[numInnerWheelsPerSide+i] = shapeResource->findNode(leftSideRotNames[i]);
   }

   // outer
   wheelRotNode[numInnerWheels()+0]  = shapeResource->findNode("outer_RF_rot");
   wheelRotNode[numInnerWheels()+1]  = shapeResource->findNode("outer_RR_rot");
   wheelRotNode[numInnerWheels()+2]  = shapeResource->findNode("outer_LR_rot");
   wheelRotNode[numInnerWheels()+3]  = shapeResource->findNode("outer_LF_rot");

   // inner
   if (oldWay)
   {
      AssertFatal(wheelNode[0]>=0,"TankShapeData::preload: missing node inner_RF");
      AssertFatal(wheelNode[1]>=0,"TankShapeData::preload: missing node inner_RR");
      AssertFatal(wheelNode[2]>=0,"TankShapeData::preload: missing node inner_LR");
      AssertFatal(wheelNode[3]>=0,"TankShapeData::preload: missing node inner_LF");
   }
   else
   {
      for (i=0; i<numInnerWheelsPerSide; i++)
         AssertFatal(wheelNode[i]>=0,"TankShapeData::preload: missing right side inner wheel node");
      for (i=0; i<numInnerWheelsPerSide; i++)
         AssertFatal(wheelNode[numInnerWheelsPerSide+i]>=0,"TankShapeData::preload: missing left side inner wheel node");
   }

   // outer
   AssertFatal(wheelNode[numInnerWheels()+0]>=0,"TankShapeData::preload: missing node outer_RF");
   AssertFatal(wheelNode[numInnerWheels()+1]>=0,"TankShapeData::preload: missing node outer_RR");
   AssertFatal(wheelNode[numInnerWheels()+2]>=0,"TankShapeData::preload: missing node outer_LR");
   AssertFatal(wheelNode[numInnerWheels()+3]>=0,"TankShapeData::preload: missing node outer_LF");

   // inner
   if (oldWay)
   {
      AssertFatal(wheelRotNode[0]>=0,"TankShapeData::preload: missing node inner_RF_rot");
      AssertFatal(wheelRotNode[1]>=0,"TankShapeData::preload: missing node inner_RR_rot");
      AssertFatal(wheelRotNode[2]>=0,"TankShapeData::preload: missing node inner_LR_rot");
      AssertFatal(wheelRotNode[3]>=0,"TankShapeData::preload: missing node inner_LF_rot");
   }
   else
   {
      for (i=0; i<numInnerWheelsPerSide; i++)
         AssertFatal(wheelRotNode[i]>=0,"TankShapeData::preload: missing right side inner wheel rotation node");
      for (i=0; i<numInnerWheelsPerSide; i++)
         AssertFatal(wheelRotNode[numInnerWheelsPerSide+i]>=0,"TankShapeData::preload: missing left side inner wheel rotation node");
   }

   // outer
   AssertFatal(wheelRotNode[numInnerWheels()+0]>=0,"TankShapeData::preload: missing node outer_RF_rot");
   AssertFatal(wheelRotNode[numInnerWheels()+1]>=0,"TankShapeData::preload: missing node outer_RR_rot");
   AssertFatal(wheelRotNode[numInnerWheels()+2]>=0,"TankShapeData::preload: missing node outer_LR_rot");
   AssertFatal(wheelRotNode[numInnerWheels()+3]>=0,"TankShapeData::preload: missing node outer_LF_rot");

   // collisions
   numCollDetails = 0;
   for (i=0; i<MaxCollisionShapes; i++)
   {
      char buff[128];
      dSprintf(buff,sizeof(buff),"Collision-%i",i+1);
      collDetails[i] = shapeResource->findDetail(buff);
      if (collDetails[i]>=0)
         ++numCollDetails;
      else
         break;
   }

   // tread sequence length...
   if (groundTransform > 0.0f)
   {
      lTreadSeqScale = 1.0f / groundTransform;
   }
   else if (lTreadSeq>=0 && shapeResource->sequences[lTreadSeq].numGroundFrames)
   {
      const TSShape::Sequence & lseq = shapeResource->sequences[lTreadSeq];

      lTreadSeqScale = 1.0f/shapeResource->groundTranslations[lseq.firstGroundFrame+lseq.numGroundFrames-1].y;
   }
   else
   {
      AssertWarn(0,"TankShapeData::preload: no ground transform on left tread");
      lTreadSeqScale = 1.0f;
   }

   if (groundTransform > 0.0f)
   {
      rTreadSeqScale = 1.0f / groundTransform;
   }
   else if (rTreadSeq>=0 && shapeResource->sequences[rTreadSeq].numGroundFrames)
   {
      const TSShape::Sequence & rseq = shapeResource->sequences[rTreadSeq];

      rTreadSeqScale = 1.0f/shapeResource->groundTranslations[rseq.firstGroundFrame+rseq.numGroundFrames-1].y;
   }
   else
   {
      AssertWarn(0,"TankShapeData::preload: no ground transform on right tread");
      rTreadSeqScale = 1.0f;
   }

   // set wheel positions...
   wheelRotMod = 0.5f; // 1/2 because we're summing left and right
   wheelRotMod *= 1.0f/lTreadSeqScale;
   wheelRotMod *= 1.0f/rTreadSeqScale;
   TSShapeInstance * shapeInstance = new TSShapeInstance(shapeResource,false);

   // HACK: Milkshape work around
   // The way Milkshape exports there will be 2 nodes with the same meshName
   // One will have an object (meshes) attached to it and one won't
   // We need to swap which node the object is attached to in order for the
   // animations to be applied correctly to the meshes
   //for (i = 0; i < shapeResource->nodes.size(); i++)
   //{
   //   TSNode* node = &shapeResource->nodes[i];
   //   const char* name = shapeResource->getName(node->nameIndex);

   //   // If this node has a mesh object attached and it doesn't have a parent
   //   // then see if there is another node with the same name
   //   if (node->firstObject > -1 && node->parentIndex == -1)
   //   {
   //      for (j = 0; j < shapeResource->nodes.size(); j++)
   //      {
   //         if (j == i)
   //            continue;

   //         TSNode* testNode = &shapeResource->nodes[j];
   //         const char* testName = shapeResource->getName(testNode->nameIndex);

   //         // If the names match and there isn't a mesh attached to the second one
   //         // then swap the parent of the object
   //         if (dStricmp(name, testName) == 0 && testNode->firstObject == -1)
   //         {
   //            TSObject* meshObject = &shapeResource->objects[node->firstObject];
   //            meshObject->nodeIndex = j;

   //            testNode->firstObject = node->firstObject;
   //            node->firstObject = -1;
   //            break;
   //         }
   //      }
   //   }
   //}

   for (i=0; i<totalWheels(); i++)
   {
      shapeInstance->mNodeTransforms[wheelNode[i]].getColumn(3,&wheelPos[i]);
     // compute wheel radius using mesh...search children of wheel node...
     const TSNode * node = &shapeResource->nodes[wheelNode[i]];

     S32 objIdx=-1;
     while (node && objIdx<0)
     {
        objIdx = node->firstObject;
        S32 nodeIdx = node->firstChild;
        node = nodeIdx<0 ? NULL : &shapeResource->nodes[nodeIdx];
     }

     AssertFatal(objIdx>=0,"TankShapeData::preload: missing wheel mesh");
     AssertFatal(shapeInstance->mMeshObjects[objIdx].meshList,"TankShapeData::preload: missing wheel mesh");
     TSMesh * mesh = shapeInstance->mMeshObjects[objIdx].meshList[0];
     Box3F wb = mesh->getBounds();
     wheelRadius[i] = 0.5f*(wb.max.z-wb.min.z);
   }
   F32 deltaRad = 0.0f;
   for (i=0; i<numInnerWheels(); i++)
   {
      // re-compute inner radius using position in object box
      // accounts for tread thickness...we'll adjust outer radius too
      F32 oldRad = wheelRadius[i];
      wheelRadius[i] = wheelPos[i].z - objectBox.min.z;
      deltaRad += (1.0f/F32(numInnerWheels())) * (wheelRadius[i]-oldRad);
      wheelRange[i] = wheelRadius[i] * suspensionRange;
      wheelRotMod *= M_2PI * wheelRadius[i];
   }
   for (i=numInnerWheels();i<totalWheels();i++)
   {
      // adjust outer radius accounting for tread thickness
      // set range and rot mod too, and adjust wheel pos so
      // "centered" is on ground
      wheelRadius[i] += deltaRad;
      wheelRotMod *= M_2PI * wheelRadius[i];
      wheelRange[i] = wheelPos[i].z-wheelRadius[i]-objectBox.min.z;
      wheelPos[i].z = objectBox.min.z + wheelRadius[i];
   }
   delete shapeInstance;
   shapeInstance = NULL;

   return true;
}

//-----------------------------------------------------------
// Function name:  TankShapeData::packData
// Summary:        Pack data into bitstream for transmission
//                 to client.
//                 Note: do not confuse packData on data
//                 blocks with writePacket on GameBase or
//                 packUpdate on NetObjects.  Data blocks are
//                 derived directly from SimObject and add
//                 the packData method themselves.
//                 GameBase adds a packData method, but it
//                 has a different purpose.  The packUpdate
//                 method is added by NetObject (and inherited
//                 by GameBase via SceneObject) and is used for
//                 updating and instantiating NetObject's
//                 across the network.
//-----------------------------------------------------------
void TankShapeData::packData(BitStream* stream)
{
   Parent::packData(stream);

   stream->writeString(shapeName);

   if (stream->writeFlag(camera))
      stream->writeRangedU32(camera->getId(),DataBlockObjectIdFirst,DataBlockObjectIdLast);
   if (stream->writeFlag(fx))
      stream->writeRangedU32(fx->getId(),DataBlockObjectIdFirst,DataBlockObjectIdLast);
   if (stream->writeFlag(misc))
      stream->writeRangedU32(misc->getId(),DataBlockObjectIdFirst,DataBlockObjectIdLast);

   stream->write(maxStepHeight);

   stream->writeFloat(friction, 10);
   stream->writeFloat(elasticity, 10);

   stream->write(turnRate);
   stream->write(accelRate);
   stream->write(deccelRate);
   stream->write(coastDeccelRate);
   stream->write(antiSlideRate);
   stream->write(maxSpeed);

   stream->write(turretVerCenter);
   stream->write(turretHorRange);
   stream->write(turretVerRange);
   stream->write(turretAutoLevel);

   stream->write(groundTransform);

   stream->write(primaryRecoil);
   stream->write(secondaryRecoil);
   stream->write(tertiaryRecoil);

   stream->write(suspensionRange);

   stream->write(numInnerWheelsPerSide);

   stream->write(springRangeX);
   stream->write(springRangeY);
   stream->write(springRangeZ);
   stream->write(springVelScale);
   stream->write(springLooseness);
}

//-----------------------------------------------------------
// Function name:  TankShapeData::unpackData
// Summary:        Unpack data from bitstream.  Inverse of
//                 'packData'.  Objects created over the net
//                 are created by first instantiating them
//                 (calling the constructor), then unpacking
//                 the data stream that was packed by the
//                 server, and then calling onAdd (so first
//                 call to unpack will be on unadded objects).
//                 Note: do not confuse unpackData on data
//                 blocks with readPacket on GameBase or
//                 unpackUpdate on NetObjects.  Data blocks are
//                 derived directly from SimObject and add
//                 the unpackData method themselves.
//                 GameBase adds a unpackData method, but it
//                 has a different purpose.  The unpackUpdate
//                 method is added by NetObject (and inherited
//                 by GameBase via SceneObject) and is used for
//                 updating and instantiating NetObject's
//                 across the network.
//-----------------------------------------------------------
void TankShapeData::unpackData(BitStream* stream)
{
   Parent::unpackData(stream);

   shapeName = stream->readSTString();

   if (stream->readFlag())
      cameraId = stream->readRangedU32(DataBlockObjectIdFirst,DataBlockObjectIdLast);
   if (stream->readFlag())
      fxId = stream->readRangedU32(DataBlockObjectIdFirst,DataBlockObjectIdLast);
   if (stream->readFlag())
      miscId = stream->readRangedU32(DataBlockObjectIdFirst,DataBlockObjectIdLast);

   stream->read(&maxStepHeight);

   friction = stream->readFloat(10);
   elasticity = stream->readFloat(10);

   stream->read(&turnRate);
   stream->read(&accelRate);
   stream->read(&deccelRate);
   stream->read(&coastDeccelRate);
   stream->read(&antiSlideRate);
   stream->read(&maxSpeed);

   stream->read(&turretVerCenter);
   stream->read(&turretHorRange);
   stream->read(&turretVerRange);
   stream->read(&turretAutoLevel);

   stream->read(&groundTransform);

   stream->read(&primaryRecoil);
   stream->read(&secondaryRecoil);
   stream->read(&tertiaryRecoil);

   stream->read(&suspensionRange);

   stream->read(&numInnerWheelsPerSide);

   stream->read(&springRangeX);
   stream->read(&springRangeY);
   stream->read(&springRangeZ);
   stream->read(&springVelScale);
   stream->read(&springLooseness);
}

//-----------------------------------------------------------
//-----------------------------------------------------------
//                              TankCameraData
//-----------------------------------------------------------
//-----------------------------------------------------------

// This automagically hooks the class up to the console
// script interface.


//-----------------------------------------------------------
// Function name:  TankCameraData::TankCameraData
// Summary:
//-----------------------------------------------------------
TankCameraData::TankCameraData()
{
   camFocusDist = 30.0f;
   camFocusUpDist = 0.0f;
   camBackupDist = 30.0f;
   camFloatHeight = 10.0f;
   camSmooth = 0.2f;
   camSmoothTurn = 0.2f;
   camSmoothUp = 0.2f;
   camFov = 90.0f;
   camNear = 1.0f;
}

//-----------------------------------------------------------
// Function name:  TankCameraData::initPersistFields
// Summary:
//-----------------------------------------------------------
void TankCameraData::initPersistFields()
{
   Parent::initPersistFields();

   addField("camFocusDist", TypeF32, Offset(camFocusDist,TankCameraData));
   addField("camFocusUpDist", TypeF32, Offset(camFocusUpDist,TankCameraData));
   addField("camBackupDist", TypeF32, Offset(camBackupDist,TankCameraData));
   addField("camFloatHeight", TypeF32, Offset(camFloatHeight,TankCameraData));
   addField("camSmooth", TypeF32, Offset(camSmooth,TankCameraData));
   addField("camSmoothTurn", TypeF32, Offset(camSmoothTurn,TankCameraData));
   addField("camSmoothUp", TypeF32, Offset(camSmoothUp,TankCameraData));
   addField("camFov", TypeF32, Offset(camFov,TankCameraData));
   addField("camNear", TypeF32, Offset(camNear,TankCameraData));
}

//-----------------------------------------------------------
// Function name:  TankCameraData::packData
// Summary:
//-----------------------------------------------------------
void TankCameraData::packData(BitStream* stream)
{
   Parent::packData(stream);

   stream->write(camFocusDist);
   stream->write(camFocusUpDist);
   stream->write(camBackupDist);
   stream->write(camFloatHeight);
   stream->write(camSmooth);
   stream->write(camSmoothTurn);
   stream->write(camSmoothUp);
   stream->write(camFov);
   stream->write(camNear);
}

//-----------------------------------------------------------
// Function name:  TankCameraData::unpackData
// Summary:
//-----------------------------------------------------------
void TankCameraData::unpackData(BitStream* stream)
{
   Parent::unpackData(stream);

   stream->read(&camFocusDist);
   stream->read(&camFocusUpDist);
   stream->read(&camBackupDist);
   stream->read(&camFloatHeight);
   stream->read(&camSmooth);
   stream->read(&camSmoothTurn);
   stream->read(&camSmoothUp);
   stream->read(&camFov);
   stream->read(&camNear);
}

//-----------------------------------------------------------
//-----------------------------------------------------------
//                              TankFxData
//-----------------------------------------------------------
//-----------------------------------------------------------

// This automagically hooks the class up to the console
// script interface.


//-----------------------------------------------------------
// Function name:  TankFxData::TankFxData
// Summary:
//-----------------------------------------------------------
TankFxData::TankFxData()
{
   hardTankCollSoundId = 0;
   hardTankCollSound = NULL;
   hardTankCollVel = 100.0f;
   softTankCollSoundId = 0;
   softTankCollSound = NULL;
   softTankCollVel = 100.0f;
   tankCollISI = 10E10;;

   hardStaticCollSoundId = 0;
   hardStaticCollSound = NULL;
   hardStaticCollVel = 100.0f;
   softStaticCollSoundId = 0;
   softStaticCollSound = NULL;
   softStaticCollVel = 100.0f;
   staticCollISI = 10E10;;

   hardGroundCollSoundId = 0;
   hardGroundCollSound = NULL;
   hardGroundCollVel = 100.0f;
   softGroundCollSoundId = 0;
   softGroundCollSound = NULL;
   softGroundCollVel = 100.0f;
   groundCollISI = 10E10;;

   engineSoundAId = 0;
   engineSoundA = NULL;
   enginePitchA0 = 1.0f;
   enginePitchA1 = 1.2f;
   engineVolA0 = 0.5f;
   engineVolA1 = 1.0f;
   engineSoundBId = 0;
   engineSoundB = NULL;
   enginePitchB0 = 1.0f;
   enginePitchB1 = 1.0f;
   engineVolB0 = 0.0f;
   engineVolB1 = 0.0f;
}

//-----------------------------------------------------------
// Function name:  TankFxData::initPersistFields
// Summary:
//-----------------------------------------------------------
void TankFxData::initPersistFields()
{
   Parent::initPersistFields();

   addField("hardTankCollSound", TypeAudioProfilePtr, Offset(hardTankCollSound,TankFxData));
   addField("hardTankCollVel", TypeF32, Offset(hardTankCollVel,TankFxData));
   addField("softTankCollSound", TypeAudioProfilePtr, Offset(softTankCollSound,TankFxData));
   addField("softTankCollVel", TypeF32, Offset(softTankCollVel,TankFxData));
   addField("tankCollISI", TypeS32,Offset(tankCollISI,TankFxData));

   addField("hardStaticCollSound", TypeAudioProfilePtr, Offset(hardStaticCollSound,TankFxData));
   addField("hardStaticCollVel", TypeF32, Offset(hardStaticCollVel,TankFxData));
   addField("softStaticCollSound", TypeAudioProfilePtr, Offset(softStaticCollSound,TankFxData));
   addField("softStaticCollVel", TypeF32, Offset(softStaticCollVel,TankFxData));
   addField("staticCollISI", TypeS32,Offset(staticCollISI,TankFxData));

   addField("hardGroundCollSound", TypeAudioProfilePtr, Offset(hardGroundCollSound,TankFxData));
   addField("hardGroundCollVel", TypeF32, Offset(hardGroundCollVel,TankFxData));
   addField("softGroundCollSound", TypeAudioProfilePtr, Offset(softGroundCollSound,TankFxData));
   addField("softGroundCollVel", TypeF32, Offset(softGroundCollVel,TankFxData));
   addField("groundCollISI", TypeS32,Offset(groundCollISI,TankFxData));

   addField("engineSoundA", TypeAudioProfilePtr, Offset(engineSoundA,TankFxData));
   addField("enginePitchA0", TypeF32, Offset(enginePitchA0,TankFxData));
   addField("enginePitchA1", TypeF32, Offset(enginePitchA1,TankFxData));
   addField("engineVolA0", TypeF32, Offset(engineVolA0,TankFxData));
   addField("engineVolA1", TypeF32, Offset(engineVolA1,TankFxData));
   addField("engineSoundB", TypeAudioProfilePtr, Offset(engineSoundB,TankFxData));
   addField("enginePitchB0", TypeF32, Offset(enginePitchB0,TankFxData));
   addField("enginePitchB1", TypeF32, Offset(enginePitchB1,TankFxData));
   addField("engineVolB0", TypeF32, Offset(engineVolB0,TankFxData));
   addField("engineVolB1", TypeF32, Offset(engineVolB1,TankFxData));
}

//-----------------------------------------------------------
// Function name:  TankFxData::preload
// Summary:
//-----------------------------------------------------------
bool TankFxData::preload(bool server, char errorBuffer[256])
{
   if (!Parent::preload(server,errorBuffer))
      return false;

   if (server && hardTankCollSound)
      hardTankCollSoundId = hardTankCollSound->getId();
   else if (!server && hardTankCollSoundId)
   {
      if (!Sim::findObject(hardTankCollSoundId,hardTankCollSound))
         Con::errorf(ConsoleLogEntry::General,"Error, unable to load collision sound for tank");
   }

   if (server && softTankCollSound)
      softTankCollSoundId = softTankCollSound->getId();
   else if (!server && softTankCollSoundId)
   {
      if (!Sim::findObject(softTankCollSoundId,softTankCollSound))
         Con::errorf(ConsoleLogEntry::General,"Error, unable to load collision sound for tank");
   }

   if (server && hardStaticCollSound)
      hardStaticCollSoundId = hardStaticCollSound->getId();
   else if (!server && hardStaticCollSoundId)
   {
      if (!Sim::findObject(hardStaticCollSoundId,hardStaticCollSound))
         Con::errorf(ConsoleLogEntry::General,"Error, unable to load collision sound for tank");
   }

   if (server && softStaticCollSound)
      softStaticCollSoundId = softStaticCollSound->getId();
   else if (!server && softStaticCollSoundId)
   {
      if (!Sim::findObject(softStaticCollSoundId,softStaticCollSound))
         Con::errorf(ConsoleLogEntry::General,"Error, unable to load collision sound for tank");
   }

   if (server && hardGroundCollSound)
      hardGroundCollSoundId = hardGroundCollSound->getId();
   else if (!server && hardGroundCollSoundId)
   {
      if (!Sim::findObject(hardGroundCollSoundId,hardGroundCollSound))
         Con::errorf(ConsoleLogEntry::General,"Error, unable to load collision sound for tank");
   }

   if (server && softGroundCollSound)
      softGroundCollSoundId = softGroundCollSound->getId();
   else if (!server && softGroundCollSoundId)
   {
      if (!Sim::findObject(softGroundCollSoundId,softGroundCollSound))
         Con::errorf(ConsoleLogEntry::General,"Error, unable to load collision sound for tank");
   }

   if (server && engineSoundA)
      engineSoundAId = engineSoundA->getId();
   else if (!server && engineSoundAId)
   {
      if (!Sim::findObject(engineSoundAId,engineSoundA))
         Con::errorf(ConsoleLogEntry::General,"Error, unable to load EngineSoundA for tank");
   }

   if (server && engineSoundB)
      engineSoundBId = engineSoundB->getId();
   else if (!server && engineSoundBId)
   {
      if (!Sim::findObject(engineSoundBId,engineSoundB))
         Con::errorf(ConsoleLogEntry::General,"Error, unable to load EngineSoundB for tank");
   }

   return true;
}

//-----------------------------------------------------------
// Function name:  TankFxData::packData
// Summary:
//-----------------------------------------------------------
void TankFxData::packData(BitStream* stream)
{
   Parent::packData(stream);

   if (stream->writeFlag(hardTankCollSoundId))
   {
      stream->writeRangedU32(hardTankCollSoundId,DataBlockObjectIdFirst,DataBlockObjectIdLast);
      stream->write(hardTankCollVel);
   }

   if (stream->writeFlag(softTankCollSoundId))
   {
      stream->writeRangedU32(softTankCollSoundId,DataBlockObjectIdFirst,DataBlockObjectIdLast);
      stream->write(softTankCollVel);
   }

   if (stream->writeFlag(hardStaticCollSoundId))
   {
      stream->writeRangedU32(hardStaticCollSoundId,DataBlockObjectIdFirst,DataBlockObjectIdLast);
      stream->write(hardStaticCollVel);
   }

   if (stream->writeFlag(softStaticCollSoundId))
   {
      stream->writeRangedU32(softStaticCollSoundId,DataBlockObjectIdFirst,DataBlockObjectIdLast);
      stream->write(softStaticCollVel);
   }

   if (stream->writeFlag(hardGroundCollSoundId))
   {
      stream->writeRangedU32(hardGroundCollSoundId,DataBlockObjectIdFirst,DataBlockObjectIdLast);
      stream->write(hardGroundCollVel);
   }

   if (stream->writeFlag(softGroundCollSoundId))
   {
      stream->writeRangedU32(softGroundCollSoundId,DataBlockObjectIdFirst,DataBlockObjectIdLast);
      stream->write(softGroundCollVel);
   }

   stream->write(tankCollISI);
   stream->write(staticCollISI);
   stream->write(groundCollISI);

   stream->write(engineSoundAId);
   stream->write(enginePitchA0);
   stream->write(enginePitchA1);
   stream->write(engineVolA0);
   stream->write(engineVolA1);
   stream->write(engineSoundBId);
   stream->write(enginePitchB0);
   stream->write(enginePitchB1);
   stream->write(engineVolB0);
   stream->write(engineVolB1);
}

//-----------------------------------------------------------
// Function name:  TankFxData::unpackData
// Summary:
//-----------------------------------------------------------
void TankFxData::unpackData(BitStream* stream)
{
   Parent::unpackData(stream);

   if (stream->readFlag())
   {
      hardTankCollSoundId = stream->readRangedU32(DataBlockObjectIdFirst,DataBlockObjectIdLast);
      stream->read(&hardTankCollVel);
   }

   if (stream->readFlag())
   {
      softTankCollSoundId = stream->readRangedU32(DataBlockObjectIdFirst,DataBlockObjectIdLast);
      stream->read(&softTankCollVel);
   }

   if (stream->readFlag())
   {
      hardStaticCollSoundId = stream->readRangedU32(DataBlockObjectIdFirst,DataBlockObjectIdLast);
      stream->read(&hardStaticCollVel);
   }

   if (stream->readFlag())
   {
      softStaticCollSoundId = stream->readRangedU32(DataBlockObjectIdFirst,DataBlockObjectIdLast);
      stream->read(&softStaticCollVel);
   }

   if (stream->readFlag())
   {
      hardGroundCollSoundId = stream->readRangedU32(DataBlockObjectIdFirst,DataBlockObjectIdLast);
      stream->read(&hardGroundCollVel);
   }

   if (stream->readFlag())
   {
      softGroundCollSoundId = stream->readRangedU32(DataBlockObjectIdFirst,DataBlockObjectIdLast);
      stream->read(&softGroundCollVel);
   }

   stream->read(&tankCollISI);
   stream->read(&staticCollISI);
   stream->read(&groundCollISI);

   stream->read(&engineSoundAId);
   stream->read(&enginePitchA0);
   stream->read(&enginePitchA1);
   stream->read(&engineVolA0);
   stream->read(&engineVolA1);
   stream->read(&engineSoundBId);
   stream->read(&enginePitchB0);
   stream->read(&enginePitchB1);
   stream->read(&engineVolB0);
   stream->read(&engineVolB1);
}

//-----------------------------------------------------------
//-----------------------------------------------------------
//                              TankMiscData
//-----------------------------------------------------------
//-----------------------------------------------------------

// This automagically hooks the class up to the console
// script interface.


//-----------------------------------------------------------
// Function name:  TankMiscData::TankMiscData
// Summary:
//-----------------------------------------------------------
TankMiscData::TankMiscData()
{
   boostTicks = 5;
   bounceStatic = 0.5f;
   bounceTank = 0.5f;
   unstuckTime = 1000;
   unstuckBoost = 5.0f;
}

//-----------------------------------------------------------
// Function name:  TankMiscData::initPersistFields
// Summary:
//-----------------------------------------------------------
void TankMiscData::initPersistFields()
{
   Parent::initPersistFields();

   addField("boostTicks", TypeS32, Offset(boostTicks,TankMiscData));
   addField("bounceStatic", TypeF32, Offset(bounceStatic,TankMiscData));
   addField("bounceTank", TypeF32, Offset(bounceTank,TankMiscData));
   addField("unstuckTime", TypeS32, Offset(unstuckTime,TankMiscData));
   addField("unstuckBoost", TypeF32, Offset(unstuckBoost,TankMiscData));
}

//-----------------------------------------------------------
// Function name:  TankMiscData::packData
// Summary:
//-----------------------------------------------------------
void TankMiscData::packData(BitStream* stream)
{
   Parent::packData(stream);

   stream->write(boostTicks);
   stream->write(bounceStatic);
   stream->write(bounceTank);
   stream->write(unstuckTime);
   stream->write(unstuckBoost);
}

//-----------------------------------------------------------
// Function name:  TankMiscData::unpackData
// Summary:
//-----------------------------------------------------------
void TankMiscData::unpackData(BitStream* stream)
{
   Parent::unpackData(stream);

   stream->read(&boostTicks);
   stream->read(&bounceStatic);
   stream->read(&bounceTank);
   stream->read(&unstuckTime);
   stream->read(&unstuckBoost);
}

//-----------------------------------------------------------
//-----------------------------------------------------------
//                              TankShape
//-----------------------------------------------------------
//-----------------------------------------------------------

// This automagically hooks the class up to the console
// script interface.
IMPLEMENT_CO_NETOBJECT_V1(TankShape);


//-----------------------------------------------------------
// Function name:  TankShape::TankShape
// Summary:        Constructor.  Set type mask here for
//                 spatial database searches.
//-----------------------------------------------------------
TankShape::TankShape()
{
   mTypeMask |= PlayerObjectType;

   mPrevCameraPos.set(0,0,0);
   mPrevCameraTime = 0;

   mVelocity.set(0,0,0);
   mContact = mFullContact = false;
   mTurn = 0;
   mMovy = 0;
   mBoostTicks = 0;
   mStuckTicks = 0;
   mTankSpringCenter.set(0,0,0);
   mTankSpringPos.set(0,0,0);
   mTankSpringVel.set(0,0,0);

   mLTreadThread = NULL;
   mRTreadThread = NULL;

   mLastTankCollTime = 0;
   mLastStaticCollTime = 0;
   mLastGroundCollTime = 0;

   mEngineSoundA = NULL_AUDIOHANDLE;
   mEngineSoundB = NULL_AUDIOHANDLE;
   mEngineAmp = 0.0f;

   mCollisionObject = 0;
   mCollisionTimeout = 0;

   mWheelDropVel[0] = mWheelDropVel[1] = mWheelDropVel[2] = mWheelDropVel[3] = 0.0f;

   mConvex.init(this);
   mWorkingQueryBox.min.set(-1e9, -1e9, -1e9);
   mWorkingQueryBox.max.set(-1e9, -1e9, -1e9);

}

//-----------------------------------------------------------
// Function name:  TankShape::~TankShape
// Summary:        Destructor.
//-----------------------------------------------------------
TankShape::~TankShape()
{
   if (mEngineSoundA != NULL_AUDIOHANDLE)
      alxStop(mEngineSoundA);
   if (mEngineSoundB != NULL_AUDIOHANDLE)
      alxStop(mEngineSoundB);
}

U32 TankShape::getCollisionMask()
{
   if (isServerObject())
      return sServerCollisionMask;
   else
      return sClientCollisionMask;
}

U32 TankShape::getConformToMask()
{
   if (getDataBlock() == NULL)
      return sConformToMask;
   return sConformToMask;
}

//-----------------------------------------------------------
// Function name:  TankShape::onAdd
// Summary:        Called when object added to manager.  Must
//                 call parent onAdd method, add the object
//                 to the scene, and call script on add.  The
//                 later two are optional (but know what you
//                 are doing if you skip them) whereas the
//                 first is mandatory.
//-----------------------------------------------------------
bool TankShape::onAdd()
{
   if (!Parent::onAdd() || !getDataBlock())
      // not properly added
      return false;

   // set up deltaHelper
   MatrixF mat = getTransform();
   Point3F pos;
   QuatF rot;

   mat.getColumn(3,&pos);
   rot.set(mat);
   deltaHelper.init(pos,rot);

   // add to scene manager
   addToScene();

   // call script "TankShape::onAdd" function
   scriptOnAdd();

   // properly added
   return true;
}

//-----------------------------------------------------------
// Function name:  TankShape::onRemove
// Summary:        Undo onAdd.  Generally undo whatever was
//                 done in onAdd.
//-----------------------------------------------------------
void TankShape::onRemove()
{
   scriptOnRemove();
   removeFromScene();

   Parent::onRemove();
}

//------------------------------------------
// GameBase and NetObject derived methods
//------------------------------------------

//-----------------------------------------------------------
// Function name:  TankShape::onNewDataBlock
// Summary:        This method called when data block
//                 changes.  Note that this method called
//                 during onAdd (before any TankShape::onAdd
//                 specific code is executed).
//-----------------------------------------------------------
bool TankShape::onNewDataBlock(GameBaseData * dptr)
{
   if (!dptr || !Parent::onNewDataBlock(dptr))
      return false;

   // rid us of old shape instance...
   delete mShapeInstance;
   mShapeInstance = NULL;

   // load new shape instance...
   AssertFatal(bool(getDataBlock()->shapeResource),
      "TankShape::onNewDataBlock: no shape resource");
   mShapeInstance = new TSShapeInstance(getDataBlock()->shapeResource, isClientObject());

   // mark callback nodes (for turret/weapon control)
   mShapeInstance->setNodeAnimationState(getDataBlock()->turretNode,TSShapeInstance::MaskNodeHandsOff);
   mShapeInstance->setNodeAnimationState(getDataBlock()->weaponNode,TSShapeInstance::MaskNodeHandsOff);
   if (isClientObject())
   {
      int i;
      for (i=0; i<numInnerWheels(); i++)
         mShapeInstance->setNodeAnimationState(getDataBlock()->wheelNode[i],TSShapeInstance::MaskNodeHandsOff);
      mShapeInstance->setNodeAnimationState(getDataBlock()->suspensionNode,TSShapeInstance::MaskNodeHandsOff);
      for (i=0; i<totalWheels(); i++)
         mShapeInstance->setNodeAnimationState(getDataBlock()->wheelRotNode[i],TSShapeInstance::MaskNodeHandsOff);
   }

   mLTreadThread = mShapeInstance->addThread();
   mShapeInstance->setSequence(mLTreadThread,getDataBlock()->lTreadSeq,0.0f);
   mRTreadThread = mShapeInstance->addThread();
   mShapeInstance->setSequence(mRTreadThread,getDataBlock()->rTreadSeq,0.0f);

   // this sets the bounding box...why isn't this a function
   // call rather than messing with a parent variable (which
   // also happens to have it's effect via side-effect)?
   // Because this is Torque, get used to it.
   // Note: this is done in onNewDataBlock because this info
   // normally comes from the data block (either from a shape
   // in the data block or the data block explicitly).
   mObjBox = getDataBlock()->objectBox;

   // leaf classes must call this...one annoying side-effect
   // is that if we derive from TankShape we get two calls to
   // the script onAdd method.
   scriptOnNewDataBlock();
   return true;
}

//-----------------------------------------------------------
// Function name:  TankShape::processTick
// Summary:        A tick is the basic unit of update time
//                 on the server.  Fixed at 1/32 sec, but
//                 we could potentially change it.  On both
//                 the client and server, objects will receive
//                 a processTick once per tick.  On the server
//                 the object should move.  On the client, it
//                 needs to do the same, but also needs to
//                 update interpolation parameters so that
//                 interpolateTick can be called.  A move
//                 is passed to processTick for the client
//                 control object and for server objects.
//                 For client ghosts, no move is passed.
//                 The processTick logic also needs to
//                 behave well along with packUpdate and
//                 readPacket methods, since that is where
//                 new data ultimately comes from.
//-----------------------------------------------------------
void TankShape::processTick(const Move * move)
{
   Parent::processTick(move);

   // remember current collision state -- used for determining
   // collision sounds at the end of the tick
   smStartVelocity = mVelocity;
   smCollisionMask = 0;
   if (mContact)
      smCollisionMask |= WasContact;
   if (mFullContact)
      smCollisionMask |= WasFullContact;

   // end of previous tick...
   deltaHelper.setBackDelta(0.0f);
   Point3F pos = deltaHelper.getPos();
   QuatF rot = deltaHelper.getRot();
   Point3F oldPos = pos;
   QuatF oldRot = rot;

   Point3F leftTread0;
   Point3F rightTread0;
   if (isClientObject())
      markTreads(leftTread0,rightTread0,getTransform());

   // update boost
   if (!gEditingMission && mBoostTicks)
   {
      if (mBoostTicks<=getDataBlock()->misc->boostTicks)
         mVelocity += mBoostVel;
      --mBoostTicks;
   }

   // stuck?
   if (!gEditingMission && !mContact && mDot(mVelocity,mVelocity)<0.1f)
   {
      ++mStuckTicks;
      if (F32(mStuckTicks) * TickMs > getDataBlock()->misc->unstuckTime)
      {
         mWheelDropVel[0] = mWheelDropVel[1] = mWheelDropVel[2] = mWheelDropVel[3] = 0.0f;
         if (!isClientObject())
         {
            Point3F vd(0,0,1);
            Point3F dir = MathUtils::randomDir(vd,0,90);
            mVelocity += getDataBlock()->misc->unstuckBoost * dir;
            setMaskBits(MoveMask);
         }
      }
   }
   else
      mStuckTicks = 0;

   // next tick...
   if (!gEditingMission && !deltaHelper.doTick())
   {
      updateMove(move,pos,rot,getTransform());

      updateWorkingCollisionSet(getCollisionMask(), TickSec);

      // account for non-terrain collisions...
      // ...this will modify pos & rot if collision
      // it will also modify velocities of all tanks
      // involved in collision (including our own).
      Point3F tryPos = pos;
      QuatF tryRot = rot;
      if (updatePos(pos,rot,oldPos,oldRot,TickSec))
      {
         // didn't find a collision plane (but collided)
         // perhaps we can move if we don't rotate...
         pos = tryPos;
         rot = oldRot;
         if (updatePos(pos,rot,oldPos,oldRot,TickSec))
            // nope...better kill velocity
            mVelocity.set(0,0,0);
      }

      // update deltaHelper
      deltaHelper.setupInterpolation(pos,rot);
      deltaHelper.doTick();
   }
   else
   {
      // just following servers lead...skip collisions
      deltaHelper.setBackDelta(0.0f);
      pos = deltaHelper.getPos();
      rot = deltaHelper.getRot();
   }

   // set position to pos at end of tick...
   setPosition(pos,rot);


   if (isClientObject())
   {
      Point3F leftTread1;
      Point3F rightTread1;
      markTreads(leftTread1,rightTread1,getTransform());

      Point3F lt = leftTread0-leftTread1;
      Point3F rt = rightTread0-rightTread1;
      updateTreads(lt,rt,getTransform());
   }

   if (isClientObject())
      // on server, no interpolation so start at the end
      // on client, interpolation so start at the beginning
      // (actually shouldn't matter because this value of
      // back delta is only valid till the end of processTick,
      // but just in case we try to get pos/rot from deltaHelper
      // at some later time in the future, let's set the proper
      // value now).
      deltaHelper.setBackDelta(1.0f);

   // go ahead and set mask bits every tick (i.e., send move data
   // across network every tick)...in future, we could be more
   // efficient.
   setMaskBits(MoveMask);

   if (move)
   {
      // turret...
      updateTurret(move,oldRot,rot);
   }

   updateAnimation();

   // be extra careful and make sure all connection objects are present,
   // even though they surely should be anyway.
   if (isClientObject() && GameConnection::getConnectionToServer() &&
       GameConnection::getConnectionToServer()->getControlObject())
   {
      // handle collision and engine sounds...
      Point3F cpos;
      GameConnection::getConnectionToServer()->getControlObject()->getTransform().getColumn(3,&cpos);
      cpos -= pos;
      if (mDot(cpos,cpos)<50*50)
      {
         updateCollisionSound();
         updateEngineSound(true);
      }
      else
         updateEngineSound(false);
   }

   // tank suspension...
   if (!gEditingMission && isClientObject())
      updateTankSuspension();
}

void TankShape::updateTankSuspension()
{
   Point3F x,y,z;
   getTransform().getColumn(0,&x);
   getTransform().getColumn(1,&y);
   getTransform().getColumn(2,&z);

   Point3F adjustForce1(0,0,0);
   if (mContact)
   {
      // if on the ground, apply force based on acceleration
      Point3F dv = smStartVelocity - mVelocity;
      adjustForce1.x -= mDot(x,dv);
      adjustForce1.y -= mDot(y,dv);
      F32 redist = mRandF(0.0f,1.0f);
      adjustForce1.x -= redist * mDot(z,dv);
      adjustForce1.y -= (1.0f-redist) * mDot(z,dv);
      adjustForce1 *= getDataBlock()->springVelScale;

      // if on the ground, set the center position of spring
      // based on the angle of the tank
      F32 scale = -1.4f; // magic scale...
      mTankSpringCenter.x = scale * x.z * getDataBlock()->springRangeX;
      mTankSpringCenter.x = mClampF(mTankSpringCenter.x,-getDataBlock()->springRangeX,getDataBlock()->springRangeX);
      mTankSpringCenter.y = scale * y.z * getDataBlock()->springRangeY;
      mTankSpringCenter.y = mClampF(mTankSpringCenter.y,-getDataBlock()->springRangeY,getDataBlock()->springRangeY);
      mTankSpringCenter.z = 0.0f;
   }

   // spring back to center position
   Point3F adjustForce2 = mTankSpringPos - mTankSpringCenter;
   //adjustForce2 *= getDataBlock()->springCorrectScale1;
   // No harm hard-coding this
   adjustForce2 *= 0.5f;

   mTankSpringVel -= adjustForce1;
   mTankSpringVel -= adjustForce2;

   F32 springScale = mContact ? getDataBlock()->springLooseness : 0.9f;
   mTankSpringPos *= springScale;
   mTankSpringPos += (1.0f-getDataBlock()->springLooseness) * mTankSpringCenter;
   mTankSpringPos += mTankSpringVel * TickSec;

   F32 clamped = mClampF(mTankSpringPos.x,-getDataBlock()->springRangeX,getDataBlock()->springRangeX);
   if (clamped!=mTankSpringPos.x)
      mTankSpringVel.x = 0.0f;
   mTankSpringPos.x = clamped;

   clamped = mClampF(mTankSpringPos.y,-getDataBlock()->springRangeY,getDataBlock()->springRangeY);
   if (clamped!=mTankSpringPos.y)
      mTankSpringVel.y = 0.0f;
   mTankSpringPos.y = clamped;

   clamped = mClampF(mTankSpringPos.z,-getDataBlock()->springRangeZ,getDataBlock()->springRangeZ);
   if (clamped!=mTankSpringPos.z)
      mTankSpringVel.z = 0.0f;
   mTankSpringPos.z = clamped;
}

//-----------------------------------------------------------
// Function name:  TankShape::impact
// Summary:
//-----------------------------------------------------------
void TankShape::impact(const Point3F & p, F32 force)
{
   Point3F x,y,z,pos;
   getTransform().getColumn(0,&x);
   getTransform().getColumn(1,&y);
   getTransform().getColumn(3,&pos);
   pos -= p;
   pos.z = 0.0f;
   if (mDot(pos,pos)>0.01f)
      pos.normalize();
   F32 dotx = mDot(x,pos);
   F32 doty = mDot(y,pos);
   mTankSpringVel.x += dotx * force;
   mTankSpringVel.y += doty * force;
}

//-----------------------------------------------------------
// Function name:  TankShape::markTreads
// Summary:        Return center of left,right tread given
//                 passed transform.
//-----------------------------------------------------------
void TankShape::markTreads(Point3F & left, Point3F & right, const MatrixF & mat)
{
   left.set(getDataBlock()->objectBox.min.x,0,0);
   right.set(getDataBlock()->objectBox.max.x,0,0);
   mat.mulP(left);
   mat.mulP(right);
}

//-----------------------------------------------------------
// Function name:  TankShape::updateTreads
// Summary:        Advance position on treads given current
//                 movement vector for each tread.
//-----------------------------------------------------------
void TankShape::updateTreads(Point3F & leftMove, Point3F & rightMove, const MatrixF & mat)
{
   Point3F y;
   mat.getColumn(1,&y);
   deltaHelper.advanceTread(mDot(y,leftMove),mDot(y,rightMove),getDataBlock()->wheelRotMod);
}

//-----------------------------------------------------------
// Function name:  TankShape::updateTurret
// Summary:        Update turret on processTick.
//-----------------------------------------------------------
void TankShape::updateTurret(const Move * move, const QuatF & oldRot, const QuatF & newRot)
{
   AssertFatal(move,"doh!");

   // get old position
   F32 tHor = deltaHelper.getTurretHorTarget();
   F32 tVer = deltaHelper.getTurretVerTarget();

   // auto adjust to stay level
   if (getDataBlock()->turretAutoLevel>0.01f)
   {
      MatrixF oldMat, newMat;
      MatrixF turretMat(EulerF(0,0,tHor * mDegToRad(getDataBlock()->turretHorRange)));
      turretMat.mul(MatrixF(EulerF(tVer * mDegToRad(getDataBlock()->turretVerRange) + mDegToRad(getDataBlock()->turretVerCenter),0,0)));
      oldRot.setMatrix(&oldMat);
      oldMat.mul(turretMat);
      newRot.setMatrix(&newMat);
      newMat.mul(turretMat);

      Point3F y0,y1,x1;
      oldMat.getColumn(1,&y0);
      newMat.getColumn(1,&y1);
      newMat.getColumn(0,&x1);

      F32 muzzleDelta = 0.0f;
      y0 -= mDot(y0,x1) * x1;
      if (mDot(y0,y0)>0.1f)
      {
         y0.normalize();
         if (mDot(y0,y1)<0.99999f)
            muzzleDelta = mAcos(mDot(y0,y1));
         if (y0.z<y1.z)
            muzzleDelta *= -1.0f;
      }
      tVer -= getDataBlock()->turretAutoLevel * muzzleDelta/mDegToRad(getDataBlock()->turretVerRange);
   }

   // move to new turret position...adjust directly, no turret
   // velocity...however, there is interpolation between ticks
   tHor += (move->yaw / M_PI);
   tVer += (move->pitch / M_PI);
   tHor = mClampF(tHor,-1.0f,1.0f);
   tVer = mClampF(tVer,-1.0f,1.0f);
   deltaHelper.setTurret(tHor,tVer);
   setMaskBits(TurretMask);
}

//-----------------------------------------------------------
// Function name:  TankShape::onImageRecoil
// Summary:        Callback when weapon fires...from ShapeBase
//-----------------------------------------------------------
void TankShape::onImageRecoil(U32 imageSlot, ShapeBaseImageData::StateData::RecoilState)
{
   // Use hard-coded recoil value...
   F32 kickPower;

   if (imageSlot == 0)
      kickPower = getDataBlock()->primaryRecoil;
   else if (imageSlot == 1)
      kickPower = getDataBlock()->secondaryRecoil;
   else
      kickPower = getDataBlock()->tertiaryRecoil;

   F32 angle = mDegToRad(getDataBlock()->turretHorRange) * deltaHelper.getTurretHorTarget();
   mTankSpringVel.x -= kickPower * mSin(angle);
   mTankSpringVel.y -= kickPower * mCos(angle);
}


//-----------------------------------------------------------
// Function name:  TankShape::updateMove
// Summary:        Process one move.  Called from processTick.
//-----------------------------------------------------------
void TankShape::updateMove(const Move * move, Point3F & pos, QuatF & rot, MatrixF mat)
{
   // Trigger images
   if (move != NULL && mDamageState == Enabled) {
      setImageTriggerState(0,move->trigger[0]);
      setImageTriggerState(1,move->trigger[1]);
      setImageTriggerState(2,move->trigger[2]);
   }

   // if last round we had all our wheels on the ground,
   // get rid of velocity through the z-axis...
   // ...otherwise, apply gravity
   if (mFullContact)
   {
      // get rid of velocity along z axis
      Point3F z;
      mat.getColumn(2,&z);
      F32 zvel = mDot(z,mVelocity);
      if (zvel>0.0f)
         // can still go up...
         zvel = 0.0f;
      mVelocity -= zvel*z;
   }
   else if (!mContact)
      // apply gravity globally if all wheels are off the ground
      mVelocity.z += sGravity * TickSec;

   if (mContact && move)
      mTurn = move->x;
   if (mContact && move)
      mMovy = move->y;

   // interpret move...if at all on the ground
   if (mContact)
   {
      // get forward and side vectors
      Point3F x,y;
      mat.getColumn(0,&x);
      mat.getColumn(1,&y);

      // slide?
      F32 dotx = mDot(x,mVelocity);
      if (dotx<-getDataBlock()->antiSlideRate * TickSec)
         dotx = -getDataBlock()->antiSlideRate * TickSec;
      else if (dotx>getDataBlock()->antiSlideRate * TickSec)
         dotx = getDataBlock()->antiSlideRate * TickSec;
      mVelocity -= dotx * x;

      // move?
      F32 doty = mDot(y,mVelocity);
      bool coast = mFabs(doty)>getDataBlock()->maxSpeed && doty*mMovy>0.0f;
      if (mFabs(mMovy)>0.001f && !coast)
      {
         if (doty*mMovy>=0.0f)
         {
            // make sure we don't accelerate above maxSpeed
            F32 movy = mMovy;
            F32 newVel = doty+movy * getDataBlock()->accelRate * TickSec;
            if (mFabs(newVel) > getDataBlock()->maxSpeed)
               movy *= (getDataBlock()->maxSpeed - mFabs(doty)) / (mFabs(newVel) - mFabs(doty));
            // accelerating...(whether forwards or backwards)
            mVelocity += (movy * getDataBlock()->accelRate * TickSec) * y;
         }
         else
            // deccelerating (braking)...
            mVelocity += (mMovy * getDataBlock()->deccelRate * TickSec) * y;
      }
      else if (coast)
      {
         F32 coastVel = doty > 0 ? doty-getDataBlock()->maxSpeed : doty+getDataBlock()->maxSpeed;
         mVelocity -= TickSec * mClampF(coastVel,-getDataBlock()->coastDeccelRate,getDataBlock()->coastDeccelRate) * y;
      }
      else
         // no accelerator, no brake...simply dissipate
         mVelocity -= TickSec * mClampF(doty,-getDataBlock()->coastDeccelRate,getDataBlock()->coastDeccelRate) * y;
   }

   // get transform, apply turn -- legal values are 0,1,-1
   if (mTurn*mTurn>0.1f)
   {
      F32 turn = mTurn * mDegToRad(getDataBlock()->turnRate) * TickSec;
      mat.mul(MatrixF(EulerF(0,0,turn)));

      // extract new rotation from matrix (after turning)
      rot.set(mat);
   }

   // adjust position using velocity
   pos += TickSec * mVelocity;

   // interact with the ground...
   updateTerrainCollision(pos,rot,mat);
}

//-----------------------------------------------------------
// Function name:  TankShape::updatePos
// Summary:        Update pos accounting for non-terrain
//                 collisions.  New values derived from
//                 other method (e.g., updateMove), updatePos
//                 returns as far along the path as it can,
//                 and adjusts velocity of the tank and any
//                 moveable objects that were hit.
//                 Return true if we at least move...
//-----------------------------------------------------------
bool TankShape::updatePos(Point3F & newPos, QuatF & newRot, const Point3F & oldPos, const QuatF & oldRot, const F32 dt)
{
   bool contact = false;
   bool nonStatic = false;
   CollisionList collisionList;

   static Polyhedron sBoxPolyhedron;
   static ClippedPolyList sPolyList;

   MatrixF collisionMatrix;
   newRot.setMatrix(&collisionMatrix);
   collisionMatrix.setColumn(3,newPos);
   U32 mask = getCollisionMask();

   RayInfo rinfo;

   Box3F oBox = getObjBox();
   oBox.min.z += getDataBlock()->wheelRadius[0] * 2;
   sBoxPolyhedron.buildBox(collisionMatrix, oBox);

   Box3F wBox = oBox;
   collisionMatrix.mul(wBox);

   sPolyList.clear();
   sPolyList.mPlaneList.setSize(sBoxPolyhedron.planeList.size());
   for (S32 i=0; i<sBoxPolyhedron.planeList.size(); i++)
      sPolyList.mPlaneList[i] = sBoxPolyhedron.planeList[i];

   CollisionWorkingList& eorList = mConvex.getWorkingList();
   CollisionWorkingList* eopList = eorList.wLink.mNext;
   while (eopList != &eorList)
   {
      if ((eopList->mConvex->getObject()->getType() & mask) != 0)
      {
         Box3F convexBox = eopList->mConvex->getBoundingBox();
         if (wBox.isOverlapped(convexBox))
            eopList->mConvex->getPolyList(&sPolyList);
      }
      eopList = eopList->wLink.mNext;
   }

   bool noPlaneFound=false;
   if (!sPolyList.isEmpty())
   {
      newPos = oldPos;
      newRot = oldRot;
      F32 minDot=10E10f;
      S32 planeIdx=-1;
      for (S32 i=0; i<sPolyList.mPolyList.size(); i++)
      {
         F32 dot = mDot(sPolyList.mPolyList[i].plane,mVelocity);
         if (dot<minDot)
         {
            minDot=dot;
            planeIdx=i;
         }
      }
      if (planeIdx>=0 && minDot<0)
      {
         Point3F collNormal = sPolyList.mPolyList[planeIdx].plane;

         F32 bd = -minDot;
         VectorF fv = mVelocity + collNormal * bd;
         F32 fvl = fv.len();
         if (fvl)
         {
            F32 ff = bd * getDataBlock()->friction;
            if (ff < fvl)
            {
               fv *= ff / fvl;
               fvl = ff;
            }
         }
         bd *= 1 + getDataBlock()->elasticity;
         VectorF dv = collNormal * (bd + 0.002);
         mVelocity += dv;
         mVelocity -= fv;

         // Keep track of what we hit
         contact = true;
         SceneObject * collided = sPolyList.mPolyList[planeIdx].object;
         U32 typeMask = collided->getTypeMask();
         if (!(typeMask & StaticObjectType))
            nonStatic = true;
         if (isServerObject() && (typeMask & ShapeBaseObjectType))
         {
            ShapeBase* col = static_cast<ShapeBase*>(collided);
            queueCollision(col,mVelocity - col->getVelocity());
         }
      }
      else
         noPlaneFound = true;
   }

   enableCollision();
   if (mCollisionObject)
      mCollisionObject->enableCollision();
   updateContainer();

   // if we hit anything...
   if (contact)
   {
      // nothing special...
   }

   // Collision callbacks. These need to be processed whether we hit
   // anything or not.
   if (!isGhost())
   {
      SimObjectPtr<TankShape> safePtr(this);
      notifyCollision();

      // water
      if(bool(safePtr))
      {
         if(!mInLiquid && mWaterCoverage != 0.0f)
         {
            Con::executef(getDataBlock(),4,"onEnterLiquid",scriptThis(), Con::getFloatArg(mWaterCoverage), Con::getIntArg(mLiquidType));
            mInLiquid = true;
         }
         else if(mInLiquid && mWaterCoverage == 0.0f)
         {
            Con::executef(getDataBlock(),3,"onLeaveLiquid",scriptThis(), Con::getIntArg(mLiquidType));
            mInLiquid = false;
         }
      }
   }
   return noPlaneFound;
}

//----------------------------------------------------------------------------
void TankShape::updateWorkingCollisionSet(const U32 mask, const F32 dt)
{
   // It is assumed that we will never accelerate more than 10 m/s for gravity...
   //
   Point3F scaledVelocity = mVelocity * dt;
   F32 len    = scaledVelocity.len();
   F32 newLen = len + (10 * dt);

   // Check to see if it is actually necessary to construct the new working list,
   //  or if we can use the cached version from the last query.  We use the x
   //  component of the min member of the mWorkingQueryBox, which is lame, but
   //  it works ok.
   bool updateSet = false;

   Box3F convexBox = mConvex.getBoundingBox(getTransform(), getScale());
   F32 l = (newLen * 1.1) + 0.1;  // from Convex::updateWorkingList
   convexBox.min -= Point3F(l, l, l);
   convexBox.max += Point3F(l, l, l);

   // Check containment
   {
      if (mWorkingQueryBox.min.x != -1e9)
      {
         if (mWorkingQueryBox.isContained(convexBox) == false)
         {
            // Needed region is outside the cached region.  Update it.
            updateSet = true;
         }
         else
         {
            // We can leave it alone, we're still inside the cached region
         }
      }
      else
      {
         // Must update
         updateSet = true;
      }
   }

   // Actually perform the query, if necessary
   if (updateSet == true)
   {
      mWorkingQueryBox = convexBox;
      mWorkingQueryBox.min -= Point3F(2 * l, 2 * l, 2 * l);
      mWorkingQueryBox.max += Point3F(2 * l, 2 * l, 2 * l);

      disableCollision();
      if (mCollisionObject)
         mCollisionObject->disableCollision();

      // Disable collision for the mounted objects
      for (S32 i = 0; i < getMountedObjectCount(); i++)
         getMountedObject(i)->disableCollision();

      mConvex.updateWorkingList(mWorkingQueryBox, mask);

      // Re-enable collision for the mounted objects
      for (S32 i = 0; i < getMountedObjectCount(); i++)
         getMountedObject(i)->enableCollision();

      if (mCollisionObject)
         mCollisionObject->enableCollision();
      enableCollision();
   }
}

static MatrixF IMat(1);

bool TankShape::buildPolyList(AbstractPolyList* polyList, const Box3F&, const SphereF&)
{
   // Collision with the item is always against the item's object
   // space bounding box axis aligned in world space.
   Point3F pos;
   mObjToWorld.getColumn(3,&pos);
   IMat.setColumn(3,pos);
   polyList->setTransform(&IMat, mObjScale);
   polyList->setObject(this);
   polyList->addBox(mObjBox);
   return true;
}


void TankShape::buildConvex(const Box3F& box, Convex* convex)
{
   if (mShapeInstance == NULL)
      return;

   // These should really come out of a pool
   mConvexList->collectGarbage();

   if (box.isOverlapped(getWorldBox()) == false)
      return;

   // Just return a box convex for the entire shape...
   Convex* cc = 0;
   CollisionWorkingList& wl = convex->getWorkingList();
   for (CollisionWorkingList* itr = wl.wLink.mNext; itr != &wl; itr = itr->wLink.mNext) {
      if (itr->mConvex->getType() == BoxConvexType &&
          itr->mConvex->getObject() == this) {
         cc = itr->mConvex;
         break;
      }
   }
   if (cc)
      return;

   // Create a new convex.
   BoxConvex* cp = new BoxConvex;
   mConvexList->registerObject(cp);
   convex->addToWorkingList(cp);
   cp->init(this);

   mObjBox.getCenter(&cp->mCenter);
   cp->mSize.x = mObjBox.len_x() / 2.0f;
   cp->mSize.y = mObjBox.len_y() / 2.0f;
   cp->mSize.z = mObjBox.len_z() / 2.0f;
}

//-----------------------------------------------------------
// Function name:  TankShape::getWorldCenter
// Summary:        Get center of tank in world space, given
//                 passed object to world transform.
//-----------------------------------------------------------
Point3F TankShape::getWorldCenter(const MatrixF & mat)
{
   const Box3F & obox = getDataBlock()->objectBox;
   Point3F center = (obox.min + obox.max) * 0.5f;
   mat.mulP(center);
   return center;
}

//-----------------------------------------------------------
// Function name:  TankShape::getWheelOffsets
// Summary:        Get distance of each wheel above terrain.
//-----------------------------------------------------------
void TankShape::getWheelOffsets(MatrixF & mat, F32 * woff,S32 a,S32 b)
{
   Point3F wp;

   // get position of wheels in object space...
   // compute offset from ground (positive is above the ground)
   for (S32 i=a; i<b; i++)
   {
      wp = getDataBlock()->wheelPos[i];
      wp.z -= getDataBlock()->wheelRadius[i];
      mat.mulP(wp);
      woff[i]  = wp.z;
      goTowardGround(wp,getConformToMask());
      woff[i] -= wp.z;
   }
}

//-----------------------------------------------------------
// Function name:  TankShape::updateTerrainCollision
// Summary:        Let tank interact with terrain.  Return
//                 new pos and rot (mat will be dirty).
//-----------------------------------------------------------
void TankShape::updateTerrainCollision(Point3F & pos, QuatF & rot, MatrixF & mat)
{
   S32 i;
   Point3F x,y,z;
   F32 woff[TankShapeData::MaxInnerWheels+4];

   // client side this can be called before the datablock is actaully set
   // so check for NULL and bail out if no yet set
   if (getDataBlock() == NULL)
      return;

   const F32 * wheelRange = getDataBlock()->wheelRange;

   // get wheel offsets in order to see how much we
   // should rotate tank due to terrain collisions...
   // only need outer wheels...
   getWheelOffsets(mat,woff,numInnerWheels(),totalWheels());
   for (i=numInnerWheels();i<totalWheels();i++)
      if (woff[i]>0)
         // tread will be extended...don't worry about it here...
         woff[i] = 0.0f;

   // compute desired new wheel positions (of outer wheels)
   Point3F wp[4];
   mat.getColumn(2,&z);
   for (i=numInnerWheels();i<totalWheels();i++)
   {
      wp[i-numInnerWheels()] = getDataBlock()->wheelPos[i];
      wp[i-numInnerWheels()].z -= getDataBlock()->wheelRadius[i];
      mat.mulV(wp[i-numInnerWheels()]);
      wp[i-numInnerWheels()].z -= woff[i];
      wp[i-numInnerWheels()].z += mWheelDropVel[i-numInnerWheels()] * TickSec;
   }

   // find a new z...by choosing average candidate...
   // ...candidates are those z we'd get by using three
   // points and ignoring the other
   Point3F avgZ(0,0,0);
   for (i=0; i<4; i++)
   {
      mCross(wp[(i+3)%4]-wp[(i+1)%4],wp[(i+2)%4]-wp[(i+1)%4],&z);
      z.normalize();
      avgZ += z;
   }
   avgZ.normalize();

   // choose z and rebuild matrix...
   z=avgZ;
   mat.getColumn(1,&y);
   mCross(y,z,&x);
   x.normalize();
   mCross(z,x,&y);
   mat.setColumn(0,x);
   mat.setColumn(1,y);
   mat.setColumn(2,z);

   // based on new rotation, adjust wheels (and possibly whole
   // car) based on wheel offsets...
   // get both outer and inner wheels this time...
   getWheelOffsets(mat,woff,0,totalWheels());

   // make sure none of the wheels are now under ground
   for (i=0;i<totalWheels();i++)
   {
      if (woff[i]<-wheelRange[i])
      {
         // wheel under ground, shift tank up
         F32 delta = woff[i]+wheelRange[i];
         for (S32 j=0; j<totalWheels(); j++)
            woff[j]-=delta;
         pos -= delta * z;
      }
   }

   // if all inner springs are negative, adjust up
   F32 maxZ = -100.0f;
   for (i=numInnerWheels();i<totalWheels();i++)
      if (woff[i]>maxZ)
         maxZ = woff[i];
   if (maxZ < 0.0f)
   {
      for (i=0;i<totalWheels();i++)
         woff[i] -= maxZ;
      pos -= maxZ * z;
   }

   // set wheel springs in order to put wheel on ground, if possible...
   for (i=0;i<numInnerWheels();i++)
   {
      if (woff[i]>wheelRange[i])
         woff[i] = wheelRange[i];
   }
   deltaHelper.setWheelSpring(woff);

   // pos might have been changed above...
   // ...change rot now
   rot.set(mat);
   rot.normalize();
   mat.setColumn(3,pos);

   // contact information...
   bool contact[TankShapeData::MaxInnerWheels+4];
   mContact=false;
   mFullContact=true;
   for (i=0; i<totalWheels(); i++)
   {
      contact[i] = woff[i]<wheelRange[i]*0.75f;
      mContact |= contact[i];
      if (i>=numInnerWheels())
         mFullContact &= contact[i];
   }

   // check to see if center of mass is supported...
   bool frontSupport = false;
   bool backSupport = false;
   for (i=0; i<totalWheels(); i++)
   {
      if (!contact[i])
         continue;
      if (getDataBlock()->wheelPos[i].y>0)
         frontSupport = true;
      else
         backSupport = true;
   }
   bool cmSupport = frontSupport && backSupport;

   // handle wheel drop velocity -- this is what
   // gives vehicle angular rotation
   if (mFullContact)
   {
      for (i=0;i<4;i++)
         mWheelDropVel[i] = 0.0f;
   }
   else if (cmSupport)
   {
      for (i=0; i<4;i++)
      {
         if (!contact[i+numInnerWheels()])
            mWheelDropVel[i] *= 0.9f; // slow it down...TODO: fix magic number
         else
            mWheelDropVel[i] = 0;
      }
   }
   else if (mContact)
   {
      for (i=0;i<4;i++)
      {
         if (!contact[i+numInnerWheels()])
            mWheelDropVel[i] += sGravity * TickSec;
         else
            mWheelDropVel[i] = 0;
      }
   }
   if (cmSupport || mContact)
   {
      // keep from twisting
      F32 wdv0 = (1.0f - sWheelDropSmoothTwist) * mWheelDropVel[0] + sWheelDropSmoothTwist * mWheelDropVel[3];
      F32 wdv1 = (1.0f - sWheelDropSmoothTwist) * mWheelDropVel[1] + sWheelDropSmoothTwist * mWheelDropVel[2];
      F32 wdv2 = (1.0f - sWheelDropSmoothTwist) * mWheelDropVel[2] + sWheelDropSmoothTwist * mWheelDropVel[1];
      F32 wdv3 = (1.0f - sWheelDropSmoothTwist) * mWheelDropVel[3] + sWheelDropSmoothTwist * mWheelDropVel[0];
      mWheelDropVel[0] = wdv0;
      mWheelDropVel[1] = wdv1;
      mWheelDropVel[2] = wdv2;
      mWheelDropVel[3] = wdv3;
   }
}

//-----------------------------------------------------------
// Function name:  TankShape::updateCollisionSound
// Summary:
//-----------------------------------------------------------
void TankShape::updateCollisionSound()
{
   // handle collision sound...figure out if we hit something and what it was
   // and figure out which sound to play in response.
   AudioProfile * playSound = NULL;
   U32 * setTime = NULL;
   U32 t = Platform::getVirtualMilliseconds();
   F32 dv2 = mDot(mVelocity-smStartVelocity,mVelocity-smStartVelocity);
   if ((smCollisionMask & HitTank) && t-mLastTankCollTime > getDataBlock()->fx->tankCollISI)
   {
      if (dv2 > getDataBlock()->fx->hardTankCollVel * getDataBlock()->fx->hardTankCollVel)
      {
         playSound  = getDataBlock()->fx->hardTankCollSound;
         setTime = &mLastTankCollTime;
      }
      else if (dv2 > getDataBlock()->fx->softTankCollVel * getDataBlock()->fx->softTankCollVel)
      {
         playSound  = getDataBlock()->fx->softTankCollSound;
         setTime = &mLastTankCollTime;
      }
   }
   else if ((smCollisionMask & HitStatic) && t-mLastStaticCollTime > getDataBlock()->fx->staticCollISI)
   {
      if (dv2 > getDataBlock()->fx->hardStaticCollVel * getDataBlock()->fx->hardStaticCollVel)
      {
         playSound  = getDataBlock()->fx->hardStaticCollSound;
         setTime = &mLastStaticCollTime;
      }
      else if (dv2 > getDataBlock()->fx->softStaticCollVel * getDataBlock()->fx->softStaticCollVel)
      {
         playSound  = getDataBlock()->fx->softStaticCollSound;
         setTime = &mLastStaticCollTime;
      }
   }
   else if ((mContact && !(smCollisionMask & WasContact)) && t-mLastGroundCollTime > getDataBlock()->fx->groundCollISI)
   {
      // ground sound based on downward start velocity not delta velocity
      F32 v2 = mFabs(smStartVelocity.z);
      if (v2 > getDataBlock()->fx->hardGroundCollVel)
      {
         playSound  = getDataBlock()->fx->hardGroundCollSound;
         setTime = &mLastGroundCollTime;
      }
      else if (v2 > getDataBlock()->fx->softGroundCollVel)
      {
         playSound  = getDataBlock()->fx->softGroundCollSound;
         setTime = &mLastGroundCollTime;
      }
   }

   if (playSound && setTime)
   {
      alxPlay(playSound,&getTransform());
      *setTime = t;
   }
}

//-----------------------------------------------------------
// Function name:  TankShape::updateEngineSound
// Summary:
//-----------------------------------------------------------
void TankShape::updateEngineSound(bool play)
{
   if (!play)
   {
      // make sure engine sound is cancled...
      if (mEngineSoundA != NULL_AUDIOHANDLE)
         alxStop(mEngineSoundA);
      if (mEngineSoundB != NULL_AUDIOHANDLE)
         alxStop(mEngineSoundB);
      mEngineSoundA = mEngineSoundB = NULL_AUDIOHANDLE;
      return;
   }

   if (!getDataBlock()->fx->engineSoundA && !getDataBlock()->fx->engineSoundB)
      return;

   if (getDataBlock()->fx->engineSoundA && mEngineSoundA == NULL_AUDIOHANDLE)
      mEngineSoundA = alxPlay(getDataBlock()->fx->engineSoundA,&getTransform());
   if (getDataBlock()->fx->engineSoundB && mEngineSoundB == NULL_AUDIOHANDLE)
      mEngineSoundB = alxPlay(getDataBlock()->fx->engineSoundB,&getTransform());

   Point3F x,y;
   getTransform().getColumn(0,&x);
   getTransform().getColumn(1,&y);
   F32 k = mFabs(mDot(y,mVelocity)) + 0.25f * mFabs(mDot(x,mVelocity));
   k /= getDataBlock()->maxSpeed;
   if (mTurn*mTurn>0.5f && k<0.5f)
      k = 0.5f;
   if (!mContact)
      k *= 1.25f;
   k = mClampF(k,0,1.5f);
   mEngineAmp = 0.9f * mEngineAmp + 0.1f * k;

   F32 pa = getDataBlock()->fx->enginePitchA0 + mEngineAmp * (getDataBlock()->fx->enginePitchA1-getDataBlock()->fx->enginePitchA0);
   F32 pb = getDataBlock()->fx->enginePitchB0 + mEngineAmp * (getDataBlock()->fx->enginePitchB1-getDataBlock()->fx->enginePitchB0);
   F32 va = getDataBlock()->fx->engineVolA0 + mEngineAmp * (getDataBlock()->fx->engineVolA1-getDataBlock()->fx->engineVolA0);
   F32 vb = getDataBlock()->fx->engineVolB0 + mEngineAmp * (getDataBlock()->fx->engineVolB1-getDataBlock()->fx->engineVolB0);

   if (alxIsValidHandle(mEngineSoundA))
   {
      alxSourceMatrixF(mEngineSoundA, &getTransform());
      alxSourcef(mEngineSoundA,AL_PITCH,pa);
      alxSourcef(mEngineSoundA,AL_GAIN_LINEAR,va);
   }
   if (alxIsValidHandle(mEngineSoundB))
   {
      alxSourceMatrixF(mEngineSoundB, &getTransform());
      alxSourcef(mEngineSoundB,AL_PITCH,pb);
      alxSourcef(mEngineSoundB,AL_GAIN_LINEAR,vb);
   }
}

//-----------------------------------------------------------
// Function name:  TankShape::interpolateTick
// Summary:        Interpolate between prev tick location and
//                 next.  A backdelta of 1 corresponds to
//                 prev tick location.  A back delta of 0
//                 corresponds to next.  This is a client-side
//                 only method.
//-----------------------------------------------------------
void TankShape::interpolateTick(F32 backDelta)
{
   deltaHelper.setBackDelta(backDelta);

   Point3F pos = deltaHelper.getPos();
   QuatF   rot = deltaHelper.getRot();

   setRenderPosition(pos,rot);

   updateAnimation();
}

//-----------------------------------------------------------
// Function name:  TankShape::setPosition
// Summary:        More convenient way to set transform on
//                 tank than setTransform.
//-----------------------------------------------------------
void TankShape::setPosition(const Point3F &pos, const QuatF &rot)
{
   MatrixF mat;
   rot.setMatrix(&mat);
   mat.setColumn(3,pos);
   // call parent setTransform because we don't want to
   // interupt the deltaHelper settings
   Parent::setTransform(mat);
}

//-----------------------------------------------------------
// Function name:  TankShape::setRenderPosition
// Summary:        More convenient way to set render transform
//                 on tank than setRenderTransform.
//-----------------------------------------------------------
void TankShape::setRenderPosition(const Point3F &pos, const QuatF &rot)
{
   MatrixF mat;
   rot.setMatrix(&mat);
   mat.setColumn(3,pos);
   setRenderTransform(mat);
}

//-----------------------------------------------------------
// Function name:  TankShape::getMuzzleTransform
// Summary:
//-----------------------------------------------------------
void TankShape::getMuzzleTransform(MatrixF * mat)
{
   *mat = getTransform();
   // make sure tank is animated...
   // ...then grab muzzle transform
   updateAnimation(true);

   mat->mul(mShapeInstance->mNodeTransforms[getDataBlock()->muzzleNode]);
}

//-----------------------------------------------------------
// Function name:  TankShape::stickToGround
// Summary:        Find ground height at x,y position of
//                 passed 'pos' and set 'pos.z' to height.
//-----------------------------------------------------------
void TankShape::stickToGround(Point3F & pos, QuatF & rot)
{
   MatrixF mat;
   rot.setMatrix(&mat);
   goTowardGround(pos,getConformToMask());
   mat.setColumn(3,pos);

   updateTerrainCollision(pos,rot,mat);
}

//-----------------------------------------------------------
// Function name:  TankShape::goTowardGround
// Summary:        Find highest object at x,y position of
//                 passed 'pos' and set 'pos.z' to height.
//-----------------------------------------------------------
void TankShape::goTowardGround(Point3F & pos, const U32 mask)
{
   Point3F z;
   getTransform().getColumn(2,&z);

   RayInfo coll;
   Point3F start = pos;
   Point3F end   = pos;
   //start.z += sZFudgeForCastRay;
   start.z += getDataBlock() ? getDataBlock()->maxStepHeight : 0;
   end.z   -= sZFudgeForCastRay;
   if (mContainer && mContainer->castRay(start,end,mask, &coll))
   {
      // don't climb interior walls and don't climb interior "insides"
      bool isTerr = coll.object && (coll.object->getTypeMask() & TerrainObjectType);
      bool isItr  = coll.object && (coll.object->getTypeMask() & InteriorObjectType);
      if (!isItr || coll.face != -1)
         pos.z = coll.point.z;
   }
   else
      pos.z = end.z;
   // Note: if we don't intersect anything, leave it alone
}

//-----------------------------------------------------------
// Function name:  setBoost
// Summary:        Apply boost over so many ticks.
//-----------------------------------------------------------
void TankShape::setBoost(const Point3F & boostVel)
{
   if (mBoostTicks)
      return;
   mBoostVel = boostVel/getDataBlock()->misc->boostTicks;
   mBoostTicks = 2*getDataBlock()->misc->boostTicks;
   AssertFatal(mDot(mBoostVel,mBoostVel)<=MAX_BOOST_VEL*MAX_BOOST_VEL,"TankShape::setBoost: boost velocity too high -- increase max");
   mWheelDropVel[0] = mWheelDropVel[1] = mWheelDropVel[2] = mWheelDropVel[3] = 0;
   setMaskBits(BoostMask);
}

//-----------------------------------------------------------
// Function name:  TankShape::packUpdate
// Summary:        Pack data into bitstream for transmission
//                 to client.  Use mask to determine which
//                 update flags are set and only update what
//                 needs updating.  Check for
//                 GameBase::InitialUpdateMask to determine
//                 if this is initial update (in which case
//                 onAdd has not been called yet).  Return
//                 value indicates what flags still need
//                 updating.  So a return value of 0 means
//                 all data is up to date.  (On initial
//                 update, return value always treated as
//                 zero).
//-----------------------------------------------------------
U32 TankShape::packUpdate(NetConnection * con, U32 mask, BitStream * stream)
{
   U32 retMask = Parent::packUpdate(con,mask,stream);

   bool isntControl = getControllingClient()!=(GameConnection*)con;

   // We need to do a move update if mask bit is set, unless  this is the
   // controlling cient, in which case that information is sent in readPacket.
   bool doMove = mask & MoveMask;
   doMove &= isntControl;
   doMove |= ((mask & InitialUpdateMask)!=0);

   if (stream->writeFlag(mask&InitialUpdateMask))
   {
   }

   if (stream->writeFlag(doMove))
   {
      Point3F pos;
      QuatF rot;

      // we're on the server so the deltaHelper should match our transform
      // more convenient to get it right out of here, though
      pos  = deltaHelper.getPos();
      rot  = deltaHelper.getRot();

      stream->writeCompressedPoint(pos);

      // write rotation by writing x,y,z as vector, then writing sign of w
      Point3F rotxyz(rot.x,rot.y,rot.z);

      F32 lensq = mDot(rotxyz,rotxyz);
      if (stream->writeFlag(lensq>0.001f))
      {
         stream->write(rot.x);
         stream->write(rot.y);
         stream->write(rot.z);
         stream->writeFlag(rot.w<0.0f);
      }
      F32 vel = mVelocity.len();
      if (stream->writeFlag(vel > MIN_NET_VEL))
      {
         stream->write(mVelocity.x);
         stream->write(mVelocity.y);
         stream->write(mVelocity.z);
      }

      if (stream->writeFlag(mFabs(mTurn)>0.5f))
         stream->writeFlag(mTurn>0.5f);
      if (stream->writeFlag(mFabs(mMovy)>0.5f))
         stream->writeFlag(mMovy>0.5f);
      if (!stream->writeFlag(mFullContact))
      {
         stream->writeFlag(mContact);
         stream->writeSignedFloat(mWheelDropVel[0]/MAX_WHEEL_DROP_MAG,WHEEL_DROP_BITS);
         stream->writeSignedFloat(mWheelDropVel[1]/MAX_WHEEL_DROP_MAG,WHEEL_DROP_BITS);
         stream->writeSignedFloat(mWheelDropVel[2]/MAX_WHEEL_DROP_MAG,WHEEL_DROP_BITS);
         stream->writeSignedFloat(mWheelDropVel[3]/MAX_WHEEL_DROP_MAG,WHEEL_DROP_BITS);
      }
   }

   // turret mask?
   bool doTurret = mask & TurretMask;
   doTurret &= isntControl;
   doTurret |= ((mask & InitialUpdateMask)!=0);
   if (stream->writeFlag(doTurret))
   {
      F32 thor = deltaHelper.getTurretHor();
      F32 tver = deltaHelper.getTurretVer();
      mClampF(thor,-1.0f,1.0f);
      mClampF(tver,-1.0f,1.0f);
      stream->writeSignedFloat(thor,THOR_BITS);
      stream->writeSignedFloat(tver,TVER_BITS);
   }

   return retMask;
}

//-----------------------------------------------------------
// Function name:  TankShape::unpackUpdate
// Summary:        Unpack data from bitstream.  Inverse of
//                 'packUpdate'.  Objects created over the net
//                 are created by first instantiating them
//                 (calling the constructor), then unpacking
//                 the data stream that was packed by the
//                 server, and then calling onAdd (so first
//                 call to unpack will be on unadded objects.
//-----------------------------------------------------------
void TankShape::unpackUpdate(NetConnection * con, BitStream * stream)
{
   Parent::unpackUpdate(con,stream);

   bool initial = stream->readFlag();
   if (initial)
   {
   }

   // move mask?
   if (stream->readFlag())
   {
      Point3F pos;
      QuatF rot;

      stream->readCompressedPoint(&pos);

      // read rotation
      if (stream->readFlag())
      {
         stream->read(&rot.x);
         stream->read(&rot.y);
         stream->read(&rot.z);
         rot.w = 1.0f-rot.x*rot.x-rot.y*rot.y-rot.z*rot.z;
         if (rot.w>0.0f)
            rot.w = mSqrt(rot.w);
         else
            rot.w = 0.0f;
         if (stream->readFlag())
            rot.w *= -1.0f;
      }
      else
      {
         // trivial (illegal?) case
         rot.set(0,0,0,1);
      }

      // read velocity
      if (stream->readFlag())
      {
         stream->read(&mVelocity.x);
         stream->read(&mVelocity.y);
         stream->read(&mVelocity.z);
      }
      else
      {
         mVelocity.set(0,0,0);
      }

      // turn...
      if (stream->readFlag())
         mTurn = stream->readFlag() ? 1.0f : -1.0f;
      else
         mTurn = 0.0f;

      // move->y
      if (stream->readFlag())
         mMovy = stream->readFlag() ? 1.0f : -1.0f;
      else
         mMovy = 0.0f;

      if (!stream->readFlag())
      {
         mFullContact = false;
         mContact = stream->readFlag();
         mWheelDropVel[0] = MAX_WHEEL_DROP_MAG * stream->readSignedFloat(WHEEL_DROP_BITS);
         mWheelDropVel[1] = MAX_WHEEL_DROP_MAG * stream->readSignedFloat(WHEEL_DROP_BITS);
         mWheelDropVel[2] = MAX_WHEEL_DROP_MAG * stream->readSignedFloat(WHEEL_DROP_BITS);
         mWheelDropVel[3] = MAX_WHEEL_DROP_MAG * stream->readSignedFloat(WHEEL_DROP_BITS);
      }
      else
      {
         mFullContact = mContact = true;
         mWheelDropVel[0] = mWheelDropVel[1] = mWheelDropVel[2] = mWheelDropVel[3] = 0.0f;
      }

      if (!deltaHelper.nextTick(pos,rot,mVelocity) || initial)
         setPosition(pos,rot);
   }

   // turret mask?
   if (stream->readFlag())
   {
      F32 th = stream->readSignedFloat(THOR_BITS);
      F32 tv = stream->readSignedFloat(TVER_BITS);
      deltaHelper.setTurret(th,tv);
   }
}

//-----------------------------------------------------------
// Function name:  TankShape::writePacketData
// Summary:        Privileged data transfer between server
//                 and controlling object on the client,
//                 typically the player.  In T2, player object
//                 writes exact position in this routine, and
//                 client player moves there immediately
//                 without interpolation!  Not sure why there
//                 isn't a warping problem, but that's the
//                 way it is done.  Return value is ignored,
//                 so I have no idea what it is supposed to be.
//-----------------------------------------------------------
void TankShape::writePacketData(GameConnection * conn, BitStream *stream)
{
   Parent::writePacketData(conn,stream);

   Point3F pos;
   QuatF rot;

   // we're on the server so the deltaHelper should match our transform
   // more convenient to get it right out of here, though
   pos  = deltaHelper.getPos();
   rot = deltaHelper.getRot();

   // control client should always set a compression point, which
   // will be used for writing compressed points by all the packUpdates...
   // ...just be sure to set it to the same value on the readPacketData
   stream->setCompressionPoint(pos);
   stream->write(pos.x);
   stream->write(pos.y);
   stream->write(pos.z);
   stream->write(rot.x);
   stream->write(rot.y);
   stream->write(rot.z);
   stream->writeFlag(rot.w<0.0f);
   stream->write(mVelocity.x);
   stream->write(mVelocity.y);
   stream->write(mVelocity.z);

   // use a little compression for turret...
   F32 thor = deltaHelper.getTurretHor();
   F32 tver = deltaHelper.getTurretVer();
   mClampF(thor,-1.0f,1.0f);
   mClampF(tver,-1.0f,1.0f);
   stream->writeSignedFloat(thor,THOR_OWN_BITS);
   stream->writeSignedFloat(tver,TVER_OWN_BITS);

   if (stream->writeFlag(mFabs(mTurn)>0.5f))
      stream->writeFlag(mTurn>0.5f);

   if (stream->writeFlag(mFabs(mMovy)>0.5f))
      stream->writeFlag(mMovy>0.5f);

   if (!stream->writeFlag(mFullContact))
   {
      stream->writeFlag(mContact);
      stream->writeSignedFloat(mWheelDropVel[0]/MAX_WHEEL_DROP_MAG,WHEEL_DROP_BITS);
      stream->writeSignedFloat(mWheelDropVel[1]/MAX_WHEEL_DROP_MAG,WHEEL_DROP_BITS);
      stream->writeSignedFloat(mWheelDropVel[2]/MAX_WHEEL_DROP_MAG,WHEEL_DROP_BITS);
      stream->writeSignedFloat(mWheelDropVel[3]/MAX_WHEEL_DROP_MAG,WHEEL_DROP_BITS);
   }
}

//-----------------------------------------------------------
// Function name:  TankShape::readPacketData
// Summary:        Privileged data transfer between server
//                 and controlling object on the client,
//                 typically the player.  In T2, player object
//                 writes exact position in this routine, and
//                 client player moves there immediately
//                 without interpolation!  Not sure why there
//                 isn't a warping problem, but that's the
//                 way it is done.
//-----------------------------------------------------------
void TankShape::readPacketData(GameConnection * conn, BitStream *stream)
{
   Parent::readPacketData(conn,stream);

   Point3F pos;
   QuatF rot;
   F32 th,tv; // turret

   stream->read(&pos.x);
   stream->read(&pos.y);
   stream->read(&pos.z);
   stream->read(&rot.x);
   stream->read(&rot.y);
   stream->read(&rot.z);
   rot.w = 1.0f-rot.x*rot.x-rot.y*rot.y-rot.z*rot.z;
   if (rot.w>0.0f)
      rot.w = mSqrt(rot.w);
   else
      rot.w = 0.0f;
   if (stream->readFlag())
      rot.w *= -1.0f;
   stream->read(&mVelocity.x);
   stream->read(&mVelocity.y);
   stream->read(&mVelocity.z);

   th = stream->readSignedFloat(THOR_OWN_BITS);
   tv = stream->readSignedFloat(TVER_OWN_BITS);

   if (stream->readFlag())
      mTurn = stream->readFlag() ? 1.0f : -1.0f;
   else
      mTurn = 0.0f;

   if (stream->readFlag())
      mMovy = stream->readFlag() ? 1.0f : -1.0f;
   else
      mMovy = 0.0f;

   if (!stream->readFlag())
   {
      mFullContact = false;
      mContact = stream->readFlag();
      mWheelDropVel[0] = MAX_WHEEL_DROP_MAG * stream->readSignedFloat(WHEEL_DROP_BITS);
      mWheelDropVel[1] = MAX_WHEEL_DROP_MAG * stream->readSignedFloat(WHEEL_DROP_BITS);
      mWheelDropVel[2] = MAX_WHEEL_DROP_MAG * stream->readSignedFloat(WHEEL_DROP_BITS);
      mWheelDropVel[3] = MAX_WHEEL_DROP_MAG * stream->readSignedFloat(WHEEL_DROP_BITS);
   }
   else
   {
      mFullContact = mContact = true;
      mWheelDropVel[0] = mWheelDropVel[1] = mWheelDropVel[2] = mWheelDropVel[3] = 0.0f;
   }

   stream->setCompressionPoint(pos);

   deltaHelper.setControlData(pos,rot);
   setPosition(pos,rot);

   deltaHelper.setTurret(th,tv);
}

//-----------------------------------------------------------
// Function name:  TankShape::getVelocity
// Summary:        Return velocity of object.  Used by
//                 GameBase method getUpdatePriority for
//                 calculating network priority.  We are
//                 responsible for tracking our own velocity,
//                 but if we simply call parent a zero
//                 velocity is returned with no harmful
//                 side-effects.
//-----------------------------------------------------------
Point3F TankShape::getVelocity() const
{
   return mVelocity;
}

//-----------------------------------------------------------
// Function name:  TankShape::setVelocity
// Summary:        Change velocity of object.  Velocity is
//                 Used by GameBase method getUpdatePriority
//                 for calculating network priority.  If we
//                 want to track velocity, we need to save it
//                 ourselves.  If we want to ignore velocity
//                 simply use parent method.
//-----------------------------------------------------------
void TankShape::setVelocity(const Point3F & vel)
{
   mVelocity = vel;
}

//-----------------------------------------------------------
// Function name:  TankShape::getCameraTransform
// Summary:        Put camera matrix into 'mat' using '*pos'
//                 between 0 and 1.  A value of 0 means
//                 first person camera whereas 1 means third
//                 person.  Optionally, object can ignore
//                 pos and always return whatever it wants.
//                 First versus third person is tracked by
//                 game on the game connection.  This
//                 method is called when this object is the
//                 clients control object (usually the player
//                 but can also be a Camera object -- see
//                 camera.h and camera.cc).
//-----------------------------------------------------------
void TankShape::getCameraTransform(F32* pos,MatrixF* mat)
{
   // track last mode -- see code for details...a little kooky
   static bool altMode = false;
   static F32 altMultiplier = 1.0f;
   if (pos && *pos>0.5f && !altMode)
      altMultiplier *= -1.0f;
   altMode = pos && *pos>0.5f;

   // matrix not always properly initialized at this point
   // set to identity in order to get rid of junk in unused
   // part of matrix
   mat->identity();

   // if time step too big, warp camera position
   // otherwise, perform smoothing operation on camera...
   U32 deltaTime = Platform::getVirtualMilliseconds()-mPrevCameraTime;
   F64 k = (F64)(deltaTime)/sCameraSmoothTime;
   bool doWarp = deltaTime>sCameraWarpTime;

   // back up camera -- use x & z to get y
   // smooth on x,z, and p
   Point3F p,x,y,z;
   getRenderTransform().getColumn(0,&x);
   getRenderTransform().getColumn(2,&z);
   getRenderTransform().getColumn(3,&p);
   if (doWarp)
   {
      // just grab y from matrix
      getRenderTransform().getColumn(1,&y);
   }
   else
   {
      // smooth out x & z, then generate y

      // do quick and dirty vector averages...
      F32 smoothX = exp(k*log((F64)mClampF(getDataBlock()->camera->camSmoothTurn,0.1f,1.0f)));
      x = smoothX * mPrevCameraX + (1.0f-mClampF(smoothX,0.0f,1.0f)) * x;
      if (mDot(x,x)>0.0001f)
         x.normalize();
      else
         // oops, recover gracefully...
         getRenderTransform().getColumn(0,&x);
      F32 smoothZ = exp(k*log((F64)mClampF(getDataBlock()->camera->camSmoothUp,0.1f,1.0f)));
      z = smoothZ * mPrevCameraZ + (1.0f-mClampF(smoothZ,0.0f,1.0f)) * z;
      if (mDot(z,z)>0.01f)
         z.normalize();
      else
         // oops, recover gracefully...
         getRenderTransform().getColumn(2,&z);

      mCross(z,x,&y);
      if (mDot(y,y)>0.01f)
         y.normalize();
      else
         // oops, recover gracefully...
         getRenderTransform().getColumn(1,&y);
   }
   mPrevCameraX = x;
   mPrevCameraZ = z;

   Point3F lookat = p;
   lookat += y * getDataBlock()->camera->camFocusDist; // focus this many meters out
   lookat.z += getDataBlock()->camera->camFocusUpDist;   // focus this many meters up

   Point3F cam = p;
   cam -= getDataBlock()->camera->camBackupDist * y;

   // try a different camera view -- side view
   if (altMode)
   {
      cam = p;
      cam += altMultiplier * getDataBlock()->camera->camBackupDist * mPrevCameraX;
      lookat = p;
   }

   // adjust z so that it doesn't go under ground
   // and floats a certain distance above tank's
   // orientation plane...
   F32 saveZ = cam.z;
   goTowardGround(cam,sCameraCollisionMask);
   cam.z = getMax(cam.z,saveZ);
   cam.z += getDataBlock()->camera->camFloatHeight; // hang out this many meters above the ground behind the tank

   if (altMode)
      // over-ride this from side view and hard-code new value
      cam.z -= getDataBlock()->camera->camFloatHeight - 3.0f;

   // above we "warped" if too much time had passed...warp also if position step too big...
   // otherwise, perform smoothing operation on camera...
   Point3F deltaPos = cam-mPrevCameraPos;
   doWarp |= mDot(deltaPos,deltaPos)>sCameraWarpDistance*sCameraWarpDistance;
   if (!doWarp)
   {
      // Apply camera smoothing...but in frame-rate independent manner
      // (this function called once per frame, so must pay attention
      // to deltaTime).  The smooth factor from the datablock is normalized
      // to occur over a duration determined by sCameraSmoothTime.
      F32 smoothFactor = exp(k*log((F64)mClampF(getDataBlock()->camera->camSmooth,0.1f,1.0f)));
      // Perform the smooth using exponential average (weighted sum of old and new).
      cam = smoothFactor * mPrevCameraPos + (1.0f-mClampF(smoothFactor,0.0f,1.0f)) * cam;
   }
   mPrevCameraPos = cam;
   mPrevCameraTime = Platform::getVirtualMilliseconds();

   Point3F look = lookat-cam;
   look.normalize(); // take our chances with an exception here...

   Point3F up,left;
   mCross(look,Point3F(0,0,1),&left);
   left.normalize(); // take our chances with an exception here...
   mCross(left,look,&up);

   // now set materix
   mat->setColumn(0,left);
   mat->setColumn(1,look);
   mat->setColumn(2,up);
   mat->setColumn(3,cam);
}

//------------------------------------------
// SceneObject derived methods
//------------------------------------------

//-----------------------------------------------------------
// Function name:  TankShape::setTransform
// Summary:        Sets the transform (sans scale) of the
//                 object.  Almost always handled entirely
//                 by SceneObject.
//                 Note1: to find current value call
//                        getTransform.
//                 Note2: as implemented here, this method
//                        should never be called except to
//                        initialize the object.  The reason
//                        for this is that when this object
//                        is created in script, the first
//                        thing that happens after the
//                        object is created is the transform
//                        gets set (via this method).  At
//                        that time, the deltaHelper needs to
//                        be initialized with new values.
//                        Better way?  If you want to set
//                        the transform for another reason,
//                        use setPosition.
//-----------------------------------------------------------
void TankShape::setTransform(const MatrixF & mat)
{
   Point3F pos;
   QuatF rot;
   if (!gEditingMission)
   {
      // restrict initial transform
      Point3F x,y,z;
      mat.getColumn(1,&y);
      mat.getColumn(3,&pos);
      if (y.z*y.z>0.9f)
         y.set(0,1,0);
      y.z=0;
      y.normalize();
      z.set(0,0,1);
      mCross(y,z,&x);
      MatrixF mat2(true);
      mat2.setColumn(0,x);
      mat2.setColumn(1,y);
      mat2.setColumn(2,z);
      mat2.setColumn(3,pos);
   
      // clear drop velocity
      for (S32 j=0;j<4;j++)
         mWheelDropVel[j] = 0.0f;
   
      // stick to ground
      rot.set(mat2);
      stickToGround(pos,rot);
      rot.setMatrix(&mat2);
      mat2.setColumn(3,pos);

      // call parent method to set the transform variable
      Parent::setTransform(mat2);
   }
   else
   {
      mat.getColumn(3,&pos);
      rot.set(mat);
      Parent::setTransform(mat);
   }

   // set up deltaHelper...
   deltaHelper.init(pos,rot);   
}

//-----------------------------------------------------------
// Function name:  TankShape::castRay
// Summary:        Perform line of sight check.  Should return
//                 true if the line intersects the object,
//                 false otherwise.  Should also fill out
//                 RayInfo structure, filling in data for
//                 closest collision.  Here, we cast ray
//                 against bounding box (which also happens
//                 to be body of the tank).
//-----------------------------------------------------------
bool TankShape::castRay(const Point3F &start, const Point3F &end, RayInfo* info)
{
   if (getDataBlock()->numCollDetails)
   {
      RayInfo shortest;
      shortest.t = 1e8;

      info->object = NULL;
      for (U32 i = 0; i < getDataBlock()->numCollDetails; i++)
      {
         mShapeInstance->animate(getDataBlock()->collDetails[i]);
         if (mShapeInstance->castRay(start, end, info, getDataBlock()->collDetails[i]))
         {
            info->object = this;
            if (info->t < shortest.t)
               shortest = *info;
         }
      }

      if (info->object == this)
      {
         // Copy out the shortest time...
         *info = shortest;
         return true;
      }

      return false;
   }
   else
      return SceneObject::collideBox(start,end,info);
}

void TankShape::updateAnimation(bool muzzleOnly)
{
   // set turret...
   S32 node = getDataBlock()->turretNode;
   MatrixF * mat = &mShapeInstance->mNodeTransforms[node];
   Point3F defaultPos = getDataBlock()->shapeResource->defaultTranslations[node];
   F32 turretH = getTurretHor();
   mat->set(EulerF(0,0,turretH));
   mat->setColumn(3,defaultPos);

   // set weapon...
   node = getDataBlock()->weaponNode;
   mat = &mShapeInstance->mNodeTransforms[node];
   defaultPos = getDataBlock()->shapeResource->defaultTranslations[node];
   F32 turretV = getTurretVert();
   mat->set(EulerF(turretV,0,0));
   mat->setColumn(3,defaultPos);

   if (isClientObject())
   {
      if (muzzleOnly)
      {
         // tank suspension...
         node = getDataBlock()->suspensionNode;
         mat = &mShapeInstance->mNodeTransforms[node];
         defaultPos = getDataBlock()->shapeResource->defaultTranslations[node];
         mat->identity();
         mat->setColumn(3,defaultPos);
      }
      else
      {
         S32 i;

         // wheel suspension...
         for (i=0; i<numInnerWheels(); i++)
         {
            node = getDataBlock()->wheelNode[i];
            mat = &mShapeInstance->mNodeTransforms[node];
            defaultPos = getDataBlock()->shapeResource->defaultTranslations[node];
            defaultPos.z -= getWheelPos(i);
            mat->identity();
            mat->setColumn(3,defaultPos);
         }

         // wheel rotations...
         for (i=0; i<totalWheels(); i++)
         {
            node = getDataBlock()->wheelRotNode[i];
            mat = &mShapeInstance->mNodeTransforms[node];
            F32 dist;
            bool onRight = false;
            if (i >= numInnerWheels())
            {
               if (i < numInnerWheels()+2)
                  onRight = true;
            }
            else
            {
               if ( i<(numInnerWheels()/2) )
                  onRight = true;
            }
            if ( onRight )
               dist = -deltaHelper.getRTread();
            else
               dist = -deltaHelper.getLTread();
            mat->set(EulerF(dist/getDataBlock()->wheelRadius[i],0,0),getDataBlock()->shapeResource->defaultTranslations[node]);
         }

         // tank suspension...
         node = getDataBlock()->suspensionNode;
         mat = &mShapeInstance->mNodeTransforms[node];
         defaultPos = getDataBlock()->shapeResource->defaultTranslations[node];
         defaultPos.z -= mTankSpringPos.z;
         Point3F z = mTankSpringPos;
         z.z=1.0f;
         z.normalize();
         Point3F x,y;
         mCross(Point3F(0,1,0),z,&x);
         x.normalize();
         mCross(z,x,&y);

         mat->setColumn(0,x);
         mat->setColumn(1,y);
         mat->setColumn(2,z);
         mat->setColumn(3,defaultPos);

         mShapeInstance->setPos(mLTreadThread,fmod(1.0f-deltaHelper.getLTread()*getDataBlock()->lTreadSeqScale,1.0f));
         mShapeInstance->setPos(mRTreadThread,fmod(1.0f-deltaHelper.getRTread()*getDataBlock()->rTreadSeqScale,1.0f));
      }
   }

   mShapeInstance->setDirty(TSShapeInstance::TransformDirty);
   mShapeInstance->animate();
}

//-----------------------------------------------------------
// Function name:  TankShape::DeltaHelper::init
// Summary:        Initialize DeltaHelper.  Setup so that
//                 our parameters are set as designated and
//                 so that no interpolation is occuring.
//-----------------------------------------------------------
void TankShape::DeltaHelper::init(const Point3F & p, const QuatF & r)
{
   rot=r;
   rotStep.set(0,0,0,0);

   pos=p;
   posStep.set(0,0,0);

   turretHor = 0.0f;
   turretHorStep = 0.0f;

   turretVer = 0.0f;
   turretVerStep = 0.0f;

   for (S32 i=0;i<4;i++)
      wheelSpring[i] = wheelSpringStep[i] = 0;

   LTreadDist = 0;
   LTreadDistStep = 0;

   RTreadDist = 0;
   RTreadDistStep = 0;

   backDelta=1.0f;
   next = false;
}

//-----------------------------------------------------------
// Function name:  TankShape::DeltaHelper::doTick
// Summary:        Checks to see if next interpolation is
//                 ready.  If so, set it up.  Return value
//                 indicates whether interpolation (warp)
//                 was set up.
//-----------------------------------------------------------
bool TankShape::DeltaHelper::doTick()
{
   if (next)
   {
      // set up interpolation so that backDelta of
      // 1 returns current, 0 returns next

      posStep = pos-posNext;
      pos = posNext;

      rotStep.x = rot.x-rotNext.x;
      rotStep.y = rot.y-rotNext.y;
      rotStep.z = rot.z-rotNext.z;
      rotStep.w = rot.w-rotNext.w;
      rot = rotNext;

      // no need to touch turret because it's configured
      // to always have the most recent data at the end of
      // a tick...just turn off step...
      turretHorStep = 0.0f;
      turretVerStep = 0.0f;

      next = false;
      backDelta = 1.0f;

      return true;
   }
   return false;
}

//-----------------------------------------------------------
// Function name:  TankShape::DeltaHelper::nextTick
// Summary:        Set up for next tick.  Velocity is passed
//                 to determine how we need to handle data.
//                 If we are close to the updated position
//                 already (where "close" is based on
//                 velocity) then just adjust current tick.
//                 If we aren't, set up interpolation on
//                 next tick.  Note that everything is based
//                 on position (i.e., rot adjusts as pos does).
//                 Return true if next tick set up, return false
//                 if handled this tick.
//-----------------------------------------------------------
bool TankShape::DeltaHelper::nextTick(const Point3F & p, const QuatF & r, const Point3F & vel)
{
   // use position in order to decide what to do...
   Point3F deltaPos = pos-p;

   F32 velSq = mDot(vel,vel);
   F32 distSq = mDot(deltaPos,deltaPos);

   if (distSq < smMinWarpTicks * smMinWarpTicks * TickMs * TickMs * velSq)
   {
      // short enough distance, just adjust current target pos
      // we want to set pos and posStep s.t. current interpolation
      // is the same as it is now and final interpolation is at
      // new pos.  So:
      //    newPos = pos
      //    curPos = pos + backDelta * posStep = oldPos + backDelta * oldPosStep
      // so, solving for posStep, and assuming backDelta != 0
      //    posStep = (oldPos-newPos)/backDelta + oldPosStep
      // if backDelta is 0, then we are in a bad spot...simply go to new position
      //
      // same thing for rot...and turret...

      if (backDelta>0.001f)
      {
         F32 invBD = 1.0f / backDelta;
         posStep += deltaPos * invBD;
         rotStep.x += (rot.x-r.x) * invBD;
         rotStep.y += (rot.y-r.y) * invBD;
         rotStep.z += (rot.z-r.z) * invBD;
         rotStep.w += (rot.w-r.w) * invBD;
      }
      else
      {
         posStep.set(0.0f,0.0f,0.0f);
         rotStep.set(0,0,0,0);
      }
      pos = p;
      rot = r;
      next = false; // in case we had planned interpolation on older data...
   }
   else if (distSq < 65.0f)
   {
      // set up interpolation for next tick
      setupInterpolation(p,r);
   }
   else
   {
      pos = p;
      rot = r;
      posStep.set(0,0,0);
      rotStep.set(0,0,0,0);
      next = false;
   }
   return next;
}

//-----------------------------------------------------------
// Function name:  TankShape::DeltaHelper::setTurret
// Summary:        Set interpolation parameters to reflect
//                 new turret position.  Turret always
//                 interpolates to the newest position
//                 (i.e., no complicated next tick logic).
//-----------------------------------------------------------
void TankShape::DeltaHelper::setTurret(F32 tHor, F32 tVer)
{
   if (backDelta>0.001f)
   {
      F32 invBD = 1.0f / backDelta;
      turretHorStep += (turretHor - tHor) * invBD;
      turretVerStep += (turretVer - tVer) * invBD;
   }
   else
   {
      turretHorStep = 0.0f;
      turretVerStep = 0.0f;
   }
   turretHor = tHor;
   turretVer = tVer;
}

//-----------------------------------------------------------
// Function name:  TankShape::DeltaHelper::setupInterpolation
// Summary:        Set interpolation parameters.
//                 Note that player object in T2 will potentially take
//                 up to 3 ticks to perform interpolation, we keep it simple here
//                 and always do it in one tick.
//-----------------------------------------------------------
void TankShape::DeltaHelper::setupInterpolation(const Point3F &p, const QuatF &r)
{
   posNext = p;
   rotNext = r;
   next = true;
}

//-----------------------------------------------------------
// Function name:  TankShape::DeltaHelper::setControlData
// Summary:        Set data on control object.  Assumed to
//                 occur within readPacketData of the control
//                 object for this client.  Some parameters
//                 will simply be over-written, others may
//                 have on-going warp adjusted instead.
//-----------------------------------------------------------
void TankShape::DeltaHelper::setControlData(const Point3F & p, const QuatF & r)
{
   if (backDelta>0.001f)
   {
      F32 invBD = 1.0f / backDelta;
      posStep += (pos-p) * invBD;
      rotStep.x += (rot.x-r.x) * invBD;
      rotStep.y += (rot.y-r.y) * invBD;
      rotStep.z += (rot.z-r.z) * invBD;
      rotStep.w += (rot.w-r.w) * invBD;
   }
   pos = p;
   rot = r;
   next = false;
}

//-----------------------------------------------------------
// Function name:  TankShape::DeltaHelper::getRot
// Summary:        Get interpolated rotation.
//-----------------------------------------------------------
QuatF TankShape::DeltaHelper::getRot()
{
   QuatF rot2(rot.x+rotStep.x,rot.y+rotStep.y,rot.z+rotStep.z,rot.w+rotStep.w);
   QuatF ret;
   return ret.interpolate(rot,rot2,backDelta);
}

//-----------------------------------------------------------
// Function name:  TankShape::DeltaHelper::setWheelSpring
// Summary:        Set wheel spring position.
//-----------------------------------------------------------
void TankShape::DeltaHelper::setWheelSpring(F32 * spring)
{
   for (S32 i=0; i<TankShapeData::MaxInnerWheels; i++)
   {
      wheelSpringStep[i] = wheelSpring[i];
      wheelSpring[i] = spring[i];
      wheelSpringStep[i] -= wheelSpring[i];
   }
}

//-----------------------------------------------------------
// Function name:  TankShape::DeltaHelper::advanceTread
// Summary:        Advance treads.
//-----------------------------------------------------------
void TankShape::DeltaHelper::advanceTread(F32 leftMove, F32 rightMove, F32 rotMod)
{
   LTreadDistStep = LTreadDist;
   LTreadDist += leftMove;
   LTreadDistStep -= LTreadDist;

   // apply rotation modulus, taking care to keep start and end distances together
   if (LTreadDist<0 && LTreadDist+LTreadDistStep<0)
      LTreadDist += rotMod;
   else if (LTreadDist>rotMod && LTreadDist+LTreadDistStep>rotMod)
      LTreadDist -= rotMod;

   RTreadDistStep = RTreadDist;
   RTreadDist += rightMove;
   RTreadDistStep -= RTreadDist;

   // apply rotation modulus, taking care to keep start and end distances together
   if (RTreadDist<0 && RTreadDist+RTreadDistStep<0)
      RTreadDist += rotMod;
   else if (RTreadDist>rotMod && RTreadDist+RTreadDistStep>rotMod)
      RTreadDist -= rotMod;
}

