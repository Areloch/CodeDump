//-----------------------------------------------------------------------------
// TankShape Object
//
// Copyright (c) 2004 BraveTree Productions
//-----------------------------------------------------------------------------


#ifndef _TANKEHICLE_H_
#define _TANKVEHICLE_H_

#ifndef _SHAPEBASE_H_
#include "game/shapeBase.h"
#endif


#ifndef _CLIPPEDPOLYLIST_H_
#include "collision/clippedPolyList.h"
#endif

#ifndef _BOXCONVEX_H_
#include "collision/boxConvex.h"
#endif

class TSShape;
class TSShapeInstance;
class TSThread;
class TankCameraData;
class TankFxData;
class TankMiscData;


//----------------------------------------------------------------------------
// Data structure for storing "tank" parameters
//----------------------------------------------------------------------------

class TankShapeData : public ShapeBaseData
{
  private:
   typedef ShapeBaseData Parent;

  public:

   enum { MaxCollisionShapes = 8, 
          MaxDestructSequences = 4, 
          // NOTE: dependency here and tankShape.cc where TankShapeData::preload() defines array leftSideNames[] etc...
          MaxInnerWheelsPerSide = 9,
          MaxInnerWheels=MaxInnerWheelsPerSide*2,
          MaxWheels=MaxInnerWheels+4};

   TankCameraData * camera;
   TankFxData * fx;
   TankMiscData * misc;

   F32 maxStepHeight;
   F32 friction;
   F32 elasticity;

   F32 turnRate;          // degrees per second
   F32 accelRate;         // increase velocity this many meters per second
   F32 deccelRate;        // when breaking, decrease velocity this many meters per second
   F32 coastDeccelRate;   // rate of decceleration when coasting
   F32 antiSlideRate;     // dissipate sideways velocity by this many meters per second
   F32 maxSpeed;          // meters per second (in forward direction)

   // turret variables
   F32 turretVerCenter;   // vertical resting angle of turret in degrees
   F32 turretHorRange;    // range in +/- degrees of turret horizontally
   F32 turretVerRange;    // range in +/- degrees of turret vertically
   F32 turretAutoLevel;   // 0-1

   F32 groundTransform;

   // wheel information
   F32 suspensionRange;   // proportion of wheel size for wheel to move up/down

   // tank suspension
   F32 springRangeX;
   F32 springRangeY;
   F32 springRangeZ;
   F32 springVelScale;
   F32 springLooseness;

   // recoil
   F32 primaryRecoil;
   F32 secondaryRecoil;
   F32 tertiaryRecoil;

   // actaual number of inner wheels on a side
   S32 numInnerWheelsPerSide;

   // derived shape information
   Resource<TSShape> shapeResource;

   S32 numCollDetails;
   S32 collDetails[MaxCollisionShapes];
   S32 shadowDetail;
   S32 turretNode;
   S32 weaponNode;
   S32 muzzleNode;
   S32 suspensionNode;
   S32 seatNode;
   S32 scrumNode;
   S32 lTreadSeq;
   S32 rTreadSeq;
   F32 lTreadSeqScale;
   F32 rTreadSeqScale;
   S32 fireSeq;
   S32 numDestructSeq;
   S32 destructSeq[MaxDestructSequences];
   S32 flipNode;
   S32 flipCenterNode;

   // dimension parameters -- set by shape
   F32 height;            // height of tank body
   F32 width;             // width of tank body
   F32 length;            // length of tank body

   U32 cameraId;
   U32 fxId;
   U32 miscId;

   // derived wheel information
   // inner wheels come first followed by 4 outer wheels
   // outer 4 wheels order is this  RF, RR, LR, LF
   S32 wheelNode[MaxInnerWheels+4];
   S32 wheelRotNode[MaxInnerWheels+4];
   S32 wheelRotNodeChild[MaxInnerWheels+4];
   F32 wheelRadius[MaxInnerWheels+4];
   F32 wheelRange[MaxInnerWheels+4];
   Point3F wheelPos[MaxInnerWheels+4]; // object space
   F32 wheelRotMod;

   // derived dimension
   Box3F objectBox;       // object space bounding box of entire car
   F32 collRadius;        // radius of sphere enclosing object box
   F32 tankCollRadius;    // radius of sphere used for tank-tank collisions

   DECLARE_CONOBJECT(TankShapeData);

   TankShapeData();
   static void initPersistFields();
   bool preload(bool server, char errorBuffer[256]);
   void unpackData(BitStream* stream);
   void packData(BitStream* stream);

   inline int numInnerWheels() { return numInnerWheelsPerSide*2; }
   inline int totalWheels() { return numInnerWheels()+4; }
};

//----------------------------------------------------------------------------

class TankCameraData : public GameBaseData
{
  private:
   typedef GameBaseData Parent;

  public:

   F32 camFocusDist;      // distance in front of tank to focus camera
   F32 camFocusUpDist;    // dist. above tank to focus cam
   F32 camBackupDist;     // distance behind tank to place camera
   F32 camFloatHeight;    // distance above the ground to float camera
   F32 camSmooth;         // 0->no smoothing, 1->so smooth camera doesn't move
   F32 camSmoothTurn;     // 0->no smoothing, 1->so smooth camera doesn't move
   F32 camSmoothUp;       // 0->no smoothing, 1->so smooth camera doesn't move
   F32 camFov;            // camera field of view, in degrees
   F32 camNear;           // camera near dist

   DECLARE_CONOBJECT(TankCameraData);

   TankCameraData();
   static void initPersistFields();
   void unpackData(BitStream* stream);
   void packData(BitStream* stream);
};

//----------------------------------------------------------------------------

class TankFxData : public GameBaseData
{
  private:
   typedef GameBaseData Parent;

  public:

   AudioProfile * hardTankCollSound;
   F32 hardTankCollVel;
   AudioProfile * softTankCollSound;
   F32 softTankCollVel;
   S32 tankCollISI;

   AudioProfile * hardStaticCollSound;
   F32 hardStaticCollVel;
   AudioProfile * softStaticCollSound;
   F32 softStaticCollVel;
   S32 staticCollISI;

   AudioProfile * hardGroundCollSound;
   F32 hardGroundCollVel;
   AudioProfile * softGroundCollSound;
   F32 softGroundCollVel;
   S32 groundCollISI;

   // engine sound parameters...allow mixing of two sounds
   AudioProfile * engineSoundA;
   F32 enginePitchA0;
   F32 enginePitchA1;
   F32 engineVolA0;
   F32 engineVolA1;
   AudioProfile * engineSoundB;
   F32 enginePitchB0;
   F32 enginePitchB1;
   F32 engineVolB0;
   F32 engineVolB1;

   // derived collision sounds
   U32 hardTankCollSoundId;
   U32 softTankCollSoundId;
   U32 hardStaticCollSoundId;
   U32 softStaticCollSoundId;
   U32 hardGroundCollSoundId;
   U32 softGroundCollSoundId;
   U32 looseHeadSoundId;
   U32 fireSoundId;
   U32 dryFireSoundId;
   U32 engineKnockSoundId;
   U32 engineSoundAId;
   U32 engineSoundBId;

   DECLARE_CONOBJECT(TankFxData);

   TankFxData();
   static void initPersistFields();
   bool preload(bool server, char errorBuffer[256]);
   void unpackData(BitStream* stream);
   void packData(BitStream* stream);
};

//----------------------------------------------------------------------------

class TankMiscData : public GameBaseData
{
  private:
   typedef GameBaseData Parent;

  public:

   F32 bounceStatic;      // static obj collisions.  0->complete stop, 1->full reverse
   F32 bounceTank;        // tank collisions.        0->tanks get average v, 1->swap v

   S32 boostTicks;        // spread boost over this many ticks...

   // unstuck boost
   S32 unstuckTime;       // time (in ms) tank can be stuck before getting unstuck boost
   F32 unstuckBoost;      // velocity boost in m/s

   DECLARE_CONOBJECT(TankMiscData);

   TankMiscData();
   static void initPersistFields();
   void unpackData(BitStream* stream);
   void packData(BitStream* stream);
};

//----------------------------------------------------------------------------

class TankShape : public ShapeBase
{
   typedef ShapeBase Parent;

   class DeltaHelper
   {
      Point3F pos;
      Point3F posStep;
      Point3F posNext;

      QuatF rot;
      QuatF rotStep;
      QuatF rotNext;

      F32 turretHor;
      F32 turretHorStep;

      F32 turretVer;
      F32 turretVerStep;

      F32 wheelSpring[TankShapeData::MaxInnerWheels];
      F32 wheelSpringStep[TankShapeData::MaxInnerWheels];

      F32 LTreadDist;
      F32 LTreadDistStep;

      F32 RTreadDist;
      F32 RTreadDistStep;

      F32 backDelta;
      bool next;

      static F32 smMinWarpTicks;

   public:

      void init(const Point3F & p, const QuatF & rot);
      void setBackDelta(F32 bdt) { backDelta=bdt; }

      Point3F getPos() { return pos + backDelta * posStep; }
      QuatF getRot();

      F32 getTurretHor() { return turretHor + backDelta * turretHorStep; }
      F32 getTurretVer() { return turretVer + backDelta * turretVerStep; }
      F32 getTurretHorTarget() { return turretHor; }
      F32 getTurretVerTarget() { return turretVer; }

      F32 getWheelSpring(S32 i) { return wheelSpring[i] + backDelta * wheelSpringStep[i]; }
      F32 getLTread() { return LTreadDist + backDelta * LTreadDistStep; }
      F32 getRTread() { return RTreadDist + backDelta * RTreadDistStep; }

      // the prediction logic is encapsulated here
      void setupInterpolation(const Point3F & p, const QuatF & r);
      bool nextTick(const Point3F & p, const QuatF & r, const Point3F & vel);
      void setTurret(F32 th, F32 tv);

      void setWheelSpring(F32 *);
      void advanceTread(F32 leftMove, F32 rightMove, F32 rotMod);
      bool doTick();
      void setControlData(const Point3F & p, const QuatF & r);

   };
   DeltaHelper deltaHelper;

   // track collisions -- used for collision sounds
   // but may be useful for other things too at some point
   // only valid during processTick (except last collision time
   // which remembers time of last collision of any tank on
   // client with anything).
   enum
   {
      WasContact = 1,
      WasFullContact = 2,
      HitTank = 4,
      HitStatic = 8
   };
   static U32 smCollisionMask;
   static Point3F smStartVelocity;

   Point3F mVelocity;

   // track turn for turning while in the air
   // and for sending to non-player ghosts
   F32 mTurn;
   F32 mMovy;

   // wheel data
   F32 mWheelDropVel[4];
   bool mContact;
   bool mFullContact;

   Point3F mTankSpringCenter;
   Point3F mTankSpringPos;
   Point3F mTankSpringVel;

   Point3F mPrevCameraPos;
   Point3F mPrevCameraX;
   Point3F mPrevCameraZ;
   U32 mPrevCameraTime;

   Point3F mBoostVel;
   S32 mBoostTicks;

   S32 mStuckTicks;

   TSThread * mLTreadThread;
   TSThread * mRTreadThread;

   // sound data...
   U32 mLastTankCollTime;
   U32 mLastStaticCollTime;
   U32 mLastGroundCollTime;
   AUDIOHANDLE mEngineSoundA;
   AUDIOHANDLE mEngineSoundB;
   F32 mEngineAmp;

   U32 getConformToMask();
   U32 getCollisionMask();

  private:
  bool mInLiquid;

   ShapeBase* mCollisionObject;
   U32 mCollisionTimeout;

   OrthoBoxConvex mConvex;
   Box3F          mWorkingQueryBox;

  public:

   enum TankMasks
   {
      FirstMask    =     Parent::NextFreeMask,
      MoveMask     =     FirstMask,
      TurretMask   =     FirstMask << 1,
      BoostMask    =     FirstMask << 2,
      NextFreeMask =     FirstMask << 3
   };

   //------------------------------------------
   // ShapeBase derived methods
   //------------------------------------------

   void onImageRecoil(U32 imageSlot, ShapeBaseImageData::StateData::RecoilState);

   //------------------------------------------
   // GameBase derived methods
   //------------------------------------------

   // Data block
   TankShapeData* getDataBlock()  { return (TankShapeData*)Parent::getDataBlock(); }
   bool onNewDataBlock(GameBaseData * dptr);

   // Processing
   void processTick(const Move*);
   void interpolateTick(F32 backDelta);
   //void advanceTime(F32 dt);

   // Network
   U32  packUpdate(NetConnection *, U32 mask, BitStream *stream);
   void unpackUpdate(NetConnection *, BitStream *stream);
   void writePacketData(GameConnection *, BitStream *stream);
   void readPacketData(GameConnection *, BitStream *stream);

   // Add a little physics for network priority
   Point3F getVelocity() const;
   void setVelocity(const Point3F &);

   // camera: in degrees
   F32  getCameraNear()       { return getDataBlock()->camera->camNear; }
   F32  getCameraFov()        { return getDataBlock()->camera->camFov; }
   F32  getDefaultCameraFov() { return getDataBlock()->camera->camFov; }
   void getCameraTransform(F32* pos,MatrixF* mat);

   //------------------------------------------
   // SceneObject derived methods
   //------------------------------------------

   // physics interface

   // transform interface
   void setTransform(const MatrixF&);

   // collision interface
   bool castRay(const Point3F &start, const Point3F &end, RayInfo* info);

   //------------------------------------------
   // Methods we added ourselves
   //------------------------------------------

   void setPosition(const Point3F & pos, const QuatF & rot);
   void setRenderPosition(const Point3F & pos, const QuatF & rot);
   void getMuzzleTransform(MatrixF * mat);

   void updateMove(const Move *, Point3F & pos, QuatF & rot, MatrixF mat);
   void updateTurret(const Move * move, const QuatF & oldRot, const QuatF & newRot);
   bool updatePos(Point3F & pos, QuatF & rot, const Point3F & oldPos, const QuatF & oldRot, const F32 dt);

   void updateWorkingCollisionSet(const U32 mask, const F32 dt);
   bool buildPolyList(AbstractPolyList* polyList, const Box3F &box, const SphereF &sphere);
   void buildConvex(const Box3F& box, Convex* convex);

   void updateCollisionSound();
   void updateEngineSound(bool play);
   void updateAnimation(bool muzzleOnly = false);
   void updateTankSuspension();

   void getWheelOffsets(MatrixF & mat, F32 * woff, S32 a, S32 b);
   void updateTerrainCollision(Point3F & pos, QuatF & rot, MatrixF & mat);
   void stickToGround(Point3F & pos, QuatF & rot);
   void goTowardGround(Point3F & pos, const U32 mask);
   Point3F getWorldCenter(const MatrixF & mat);

   void impact(const Point3F & pos, F32 force);

   void setBoost(const Point3F & boostVel);

   void markTreads(Point3F & left, Point3F & right, const MatrixF & mat);
   void updateTreads(Point3F & leftMove, Point3F & rightMove, const MatrixF & mat);

   //void renderShadow(F32 dist, F32 fogAmount);
   void renderReticle();

   // helpers
   F32 getTurretHor();
   F32 getTurretVert();
   F32 getWheelPos(S32 wheel);
   int numInnerWheels() { return getDataBlock()->numInnerWheels(); }
   int totalWheels() { return getDataBlock()->totalWheels(); }

   //------------------------------------------

   TankShape();
   ~TankShape();

   // Init
   bool onAdd();
   void onRemove();
   DECLARE_CONOBJECT(TankShape);
};

inline F32 TankShape::getTurretHor()
{
    return deltaHelper.getTurretHor() * mDegToRad(getDataBlock()->turretHorRange);
}

inline F32 TankShape::getTurretVert()
{
    return deltaHelper.getTurretVer() * mDegToRad(getDataBlock()->turretVerRange) - mDegToRad(getDataBlock()->turretVerCenter);
}

inline F32 TankShape::getWheelPos(S32 wheel)
{
   AssertFatal(wheel>=0 && wheel<totalWheels(),"wheel out of range");
   return deltaHelper.getWheelSpring(wheel);
}

#endif

