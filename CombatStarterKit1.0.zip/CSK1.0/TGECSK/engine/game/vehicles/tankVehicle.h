//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#ifndef _TankVehicle_H_
#define _TankVehicle_H_

#ifndef _VEHICLE_H_
#include "game/vehicles/wheeledVehicle.h"
#endif

#ifndef _CLIPPEDPOLYLIST_H_
#include "collision/clippedPolyList.h"
#endif

class ParticleEmitter;
class ParticleEmitterData;


//----------------------------------------------------------------------------




//----------------------------------------------------------------------------

class TankVehicle: public WheeledVehicle
{	 
	typedef WheeledVehicle Parent;  

protected:
	void renderImage(SceneState *state, SceneRenderImage *image);

public:
	DECLARE_CONOBJECT(TankVehicle);

	TankVehicle();
	~TankVehicle();

};


#endif
