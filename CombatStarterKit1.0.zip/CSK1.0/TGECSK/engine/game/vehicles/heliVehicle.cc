//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#include "game/vehicles/heliVehicle.h"

#include "platform/platform.h"
#include "dgl/dgl.h"
#include "game/game.h"
#include "math/mMath.h"
#include "console/simBase.h"
#include "console/console.h"
#include "console/consoleTypes.h"
#include "collision/clippedPolyList.h"
#include "collision/planeExtractor.h"
#include "game/moveManager.h"
#include "core/bitStream.h"
#include "core/dnet.h"
#include "game/gameConnection.h"
#include "ts/tsShapeInstance.h"
#include "game/fx/particleEngine.h"
#include "audio/audioDataBlock.h"
#include "game/missionArea.h"

//----------------------------------------------------------------------------

const static U32 sCollisionMoveMask = (TerrainObjectType        | InteriorObjectType   |
                                       WaterObjectType          | PlayerObjectType     |
                                       StaticShapeObjectType    | VehicleObjectType    |
                                       VehicleBlockerObjectType | StaticTSObjectType);
static U32 sServerCollisionMask = sCollisionMoveMask; // ItemObjectType
static U32 sClientCollisionMask = sCollisionMoveMask;

// Sound
static F32 sIdleEngineVolume = 0.2;
// Physics and collision constants
static F32 sRestTol = 0.2;             // % of gravity energy to be at rest
static int sRestCount = 5;            // Consecutive ticks before coming to rest
//
const char* heliVehicle::sJetSequence[heliVehicle::JetAnimCount] =
{
   "activateBack",
   "maintainBack",
   "activateBot",
   "maintainBot",
};

const char* heliVehicleData::sJetNode[heliVehicleData::MaxJetNodes] =
{
   "JetNozzle0",  // Thrust Forward
   "JetNozzle1",
   "JetNozzleX",  // Thrust Backward
   "JetNozzleX",
   "JetNozzleX",  // Thrust Downward
   "JetNozzleX",
   "JetNozzleX",  // Thrust Upward
   "JetNozzleX",
   "contrail0",   // Trail
   "contrail1",
   "contrail2",
   "contrail3",
};

// Convert thrust direction into nodes & emitters
heliVehicle::JetActivation heliVehicle::sJetActivation[NumThrustDirections] = {
   { heliVehicleData::ForwardJetNode, heliVehicleData::ForwardJetEmitter },
   { heliVehicleData::BackwardJetNode, heliVehicleData::BackwardJetEmitter },
   { heliVehicleData::DownwardJetNode, heliVehicleData::DownwardJetEmitter },
   { heliVehicleData::UpwardJetNode, heliVehicleData::UpwardJetEmitter },
};


//----------------------------------------------------------------------------

IMPLEMENT_CO_DATABLOCK_V1(heliVehicleData);

heliVehicleData::heliVehicleData()
{
   maneuveringForce = 0;
   horizontalSurfaceForce = 0;
   verticalSurfaceForce = 0;
   autoInputDamping = 1;
   steeringForce = 1;
   steeringRollForce = 1;
   rollForce = 1;
   autoAngularForce = 0;
   rotationalDrag = 0;
   autoLinearForce = 0;
   maxAutoSpeed = 0;
   hoverHeight = 2;
   //maxSteeringAngle = 0.785; // == 45 deg. //moved to vehicle.cc
   minTrailSpeed = 1;
   maxSpeed = 100;
   bladeSequence = -1;
   liftCoefficient = 2.8f;
   wingArea = 16.0f;
   airDensity = 0.1f;
   dragCoefficient = 0.4f;
   pitchLinForce = 100.0f;
   noseDownCutoff = 50.0f;
   noseDownHigh = 200.0f;  
   maxForwardVelocity = 3200.0f; 
   //steeringDecay = 0.95f;  // moved to vehicle.cc
   maneuverCutoff = 15.0f;
   manueverHigh = 65.0f;
   propThrustCoeff = 0.3;
   manueverAltitude = 0.0;

   for (S32 k = 0; k < MaxJetNodes; k++)
      jetNode[k] = -1;

   for (S32 j = 0; j < MaxJetEmitters; j++)
      jetEmitter[j] = 0;

   for (S32 i = 0; i < MaxSounds; i++)
      sound[i] = 0;

   vertThrustMultiple = 1.0;
}

bool heliVehicleData::preload(bool server, char errorBuffer[256])
{
   if (!Parent::preload(server, errorBuffer))
      return false;

   TSShapeInstance* si = new TSShapeInstance(shape,false);

   // Resolve objects transmitted from server
   if (!server) {
      for (S32 i = 0; i < MaxSounds; i++)
         if (sound[i])
            Sim::findObject(SimObjectId(sound[i]),sound[i]);

      for (S32 j = 0; j < MaxJetEmitters; j++)
         if (jetEmitter[j])
            Sim::findObject(SimObjectId(jetEmitter[j]),jetEmitter[j]);
   }
   // Blades
   bladeSequence = shape->findSequence("blades");

   // Extract collision planes from shape collision detail level
   if (collisionDetails[0] != -1) {
      MatrixF imat(1);
      PlaneExtractorPolyList polyList;
      polyList.mPlaneList = &rigidBody.mPlaneList;
      polyList.setTransform(&imat, Point3F(1,1,1));
      si->animate(collisionDetails[0]);
      si->buildPolyList(&polyList,collisionDetails[0]);
   }

   groundNode = shape->findNode("groundLevel");

   // Resolve jet nodes
   for (S32 j = 0; j < MaxJetNodes; j++)
      jetNode[j] = shape->findNode(sJetNode[j]);

   //
   maxSpeed = maneuveringForce / minDrag;

   delete si;
   return true;
}

void heliVehicleData::initPersistFields()
{
   Parent::initPersistFields();

   addField("jetSound",               TypeAudioProfilePtr,        Offset(sound[JetSound],                heliVehicleData));
   addField("engineSound",            TypeAudioProfilePtr,        Offset(sound[EngineSound],             heliVehicleData));

   addField("maneuveringForce",       TypeF32,                    Offset(maneuveringForce,               heliVehicleData));
   addField("horizontalSurfaceForce", TypeF32,                    Offset(horizontalSurfaceForce,         heliVehicleData));
   addField("verticalSurfaceForce",   TypeF32,                    Offset(verticalSurfaceForce,           heliVehicleData));
   addField("autoInputDamping",       TypeF32,                    Offset(autoInputDamping,               heliVehicleData));
   addField("steeringForce",          TypeF32,                    Offset(steeringForce,                  heliVehicleData));
   addField("steeringRollForce",      TypeF32,                    Offset(steeringRollForce,              heliVehicleData));
   addField("rollForce",              TypeF32,                    Offset(rollForce,                      heliVehicleData));
   addField("autoAngularForce",       TypeF32,                    Offset(autoAngularForce,               heliVehicleData));
   addField("rotationalDrag",         TypeF32,                    Offset(rotationalDrag,                 heliVehicleData));
   addField("autoLinearForce",        TypeF32,                    Offset(autoLinearForce,                heliVehicleData));
   addField("maxAutoSpeed",           TypeF32,                    Offset(maxAutoSpeed,                   heliVehicleData));
   addField("hoverHeight",            TypeF32,                    Offset(hoverHeight,                    heliVehicleData));
   addField("createHoverHeight",      TypeF32,                    Offset(createHoverHeight,              heliVehicleData));

   addField("forwardJetEmitter",      TypeParticleEmitterDataPtr, Offset(jetEmitter[ForwardJetEmitter],  heliVehicleData));
   addField("backwardJetEmitter",     TypeParticleEmitterDataPtr, Offset(jetEmitter[BackwardJetEmitter], heliVehicleData));
   addField("downJetEmitter",         TypeParticleEmitterDataPtr, Offset(jetEmitter[DownwardJetEmitter], heliVehicleData));
   addField("trailEmitter",           TypeParticleEmitterDataPtr, Offset(jetEmitter[TrailEmitter],       heliVehicleData));
   addField("minTrailSpeed",          TypeF32,                    Offset(minTrailSpeed,                  heliVehicleData));
   addField("vertThrustMultiple",     TypeF32,                    Offset(vertThrustMultiple,             heliVehicleData));

   addField("liftCoefficient",        TypeF32,                    Offset(liftCoefficient,                heliVehicleData));
   addField("wingArea",               TypeF32,                    Offset(wingArea,                       heliVehicleData));
   addField("airDensity",             TypeF32,                    Offset(airDensity,                     heliVehicleData));
   addField("dragCoefficient",        TypeF32,                    Offset(dragCoefficient,                heliVehicleData));
   addField("pitchLinForce",          TypeF32,                    Offset(pitchLinForce,                  heliVehicleData));
   addField("noseDownCutoff",         TypeF32,                    Offset(noseDownCutoff,                 heliVehicleData));
   addField("noseDownHigh",           TypeF32,                    Offset(noseDownHigh,                   heliVehicleData));
   addField("maxForwardVelocity",     TypeF32,                    Offset(maxForwardVelocity,             heliVehicleData));
   // moved following to vehicle.cc
   //addField("steeringDecay",          TypeF32,                    Offset(steeringDecay,                  heliVehicleData));
   addField("propThrustCoeff",        TypeF32,                    Offset(propThrustCoeff,                heliVehicleData));
   addField("manueverAltitude",        TypeF32,                   Offset(manueverAltitude,               heliVehicleData));
}

void heliVehicleData::packData(BitStream* stream)
{
   Parent::packData(stream);

   for (S32 i = 0; i < MaxSounds; i++)
   {
      if (stream->writeFlag(sound[i]))
      {
         SimObjectId writtenId = packed ? SimObjectId(sound[i]) : sound[i]->getId();
         stream->writeRangedU32(writtenId, DataBlockObjectIdFirst, DataBlockObjectIdLast);
      }
   }

   for (S32 j = 0; j < MaxJetEmitters; j++)
   {
      if (stream->writeFlag(jetEmitter[j]))
      {
         SimObjectId writtenId = packed ? SimObjectId(jetEmitter[j]) : jetEmitter[j]->getId();
         stream->writeRangedU32(writtenId, DataBlockObjectIdFirst,DataBlockObjectIdLast);
      }
   }

   stream->write(maneuveringForce);
   stream->write(horizontalSurfaceForce);
   stream->write(verticalSurfaceForce);
   stream->write(autoInputDamping);
   stream->write(steeringForce);
   stream->write(steeringRollForce);
   stream->write(rollForce);
   stream->write(autoAngularForce);
   stream->write(rotationalDrag);
   stream->write(autoLinearForce);
   stream->write(maxAutoSpeed);
   stream->write(hoverHeight);
   stream->write(createHoverHeight);
   stream->write(minTrailSpeed);
   stream->write(vertThrustMultiple);
   stream->write(liftCoefficient);
   stream->write(wingArea);
   stream->write(airDensity);
   stream->write(dragCoefficient);
   stream->write(pitchLinForce);
   stream->write(noseDownCutoff); 
   stream->write(noseDownHigh); 
   stream->write(maxForwardVelocity); 
   //stream->write(steeringDecay); // moved to vehicle.cc
   stream->write(propThrustCoeff);
   stream->write(manueverAltitude);
}

void heliVehicleData::unpackData(BitStream* stream)
{
   Parent::unpackData(stream);

   for (S32 i = 0; i < MaxSounds; i++) {
      sound[i] = NULL;
      if (stream->readFlag())
         sound[i] = (AudioProfile*)stream->readRangedU32(DataBlockObjectIdFirst,
                                                         DataBlockObjectIdLast);
   }

   for (S32 j = 0; j < MaxJetEmitters; j++) {
      jetEmitter[j] = NULL;
      if (stream->readFlag())
         jetEmitter[j] = (ParticleEmitterData*)stream->readRangedU32(DataBlockObjectIdFirst,
                                                                     DataBlockObjectIdLast);
   }

   stream->read(&maneuveringForce);
   stream->read(&horizontalSurfaceForce);
   stream->read(&verticalSurfaceForce);
   stream->read(&autoInputDamping);
   stream->read(&steeringForce);
   stream->read(&steeringRollForce);
   stream->read(&rollForce);
   stream->read(&autoAngularForce);
   stream->read(&rotationalDrag);
   stream->read(&autoLinearForce);
   stream->read(&maxAutoSpeed);
   stream->read(&hoverHeight);
   stream->read(&createHoverHeight);
   stream->read(&minTrailSpeed);
   stream->read(&vertThrustMultiple);
   stream->read(&liftCoefficient);
   stream->read(&wingArea);
   stream->read(&airDensity);
   stream->read(&dragCoefficient);
   stream->read(&pitchLinForce);
   stream->read(&noseDownCutoff); 
   stream->read(&noseDownHigh); 
   stream->read(&maxForwardVelocity); 
  // stream->read(&steeringDecay); // moved to vehicle.cc
   stream->read(&propThrustCoeff);
   stream->read(&manueverAltitude);
}


//----------------------------------------------------------------------------

IMPLEMENT_CO_NETOBJECT_V1(heliVehicle);

heliVehicle::heliVehicle()
{
   mBladeThread = 0;
   mSteering.set(0,0);
   mThrottle = 0;
   mJetting = true;
   mJettingDn = true;

   mJetSound = 0;
   mEngineSound = 0;

   mBackMaintainOn = false;
   mBottomMaintainOn = false;

   for (S32 i = 0; i < JetAnimCount; i++)
      mJetThread[i] = 0;
}

heliVehicle::~heliVehicle()
{
   if (mJetSound)
      alxStop(mJetSound);
   if (mEngineSound)
      alxStop(mEngineSound);
}


//----------------------------------------------------------------------------

bool heliVehicle::onAdd()
{
   if(!Parent::onAdd())
      return false;

   addToScene();

   if (isServerObject())
      scriptOnAdd();
   return true;
}

bool heliVehicle::onNewDataBlock(GameBaseData* dptr)
{
   mDataBlock = dynamic_cast<heliVehicleData*>(dptr);
   if (!mDataBlock || !Parent::onNewDataBlock(dptr))
      return false;

   // Sounds
   if (mJetSound) {
      alxStop(mJetSound);
      mJetSound = 0;
   }
   if (mEngineSound) {
      alxStop(mEngineSound);
      mEngineSound = 0;
   }

   // Threads
   // Top blade sequence
   if (mDataBlock->bladeSequence != -1) {
       mBladeThread = mShapeInstance->addThread();
       mShapeInstance->setSequence(mBladeThread,mDataBlock->bladeSequence,0);
       mShapeInstance->setTimeScale(mBladeThread, 1);
   }
   else
       mBladeThread = 0;

   scriptOnNewDataBlock();
   return true;
}

void heliVehicle::onRemove()
{
   scriptOnRemove();
   removeFromScene();
   Parent::onRemove();
}


//----------------------------------------------------------------------------

void heliVehicle::advanceTime(F32 dt)
{
   Parent::advanceTime(dt);

   updateEngineSound(1);
   updateJet(dt);
   // Animate the blades.
   if (IsEngineOn() || vehicleInMotion) {
       if (mBladeThread)
           mShapeInstance->advanceTime(dt, mBladeThread);
   }
}


//----------------------------------------------------------------------------

void heliVehicle::updateMove(const Move* move)
{
   Parent::updateMove(move);

   if (!IsEngineOn() && !vehicleInMotion)
      return;

   if (move == &NullMove)
      mSteering.set(0,0);

   // Roll 
   mSteeringRoll = mClampF(move->roll, -mDataBlock->maxSteeringAngle, mDataBlock->maxSteeringAngle);

   F32 speed = mRigid.linVelocity.len();
   if (speed < mDataBlock->maxAutoSpeed)
      mSteering *= mDataBlock->autoInputDamping;

   mCeilingFactor = 50.0f; //change

   mThrust.x = move->x;
   mThrust.y = move->y;//mClampF(mThrust.y + move->y, 0, 1);
   mThrust.z = move->z;
   mRPY.x    = move->roll;
   mRPY.y    = move->pitch;
   mRPY.z    = move->yaw;

   if (mThrust.z != 0.0f)
       if (mThrust.z > 0)
           mThrustDirection = ThrustUp;
       else
           mThrustDirection = ThrustDown;
   else if (mThrust.y != 0.0f)
      if (mThrust.y > 0)
         mThrustDirection = ThrustForward;
      else
         mThrustDirection = ThrustBackward;

   //mSteering.x *= mDataBlock->steeringDecay; //moved to vehicle.cc
   mSteering.y *= mDataBlock->steeringDecay;
   mSteeringRoll *= mDataBlock->steeringDecay;

   if (mThrust.y < 0.1)
       mThrust.y = 0;
   if (getAltitudeOffTerrain() < mDataBlock->manueverAltitude)
       mThrust.y = 0;
   if (getDamageValue() > 0.99)
       mThrust.set(0, 0, 0);
}

F32 heliVehicle::inputAdjust(const F32 inputAmt)
{
    if (inputAmt != 0) {
        return (inputAmt*inputAmt) * (inputAmt / mFabs(inputAmt));
    } else {
        return 0;
    }
}

//----------------------------------------------------------------------------

void heliVehicle::updateForces(F32 dt)
{
   MatrixF currPosMat;
   mRigid.getTransform(&currPosMat);
   mRigid.atRest = false;

   Point3F massCenter;
   currPosMat.mulP(mDataBlock->massCenter,&massCenter);

   Point3F xv,yv,zv, Adj;
   currPosMat.getColumn(0,&xv);
   currPosMat.getColumn(1,&yv);
   currPosMat.getColumn(2,&zv);

   // Calculate PRH (x = pitch, y = roll, z = heading)
   Point3F heliRot(-mAtan(yv.z, mSqrt(yv.x*yv.x + yv.y*yv.y)), mDot(xv,Point3F(0,0,1)), -mAtan(-yv.x,yv.y) );

   F32 controlDamageMult = 1 - getDamageValue();
   F32 controlDamageAdd  = getDamageValue();

   if(isGhost())
   {
	   // simulate some wind and other effects
	   controlDamageMult -= mRandF(0,0.2);
	   controlDamageAdd += mRandF(-0.1,0.1);
   }
   

   heliRot.x *= controlDamageMult;
   heliRot.y *= controlDamageMult;
   heliRot.z += controlDamageAdd;

   // Set up vars
   F32 pitch = mRadToDeg(heliRot.x);	 // Pitch
   F32 yaw   = mRadToDeg(heliRot.z);	 // Heading
   F32 roll  = mRadToDeg(heliRot.y);	 // Roll   
   F32 speed = mRigid.linVelocity.len(); // velocity

   Point3F force  = Point3F(0, 0, mGravity * mRigid.mass * mGravityMod);
   Point3F torque = Point3F(0, 0, 0);
   
   // Engine off, falling
   if (!IsEngineOn()) {
	   controlDamageAdd += 0.8;
	   controlDamageMult -= 0.5;
       torque += yv * 10 * mDataBlock->steeringRollForce/* * rollAmt*/;
   }
   Point3F Tilt(0, controlDamageAdd,controlDamageMult);

   // Drag at any speed
   force  -= mRigid.linVelocity * mDataBlock->minDrag;
   torque -= mRigid.angMomentum * mDataBlock->rotationalDrag;

   // Auto-stop at low speeds
   if (speed < mDataBlock->maxAutoSpeed) {
      F32 autoScale = 1 - speed / mDataBlock->maxAutoSpeed;

      // Gyroscope
      F32 gf = mDataBlock->autoAngularForce * autoScale;
      torque -= xv * gf * mDot(yv,Tilt);//Point3F(0,0,1));

      // Maneuvering jets
      F32 sf = mDataBlock->autoLinearForce * autoScale;
      force -= yv * sf * mDot(yv, mRigid.linVelocity);
      force -= xv * sf * mDot(xv, mRigid.linVelocity);
   }

   // Hovering Jet
   F32 vf = -mGravity * mRigid.mass * mGravityMod;
   F32 h  = getHeight();
   if (h <= 1) {
      if (h > 0) {
         vf -= vf * h * 0.1;
      } else {
         vf += mDataBlock->jetForce * -h;
      }
   }
   if (IsEngineOn()) 
   {
	   force += zv * vf;

	   // Damping "surfaces"
	   force -= xv * speed * mDot(xv,mRigid.linVelocity) * mDataBlock->horizontalSurfaceForce;
	   force -= zv * speed * mDot(zv,mRigid.linVelocity) * mDataBlock->verticalSurfaceForce;

	   if (mThrustDirection == ThrustUp)
		   force += zv * (mThrust.z * mDataBlock->maneuveringForce * mCeilingFactor * controlDamageMult);
	   else if (mThrustDirection == ThrustDown)
		   force -= zv * (-mThrust.z * mDataBlock->maneuveringForce * mCeilingFactor);

	   // Maneuvering jets
	   force += yv * (mThrust.y * mDataBlock->maneuveringForce * mCeilingFactor * 1.5);
	   force += xv * (mThrust.x * mDataBlock->maneuveringForce * mCeilingFactor);
   }
   // Steering
   Point3F steering;
   steering.x = mSteering.x / mDataBlock->maxSteeringAngle;
   steering.x *= mFabs(steering.x);
   steering.x += controlDamageAdd; //spin when damaged
   steering.y = mSteering.y / mDataBlock->maxSteeringAngle;
   steering.y *= mFabs(steering.y);

   torque -= xv * steering.y * mDataBlock->steeringForce;//change
   torque -= zv * steering.x * mDataBlock->steeringForce;

   // Pitch control (up/down)
   F32 pitchAmt = inputAdjust(heliRot.x / mDataBlock->maxSteeringAngle); // normalize angle 0..1
   torque += xv * pitchAmt * mDataBlock->steeringForce /* * manueverCoeff*/;
   force += zv * pitchAmt * mDataBlock->pitchLinForce ;  // let's immediately apply some force here

   // Roll control
   F32 rollAmt = inputAdjust(mSteeringRoll / mDataBlock->maxSteeringAngle);
   //torque += yv * rollAmt * mDataBlock->steeringRollForce/* * manueverCoeff*/;

   // Yaw control
   //F32 yawAmt = inputAdjust(mSteering.x / mDataBlock->maxSteeringAngle);
   //torque += zv * yawAmt * mDataBlock->steeringForce/* * manueverCoeff*/;
   // Roll //change
   torque += yv * steering.x * mDataBlock->steeringRollForce/* * rollAmt*/;
   F32 ar = mDataBlock->autoAngularForce * mDot(xv,Point3F(0,0,1));
   ar -= mDataBlock->rollForce * mDot(xv, mRigid.linVelocity);
   torque += ar * yv;//yv * ar

   // Add in force from physical zones...
   force += mAppliedForce;

   // Container buoyancy & drag
   force -= Point3F(0, 0, 1) * (mBuoyancy * mGravity * mRigid.mass * mGravityMod);
   force -= mRigid.linVelocity * mDrag;

   
   mRigid.force  = force;  
   mRigid.torque = torque;
}


//----------------------------------------------------------------------------

F32 heliVehicle::getHeight()
{
	

	Point3F sp,ep;
	RayInfo collision;
	F32 height = mDataBlock->hoverHeight;
	F32 r = 10 + height;
	F32 result = 0;
	//getTransform().getColumn(3, &sp);	
    MatrixF node = mShapeInstance->mNodeTransforms[mDataBlock->groundNode];
	MatrixF mat;
	if(isServerObject())
	  mat.mul(getTransform(),node);
	else
	  mat.mul(getRenderTransform(),node);

	mat.getColumn(3,&sp);

	ep.x = sp.x;
	ep.y = sp.y;
	ep.z = sp.z - r;
	inAir = false;
	disableCollision();
	if (mContainer->castRay(sp,ep,~(WaterObjectType | GameBaseObjectType | DefaultObjectType),&collision))
	{	   
		if(collision.t  >0)
		{
			result = (r * collision.t - height) / 10;
		    if(collision.t * r  > 1.0)
                inAir = true;
		}
	}
	else
		inAir = true;

	enableCollision();

	return result;
}

//----------------------------------------------------------------------------
U32 heliVehicle::getCollisionMask()
{
   if (isServerObject())
      return sServerCollisionMask;
   else
      return sClientCollisionMask;
}

//----------------------------------------------------------------------------

void heliVehicle::updateEngineSound(F32 level)
{
    if (!IsEngineOn() && !vehicleInMotion)
    {
        if (mJetSound)
        {
            alxStop(mJetSound);
            mJetSound = NULL_AUDIOHANDLE;
        }
        if (mEngineSound)
        {
            alxStop(mEngineSound);
            mEngineSound = NULL_AUDIOHANDLE;
        }
        return;
    }

   if (mEngineSound == NULL_AUDIOHANDLE && mDataBlock->sound[heliVehicleData::EngineSound] != NULL)
       mEngineSound = alxPlay(mDataBlock->sound[heliVehicleData::EngineSound], &getTransform());
   if (mEngineSound != NULL_AUDIOHANDLE) {
       alxSourceMatrixF(mEngineSound, &getTransform());

       F32 factor  = mThrust.z + mThrust.y;
       F32 vol = 0.25 + factor * 0.75;
       alxSourcef(mEngineSound, AL_GAIN_LINEAR, vol);
   }
}

void heliVehicle::updateJet(F32 dt)
{
//    if (!IsEngineOn())
        return;

   // Thrust Animation threads
   //  Back
   if (mJetSeq[BackActivate] >=0 ) {
      if(!mBackMaintainOn || mThrustDirection != ThrustForward) {
         if(mBackMaintainOn) {
            mShapeInstance->setPos(mJetThread[BackActivate], 1);
            mShapeInstance->destroyThread(mJetThread[BackMaintain]);
            mBackMaintainOn = false;
         }
         mShapeInstance->setTimeScale(mJetThread[BackActivate],
            (mThrustDirection == ThrustForward)? 1: -1);
         mShapeInstance->advanceTime(dt,mJetThread[BackActivate]);
      }
      if(mJetSeq[BackMaintain] >= 0 && !mBackMaintainOn &&
            mShapeInstance->getPos(mJetThread[BackActivate]) >= 1.0) {
         mShapeInstance->setPos(mJetThread[BackActivate], 0);
         mShapeInstance->setTimeScale(mJetThread[BackActivate], 0);
         mJetThread[BackMaintain] = mShapeInstance->addThread();
         mShapeInstance->setSequence(mJetThread[BackMaintain],mJetSeq[BackMaintain],0);
         mShapeInstance->setTimeScale(mJetThread[BackMaintain],1);
         mBackMaintainOn = true;
      }
      if(mBackMaintainOn)
         mShapeInstance->advanceTime(dt,mJetThread[BackMaintain]);
   }

   // Thrust Animation threads
   //   Bottom
   //if (mJetSeq[BottomActivate] >=0 ) {
   //   if(!mBottomMaintainOn || mThrustDirection != ThrustDown || !mJetting) {
   //      if(mBottomMaintainOn) {
   //         mShapeInstance->setPos(mJetThread[BottomActivate], 1);
   //         mShapeInstance->destroyThread(mJetThread[BottomMaintain]);
   //         mBottomMaintainOn = false;
   //      }
   //      mShapeInstance->setTimeScale(mJetThread[BottomActivate],
   //         (mThrustDirection == ThrustDown && mJetting)? 1: -1);
   //      mShapeInstance->advanceTime(dt,mJetThread[BottomActivate]);
   //   }
   //   if(mJetSeq[BottomMaintain] >= 0 && !mBottomMaintainOn &&
   //         mShapeInstance->getPos(mJetThread[BottomActivate]) >= 1.0) {
   //      mShapeInstance->setPos(mJetThread[BottomActivate], 0);
   //      mShapeInstance->setTimeScale(mJetThread[BottomActivate], 0);
   //      mJetThread[BottomMaintain] = mShapeInstance->addThread();
   //      mShapeInstance->setSequence(mJetThread[BottomMaintain],mJetSeq[BottomMaintain],0);
   //      mShapeInstance->setTimeScale(mJetThread[BottomMaintain],1);
   //      mBottomMaintainOn = true;
   //   }
   //   if(mBottomMaintainOn)
   //      mShapeInstance->advanceTime(dt,mJetThread[BottomMaintain]);
   //}

   // Jet particles
   for (S32 j = 0; j < NumThrustDirections; j++) {
      JetActivation& jet = sJetActivation[j];
      updateEmitter(mJetting && j == mThrustDirection,dt,mDataBlock->jetEmitter[jet.emitter],
                    jet.node,heliVehicleData::MaxDirectionJets);
   }

   // Trail jets
   Point3F yv;
   mObjToWorld.getColumn(1,&yv);
   F32 speed = mFabs(mDot(yv,mRigid.linVelocity));
   F32 trail = 0;
   if (speed > mDataBlock->minTrailSpeed) {
      trail = dt;
      if (speed < mDataBlock->maxSpeed)
         trail *= (speed - mDataBlock->minTrailSpeed) / mDataBlock->maxSpeed;
   }
   updateEmitter(trail,trail,mDataBlock->jetEmitter[heliVehicleData::TrailEmitter],
                 heliVehicleData::TrailNode,heliVehicleData::MaxTrails);

   // Allocate/Deallocate voice on demand.
   if (!mDataBlock->sound[heliVehicleData::JetSound])
      return;
   if (!mJetting) {
      if (mJetSound) {
         alxStop(mJetSound);
         mJetSound = 0;
      }
   }
   else {
      if (!mJetSound)
         mJetSound = alxPlay(mDataBlock->sound[heliVehicleData::JetSound], &getTransform());

      alxSourceMatrixF(mJetSound, &getTransform());
   }
}

//----------------------------------------------------------------------------

void heliVehicle::updateEmitter(bool active,F32 dt,ParticleEmitterData *emitter,S32 idx,S32 count)
{
   if (!emitter)
      return;
   for (S32 j = idx; j < idx + count; j++)
      if (active) {
         if (mDataBlock->jetNode[j] != -1) {
            if (!bool(mJetEmitter[j])) {
               mJetEmitter[j] = new ParticleEmitter;
               mJetEmitter[j]->onNewDataBlock(emitter);
               mJetEmitter[j]->registerObject();
            }
            MatrixF mat;
            Point3F pos,axis;
            mat.mul(getRenderTransform(),
                    mShapeInstance->mNodeTransforms[mDataBlock->jetNode[j]]);
            mat.getColumn(1,&axis);
            mat.getColumn(3,&pos);
            mJetEmitter[j]->emitParticles(pos,true,axis,getVelocity(),(U32)(dt * 1000));
         }
      }
      else {
         for (S32 j = idx; j < idx + count; j++)
            if (bool(mJetEmitter[j])) {
               mJetEmitter[j]->deleteWhenEmpty();
               mJetEmitter[j] = 0;
            }
      }
}


//----------------------------------------------------------------------------

void heliVehicle::writePacketData(GameConnection *connection, BitStream *stream)
{
   Parent::writePacketData(connection, stream);
}

void heliVehicle::readPacketData(GameConnection *connection, BitStream *stream)
{
   Parent::readPacketData(connection, stream);

   setPosition(mRigid.linPosition,mRigid.angPosition);
   mDelta.pos = mRigid.linPosition;
   mDelta.rot[1] = mRigid.angPosition;
}

U32 heliVehicle::packUpdate(NetConnection *con, U32 mask, BitStream *stream)
{
   U32 retMask = Parent::packUpdate(con, mask, stream);

   // The rest of the data is part of the control object packet update.
   // If we're controlled by this client, we don't need to send it.
   if(getControllingClient() == con && !(mask & InitialUpdateMask))
      return retMask;

   stream->writeInt(mThrustDirection,NumThrustBits);

   return retMask;
}

void heliVehicle::unpackUpdate(NetConnection *con, BitStream *stream)
{
   Parent::unpackUpdate(con,stream);

   if(getControllingClient() == con)
      return;

   mThrustDirection = ThrustDirection(stream->readInt(NumThrustBits));
}

void heliVehicle::initPersistFields()
{
   Parent::initPersistFields();
}
/*
void heliVehicle::processTick(const Move* move)
{
    Parent::processTick(move);

    // if we're not being controlled by a client, let the
    // AI sub-module get a chance at producing a move
    Move aiMove(NullMove);
    if(isServerObject() && getAIMove(&aiMove))
        move = &aiMove;

    // Warp to catch up to server
    if (mDelta.warpCount < mDelta.warpTicks) {
        mDelta.warpCount++;

        // Set new pos.
        mObjToWorld.getColumn(3,&mDelta.pos);
        mDelta.pos += mDelta.warpOffset;
        mDelta.rot[0] = mDelta.rot[1];
        mDelta.rot[1].interpolate(mDelta.warpRot[0],mDelta.warpRot[1],F32(mDelta.warpCount)/mDelta.warpTicks);
        setPosition(mDelta.pos,mDelta.rot[1]);

        // Pos backstepping
        mDelta.posVec.x = -mDelta.warpOffset.x;
        mDelta.posVec.y = -mDelta.warpOffset.y;
        mDelta.posVec.z = -mDelta.warpOffset.z;
    }
    else {
        if (!move) {
            if (isGhost()) {
                // If we haven't run out of prediction time,
                // predict using the last known move.
                if (mPredictionCount-- <= 0)
                    return;
                move = &mDelta.move;
            }
            else
                move = &NullMove;
        }

        // Process input move
        updateMove(move);

        // Save current rigid state interpolation
        mDelta.posVec = mRigid.linPosition;
        mDelta.rot[0] = mRigid.angPosition;

        //// Update the physics based on the integration rate
        //S32 count = mDataBlock->integration;
        //updateWorkingCollisionSet(getCollisionMask());
        //for (U32 i = 0; i < count; i++)
        //    updatePos(TickSec / count);
        updateWorkingCollisionSet(getCollisionMask());
		updatePos(TickSec);
        if (Vcollided)
           mVelocity.set(0,0,0);

        // Wrap up interpolation info
        mDelta.pos     = mRigid.linPosition;
        mDelta.posVec -= mRigid.linPosition;
        mDelta.rot[1]  = mRigid.angPosition;

        // Update container database
        setPosition(mRigid.linPosition, mRigid.angPosition);
        setMaskBits(PositionMask);
        updateContainer();
    }
}
*/
/*
bool heliVehicle::updatePos(F32 dt)
{
    Point3F origVelocity = mRigid.linVelocity;

    // Update internal forces acting on the body.
    mRigid.clearForces();
    updateForces(dt);

    // Update collision information based on our current pos.
    bool collided = false;
    if (!mRigid.atRest) {
        collided = updateCollision(dt);

        // Now that all the forces have been processed, lets
        // see if we're at rest.  Basically, if the kinetic energy of
        // the vehicles is less than some percentage of the energy added
        // by gravity for a short period, we're considered at rest.
        // This should really be part of the rigid class...
        if (mCollisionList.count) {
            F32 k = mRigid.getKineticEnergy();
            F32 G = mGravity * dt;
            F32 Kg = 0.5 * mRigid.mass * G * G;
            if (k < sRestTol * Kg && ++restCount > sRestCount)
                mRigid.setAtRest();
        }
        else
            restCount = 0;
    }

    // Deal with client and server scripting, sounds, etc.
    if (isServerObject()) {

        // Check triggers and other objects that we normally don't
        // collide with.  This function must be called before notifyCollision
        // as it will queue collision.
        checkTriggers();

        // Invoke the onCollision notify callback for all the objects
        // we've just hit.
        notifyCollision();

        // Server side impact script callback
        if (collided) {
            VectorF collVec = mRigid.linVelocity - origVelocity;
            F32 collSpeed = collVec.len();
            if (collSpeed > mDataBlock->minImpactSpeed)
                onImpact(collVec);
        }

        // Water script callbacks
        if (!inLiquid && mWaterCoverage != 0.0f) {
            Con::executef(mDataBlock,4,"onEnterLiquid",scriptThis(), Con::getFloatArg(mWaterCoverage), Con::getIntArg(mLiquidType));
            inLiquid = true;
        }
        else if (inLiquid && mWaterCoverage == 0.0f) {
            Con::executef(mDataBlock,3,"onLeaveLiquid",scriptThis(), Con::getIntArg(mLiquidType));
            inLiquid = false;
        }

    }
    else {

        // Play impact sounds on the client.
        if (collided) {
            F32 collSpeed = (mRigid.linVelocity - origVelocity).len();
            S32 impactSound = -1;
            if (collSpeed >= mDataBlock->hardImpactSpeed)
                impactSound = VehicleData::Body::HardImpactSound;
            else
                if (collSpeed >= mDataBlock->softImpactSpeed)
                    impactSound = VehicleData::Body::SoftImpactSound;

            if (impactSound != -1 && mDataBlock->body.sound[impactSound] != NULL)
                alxPlay(mDataBlock->body.sound[impactSound], &getTransform());
        }

        // Water volume sounds
        F32 vSpeed = getVelocity().len();
        if (!inLiquid && mWaterCoverage >= 0.8f) {
            if (vSpeed >= mDataBlock->hardSplashSoundVel)
                alxPlay(mDataBlock->waterSound[VehicleData::ImpactHard], &getTransform());
            else
                if (vSpeed >= mDataBlock->medSplashSoundVel)
                    alxPlay(mDataBlock->waterSound[VehicleData::ImpactMedium], &getTransform());
                else
                    if (vSpeed >= mDataBlock->softSplashSoundVel)
                        alxPlay(mDataBlock->waterSound[VehicleData::ImpactSoft], &getTransform());
            inLiquid = true;
        }
        else
            if(inLiquid && mWaterCoverage < 0.8f) {
                if (vSpeed >= mDataBlock->exitSplashSoundVel)
                    alxPlay(mDataBlock->waterSound[VehicleData::ExitWater], &getTransform());
                inLiquid = false;
            }
    }
    return collided;
}
*/
//------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------