//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#ifndef _heliVEHICLE_H_
#define _heliVEHICLE_H_

#ifndef _VEHICLE_H_
#include "game/vehicles/vehicle.h"
#endif

#ifndef _CLIPPEDPOLYLIST_H_
#include "collision/clippedPolyList.h"
#endif

class ParticleEmitter;
class ParticleEmitterData;


//----------------------------------------------------------------------------

struct heliVehicleData: public VehicleData {
   typedef VehicleData Parent;

   enum Sounds {
      JetSound,
      EngineSound,
      MaxSounds,
   };
   AudioProfile* sound[MaxSounds];

   enum Jets {
      // These enums index into a static name list.
      ForwardJetEmitter,      ///< Thrust forward
      BackwardJetEmitter,     ///< Thrust backward
      DownwardJetEmitter,     ///< Thrust down
      UpwardJetEmitter,       ///< Thrust up
      TrailEmitter,           ///< Contrail
      MaxJetEmitters,
   };
   ParticleEmitterData* jetEmitter[MaxJetEmitters];
   F32 minTrailSpeed;         ///< Minimum speed before we show some contrails
   S32 bladeSequence;         ///< Datablock name of the 'top-blades' animation

   F32 maneuveringForce;      ///< How much force to apply when changing direction
   F32 horizontalSurfaceForce;///< Horizontal center "wing" (provides "bite" into the wind for climbing/diving & turning)            
   F32 verticalSurfaceForce;  ///< Vertical center "wing" (controls side slip. lower numbers make MORE slide.)                                                                     
   F32 steeringForce;         ///< Steering jets (force applied when you move the mouse)                                  
   F32 steeringRollForce;     ///< Steering jets (how much you heel over when you turn)                                   
   F32 rollForce;             ///< Auto-roll (self-correction to right you after you roll/invert)                         
   F32 hoverHeight;          
                              ///< Linear Drag (eventually slows you down when not thrusting...constant drag)            
   F32 rotationalDrag;        ///< Angular Drag (dampens the drift after you stop moving the mouse...also tumble drag)
   
   F32 maxAutoSpeed;          ///< Auto stabilizer kicks in when less than this speed. (meters/second)                               
   F32 autoAngularForce;      ///< Angular stabilizer force (this force levels you out when auto stabilizer kicks in) up & down force
   F32 autoLinearForce;       ///< Linear stabilizer force (this slows you down when auto stabilizer kicks in)                       
   F32 autoInputDamping;      ///< Dampen control input so you don't` whack out at very slow speeds                                 
   
   F32 createHoverHeight;
   F32 vertThrustMultiple;
   F32 liftCoefficient;       ///< used in lift calc
   F32 wingArea;              ///< how much lift surface do we have
   F32 airDensity;            ///< used in lift calc
   F32 dragCoefficient;       ///< drag by this amount
   F32 pitchLinForce;         ///< how much force to apply to pitch immediately based on pitch
   F32 noseDownCutoff;        ///< below this speed, apply full gravity to torque
   F32 noseDownHigh;          ///< above this speed, don't apply any gravity to torque
   F32 maxForwardVelocity;    ///< don't apply anymore thrust if we are going this fast.
   //F32 steeringDecay;         ///< Scale the steering by this amount every tick, effective moves the stick to zero
   F32 maneuverCutoff;        ///< Below this speed, you can not pitch/roll
   F32 manueverHigh;          ///< Above this speed, you have full maneuver ability
   F32 manueverAltitude;      ///< Below this altitude (measured off terrain), you have limited maneuvering ability
   F32 propThrustCoeff;       ///< How much thrust does the propeller generate

   // Initialized in preload
   ClippedPolyList rigidBody;
   S32 surfaceCount;
   F32 maxSpeed;

   enum JetNodes {
      // These enums index into a static name list.
      ForwardJetNode,
      ForwardJetNode1,
      BackwardJetNode,
      BackwardJetNode1,
      DownwardJetNode,
      DownwardJetNode1,
      UpwardJetNode,
      UpwardJetNode1,
      //
      TrailNode,
      TrailNode1,
      TrailNode2,
      TrailNode3,
      //
      MaxJetNodes,
      MaxDirectionJets = 2,
      ThrustJetStart = ForwardJetNode,
      NumThrustJets = TrailNode,
      MaxTrails = 4,
   };
   static const char *sJetNode[MaxJetNodes];
   S32 jetNode[MaxJetNodes];
   S32 groundNode;
   Point3F groundNodePos;

   //
   heliVehicleData();
   DECLARE_CONOBJECT(heliVehicleData);
   static void initPersistFields();
   bool preload(bool server, char errorBuffer[256]);
   void packData(BitStream* stream);
   void unpackData(BitStream* stream);
};


//----------------------------------------------------------------------------

class heliVehicle: public Vehicle
{
   typedef Vehicle Parent;

   heliVehicleData* mDataBlock;

   TSThread* mBladeThread;
   AUDIOHANDLE mJetSound;
   AUDIOHANDLE mEngineSound;

   enum NetMaskBits {
      InitMask = BIT(0),
      HoverHeight = BIT(1)
   };
   F32 mCeilingFactor;
   
   enum ThrustDirection {
      // Enums index into sJetActivationTable
      ThrustForward,
      ThrustBackward,
      ThrustUp,
      ThrustDown,
      NumThrustDirections,
      NumThrustBits = 4
   };
   Point3F mThrust;
   Point3F mRPY;  // roll, pitch, yaw. Couldn't think up a better variable name, sorry :)
   ThrustDirection mThrustDirection;
   F32 mSteeringRoll;
   F32 mSteeringPitch;

   // Jet Threads
   enum Jets {
      // These enums index into a static name list.
      BackActivate,
      BackMaintain,
      BottomActivate,
      BottomMaintain,
      JetAnimCount
   };
   static const char* sJetSequence[heliVehicle::JetAnimCount];
   TSThread* mJetThread[JetAnimCount];
   S32 mJetSeq[JetAnimCount];
   bool mBackMaintainOn;
   bool mBottomMaintainOn;
   
   //virtual bool updatePos(F32 dt);
   //virtual void processTick(const Move* move);
   VectorF mVelocity;
   bool mAtRest;
   bool mInLiquid;

   // Jet Particles
   struct JetActivation {
      // Convert thrust direction into nodes & emitters
      S32 node;
      S32 emitter;
   };
   static JetActivation sJetActivation[NumThrustDirections];
   SimObjectPtr<ParticleEmitter> mJetEmitter[heliVehicleData::MaxJetNodes];

   //
   bool onNewDataBlock(GameBaseData* dptr);
   void updateMove(const Move *move);
   void updateForces(F32 dt);

   // Client sounds & particles
   void updateJet(F32 dt);
   void updateEngineSound(F32 level);
   void updateEmitter(bool active,F32 dt,ParticleEmitterData *emitter,S32 idx,S32 count);

   U32 getCollisionMask();
public:
   DECLARE_CONOBJECT(heliVehicle);
   static void initPersistFields();

   heliVehicle();
   ~heliVehicle();

   bool onAdd();
   void onRemove();
   void advanceTime(F32 dt);
   F32 getHeight();
   F32 inputAdjust(const F32 inputAmt);

   void writePacketData(GameConnection *conn, BitStream *stream);
   void readPacketData(GameConnection *conn, BitStream *stream);
   U32  packUpdate(NetConnection *conn, U32 mask, BitStream *stream);
   void unpackUpdate(NetConnection *conn, BitStream *stream);
};


#endif
