//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#include "game/vehicles/TankVehicle.h"

#include "platform/platform.h"
#include "dgl/dgl.h"
#include "game/game.h"
#include "math/mMath.h"
#include "math/mathIO.h"
#include "console/simBase.h"
#include "console/console.h"
#include "console/consoleTypes.h"
#include "collision/clippedPolyList.h"
#include "collision/planeExtractor.h"
#include "game/moveManager.h"
#include "core/bitStream.h"
#include "core/dnet.h"
#include "game/gameConnection.h"
#include "ts/tsShapeInstance.h"
#include "game/fx/particleEngine.h"
#include "audio/audioDataBlock.h"
#include "sceneGraph/sceneGraph.h"
#include "sim/decalManager.h"
#include "dgl/materialPropertyMap.h"
#include "terrain/terrData.h"
#include "sceneGraph/detailManager.h"

//extern MultiProcess mp;
//----------------------------------------------------------------------------

// Collision masks are used to determine what type of objects the
// wheeled vehicle will collide with.
static U32 sClientCollisionMask =
      TerrainObjectType    | InteriorObjectType       |
      PlayerObjectType     | StaticShapeObjectType    |     
	  TurretObjectType     | VehicleObjectType        |
      VehicleBlockerObjectType | StaticTSObjectType;

// Gravity constant
static F32 sTankVehicleGravity = -20;

// Misc. sound constants
static F32 sMinSquealVolume = 0.05;
static F32 sIdleEngineVolume = 0.2;

//----------------------------------------------------------------------------
// Wheeled Vehicle Class
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------

IMPLEMENT_CO_NETOBJECT_V1(TankVehicle);

TankVehicle::TankVehicle()
{

}

TankVehicle::~TankVehicle()
{
}



//----------------------------------------------------------------------------

void TankVehicle::renderImage(SceneState* state, SceneRenderImage* image)
{
	if (!IsEngineOn() && !vehicleInMotion)
		AverageWheelSpeed = 0;

	mShapeInstance->setUVSpeed(AverageWheelSpeed,mDataBlock->UVspeedScale);

   Vehicle::renderImage(state, image);

   // Shape transform
   glPushMatrix();
   dglMultMatrix(&getRenderTransform());

   Wheel* wend = &mWheel[mDataBlock->wheelCount];
   for (Wheel* wheel = mWheel; wheel < wend; wheel++) 
   {
      if (wheel->shapeInstance) 
      {
         glPushMatrix();

         // Steering & spring extension
         //MatrixF hub(EulerF(0,0,mSteering.x * wheel->steering));
         MatrixF hub(1); // dont animate steering
         Point3F pos = wheel->data->pos;
         pos.z -= wheel->spring->length * wheel->extension;
         hub.setColumn(3,pos);
         dglMultMatrix(&hub);

         // Wheel rotation
         MatrixF rot(EulerF(wheel->apos * M_2PI,0,0));
         dglMultMatrix(&rot);

         // Rotation the tire to face the right direction
         // (could pre-calculate this)
         MatrixF wrot(EulerF(0,0,(wheel->data->pos.x > 0)? M_PI/2: -M_PI/2));
         dglMultMatrix(&wrot);

         // Render it
         wheel->shapeInstance->animate();
         wheel->shapeInstance->render();
         glPopMatrix();
      }
   }

   glPopMatrix();
}


//----------------------------------------------------------------------------
// Console Methods
//----------------------------------------------------------------------------

ConsoleMethod(TankVehicle, setWheelSteering, bool, 4, 4, "obj.setWheelSteering(wheel#,float)")
{
   S32 wheel = dAtoi(argv[2]);
   if (wheel >= 0 && wheel < object->getWheelCount()) 
   {
      object->setWheelSteering(wheel,dAtof(argv[3]));
      return true;
   }
   else
      Con::warnf("setWheelSteering: wheel index out of bounds, vehicle has %d hubs",
         argv[3],object->getWheelCount());
   return false;
}

ConsoleMethod(TankVehicle, setWheelPowered, bool, 4, 4, "obj.setWheelPowered(wheel#,bool)")
{
   S32 wheel = dAtoi(argv[2]);
   if (wheel >= 0 && wheel < object->getWheelCount()) 
   {
      object->setWheelPowered(wheel,dAtob(argv[3]));
      return true;
   }
   else
      Con::warnf("setWheelPowered: wheel index out of bounds, vehicle has %d hubs",
         argv[3],object->getWheelCount());
   return false;
}

ConsoleMethod(TankVehicle, setWheelTire, bool, 4, 4, "obj.setWheelTire(wheel#,tire)")
{
   WheeledVehicleTire* tire;
   if (Sim::findObject(argv[3],tire)) 
   {
      S32 wheel = dAtoi(argv[2]);
      if (wheel >= 0 && wheel < object->getWheelCount()) 
      {
         object->setWheelTire(wheel,tire);
         return true;
      }
      else
         Con::warnf("setWheelTire: wheel index out of bounds, vehicle has %d hubs",
            argv[3],object->getWheelCount());
   }
   else
      Con::warnf("setWheelTire: %s datablock does not exist (or is not a tire)",argv[3]);
   return false;
}

ConsoleMethod(TankVehicle, setWheelSpring, bool, 4, 4, "obj.setWheelSpring(wheel#,spring)")
{
   WheeledVehicleSpring* spring;
   if (Sim::findObject(argv[3],spring)) 
   {
      S32 wheel = dAtoi(argv[2]);
      if (wheel >= 0 && wheel < object->getWheelCount()) 
      {
         object->setWheelSpring(wheel,spring);
         return true;
      }
      else
         Con::warnf("setWheelSpring: wheel index out of bounds, vehicle has %d hubs",
            argv[3],object->getWheelCount());
   }
   else
      Con::warnf("setWheelSpring: %s datablock does not exist (or is not a spring)",argv[3]);
   return false;
}

ConsoleMethod(TankVehicle, getWheelCount, S32, 2, 2, "obj.getWheelCount()")
{
   return object->getWheelCount();
}