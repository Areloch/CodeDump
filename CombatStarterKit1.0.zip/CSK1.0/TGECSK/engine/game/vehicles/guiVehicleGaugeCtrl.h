//-----------------------------------------------------------------------------
// GuiVehicleGaugeCtrl.h
// based on Matt "CaptFallout" Webster code
// changed by Frank Bignone, 2002
// changed by Brett Fattori, 2003
// changed by Erik Madison   2007
//-----------------------------------------------------------------------------
#ifndef _GuiVehicleGaugeCtrl_H_
#define _GuiVehicleGaugeCtrl_H_

#ifndef _GUIBITMAPCTRL_H_
#include "gui/controls/guiBitmapCtrl.h"
#endif

#ifndef _SCENEOBJECT_H_
#include "sim/sceneObject.h"
#endif

class GuiVehicleGaugeCtrl : public GuiControl
{
    typedef GuiControl Parent;
private:
	StringTableEntry mBitmapSpin;
	StringTableEntry mBitmapBackground;
	StringTableEntry mBitmapForeground;
	StringTableEntry mBitmapVelocity;
	StringTableEntry mBitmapCompass;
	TextureHandle mMeterSpin;
	TextureHandle mMeterBackground;
	TextureHandle mMeterForeground;
	TextureHandle mMeterVelocity;
	TextureHandle mMeterCompass;
	Point2F	mSpinAng;
	Point2F	mVelocityPos;
    Point2F mSpinOffset;
    ColorF  mColor;
	F32		mAngle;
	F32		mAngle2;         ///< Some gauges (altitude) require 2 spinners. This gets set if needed.
	F32		mCompassAngle;
    F32     mModifier;       ///< Multiply 'value' by this amount, depending on the type of gauge we are making. (ie, kph, mph)
	bool	mInvert;
	bool	mSpinKeepAspect;
	bool	mShowVelocity;
	bool	mShowCompass;
	bool	mShowPitch;
	bool	mShowRoll;
	bool	mInvertRoll;
    Point2F mSpinBitmapOffset;
    F32     mValue;
    F32     mMaxValue;        ///< Max Value
    S32     mValueType;  
public:
    enum {
        GuiGaugeTypeDefault,
        GuiGaugeTypeManual,
        GuiGaugeTypeSpeed,
        GuiGaugeTypeEnergy,
        GuiGaugeTypeRPM,
        GuiGaugeTypeAltitude,
    };
	//creation methods
	DECLARE_CONOBJECT(GuiVehicleGaugeCtrl);
	GuiVehicleGaugeCtrl();
	static void initPersistFields();

	//Parental methods
	bool onWake();
	void onSleep();

	void setBackgroundBitmap(const char *);
	void setForegroundBitmap(const char *);
	void setSpinnerBitmap(const char *);
	void setVelocityBitmap(const char *);
	void setCompassBitmap(const char *);
	void onRender(Point2I offset, const RectI &updateRect); 

	void setSpingAng(Point2F angles) { mSpinAng = angles; }
	void setSpinOffset(Point2F offset) { mSpinOffset = offset; }
	void setVelocity(Point2F position) { mVelocityPos = position; }
	void setCompassAngle( F32 val ) { mCompassAngle = mClampF(val,-180,180); }
	void setAngle( F32 val ) { mAngle = mClampF(val,0,100); }
	void setOffset( F32 val ) { mSpinOffset.y = mClampF(val,-100,100); }
	void setColor( ColorF col ) { col.clamp(); mColor = col; }
    void setMaxValue( F32 val ) { mMaxValue = mClampF(val,0,100); }
    void setValue( F32 val ) { mValue= mClampF(val,0,100); }
    void setValueType( S32 val ) { mValueType = val; }
};

#endif //_GuiVehicleGaugeCtrl_H_
