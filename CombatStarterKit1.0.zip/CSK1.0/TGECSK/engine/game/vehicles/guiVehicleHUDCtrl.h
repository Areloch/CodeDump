//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#ifndef _GuiVehicleHUDCtrl_H_
#define _GuiVehicleHUDCtrl_H_

#ifndef _GUICONTROL_H_
#include "gui/core/guiControl.h"
#endif
#ifndef _GTEXMANAGER_H_
#include "dgl/gTexManager.h"
#endif



class GuiVehicleHUDCtrl : public GuiControl
{
private:
    typedef GuiControl Parent;
    
    enum Constants {
        MAXROCKETS = 10
    };

protected:
    static bool setBitmapName( void *obj, const char *data );
    static const char *getBitmapName( void *obj, const char *data );
    static bool setRocketName( void *obj, const char *data );
    static const char *getRocketName( void *obj, const char *data );
    static bool setAmmoName( void *obj, const char *data );
    static const char *getAmmoName( void *obj, const char *data );

    StringTableEntry mBitmapName;
    StringTableEntry mRocketName;
    StringTableEntry mAmmoName;
    TextureHandle mTextureHandle;
    TextureHandle mTextureRocket;
    TextureHandle mTextureAmmo;
    Point2I startPoint;

    ///< Damage related fields
    bool     mShowDamage;
    ColorF   mNoDamageFillColor;
    F32      mMinorDamageThreshold;
    ColorF   mMinorDamageFillColor;
    F32      mMajorDamageThreshold;
    ColorF   mMajorDamageFillColor;
    S32      mPulseRate;
    F32      mPulseThreshold;
    F32      mValue;

    S32 rocketState[MAXROCKETS];       // -1 none, 0 used, 1 ready
    Point2F rocketOffset[MAXROCKETS];
    F32      mAmmoValue;
public:
    //creation methods
    DECLARE_CONOBJECT(GuiVehicleHUDCtrl);
    GuiVehicleHUDCtrl();
    static void initPersistFields();

    //Parental methods
    bool onWake();
    void onSleep();
    void inspectPostApply();

    void setBitmap(const char *name,bool resize = false);
    void setBitmap(const TextureHandle &handle,bool resize = false);
    void setRocket(const char *name);
    void setRocket(const TextureHandle &handle);
    void setRocketState(S32 state);
    void setAmmo(const char *name);
    void setAmmo(const TextureHandle &handle);

    S32 getWidth() const       { return(mTextureHandle.getWidth()); }
    S32 getHeight() const      { return(mTextureHandle.getHeight()); }
    
    // console related methods
    virtual const char *getScriptValue();
    virtual void setScriptValue(const char *value);

    void onPreRender();
    void onRender(Point2I offset, const RectI &updateRect);
    void setValue(S32 x, S32 y);
};

#endif
