//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#include "game/vehicles/vehicle.h"

#include "platform/platform.h"
#include "dgl/dgl.h"
#include "game/game.h"
#include "math/mMath.h"
#include "math/mathUtils.h"
#include "console/simBase.h"
#include "console/console.h"
#include "console/consoleTypes.h"
#include "collision/clippedPolyList.h"
#include "collision/planeExtractor.h"
#include "game/moveManager.h"
#include "core/bitStream.h"
#include "core/dnet.h"
#include "game/gameConnection.h"
#include "ts/tsShapeInstance.h"
#include "game/fx/particleEngine.h"
#include "audio/audioDataBlock.h"
#include "math/mathIO.h"
#include "sceneGraph/sceneState.h"
#include "sceneGraph/sceneGraph.h"
#include "terrain/terrData.h"
#include "dgl/materialPropertyMap.h"
#include "game/trigger.h"
#include "game/item.h"
#include "gui/controls/guiTextCtrl.h"
#include "platform/profiler.h"


//----------------------------------------------------------------------------

namespace {

const U32 sMoveRetryCount = 3;

// Client prediction
const S32 sMaxWarpTicks = 0;           // Max warp duration in ticks
const S32 sMaxPredictionTicks = 30;    // Number of ticks to predict

// Physics and collision constants
static F32 sRestTol = 0.5;             // % of gravity energy to be at rest
static int sRestCount = 10;            // Consecutive ticks before comming to rest
static S32 mCameraMode;

} // namespace {}

// Trigger objects that are not normally collided with.
static U32 sTriggerMask = ItemObjectType     |
                          TriggerObjectType  |
                          CorpseObjectType;
//Combat Starter Kit
static U32 sDirtySetMask = PlayerObjectType     |
                           TurretObjectType |
                           VehicleObjectType;
//Combat Starter Kit


IMPLEMENT_CONOBJECT(VehicleData);

//----------------------------------------------------------------------------

VehicleData::VehicleData()
{
   shadowEnable = true;
   shadowCanMove = true;
   shadowCanAnimate = true;

   body.friction = 0;
   body.restitution = 1;

   minImpactSpeed = 25;
   softImpactSpeed = 25;
   hardImpactSpeed = 50;
   minRollSpeed = 0;
   maxSteeringAngle = 0.785; // 45 deg.

   steeringDecay = 0.75f;

   cameraRoll = true;
   cameraLag = 0;
   cameraDecay = 0;
   cameraOffset = 0;

   minDrag = 0;
   maxDrag = 0;
   integration = 1;
   collisionTol = 0.1;
   contactTol = 0.1;
   massCenter.set(0,0,0);
   massBox.set(0,0,0);

   drag = 0.7;
   density = 4;

   jetForce = 500;
   jetEnergyDrain =  0.8;
   minJetEnergy = 1;

   for (S32 i = 0; i < Body::MaxSounds; i++)
      body.sound[i] = 0;

   dustEmitter = NULL;
   dustID = 0;
   triggerDustHeight = 3.0;
   dustHeight = 1.0;

   dMemset( damageEmitterList, 0, sizeof( damageEmitterList ) );
   dMemset( damageEmitterIDList, 0, sizeof( damageEmitterIDList ) );
   dMemset( damageLevelTolerance, 0, sizeof( damageLevelTolerance ) );
   dMemset( splashEmitterList, 0, sizeof( splashEmitterList ) );
   dMemset( splashEmitterIDList, 0, sizeof( splashEmitterIDList ) );

   numDmgEmitterAreas = 0;

   splashFreqMod = 300.0;
   splashVelEpsilon = 0.50;
   exitSplashSoundVel = 2.0;
   softSplashSoundVel = 1.0;
   medSplashSoundVel = 2.0;
   hardSplashSoundVel = 3.0;

   genericShadowLevel = Vehicle_GenericShadowLevel;
   noShadowLevel = Vehicle_NoShadowLevel;

   dMemset(waterSound, 0, sizeof(waterSound));

   collDamageThresholdVel = 20;
   collDamageMultiplier   = 0.05;

   //Combat Starter Kit Vehicle hitboxes
   // size of bounding box
   boxSize.set(2.0f, 2.0f, 4.6f );

   // location of head, torso, legs
   boxTopPercentage = 0.85f;
   boxBottomPercentage = 0.55f;

   // damage locations
   boxTopLeftPercentage  = 0;
   boxTopRightPercentage = 1;
   boxTopBackPercentage  = 0;
   boxTopFrontPercentage = 1;

   maxPitchSpeed = 90.0; // degrees/second
   maxYawSpeed = 90.0;   // degrees/second
   minPitch = -90;
   maxPitch = 90;
   minYaw = -180;   // we speak of the constraints on yaw as if it's range
   maxYaw = 180;    // were -180/180 even tho it's actually stored as 0..360
}


//----------------------------------------------------------------------------

bool VehicleData::preload(bool server, char errorBuffer[256])
{
   if (!Parent::preload(server, errorBuffer))
      return false;

   // Resolve objects transmitted from server
   if (!server) {
      for (S32 i = 0; i < Body::MaxSounds; i++)
         if (body.sound[i])
            Sim::findObject(SimObjectId(body.sound[i]),body.sound[i]);
   }

   if( !dustEmitter && dustID != 0 )
   {
      if( !Sim::findObject( dustID, dustEmitter ) )
      {
         Con::errorf( ConsoleLogEntry::General, "VehicleData::preload Invalid packet, bad datablockId(dustEmitter): 0x%x", dustID );
      }
   }

   U32 i;
   for( i=0; i<VC_NUM_DAMAGE_EMITTERS; i++ )
   {
      if( !damageEmitterList[i] && damageEmitterIDList[i] != 0 )
      {
         if( !Sim::findObject( damageEmitterIDList[i], damageEmitterList[i] ) )
         {
            Con::errorf( ConsoleLogEntry::General, "VehicleData::preload Invalid packet, bad datablockId(damageEmitter): 0x%x", damageEmitterIDList[i] );
         }
      }
   }

   for( i=0; i<VC_NUM_SPLASH_EMITTERS; i++ )
   {
      if( !splashEmitterList[i] && splashEmitterIDList[i] != 0 )
      {
         if( !Sim::findObject( splashEmitterIDList[i], splashEmitterList[i] ) )
         {
            Con::errorf( ConsoleLogEntry::General, "VehicleData::preload Invalid packet, bad datablockId(splashEmitter): 0x%x", splashEmitterIDList[i] );
         }
      }
   }

   return true;
}


//----------------------------------------------------------------------------

void VehicleData::packData(BitStream* stream)
{
   S32 i;
   Parent::packData(stream);

   stream->write(steeringDecay);

   stream->write(body.restitution);
   stream->write(body.friction);
   for (i = 0; i < Body::MaxSounds; i++)
      if (stream->writeFlag(body.sound[i]))
         stream->writeRangedU32(packed? SimObjectId(body.sound[i]):
                                body.sound[i]->getId(),DataBlockObjectIdFirst,
                                DataBlockObjectIdLast);

   stream->write(minImpactSpeed);
   stream->write(softImpactSpeed);
   stream->write(hardImpactSpeed);
   stream->write(minRollSpeed);
   stream->write(maxSteeringAngle);

   stream->write(maxDrag);
   stream->write(minDrag);
   stream->write(integration);
   stream->write(collisionTol);
   stream->write(contactTol);
   mathWrite(*stream,massCenter);
   mathWrite(*stream,massBox);

   stream->write(jetForce);
   stream->write(jetEnergyDrain);
   stream->write(minJetEnergy);

   stream->writeFlag(cameraRoll);
   stream->write(cameraLag);
   stream->write(cameraDecay);
   stream->write(cameraOffset);

   stream->write( triggerDustHeight );
   stream->write( dustHeight );

   stream->write( numDmgEmitterAreas );

   stream->write(exitSplashSoundVel);
   stream->write(softSplashSoundVel);
   stream->write(medSplashSoundVel);
   stream->write(hardSplashSoundVel);

   // write the water sound profiles
   for(i = 0; i < MaxSounds; i++)
      if(stream->writeFlag(waterSound[i]))
         stream->writeRangedU32(waterSound[i]->getId(), DataBlockObjectIdFirst,  DataBlockObjectIdLast);

   if (stream->writeFlag( dustEmitter ))
   {
      stream->writeRangedU32( dustEmitter->getId(), DataBlockObjectIdFirst,  DataBlockObjectIdLast );
   }

   for (i = 0; i < VC_NUM_DAMAGE_EMITTERS; i++)
   {
      if( stream->writeFlag( damageEmitterList[i] != NULL ) )
      {
         stream->writeRangedU32( damageEmitterList[i]->getId(), DataBlockObjectIdFirst,  DataBlockObjectIdLast );
      }
   }

   for (i = 0; i < VC_NUM_SPLASH_EMITTERS; i++)
   {
      if( stream->writeFlag( splashEmitterList[i] != NULL ) )
      {
         stream->writeRangedU32( splashEmitterList[i]->getId(), DataBlockObjectIdFirst,  DataBlockObjectIdLast );
      }
   }

   for (int j = 0;  j < VC_NUM_DAMAGE_EMITTER_AREAS; j++)
   {
      stream->write( damageEmitterOffset[j].x );
      stream->write( damageEmitterOffset[j].y );
      stream->write( damageEmitterOffset[j].z );
   }

   for (int k = 0; k < VC_NUM_DAMAGE_LEVELS; k++)
   {
      stream->write( damageLevelTolerance[k] );
   }

   stream->write(splashFreqMod);
   stream->write(splashVelEpsilon);

   stream->write(collDamageThresholdVel);
   stream->write(collDamageMultiplier);

   stream->write(maxPitchSpeed);
   stream->write(maxYawSpeed);
   stream->write(minPitch);
   stream->write(maxPitch);
   stream->write(minYaw);
   stream->write(maxYaw);
}

void VehicleData::unpackData(BitStream* stream)
{
   Parent::unpackData(stream);

   stream->read(&steeringDecay);

   stream->read(&body.restitution);
   stream->read(&body.friction);
   S32 i;
   for (i = 0; i < Body::MaxSounds; i++) {
      body.sound[i] = NULL;
      if (stream->readFlag())
         body.sound[i] = (AudioProfile*)stream->readRangedU32(DataBlockObjectIdFirst,
                                                              DataBlockObjectIdLast);
   }

   stream->read(&minImpactSpeed);
   stream->read(&softImpactSpeed);
   stream->read(&hardImpactSpeed);
   stream->read(&minRollSpeed);
   stream->read(&maxSteeringAngle);

   stream->read(&maxDrag);
   stream->read(&minDrag);
   stream->read(&integration);
   stream->read(&collisionTol);
   stream->read(&contactTol);
   mathRead(*stream,&massCenter);
   mathRead(*stream,&massBox);

   stream->read(&jetForce);
   stream->read(&jetEnergyDrain);
   stream->read(&minJetEnergy);

   cameraRoll = stream->readFlag();
   stream->read(&cameraLag);
   stream->read(&cameraDecay);
   stream->read(&cameraOffset);

   stream->read( &triggerDustHeight );
   stream->read( &dustHeight );

   stream->read( &numDmgEmitterAreas );

   stream->read(&exitSplashSoundVel);
   stream->read(&softSplashSoundVel);
   stream->read(&medSplashSoundVel);
   stream->read(&hardSplashSoundVel);

   // write the water sound profiles
   for(i = 0; i < MaxSounds; i++)
      if(stream->readFlag())
      {
         U32 id = stream->readRangedU32(DataBlockObjectIdFirst, DataBlockObjectIdLast);
         waterSound[i] = dynamic_cast<AudioProfile*>( Sim::findObject(id) );
      }

   if( stream->readFlag() )
   {
      dustID = (S32) stream->readRangedU32(DataBlockObjectIdFirst, DataBlockObjectIdLast);
   }

   for (i = 0; i < VC_NUM_DAMAGE_EMITTERS; i++)
   {
      if( stream->readFlag() )
      {
         damageEmitterIDList[i] = stream->readRangedU32( DataBlockObjectIdFirst, DataBlockObjectIdLast );
      }
   }

   for (i = 0; i < VC_NUM_SPLASH_EMITTERS; i++)
   {
      if( stream->readFlag() )
      {
         splashEmitterIDList[i] = stream->readRangedU32( DataBlockObjectIdFirst, DataBlockObjectIdLast );
      }
   }

   for( int j=0; j<VC_NUM_DAMAGE_EMITTER_AREAS; j++ )
   {
      stream->read( &damageEmitterOffset[j].x );
      stream->read( &damageEmitterOffset[j].y );
      stream->read( &damageEmitterOffset[j].z );
   }

   for( int k=0; k<VC_NUM_DAMAGE_LEVELS; k++ )
   {
      stream->read( &damageLevelTolerance[k] );
   }

   stream->read(&splashFreqMod);
   stream->read(&splashVelEpsilon);

   stream->read(&collDamageThresholdVel);
   stream->read(&collDamageMultiplier);

   stream->read(&maxPitchSpeed);
   stream->read(&maxYawSpeed);
   stream->read(&minPitch);
   stream->read(&maxPitch);
   stream->read(&minYaw);
   stream->read(&maxYaw);
}


//----------------------------------------------------------------------------

void VehicleData::initPersistFields()
{
   Parent::initPersistFields();
   addField("steeringDecay", TypeF32, Offset(steeringDecay, VehicleData));
   addField("jetForce", TypeF32, Offset(jetForce, VehicleData));
   addField("jetEnergyDrain", TypeF32, Offset(jetEnergyDrain, VehicleData));
   addField("minJetEnergy", TypeF32, Offset(minJetEnergy, VehicleData));

   addField("massCenter", TypePoint3F, Offset(massCenter, VehicleData));
   addField("massBox", TypePoint3F, Offset(massBox, VehicleData));
   addField("bodyRestitution", TypeF32, Offset(body.restitution, VehicleData));
   addField("bodyFriction", TypeF32, Offset(body.friction, VehicleData));
   addField("softImpactSound", TypeAudioProfilePtr, Offset(body.sound[Body::SoftImpactSound], VehicleData));
   addField("hardImpactSound", TypeAudioProfilePtr, Offset(body.sound[Body::HardImpactSound], VehicleData));

   addField("minImpactSpeed", TypeF32, Offset(minImpactSpeed, VehicleData));
   addField("softImpactSpeed", TypeF32, Offset(softImpactSpeed, VehicleData));
   addField("hardImpactSpeed", TypeF32, Offset(hardImpactSpeed, VehicleData));
   addField("minRollSpeed", TypeF32, Offset(minRollSpeed, VehicleData));
   addField("maxSteeringAngle", TypeF32, Offset(maxSteeringAngle, VehicleData));

   addField("maxDrag", TypeF32, Offset(maxDrag, VehicleData));
   addField("minDrag", TypeF32, Offset(minDrag, VehicleData));
   addField("integration", TypeS32, Offset(integration, VehicleData));
   addField("collisionTol", TypeF32, Offset(collisionTol, VehicleData));
   addField("contactTol", TypeF32, Offset(contactTol, VehicleData));

   addField("cameraRoll",     TypeBool,       Offset(cameraRoll,     VehicleData));
   addField("cameraLag",      TypeF32,        Offset(cameraLag,      VehicleData));
   addField("cameraDecay",  TypeF32,        Offset(cameraDecay,  VehicleData));
   addField("cameraOffset",   TypeF32,        Offset(cameraOffset,   VehicleData));

   addField("dustEmitter",       TypeParticleEmitterDataPtr,   Offset(dustEmitter,        VehicleData));
   addField("triggerDustHeight", TypeF32,                      Offset(triggerDustHeight,  VehicleData));
   addField("dustHeight",        TypeF32,                      Offset(dustHeight,         VehicleData));

   addField("damageEmitter",        TypeParticleEmitterDataPtr,   Offset(damageEmitterList,     VehicleData), VC_NUM_DAMAGE_EMITTERS);
   addField("splashEmitter",        TypeParticleEmitterDataPtr,   Offset(splashEmitterList,     VehicleData), VC_NUM_SPLASH_EMITTERS);
   addField("damageEmitterOffset",  TypePoint3F,                  Offset(damageEmitterOffset,   VehicleData), VC_NUM_DAMAGE_EMITTER_AREAS);
   addField("damageLevelTolerance", TypeF32,                      Offset(damageLevelTolerance,  VehicleData), VC_NUM_DAMAGE_LEVELS);
   addField("numDmgEmitterAreas",   TypeF32,                      Offset(numDmgEmitterAreas,    VehicleData));

   addField("splashFreqMod",  TypeF32,                Offset(splashFreqMod,   VehicleData));
   addField("splashVelEpsilon", TypeF32,              Offset(splashVelEpsilon, VehicleData));

   addField("exitSplashSoundVelocity", TypeF32,       Offset(exitSplashSoundVel, VehicleData));
   addField("softSplashSoundVelocity", TypeF32,       Offset(softSplashSoundVel, VehicleData));
   addField("mediumSplashSoundVelocity", TypeF32,     Offset(medSplashSoundVel, VehicleData));
   addField("hardSplashSoundVelocity", TypeF32,       Offset(hardSplashSoundVel, VehicleData));
   addField("exitingWater",      TypeAudioProfilePtr, Offset(waterSound[ExitWater],   VehicleData));
   addField("impactWaterEasy",   TypeAudioProfilePtr, Offset(waterSound[ImpactSoft],   VehicleData));
   addField("impactWaterMedium", TypeAudioProfilePtr, Offset(waterSound[ImpactMedium],   VehicleData));
   addField("impactWaterHard",   TypeAudioProfilePtr, Offset(waterSound[ImpactHard],   VehicleData));
   addField("waterWakeSound",    TypeAudioProfilePtr, Offset(waterSound[Wake],   VehicleData));

   addField("boxTopPercentage", TypeF32, Offset(boxTopPercentage, VehicleData));
   addField("boxBottomPercentage", TypeF32, Offset(boxBottomPercentage, VehicleData));
   addField("boxTopLeftPercentage", TypeS32, Offset(boxTopLeftPercentage, VehicleData));
   addField("boxTopRightPercentage", TypeS32, Offset(boxTopRightPercentage, VehicleData));
   addField("boxTopBackPercentage", TypeS32, Offset(boxTopBackPercentage, VehicleData));
   addField("boxTopFrontPercentage", TypeS32, Offset(boxTopFrontPercentage, VehicleData));

   addField("collDamageThresholdVel", TypeF32, Offset(collDamageThresholdVel, VehicleData));
   addField("collDamageMultiplier",   TypeF32, Offset(collDamageMultiplier,   VehicleData));

   addField("maxPitchSpeed", TypeF32,  Offset(maxPitchSpeed, VehicleData));
   addField("maxYawSpeed", TypeF32,  Offset(maxYawSpeed, VehicleData));
   addField("minPitch", TypeF32, Offset(minPitch, VehicleData));
   addField("maxPitch", TypeF32, Offset(maxPitch, VehicleData));
   addField("minYaw", TypeF32, Offset(minYaw, VehicleData));
   addField("maxYaw", TypeF32, Offset(maxYaw, VehicleData));
}


//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
IMPLEMENT_CONOBJECT(Vehicle);

Vehicle::Vehicle()
{
   mDataBlock = 0;
   mTypeMask |= VehicleObjectType;

   mDelta.pos = Point3F(0,0,0);
   mDelta.posVec = Point3F(0,0,0);
   mDelta.warpTicks = mDelta.warpCount = 0;
   mDelta.dt = 1;
   mDelta.move = NullMove;
   mPredictionCount = 0;
   mDelta.cameraOffset.set(0,0,0);
   mDelta.cameraVec.set(0,0,0);
   mDelta.cameraRot.set(0,0,0);
   mDelta.cameraRotVec.set(0,0,0);


   mRigid.linPosition.set(0, 0, 0);
   mRigid.linVelocity.set(0, 0, 0);
   mRigid.angPosition.identity();
   mRigid.angVelocity.set(0, 0, 0);
   mRigid.linMomentum.set(0, 0, 0);
   mRigid.angMomentum.set(0, 0, 0);
   mContacts.count = 0;

   mSteering.set(0,0);
   mThrottle = 0;
   mJetting = false;
   mJettingDn = false;  //Combat Starter Kit
   mEngineState = false;

   mCameraOffset.set(0,0,0);

   dMemset( mDustEmitterList, 0, sizeof( mDustEmitterList ) );
   dMemset( mDamageEmitterList, 0, sizeof( mDamageEmitterList ) );
   dMemset( mSplashEmitterList, 0, sizeof( mSplashEmitterList ) );

   mDisableMove = false;
   restCount = 0;

   inLiquid = false;
   underLiquid = false;
   waterWakeHandle = 0;
   inAir = false;

   turretNode = -1;
   weaponNode = -1;
   mRot.set(0,0,0);
   Rotation = LastRotation = mRot;
   mHasTurretNodes = false;
   turretHasMoved = false;
   allowImpulse = 0;
}

U32 Vehicle::getCollisionMask()
{
   AssertFatal(false, "Vehicle::getCollisionMask is pure virtual!");
   return 0;
}

Point3F Vehicle::getVelocity() const
{
   return mRigid.linVelocity;
}

//----------------------------------------------------------------------------

bool Vehicle::onAdd()
{
   if (!Parent::onAdd())
      return false;

   // When loading from a mission script, the base SceneObject's transform
   // will have been set and needs to be transfered to the rigid body.
   mRigid.setTransform(mObjToWorld);

   // Initialize interpolation vars.
   mDelta.rot[1] = mDelta.rot[0] = mRigid.angPosition;
   mDelta.pos = mRigid.linPosition;
   mDelta.posVec = Point3F(0,0,0);

   // Create Emitters on the client
   if( isClientObject() )
   {
      if( mDataBlock->dustEmitter )
      {
         for( int i=0; i<VehicleData::VC_NUM_DUST_EMITTERS; i++ )
         {
            mDustEmitterList[i] = new ParticleEmitter;
            mDustEmitterList[i]->onNewDataBlock( mDataBlock->dustEmitter );
            if( !mDustEmitterList[i]->registerObject() )
            {
               Con::warnf( ConsoleLogEntry::General, "Could not register dust emitter for class: %s", mDataBlock->getName() );
               delete mDustEmitterList[i];
               mDustEmitterList[i] = NULL;
            }
         }

      }

      U32 j;
      for( j=0; j<VehicleData::VC_NUM_DAMAGE_EMITTERS; j++ )
      {
         if( mDataBlock->damageEmitterList[j] )
         {
            mDamageEmitterList[j] = new ParticleEmitter;
            mDamageEmitterList[j]->onNewDataBlock( mDataBlock->damageEmitterList[j] );
            if( !mDamageEmitterList[j]->registerObject() )
            {
               Con::warnf( ConsoleLogEntry::General, "Could not register damage emitter for class: %s", mDataBlock->getName() );
               delete mDamageEmitterList[j];
               mDamageEmitterList[j] = NULL;
            }

         }
      }

      for( j=0; j<VehicleData::VC_NUM_SPLASH_EMITTERS; j++ )
      {
         if( mDataBlock->splashEmitterList[j] )
         {
            mSplashEmitterList[j] = new ParticleEmitter;
            mSplashEmitterList[j]->onNewDataBlock( mDataBlock->splashEmitterList[j] );
            if( !mSplashEmitterList[j]->registerObject() )
            {
               Con::warnf( ConsoleLogEntry::General, "Could not register splash emitter for class: %s", mDataBlock->getName() );
               delete mSplashEmitterList[j];
               mSplashEmitterList[j] = NULL;
            }

         }
      }
   }

   // Create a new convex.
   AssertFatal(mDataBlock->collisionDetails[0] != -1, "Error, a vehicle must have a collision-1 detail!");
   mConvex.mObject    = this;
   mConvex.pShapeBase = this;
   mConvex.hullId     = 0;
   mConvex.box        = mObjBox;
   mConvex.box.min.convolve(mObjScale);
   mConvex.box.max.convolve(mObjScale);
   mConvex.findNodeTransform();

   return true;
}

void Vehicle::onRemove()
{
   U32 i=0;
   for( i=0; i<VehicleData::VC_NUM_DUST_EMITTERS; i++ )
   {
      if( mDustEmitterList[i] )
      {
         mDustEmitterList[i]->deleteWhenEmpty();
         mDustEmitterList[i] = NULL;
      }
   }

   for( i=0; i<VehicleData::VC_NUM_DAMAGE_EMITTERS; i++ )
   {
      if( mDamageEmitterList[i] )
      {
         mDamageEmitterList[i]->deleteWhenEmpty();
         mDamageEmitterList[i] = NULL;
      }
   }

   for( i=0; i<VehicleData::VC_NUM_SPLASH_EMITTERS; i++ )
   {
      if( mSplashEmitterList[i] )
      {
         mSplashEmitterList[i]->deleteWhenEmpty();
         mSplashEmitterList[i] = NULL;
      }
   }

   Parent::onRemove();
}


//----------------------------------------------------------------------------

void Vehicle::processTick(const Move* move)
{
   Parent::processTick(move);

   // if we're not being controlled by a client, let the
   // AI sub-module get a chance at producing a move
   Move aiMove(NullMove);
   if(isServerObject() && getAIMove(&aiMove))
      move = &aiMove;

   // Warp to catch up to server
   if (mDelta.warpCount < mDelta.warpTicks) {
      mDelta.warpCount++;

      // Set new pos.
      mObjToWorld.getColumn(3,&mDelta.pos);
      mDelta.pos += mDelta.warpOffset;
      mDelta.rot[0] = mDelta.rot[1];
      mDelta.rot[1].interpolate(mDelta.warpRot[0],mDelta.warpRot[1],F32(mDelta.warpCount)/mDelta.warpTicks);
      setPosition(mDelta.pos,mDelta.rot[1]);
      //setRenderPosition(mDelta.pos,mDelta.rot[1]); //Combat Starter Kit

      // Pos backstepping
      mDelta.posVec.x = -mDelta.warpOffset.x;
      mDelta.posVec.y = -mDelta.warpOffset.y;
      mDelta.posVec.z = -mDelta.warpOffset.z;
   }
   else {
      if (!move) {
         if (isGhost()) {
            // If we haven't run out of prediction time,
            // predict using the last known move.
            if (mPredictionCount-- <= 0)
               return;
            move = &mDelta.move;
         }
         else
            move = &NullMove;
      }

	  setEngineState((bool)getMountNodeObject(0)); //mount 0 must always be the driver

      // Process input move
      if(move != &NullMove)
		  updateMove(move);

      // Save current rigid state interpolation
      mDelta.posVec = mRigid.linPosition;
      mDelta.rot[0] = mRigid.angPosition;

	  Point3F curPos;
	  getTransform().getColumn(3, &curPos);
	  F32 motion = mFabs((curPos - lastTickPosition).len());
	  if((motion > 0.05)|| inAir || allowImpulse)
		  vehicleInMotion = true;
	  else
		  vehicleInMotion = false;
	  lastTickPosition = curPos;


      if(allowImpulse)
		  tickCounter++;
	  if(tickCounter >50)
	  {
		  tickCounter = 0;
		  allowImpulse = false;
	  }


      // Update the physics based on the integration rate
	  if (IsEngineOn() || vehicleInMotion)
	  {
          setMaskBits(PositionMask);
		  updateWorkingCollisionSet(getCollisionMask());
	      S32 count = mDataBlock->integration;
		  for (U32 i = 0; i < count; i++)
			  updatePos(TickSec / count);
	  }
	  else
		  if(turretHasMoved)
			  setMaskBits(PositionMask);

      // Wrap up interpolation info
      mDelta.pos     = mRigid.linPosition;
      mDelta.posVec -= mRigid.linPosition;
      mDelta.rot[1]  = mRigid.angPosition;

      // Update container database
      setPosition(mRigid.linPosition, mRigid.angPosition);
      updateContainer();
   }
}

void Vehicle::interpolateTick(F32 dt)
{
   Parent::interpolateTick(dt);

   if(dt == 0.0f)
      setRenderPosition(mDelta.pos, mDelta.rot[1]);
   else
   {
      QuatF rot;
      rot.interpolate(mDelta.rot[1], mDelta.rot[0], dt);
      Point3F pos = mDelta.pos + mDelta.posVec * dt;
      setRenderPosition(pos,rot);
   }
   mDelta.dt = dt;


   if(!mHasTurretNodes)
	   return;

   // turret

   F32 realTickSegment = calculateRealTickSegment();
   if(realTickSegment <= 1.0)
	   LastRotation =  Rotation;
   else
   {
	   LastRotation.z -= (LastRotation.z - Rotation.z) / realTickSegment;
	   LastRotation.x -= (LastRotation.x - Rotation.x) / realTickSegment;
   }

   mRot = LastRotation;

   updateLookAnimation();
}
void Vehicle::advanceTime(F32 dt)
{
   Parent::advanceTime(dt);

   updateDamageSmoke( dt );

   if (!IsEngineOn() && !vehicleInMotion)
       return;

   updateLiftoffDust( dt );
   updateFroth(dt);

   // Update 3rd person camera offset.  Camera update is done
   // here as it's a client side only animation.
   mCameraOffset -=
      (mCameraOffset * mDataBlock->cameraDecay +
      mRigid.linVelocity * mDataBlock->cameraLag) * dt;
}


//----------------------------------------------------------------------------

bool Vehicle::onNewDataBlock(GameBaseData* dptr)
{
   mDataBlock = dynamic_cast<VehicleData*>(dptr);
   if (!mDataBlock || !Parent::onNewDataBlock(dptr))
      return false;

   // Update Rigid Info
   mRigid.mass = mDataBlock->mass;
   mRigid.oneOverMass = 1 / mRigid.mass;
   mRigid.friction = mDataBlock->body.friction;
   mRigid.restitution = mDataBlock->body.restitution;
   mRigid.setCenterOfMass(mDataBlock->massCenter);

   // Ignores massBox, just set sphere for now. Derived objects
   // can set what they want.
   mRigid.setObjectInertia();

   // turret limits below

   // convert from degrees/sec to radians/server tick
   mMaxYawSpeed = mDataBlock->maxYawSpeed * (M_PI/180.0) * TickSec;
   mMaxPitchSpeed = mDataBlock->maxPitchSpeed * (M_PI/180.0) * TickSec;
   // don't allow nonsensical values
   if (mDataBlock->minYaw > 0)
      mDataBlock->minYaw = 0;
   if (mDataBlock->maxYaw < 0)
      mDataBlock->maxYaw = 0;

   // convert from degrees to radians
   // make sure if at min/max then it's exact
   // because we look for == M_PI later on...
   if (mDataBlock->minYaw <= -180.0)
      mMinYaw = -M_PI;
   else
      mMinYaw = mDataBlock->minYaw * M_PI / 180.0;

   if (mDataBlock->maxYaw >= 180.0)
      mMaxYaw = M_PI;
   else
      mMaxYaw = mDataBlock->maxYaw * M_PI / 180.0;

   // don't allow nonsensical values
   if (mDataBlock->minPitch > 0)
      mDataBlock->minPitch = 0;
   if (mDataBlock->maxPitch < 0)
      mDataBlock->maxPitch = 0;
   if (mDataBlock->minPitch < -90.0)
      mMinPitch = -M_PI/2.0;
   else
      mMinPitch = mDataBlock->minPitch * M_PI / 180.0;
   if (mDataBlock->maxPitch > 90.0)
      mMaxPitch = M_PI/2.0;
   else
      mMaxPitch = mDataBlock->maxPitch * M_PI / 180.0;

    return true;
}


//----------------------------------------------------------------------------

void Vehicle::getCameraParameters(F32 *min,F32* max,Point3F* off,MatrixF* rot)
{
   *min = mDataBlock->cameraMinDist;
   *max = mDataBlock->cameraMaxDist;

   off->set(0,0,mDataBlock->cameraOffset);
   rot->identity();
}
//----------------------------------------------------------------------------

void Vehicle::getUprightCameraTransform(  MatrixF* mat)
{
   // Build a transform that points along the eye axis
   // but where the Z axis is always up.
	  Point3F pos;
	  mat->getColumn(3, &pos);
      MatrixF cam(1);
      VectorF x,z(0,0,1);
      mCross(mCamData.direction, z, &x);
      x.normalize();
      mCross(x, mCamData.direction, &z);
      z.normalize();
      cam.setColumn(0,x);
      cam.setColumn(1,mCamData.direction);
      cam.setColumn(2,z);
	  cam.setColumn(3,pos);
      mat->mul(cam,mCamData.rot);
}

void Vehicle::getUprightTurretCameraTransform(  MatrixF* mat)
{
	// Build a transform that points along the matrix direction axis
	// but where the Z axis is always up.


	Point3F pos, direction;
	mat->getColumn(3, &pos);
	mat->getColumn(1, &direction);
	MatrixF cam(1);
	VectorF x,z(0,0,1);
	mCross(direction, z, &x);
	x.normalize();
	mCross(x, direction, &z);
	z.normalize();
	cam.setColumn(0,x);
	cam.setColumn(1,direction);
	cam.setColumn(2,z);
	cam.setColumn(3,pos);
	mat->mul(cam,mCamData.rot);
}
//----------------------------------------------------------------------------

void Vehicle::getCameraTransform(F32* pos,MatrixF* mat)
{

   // Returns camera to world space transform
   // Handles first person / third person camera position
   if (isServerObject() && mShapeInstance)
      mShapeInstance->animateNodeSubtrees(true);

   getCameraParameters(&mCamData.min,&mCamData.max,&mCamData.offset,&mCamData.rot);
   getRenderEyeTransform(&mCamData.eye);
   mCamData.eye.getColumn(1, &mCamData.direction);

   //if (*pos == 0) { // first person mode

   // camera mode 0 is used for 3rd person
   // mode 1 is first person and mode > 1 is one of many weapon nodes
   // or what ever other viewpoints you wish to add
   if(mCameraMode >0){
	   getCamera_1st_Transform(pos, mat);
	   return;
   }

   //3rd person mode follows
   getCamera_3rd_Transform(pos, mat);

}


//----------------------------------------------------------------------------
// Duncan - this has been modified to look-through weapon muzzlepoints
// camera mode 0 is for 3rd person view
// camera mode 1 is for 1st person view
// camera mode > 1 is for any weapon views you wish to use
// each vehicle must set the $weaponViews variable to suit its situation
// the code assumes that weapon views correspond to image slots in use
// and that image slots are numbered sequencially from 0 upwards
// example $weaponViews = 4 means you have weapons mounted on slots
// 0 through slot 3
// see vehicleCameraMode.cs script file
void Vehicle::getCamera_1st_Transform(F32* pos, MatrixF* mat)
{
	if(mCameraMode > 1)
	{
		U32 ImageSlot = mCameraMode-2;
	   // look for a turret and muzzlepoint

		// commented out the turret code because the client controling the vehicle
		// will now never, also be controling an external turret.  Only usefull if
		// you want him/her to see what the other mounted players are shooting at
		/*
		Turret* tmpTurret;
		for (ShapeBase* ptr = getMountList(); ptr; ptr = ptr->getMountLink())
		{
			tmpTurret = dynamic_cast<Turret*>(ptr);
			if (tmpTurret)
			{
				if(tmpTurret->getImageState(ImageSlot) != 0)
				{
					tmpTurret->getRenderCamTransform(ImageSlot,mat);
					getUprightTurretCameraTransform(mat);
					return;
				}
			}
		}
		*/
		/*
		if(mHasTurretNodes &&(turretSlot == ImageSlot))
		{
			*mat = weaponCamMat;
			return;
		}
		*/
	   // if still here then no turret or turret-cam or turret-muzzlepoint was found
	   // check if we have our own weapon image mounted on this vehicle
	   // and gets its muzzelpoint, or use the vehicle eye node
	   if(getImageState(ImageSlot) != 0){
		   getRenderCamTransform(ImageSlot,mat);
		   getUprightTurretCameraTransform(mat);
	   }
	   else
		   getRenderEyeTransform(mat);
	}
	else
		getRenderEyeTransform(mat);


}
//----------------------------------------------------------------------------
void Vehicle::getCamera_3rd_Transform(F32* pos, MatrixF* mat)
{
   if (mDataBlock->cameraRoll)
      mat->mul(mCamData.eye,mCamData.rot);
   else {
	   getUprightCameraTransform(mat);
   }

   // Camera is positioned straight back along the eye's -Y axis.
   // A ray is cast to make sure the camera doesn't go through
   // anything solid.
   VectorF vp,vec;
   vp.x = vp.z = 0;
   vp.y = -(mCamData.max - mCamData.min) * *pos;
   mCamData.eye.mulV(vp,&vec);

   // Use the camera node as the starting position if it exists.
   Point3F osp,sp;
   if (mDataBlock->cameraNode != -1) {
      mShapeInstance->mNodeTransforms[mDataBlock->cameraNode].getColumn(3,&osp);
      getRenderTransform().mulP(osp,&sp);
   }
   else
      mCamData.eye.getColumn(3,&sp);

   // Make sure we don't hit ourself...
   disableCollision();
   if (isMounted())
      getObjectMount()->disableCollision();

   // Cast the ray into the container database to see if we're going
   // to hit anything.
   RayInfo collision;
   Point3F ep = sp + vec + mCamData.offset + mCameraOffset;
   if (mContainer->castRay(sp, ep,
         ~(WaterObjectType | GameBaseObjectType | DefaultObjectType),
         &collision) == true) {

      // Shift the collision point back a little to try and
      // avoid clipping against the front camera plane.
      F32 t = collision.t - (-mDot(vec, collision.normal) / vec.len()) * 0.1;
      if (t > 0.0f)
         ep = sp + mCamData.offset + mCameraOffset + (vec * t);
      else
         mCamData.eye.getColumn(3,&ep);
   }
   mat->setColumn(3,ep);

   // Re-enable our collision.
   if (isMounted())
      getObjectMount()->enableCollision();
   enableCollision();
}
//----------------------------------------------------------------------------

void Vehicle::getVelocity(const Point3F& r, Point3F* v)
{
   mRigid.getVelocity(r, v);
}

void Vehicle::applyImpulse(const Point3F &pos, const Point3F &impulse)
{
   Point3F r;
   mRigid.getOriginVector(pos,&r);
   mRigid.applyImpulse(r, impulse);
}


//----------------------------------------------------------------------------


void Vehicle::updateMove(const Move* move)
{
	mDelta.move = *move;

	if (!IsEngineOn() && !vehicleInMotion)
	   return;

	// Image Triggers
	if (mDamageState == Enabled) {
		setImageTriggerState(0,move->trigger[0]);
		setImageTriggerState(1,move->trigger[1]);
	}

   updateTurretMove(move);

	PROFILE_START(VehicleUpdateMove);
   // Steering
   if ((move != &NullMove)) {
	   F32 y = move->yaw;
	   mSteering.x = mClampF(mSteering.x + y,-mDataBlock->maxSteeringAngle,
		   mDataBlock->maxSteeringAngle);
	   mSteering.x *= mDataBlock->steeringDecay;
	   F32 p = move->pitch;
	   mSteering.y = mClampF(mSteering.y + p,-mDataBlock->maxSteeringAngle,
		   mDataBlock->maxSteeringAngle);
	   mSteering.y *= mDataBlock->steeringDecay;
   }
   else {
	   mSteering.x = 0;
	   mSteering.y = 0;
   }

   // Throttle
   if(!mDisableMove)
       mThrottle = mFabs(move->y)>0 ? move->y :
	   move->z; // if we're not going forward, maybe we're going up. Otherwise, we should get a 0 throttle.


   // Fafhrd; All vehicles use energy (fuel). For now, let's just re-use this variable
   F32 newEnergy = getEnergyLevel() - ((mDataBlock->jetEnergyDrain / 1000) * mClampF(mThrottle, 0.01, mThrottle)); // higher throttle, more gas
   if (newEnergy < 0) {
       newEnergy = 0;
       setEngineState (0); // shut her down. Call some sound effects?
   }
   setEnergyLevel(newEnergy);

   // Jetting flag
   if (move->trigger[3]) {
      if (!mJetting && getEnergyLevel() >= mDataBlock->minJetEnergy)
         mJetting = true;
      if (mJetting) {
         F32 newEnergy = getEnergyLevel() - mDataBlock->jetEnergyDrain;
         if (newEnergy < 0) {
            newEnergy = 0;
            mJetting = false;
         }
         setEnergyLevel(newEnergy);
      }
   }
   else
      mJetting = false;
    PROFILE_END();
}


//----------------------------------------------------------------------------

void Vehicle::setPosition(const Point3F& pos,const QuatF& rot)
{
   MatrixF mat;
   rot.setMatrix(&mat);
   mat.setColumn(3,pos);
   Parent::setTransform(mat);
}

void Vehicle::setRenderPosition(const Point3F& pos, const QuatF& rot)
{
   MatrixF mat;
   rot.setMatrix(&mat);
   mat.setColumn(3,pos);
   Parent::setRenderTransform(mat);
}

void Vehicle::setTransform(const MatrixF& newMat)
{
   mRigid.setTransform(newMat);
   Parent::setTransform(newMat);
   mRigid.atRest = false;
   mContacts.count = 0;
}


//-----------------------------------------------------------------------------

void Vehicle::disableCollision()
{
   Parent::disableCollision();
   for (ShapeBase* ptr = getMountList(); ptr; ptr = ptr->getMountLink())
      ptr->disableCollision();
}

void Vehicle::enableCollision()
{
   Parent::enableCollision();
   for (ShapeBase* ptr = getMountList(); ptr; ptr = ptr->getMountLink())
      ptr->enableCollision();
}


//----------------------------------------------------------------------------
/** Update the physics
*/

void Vehicle::updatePos(F32 dt)
{
   Point3F origVelocity = mRigid.linVelocity;

   // Update internal forces acting on the body.
   mRigid.clearForces();
   updateForces(dt);

   // Update collision information based on our current pos.
   Vcollided = false;
   if (!mRigid.isAtRest(dt)) {
      Vcollided = updateCollision(dt);
      mRigid.integrate(dt);
   }

    // Deal with client and server scripting, sounds, etc.
   if (isServerObject()) {

      // Check triggers and other objects that we normally don't
      // collide with.  This function must be called before notifyCollision
      // as it will queue collision.
      checkTriggers();

      // Invoke the onCollision notify callback for all the objects
      // we've just hit.
      notifyCollision();

      // Server side impact script callback
      if (Vcollided) {
         VectorF collVec = mRigid.linVelocity - origVelocity;
         F32 collSpeed = collVec.len();
         if (collSpeed > mDataBlock->minImpactSpeed)
            onImpact(collVec);
      }

      // Water script callbacks - shallow water
      if (!inLiquid && mWaterCoverage != 0.0f) {
         Con::executef(mDataBlock,4,"onEnterLiquid",scriptThis(), Con::getFloatArg(mWaterCoverage), Con::getIntArg(mLiquidType));
         inLiquid = true;
      }
      else if (inLiquid && mWaterCoverage == 0.0f) {
         Con::executef(mDataBlock,3,"onLeaveLiquid",scriptThis(), Con::getIntArg(mLiquidType));
         inLiquid = false;
      }

      // Water script callbacks - DEEP water
	  if(!underLiquid && mWaterCoverage >= 0.9f)
	  {
        underLiquid = true;
		Con::executef(mDataBlock,2,"onUnderWater",scriptThis());
	  }
	  else
	  if(underLiquid && mWaterCoverage <= 0.5f)
	  {
        underLiquid = false;
		//Con::executef(mDataBlock,2,"onNotUnderWater",scriptThis());
	  }

   }
   else {

      // Play impact sounds on the client.
      if (Vcollided) {
         F32 collSpeed = (mRigid.linVelocity - origVelocity).len();
         S32 impactSound = -1;
         if (collSpeed >= mDataBlock->hardImpactSpeed)
            impactSound = VehicleData::Body::HardImpactSound;
         else
            if (collSpeed >= mDataBlock->softImpactSpeed)
               impactSound = VehicleData::Body::SoftImpactSound;

         if (impactSound != -1 && mDataBlock->body.sound[impactSound] != NULL)
            alxPlay(mDataBlock->body.sound[impactSound], &getTransform());
      }

      // Water volume sounds
      F32 vSpeed = getVelocity().len();
      if (!inLiquid && mWaterCoverage >= 0.8f) {
         if (vSpeed >= mDataBlock->hardSplashSoundVel)
            alxPlay(mDataBlock->waterSound[VehicleData::ImpactHard], &getTransform());
         else
            if (vSpeed >= mDataBlock->medSplashSoundVel)
               alxPlay(mDataBlock->waterSound[VehicleData::ImpactMedium], &getTransform());
         else
            if (vSpeed >= mDataBlock->softSplashSoundVel)
               alxPlay(mDataBlock->waterSound[VehicleData::ImpactSoft], &getTransform());
         inLiquid = true;
      }
      else
         if(inLiquid && mWaterCoverage < 0.8f) {
            if (vSpeed >= mDataBlock->exitSplashSoundVel)
               alxPlay(mDataBlock->waterSound[VehicleData::ExitWater], &getTransform());
         inLiquid = false;
      }
   }
}


//----------------------------------------------------------------------------

void Vehicle::updateForces(F32 /*dt*/)
{
   // Nothing here.
}


//-----------------------------------------------------------------------------
/** Update collision information
   Update the convex state and check for collisions. If the object is in
   collision, impact and contact forces are generated.
*/

bool Vehicle::updateCollision(F32 dt)
{
   // Update collision information
   MatrixF mat,cmat;
   mConvex.transform = &mat;
   mRigid.getTransform(&mat);
   cmat = mConvex.getTransform();

   mCollisionList.count = 0;
   CollisionState *state = mConvex.findClosestState(cmat, getScale(), mDataBlock->collisionTol);
   if (state && state->dist <= mDataBlock->collisionTol) {
      //resolveDisplacement(ns,state,dt);
      mConvex.getCollisionInfo(cmat, getScale(), &mCollisionList, mDataBlock->collisionTol);
   }

   // Resolve collisions
   bool collided = resolveCollision(mRigid,mCollisionList, dt);
//   resolveContacts(mRigid,mCollisionList,dt);
   return collided;
}


//----------------------------------------------------------------------------
/** Resolve collision impacts
   Handle collision impacts, as opposed to contacts. Impulses are calculated based
   on standard collision resolution formulas.
*/

bool Vehicle::resolveCollision(Rigid&  ns,CollisionList& cList, F32 dt)
{
   // Apply impulses to resolve collision
   bool colliding, collided = false;

   do {
      colliding = false;
      for (S32 i = 0; i < cList.count; i++) {
         Collision& c = cList.collision[i];
         if (c.distance < mDataBlock->collisionTol) {
            // Velocity into surface
            Point3F v,r;
            ns.getOriginVector(c.point,&r);
            ns.getVelocity(r,&v);
            F32 vn = mDot(v,c.normal);

            // Only interested in velocities greater than sContactTol,
            // velocities less than that will be dealt with as contacts
            // "constraints".
            if (vn < -mDataBlock->contactTol) {

               // Apply impulses to the rigid body to keep it from
               // penetrating the surface.
               //ns.resolveCollision(cList.collision[i].point,cList.collision[i].normal);
			   ns.resolveCollision(cList.collision[i]);
               colliding = collided  = true;

               // Keep track of objects we collide with
               if (!isGhost() && c.object->getTypeMask() & ShapeBaseObjectType) {
                  ShapeBase* col = static_cast<ShapeBase*>(c.object);
                  queueCollision(col,v - col->getVelocity());
               }
            }
			else // it's handeled as a contact
			{
				ns.resolveCollision(cList.collision[i]);
			}

		 }
      }
   } while (colliding);

   return collided;
}

/*
bool Vehicle::resolveCollision(Rigid&  ns,CollisionList& cList)
{
   // Apply impulses to resolve collision
   bool colliding, collided = false;

   do {
      colliding = false;
      for (S32 i = 0; i < cList.count; i++) {
         Collision& c = cList.collision[i];
         if (c.distance < mDataBlock->collisionTol) {
            // Velocity into surface
            Point3F v,r;
            ns.getOriginVector(c.point,&r);
            ns.getVelocity(r,&v);
            F32 vn = mDot(v,c.normal);

            // Only interested in velocities greater than sContactTol,
            // velocities less than that will be dealt with as contacts
            // "constraints".
            if (vn < -mDataBlock->contactTol) {

               // Apply impulses to the rigid body to keep it from
               // penetrating the surface.
               //ns.resolveCollision(cList.collision[i].point,cList.collision[i].normal);
			   ns.resolveCollision(cList.collision[i]);
               colliding = collided  = true;

               // Keep track of objects we collide with
               if (!isGhost() && c.object->getTypeMask() & ShapeBaseObjectType) {
                  ShapeBase* col = static_cast<ShapeBase*>(c.object);
                  queueCollision(col,v - col->getVelocity());
               }
            }
         }
      }
   } while (colliding);

   return collided;
}

//----------------------------------------------------------------------------
// Resolve contact forces
//   Resolve contact forces using the "penalty" method. Forces are generated based
//   on the depth of penetration and the moment of inertia at the point of contact.
//
bool Vehicle::resolveContacts(Rigid& ns,CollisionList& cList,F32 dt)
{
   // Use spring forces to manage contact constraints.
   bool collided = false;
   Point3F t,p(0,0,0),l(0,0,0);
   for (S32 i = 0; i < cList.count; i++) {
      Collision& c = cList.collision[i];
      if (c.distance < mDataBlock->collisionTol) {

         // Velocity into the surface
         Point3F v,r;
         ns.getOriginVector(c.point,&r);
         ns.getVelocity(r,&v);
         F32 vn = mDot(v,c.normal);

         // Only interested in velocities less than mDataBlock->contactTol,
         // velocities greater than that are dealt with as collisions.
         if (mFabs(vn) < mDataBlock->contactTol) {
            collided = true;

            // Penetration force. This is actually a spring which
            // will seperate the body from the collision surface.
            F32 zi = 2 * (mRigid.getZeroImpulse(r,c.normal));
            F32 s = (mDataBlock->collisionTol - c.distance) * zi - ((vn / mDataBlock->contactTol) * zi);
            Point3F f = c.normal * s;

            // Friction impulse, calculated as a function of the
            // amount of force it would take to stop the motion
            // perpendicular to the normal.
            Point3F uv = v - (c.normal * vn);
            F32 ul = uv.len();
            if (s > 0 && ul) {
               uv /= -ul;
               F32 u = ul * ns.getZeroImpulse(r,uv);
               s *= mRigid.friction;
               if (u > s)
                  u = s;
               f += uv * u;
            }

            // Accumulate forces
            p += f;
            mCross(r,f,&t);
            l += t;
         }
      }
   }

   // Contact constraint forces act over time...
   ns.linMomentum += p * dt;
   ns.angMomentum += l * dt;
   ns.updateVelocity();
   return true;
}

*/
//----------------------------------------------------------------------------

bool Vehicle::resolveDisplacement(Rigid& ns,CollisionState *state, F32 dt)
{
   SceneObject* obj = (state->a->getObject() == this)?
       state->b->getObject(): state->a->getObject();

   if (obj->isDisplacable() && ((obj->getTypeMask() & ShapeBaseObjectType) != 0))
   {
      // Try to displace the object by the amount we're trying to move
      Point3F objNewMom = ns.linVelocity * obj->getMass() * 1.1;
      Point3F objOldMom = obj->getMomentum();
      Point3F objNewVel = objNewMom / obj->getMass();

      Point3F myCenter;
      Point3F theirCenter;
      getWorldBox().getCenter(&myCenter);
      obj->getWorldBox().getCenter(&theirCenter);
      if (mDot(myCenter - theirCenter, objNewMom) >= 0.0f || objNewVel.len() < 0.01)
      {
         objNewMom = (theirCenter - myCenter);
         objNewMom.normalize();
         objNewMom *= 1.0f * obj->getMass();
         objNewVel = objNewMom / obj->getMass();
      }

      obj->setMomentum(objNewMom);
      if (obj->displaceObject(objNewVel * 1.1 * dt) == true)
      {
         // Queue collision and change in velocity
         VectorF dv = (objOldMom - objNewMom) / obj->getMass();
         queueCollision(static_cast<ShapeBase*>(obj), dv);
         return true;
      }
   }

   return false;
}


//----------------------------------------------------------------------------

void Vehicle::updateWorkingCollisionSet(const U32 mask)
{
   // First, we need to adjust our velocity for possible acceleration.  It is assumed
   // that we will never accelerate more than 20 m/s for gravity, plus 30 m/s for
   // jetting, and an equivalent 10 m/s for vehicle accel.  We also assume that our
   // working list is updated on a Tick basis, which means we only expand our box by
   // the possible movement in that tick, plus some extra for caching purposes
   Box3F convexBox = mConvex.getBoundingBox(getTransform(), getScale());
   F32 len = (mRigid.linVelocity.len() + 50) * TickSec;
   F32 l = (len * 1.1) + 0.1;  // fudge factor
   //F32 l = (len * 1.3) + 0.1;  // fudge factor
   convexBox.min -= Point3F(l, l, l);
   convexBox.max += Point3F(l, l, l);

   disableCollision();
   mConvex.updateWorkingList(convexBox, mask);
   enableCollision();
}


//----------------------------------------------------------------------------
/** Check collisions with trigger and items
   Perform a container search using the current bounding box
   of the main body, wheels are not included.  This method should
   only be called on the server.
*/
void Vehicle::checkTriggers()
{
   Box3F bbox = mConvex.getBoundingBox(getTransform(), getScale());
   gServerContainer.findObjects(bbox,sTriggerMask,findCallback,this);
}

/** The callback used in by the checkTriggers() method.
   The checkTriggers method uses a container search which will
   invoke this callback on each obj that matches.
*/
void Vehicle::findCallback(SceneObject* obj,void *key)
{
   Vehicle* vehicle = reinterpret_cast<Vehicle*>(key);
   U32 objectMask = obj->getTypeMask();

   // Check: triggers, corpses and items, basically the same things
   // that the player class checks for
   if (objectMask & TriggerObjectType) {
      Trigger* pTrigger = static_cast<Trigger*>(obj);
      pTrigger->potentialEnterObject(vehicle);
   }
   else if (objectMask & CorpseObjectType) {
      ShapeBase* col = static_cast<ShapeBase*>(obj);
      vehicle->queueCollision(col,vehicle->getVelocity() - col->getVelocity());
   }
   else if (objectMask & ItemObjectType) {
      Item* item = static_cast<Item*>(obj);
      if (vehicle != item->getCollisionObject())
         vehicle->queueCollision(item,vehicle->getVelocity() - item->getVelocity());
   }
}


//----------------------------------------------------------------------------

void Vehicle::writePacketData(GameConnection *connection, BitStream *stream)
{
   Parent::writePacketData(connection, stream);

   mathWrite(*stream, mSteering);
   stream->write(mRot.x);
   stream->write(mRot.z);

   mathWrite(*stream, mRigid.linPosition);
   mathWrite(*stream, mRigid.angPosition);
   mathWrite(*stream, mRigid.linMomentum);
   mathWrite(*stream, mRigid.angMomentum);
   stream->writeFlag(mRigid.atRest);
   stream->writeFlag(mContacts.count == 0);

   stream->writeFlag(mDisableMove);
   stream->setCompressionPoint(mRigid.linPosition);

}

void Vehicle::readPacketData(GameConnection *connection, BitStream *stream)
{
   Parent::readPacketData(connection, stream);

   mathRead(*stream, &mSteering);
   LastRotation = Rotation;
   stream->read(&Rotation.x);
   stream->read(&Rotation.z);
   calculateUpdateTime();

   mathRead(*stream, &mRigid.linPosition);
   mathRead(*stream, &mRigid.angPosition);
   mathRead(*stream, &mRigid.linMomentum);
   mathRead(*stream, &mRigid.angMomentum);
   mRigid.atRest = stream->readFlag();
   if (stream->readFlag())
      mContacts.count = 0;

   // Update the rigid state based on the new information
   mRigid.updateInertialTensor();
   mRigid.updateVelocity();
   mRigid.updateCenterOfMass();

   mDisableMove = stream->readFlag();
   stream->setCompressionPoint(mRigid.linPosition);

}


//----------------------------------------------------------------------------

U32 Vehicle::packUpdate(NetConnection *con, U32 mask, BitStream *stream)
{
   U32 retMask = Parent::packUpdate(con, mask, stream);

   stream->writeFlag(mJetting);
   stream->writeFlag(mJettingDn);  //Combat Starter Kit

   if (stream->writeFlag (mask & EngineMask))
   {
       stream->writeFlag(mEngineState);
   }
   if (stream->writeFlag (mask & TurretMask))
   {
	   stream->write(turretMountPoint);
	   stream->write(weaponMountPoint);
   }

   // The rest of the data is part of the control object packet update.
   // If we're controlled by this client, we don't need to send it.
   if (stream->writeFlag(getControllingClient() == con && !(mask & InitialUpdateMask)))
      return retMask;

   F32 yaw = (mSteering.x + mDataBlock->maxSteeringAngle) / (2 * mDataBlock->maxSteeringAngle);
   F32 pitch = (mSteering.y + mDataBlock->maxSteeringAngle) / (2 * mDataBlock->maxSteeringAngle);
   stream->writeFloat(yaw,9);
   stream->writeFloat(pitch,9);
   mDelta.move.pack(stream);

   if (stream->writeFlag(mask & PositionMask))
   {
      stream->writeCompressedPoint(mRigid.linPosition);
      mathWrite(*stream, mRigid.angPosition);
      mathWrite(*stream, mRigid.linMomentum);
      mathWrite(*stream, mRigid.angMomentum);
      stream->writeFlag(mRigid.atRest);
      stream->write(mRot.x);
      stream->write(mRot.z);
   }

   // send energy only to clients which need it
   bool found = false;
   if (mask & EnergyMask)
   {
      for (ShapeBase* ptr = getMountList(); ptr; ptr = ptr->getMountLink())
      {
         GameConnection * controllingClient = ptr->getControllingClient();
         if(controllingClient == con)
         {
            if(controllingClient->getControlObject() != this)
               found = true;
            break;
         }
      }
   }

   // write it...
   if(stream->writeFlag(found))
      stream->writeFloat(mClampF(getEnergyValue(), 0.f, 1.f), 8);

   return retMask;
}

void Vehicle::unpackUpdate(NetConnection *con, BitStream *stream)
{
	Parent::unpackUpdate(con,stream);

	mJetting = stream->readFlag();
	mJettingDn = stream->readFlag();  //Combat Starter Kit
	if (stream->readFlag ())
	{
		bool newstate = stream->readFlag();
		if(mEngineState != newstate)
		{
			mEngineState = newstate;
			engineStateChanged(newstate);
		}
	}

	if (stream->readFlag ())
	{
		stream->read(&turretMountPoint);
		stream->read(&weaponMountPoint);
		setTurretNode(turretMountPoint, weaponMountPoint);
	}

   if (stream->readFlag())
      return;

   F32 yaw = stream->readFloat(9);
   F32 pitch = stream->readFloat(9);
   mSteering.x = (2 * yaw * mDataBlock->maxSteeringAngle) - mDataBlock->maxSteeringAngle;
   mSteering.y = (2 * pitch * mDataBlock->maxSteeringAngle) - mDataBlock->maxSteeringAngle;
   mDelta.move.unpack(stream);

   if (stream->readFlag()) {
      mPredictionCount = sMaxPredictionTicks;
      F32 speed = mRigid.linVelocity.len();
      mDelta.warpRot[0] = mRigid.angPosition;

      // Read in new position and momentum values
      stream->readCompressedPoint(&mRigid.linPosition);
      mathRead(*stream, &mRigid.angPosition);
      mathRead(*stream, &mRigid.linMomentum);
      mathRead(*stream, &mRigid.angMomentum);
      mRigid.atRest = stream->readFlag();
      mRigid.updateVelocity();
      LastRotation = Rotation;
      stream->read(&Rotation.x);
      stream->read(&Rotation.z);
      calculateUpdateTime();

      if (isProperlyAdded()) {
         // Determine number of ticks to warp based on the average
         // of the client and server velocities.
         Point3F cp = mDelta.pos + mDelta.posVec * mDelta.dt;
         mDelta.warpOffset = mRigid.linPosition - cp;

         // Calc the distance covered in one tick as the average of
         // the old speed and the new speed from the server.
         F32 dt,as = (speed + mRigid.linVelocity.len()) * 0.5 * TickSec;

         // Calc how many ticks it will take to cover the warp offset.
         // If it's less than what's left in the current tick, we'll just
         // warp in the remaining time.
         if (!as || (dt = mDelta.warpOffset.len() / as) > sMaxWarpTicks)
            dt = mDelta.dt + sMaxWarpTicks;
         else
            dt = (dt <= mDelta.dt)? mDelta.dt : mCeil(dt - mDelta.dt) + mDelta.dt;

         // Adjust current frame interpolation
         if (mDelta.dt) {
            mDelta.pos = cp + (mDelta.warpOffset * (mDelta.dt / dt));
            mDelta.posVec = (cp - mDelta.pos) / mDelta.dt;
            QuatF cr;
            cr.interpolate(mDelta.rot[1],mDelta.rot[0],mDelta.dt);
            mDelta.rot[1].interpolate(cr,mRigid.angPosition,mDelta.dt / dt);
            mDelta.rot[0].extrapolate(mDelta.rot[1],cr,mDelta.dt);
         }

         // Calculated multi-tick warp
         mDelta.warpCount = 0;
         mDelta.warpTicks = (S32)(mFloor(dt));
         if (mDelta.warpTicks) {
            mDelta.warpOffset = mRigid.linPosition - mDelta.pos;
            mDelta.warpOffset /= mDelta.warpTicks;
            mDelta.warpRot[0] = mDelta.rot[1];
            mDelta.warpRot[1] = mRigid.angPosition;
         }
      }
      else {
         // Set the vehicle to the server position
         mDelta.dt  = 0;
         mDelta.pos = mRigid.linPosition;
         mDelta.posVec.set(0,0,0);
         mDelta.rot[1] = mDelta.rot[0] = mRigid.angPosition;
         mDelta.warpCount = mDelta.warpTicks = 0;
         setPosition(mRigid.linPosition, mRigid.angPosition);
      }

      mRigid.updateCenterOfMass();
   }

   // energy?
   if(stream->readFlag())
      setEnergyLevel(stream->readFloat(8) * mDataBlock->maxEnergy);
}


//----------------------------------------------------------------------------

void Vehicle::initPersistFields()
{
   Parent::initPersistFields();

   addField("disableMove",   TypeBool,   Offset(mDisableMove, Vehicle));
   Con::addVariable("CameraMode", TypeS32, &mCameraMode);
}


void Vehicle::mountObject(ShapeBase* obj, U32 node)
{
   Parent::mountObject(obj, node);

   // Clear objects off the working list that are from objects mounted to us.
   //  (This applies mostly to players...)
   for (CollisionWorkingList* itr = mConvex.getWorkingList().wLink.mNext; itr != &mConvex.getWorkingList(); itr = itr->wLink.mNext) {
      if (itr->mConvex->getObject() == obj) {
         CollisionWorkingList* cl = itr;
         itr = itr->wLink.mPrev;
         cl->free();
      }
   }
}





//----------------------------------------------------------------------------

void Vehicle::updateLiftoffDust( F32 dt )
{
   if( !mDustEmitterList[0] ) return;

   Point3F startPos = getPosition();
   Point3F endPos = startPos + Point3F( 0.0, 0.0, -mDataBlock->triggerDustHeight );


   RayInfo rayInfo;
   if( !getContainer()->castRay( startPos, endPos, TerrainObjectType, &rayInfo ) )
   {
      return;
   }

   TerrainBlock* tBlock = static_cast<TerrainBlock*>(rayInfo.object);
   S32 mapIndex = tBlock->mMPMIndex[0];

   MaterialPropertyMap* pMatMap = static_cast<MaterialPropertyMap*>(Sim::findObject("MaterialPropertyMap"));
   const MaterialPropertyMap::MapEntry* pEntry = pMatMap->getMapEntryFromIndex(mapIndex);

   if(pEntry)
   {
      S32 x;
      ColorF colorList[ParticleEngine::PC_COLOR_KEYS];

      for(x = 0; x < 2; ++x)
         colorList[x].set( pEntry->puffColor[x].red, pEntry->puffColor[x].green, pEntry->puffColor[x].blue, pEntry->puffColor[x].alpha );
      for(x = 2; x < ParticleEngine::PC_COLOR_KEYS; ++x)
         colorList[x].set( 1.0, 1.0, 1.0, 0.0 );

      mDustEmitterList[0]->setColors( colorList );
   }
   Point3F contactPoint = rayInfo.point + Point3F( 0.0, 0.0, mDataBlock->dustHeight );
   mDustEmitterList[0]->emitParticles( contactPoint, contactPoint, rayInfo.normal, getVelocity(), (U32)(dt * 1000) );
}


//----------------------------------------------------------------------------

void Vehicle::updateDamageSmoke( F32 dt )
{

   for( S32 j=VehicleData::VC_NUM_DAMAGE_LEVELS-1; j>=0; j-- )
   {
      F32 damagePercent = mDamage / mDataBlock->maxDamage;
      if( damagePercent >= mDataBlock->damageLevelTolerance[j] )
      {
         for( int i=0; i<mDataBlock->numDmgEmitterAreas; i++ )
         {
            MatrixF trans = getTransform();
            Point3F offset = mDataBlock->damageEmitterOffset[i];
            trans.mulP( offset );
            Point3F emitterPoint = offset;

            if( pointInWater(offset ) )
            {
               U32 emitterOffset = VehicleData::VC_BUBBLE_EMITTER;
               if( mDamageEmitterList[emitterOffset] )
               {
                  mDamageEmitterList[emitterOffset]->emitParticles( emitterPoint, emitterPoint, Point3F( 0.0, 0.0, 1.0 ), getVelocity(), (U32)( dt * 1000 ) );
               }
            }
            else
            {
               if( mDamageEmitterList[i] )
               {
                  mDamageEmitterList[i]->emitParticles( emitterPoint, emitterPoint, Point3F( 0.0, 0.0, 1.0 ), getVelocity(), (U32)(dt * 1000));
               }
            }
         }
         break;
      }
   }

}


//--------------------------------------------------------------------------
void Vehicle::updateFroth( F32 dt )
{
   // update bubbles
   Point3F moveDir = getVelocity();

   Point3F contactPoint;
   if( !collidingWithWater( contactPoint ) )
   {
      if(waterWakeHandle)
      {
         alxStop(waterWakeHandle);
         waterWakeHandle = 0;
      }
      return;
   }

   F32 speed = moveDir.len();
   if( speed < mDataBlock->splashVelEpsilon ) speed = 0.0;

   U32 emitRate = (U32)(speed * mDataBlock->splashFreqMod * dt);

   U32 i;
   if(!waterWakeHandle)
      waterWakeHandle = alxPlay(mDataBlock->waterSound[VehicleData::Wake], &getTransform());
   alxSourceMatrixF(waterWakeHandle, &getTransform());

   for( i=0; i<VehicleData::VC_NUM_SPLASH_EMITTERS; i++ )
   {
      if( mSplashEmitterList[i] )
      {
         mSplashEmitterList[i]->emitParticles( contactPoint, contactPoint, Point3F( 0.0, 0.0, 1.0 ),
                                               moveDir, emitRate );
      }
   }

}


//--------------------------------------------------------------------------
// Returns true if vehicle is intersecting a water surface (roughly)
//--------------------------------------------------------------------------
bool Vehicle::collidingWithWater( Point3F &waterHeight )
{
   Point3F curPos = getPosition();

   F32 height = mFabs( mObjBox.max.z - mObjBox.min.z );

   RayInfo rInfo;
   if( gClientContainer.castRay( curPos + Point3F(0.0, 0.0, height), curPos, WaterObjectType, &rInfo) )
   {
      waterHeight = rInfo.point;
      return true;
   }

   return false;
}

void Vehicle::setEnergyLevel(F32 energy)
{
   Parent::setEnergyLevel(energy);
   setMaskBits(EnergyMask);
}

//-----------------------------------------------------------------------------
//
void Vehicle::renderImage(SceneState *state, SceneRenderImage *image)
{
	Parent::renderImage(state, image);

   if (gShowBoundingBox) {
      glDisable(GL_LIGHTING);
      glPushMatrix();
      dglMultMatrix(&getRenderTransform());

      // Box for the center of Mass
      glDisable(GL_DEPTH_TEST);
      glColor3f(1, 1, 1);
      wireCube(Point3F(0.1,0.1,0.1),mDataBlock->massCenter);
      glPopMatrix();

      // Collision points
      for (int i = 0; i < mCollisionList.count; i++) {
         glColor3f(0, 0, 1);
         Collision& collision = mCollisionList.collision[i];
         wireCube(Point3F(0.05,0.05,0.05),collision.point);
         glColor3f(1, 1, 1);
         glBegin(GL_LINES);
         glVertex3fv(collision.point);
         glVertex3fv(collision.point + collision.normal * 0.05);
         glEnd();
      }

      // Build and render the collision polylist which is returned
      // in the server's world space.
      ClippedPolyList polyList;
      polyList.mPlaneList.setSize(6);
      polyList.mPlaneList[0].set(getWorldBox().min,VectorF(-1,0,0));
      polyList.mPlaneList[1].set(getWorldBox().min,VectorF(0,-1,0));
      polyList.mPlaneList[2].set(getWorldBox().min,VectorF(0,0,-1));
      polyList.mPlaneList[3].set(getWorldBox().max,VectorF(1,0,0));
      polyList.mPlaneList[4].set(getWorldBox().max,VectorF(0,1,0));
      polyList.mPlaneList[5].set(getWorldBox().max,VectorF(0,0,1));
      Box3F dummyBox;
      SphereF dummySphere;
      buildPolyList(&polyList, dummyBox, dummySphere);
      polyList.render();

      //
      glEnable(GL_DEPTH_TEST);
      glEnable(GL_LIGHTING);
   }
}

//-----------------------------------------------------------------------------
// Demonstrates adding rendering to mounted objects.
//
void Vehicle::renderMountedImage
(SceneState *state, ShapeImageRenderImage *image)
{
	Parent::renderMountedImage(state, image);
	if (gShowBoundingBox) {
		U32 index = image->mIndex;
		if (mMountedImageList[index].dataBlock != NULL) {
			Point3F muzzlePoint, muzzleVector, endpoint;
			getMuzzlePoint(index, &muzzlePoint);
			getMuzzleVector(index, &muzzleVector);
			endpoint = muzzlePoint + muzzleVector * 250;
			// Lighting has been installed by ShapeBase::renderObject.  Switch lighting
			// off while rendering the debug graphics.
			glDisable(GL_LIGHTING);
			glEnable(GL_BLEND);
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			glLineWidth(1);
			glBegin(GL_LINES);
			glColor4ub(0, 255, 0, 255);
			glVertex3fv(muzzlePoint);
			glVertex3fv(endpoint);
			glEnd();
			glLineWidth(1);
			glDisable(GL_BLEND);
			glEnable(GL_LIGHTING);
		}
	}
}
bool Vehicle::getAIMove(Move *move)
{
   return false;
}



void Vehicle::getDamageLocation(const Point3F& in_rPos, const char *&out_rpVert, const char *&out_rpQuad)
{
   Point3F newPoint;
   mWorldToObj.mulP(in_rPos, &newPoint);

   F32 zHeight = mDataBlock->boxSize.z;
   F32 zBottom  = mDataBlock->boxBottomPercentage;
   F32 zTop   = mDataBlock->boxTopPercentage;

   zBottom *= zHeight;
   zTop  *= zHeight;

   if (newPoint.z <= zBottom){
      out_rpVert = "Bottom";
   }
   else if (newPoint.z <= zTop){
      out_rpVert = "Top";
	  }
   else{
      out_rpVert = "Top";
   }

      F32 backToFront = mDataBlock->boxSize.x;
      F32 leftToRight = mDataBlock->boxSize.y;

      F32 backPoint  = backToFront * (mDataBlock->boxTopBackPercentage  - 0.5f);
      F32 frontPoint = backToFront * (mDataBlock->boxTopFrontPercentage - 0.5f);
      F32 leftPoint  = leftToRight * (mDataBlock->boxTopLeftPercentage  - 0.5f);
      F32 rightPoint = leftToRight * (mDataBlock->boxTopRightPercentage - 0.5f);

      S32 index = 0;
      if (newPoint.y < backPoint)
         index += 0;
      else if (newPoint.y <= frontPoint)
         index += 3;
      else
         index += 6;

      if (newPoint.x < leftPoint)
         index += 0;
      else if (newPoint.x <= rightPoint)
         index += 1;
      else
         index += 2;

      switch (index)
      {
         case 0:
         out_rpQuad = "left_back";
         break;

         case 1: out_rpQuad = "middle_back"; break;
         case 2: out_rpQuad = "right_back"; break;
         case 3: out_rpQuad = "left_middle";   break;
         case 4: out_rpQuad = "middle_middle"; break;
         case 5: out_rpQuad = "right_middle"; break;
         case 6: out_rpQuad = "left_front";   break;
         case 7: out_rpQuad = "middle_front"; break;
         case 8: out_rpQuad = "right_front"; break;

         default:
            AssertFatal(0, "Bad non-tant index");
      };

}


ConsoleMethod( Vehicle, getDamageLocation, const char*, 3, 3, "(Point3F pos)")
{
   const char *buffer1;
   const char *buffer2;
   char *buff = Con::getReturnBuffer(128);

   Point3F pos(0.0f, 0.0f, 0.0f);
   dSscanf(argv[2], "%g %g %g", &pos.x, &pos.y, &pos.z);
   object->getDamageLocation(pos, buffer1, buffer2);

   dSprintf(buff, 128, "%s %s", buffer1, buffer2);
   return buff;
}

void Vehicle::setEngineState(bool state)
{
   if (isServerObject()) {
       if (state && getEnergyLevel() <= 0)  // No gas...
           return;
       //if (state && getDamageLevel() <= 0)  // No engine?!? I don't think we could get here, but just in case...
       //    return;
       setMaskBits(EngineMask);
       mEngineState = state;
   }
}

ConsoleMethod( Vehicle, allowImpulse, void, 2, 2, "()"
              "turn Physics on for 50 ticks")
{
    object->allPhysics();   
}
ConsoleMethod( Vehicle, setEngineState, void, 3, 3, "(bool engine on)"
              "Turns on / off the engine.")
{
    object->setEngineState(dAtob (argv[2]));   
}

ConsoleMethod( Vehicle, getEngineState, bool, 2, 2, "()"
              "Checks the engine.")
{
    return object->IsEngineOn();
}


// Duncan  - turret additions =========================================================================

ConsoleMethod( Vehicle, setTurretNodes, void, 4, 4, "(S32 turretnode, S32 weaponnode)"
              "on what node is the turret mesh mounted.")
{
    object->setTurretNode(dAtoi (argv[2]),dAtoi (argv[3]));   
}
//------------------------------------------------------------------------------------------------------
void Vehicle::updateTurretMove(const Move* move) 
{ 
	if(!mHasTurretNodes)
		return;
	if(!move)
		return;

	turretHasMoved = false;

	F32 deltaPitch = 	mFabs(lastPitch - move->tpitch);
	F32 deltaYaw = 	mFabs(lastYaw - move->tyaw);
	F32 limit = 0.005;
	if((deltaPitch < limit)&&(deltaYaw < limit))
		return;

	turretHasMoved = true;


	F32 p = -move->tpitch;

	if(p>M_PI)
		p -= M_2PI;

	F32 y  = move->tyaw;

	// get new yaw value
	if (takeClosestYaw( lastYaw,y))
	{
		if( y > M_PI )
			y -= M_2PI;
		else if( y < -M_PI )
			y += M_2PI;
	}
	// limit yaw and pitch by angular speed 

	if (y > mMaxYawSpeed)
		y = mMaxYawSpeed;
	else if (y < -mMaxYawSpeed)
		y = -mMaxYawSpeed;

	// limit pitch
	if (p > mMaxPitchSpeed)
		p = mMaxPitchSpeed;
	else if (p < -mMaxPitchSpeed)
		p = -mMaxPitchSpeed;

	mRot.x = mClampF(mRot.x + p, mMinPitch, mMaxPitch);

	if((mMinYaw > 0)&&(mMaxYaw >0))
	   mRot.z = mClampF(mRot.z + y, mMinYaw, mMaxYaw);
	else
	   mRot.z = mRot.z + y;	
	
	lastPitch = move->tpitch;
	lastYaw = move->tyaw;
   

	if(isServerObject())
	{   
		updateLookAnimation();
	}

}


//------------------------------------------------------------------------------------------------------

void Vehicle::setTurretNode(S32 _turretMountPoint, S32 _weaponMountPoint) 
{ 
	char buff[80];

    turretMountPoint = _turretMountPoint;
	weaponMountPoint = _weaponMountPoint;

	sprintf(buff,"mount%d", turretMountPoint);
	turretNode = mDataBlock->shape->findNode(buff);
	if(turretNode>=0)
		mShapeInstance->setNodeAnimationState  (turretNode, TSShapeInstance::MaskNodeHandsOff);
	sprintf(buff,"mount%d", weaponMountPoint);
	weaponNode = mDataBlock->shape->findNode(buff);
	if(weaponNode>=0)
		mShapeInstance->setNodeAnimationState  (weaponNode, TSShapeInstance::MaskNodeHandsOff);


	if((turretNode>=0)&&(weaponNode>=0))
	{
		mHasTurretNodes = true;
		updateLookAnimation();
		if(isServerObject())
	      setMaskBits(TurretMask);
	}
    //else Con::errorf(ConsoleLogEntry::General,"setTurretNode is missing some parameters");
}
//------------------------------------------------------------------------------------------------------

void Vehicle::updateLookAnimation()
{
	MatrixF * TurretMat, _BarrelMat;
	Point3F turretPos, weaponPos, rotatedWeaponPos;
	VectorF directionVec;

	TurretMat = &mShapeInstance->mNodeTransforms[turretNode];       // get the turret matrix pointer
	turretPos = mDataBlock->shape->defaultTranslations[turretNode]; // get the turret position
	weaponPos = mDataBlock->shape->defaultTranslations[weaponNode];	// get the weapon position
	TurretMat->set(EulerF(0,0,mRot.z));                   // make a turret rotation matrix 
	weaponPos -= turretPos;  //get wpos in tpos's frame of reference
    TurretMat->mulP(weaponPos, &rotatedWeaponPos);  // use the rotation matrix to adjust the weapon position
	rotatedWeaponPos += turretPos;  //get wpos back in its own frame of reference
	TurretMat->setColumn(3,turretPos);       // correct the position of the turret matrix
	MathUtils::getVectorFromAngles( directionVec, mRot.z, mRot.x ); // get the barrel vector
    _BarrelMat = MathUtils::createOrientFromDir( directionVec );    // create a matrix from that vector
	_BarrelMat.setColumn(3,rotatedWeaponPos);       // correct the position of the barrel matrix
	mShapeInstance->mNodeTransforms[weaponNode] = _BarrelMat; //store it

}
//------------------------------------------------------------------------------------------------------

// utility code to determine whether to take the shortest path to the given new yaw
bool Vehicle::takeClosestYaw(F32 currYaw, F32 newYaw)
{
    // if we are unfettered then always take closest
   if (mMinYaw == -M_PI && mMaxYaw == M_PI)
      return true;

   // if new yaw is inside illegal zone...then take closest
   // (it will be stopped at limits of course)
   if (newYaw > mMaxYaw || newYaw < mMinYaw)
      return true;

   // if new and old on same side...take closest
   if (currYaw <= 0 && newYaw <= 0)
      return true;
   if (currYaw >= 0 && newYaw >= 0)
      return true;

   // if closest crosses the no-no land then dont do it!
   if (currYaw > (M_PI/2.0) && newYaw < (-M_PI/2.0))
      return false;
   if (currYaw < (-M_PI/2.0) && newYaw > (M_PI/2.0))
      return false;

   // it dont cross the no-no land
   return true;
}

//------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------

