//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#include "dgl/dgl.h"
#include "gui/core/guiControl.h"
#include "gui/core/guiTSControl.h"
#include "gui/controls/guiBitmapCtrl.h"
#include "console/consoleTypes.h"
#include "sceneGraph/sceneGraph.h"
#include "game/gameConnection.h"
#include "game/shapeBase.h"

//-----------------------------------------------------------------------------
/// Vary basic cross hair hud.
/// Uses the base bitmap control to render a bitmap, and decides whether
/// to draw or not depending on the current control object and it's state.
/// If there is ShapeBase object under the cross hair and it's named,
/// then a small health bar is displayed.
class GuiCrossHairHud : public GuiControl
{
private:
    typedef GuiControl Parent;

protected:
   ColorF   mDamageFillColor;
   ColorF   mDamageFrameColor;
   Point2I  mDamageRectSize;
   Point2I  mDamageOffset;
   F32      mWeaponRange;

   ColorF   mFillColor;
   ColorF   mFrameColor;
   ColorF   mTextColor;

   F32      mVerticalOffset;
   bool     mShowFrame;
   bool     mShowFill;
   bool     mLockonTarget;
   StringTableEntry mBitmapName;
   TextureHandle mTextureHandle;
   Point2I startPoint;

protected:
   void drawDamage(Point2I offset, F32 damage, F32 opacity);
   void drawRange(Point2I offset, F32 range, F32 lockvalue, F32 opacity);
   void drawName( Point2I offset, const char *buf, F32 opacity);
   void drawName( Point2I offset, const char *buf, S32 myFaction, S32 faction, F32 opacity);
   static bool setBitmapName( void *obj, const char *data );
   static const char *getBitmapName( void *obj, const char *data );

public:
   GuiCrossHairHud();

   //Parental methods
   bool onWake();
   void onSleep();
   static void initPersistFields();

   void setBitmap(const char *name,bool resize = false);
   void setBitmap(const TextureHandle &handle,bool resize = false);

   S32 getWidth() const       { return(mTextureHandle.getWidth()); }
   S32 getHeight() const      { return(mTextureHandle.getHeight()); }

   void onRender(Point2I offset, const RectI &updateRect);
   void setValue(S32 x, S32 y);

   DECLARE_CONOBJECT( GuiCrossHairHud );
};

/// Valid object types for which the cross hair will render, this
/// should really all be script controlled.
static const U32 ObjectMask = PlayerObjectType | VehicleObjectType;


//-----------------------------------------------------------------------------

IMPLEMENT_CONOBJECT( GuiCrossHairHud );

GuiCrossHairHud::GuiCrossHairHud()
{
   mDamageFillColor.set( 0, 1, 0, 1 );
   mDamageFrameColor.set( 1, 0.6, 0, 1 );
   mDamageRectSize.set(50, 4);
   mDamageOffset.set(0,32);
   mFillColor.set( 0.25, 0.25, 0.25, 0.25 );
   mFrameColor.set( 0, 1, 0, 1 );
   mTextColor.set( 0, 1, 0, 1 );
   mShowFrame = mShowFill = true;
   mVerticalOffset = 0.5;
   mWeaponRange = 100;  // in meters
   mBitmapName = StringTable->insert("");
   startPoint.set(0, 0);
   mLockonTarget = true; // 4way crosshair
}

void GuiCrossHairHud::initPersistFields()
{
   Parent::initPersistFields();
   addGroup("Damage");
   addField( "damageFillColor", TypeColorF, Offset( mDamageFillColor, GuiCrossHairHud ) );
   addField( "damageFrameColor", TypeColorF, Offset( mDamageFrameColor, GuiCrossHairHud ) );
   addField( "damageRect", TypePoint2I, Offset( mDamageRectSize, GuiCrossHairHud ) );
   addField( "damageOffset", TypePoint2I, Offset( mDamageOffset, GuiCrossHairHud ) );
   endGroup("Damage");

   addGroup("Colors");
   addField( "fillColor",  TypeColorF, Offset( mFillColor, GuiCrossHairHud ) );
   addField( "frameColor", TypeColorF, Offset( mFrameColor, GuiCrossHairHud ) );
   addField( "textColor",  TypeColorF, Offset( mTextColor, GuiCrossHairHud ) );
   endGroup("Colors");

   addGroup("Misc");
   addProtectedField( "bitmap", TypeFilename, Offset( mBitmapName, GuiCrossHairHud ), &setBitmapName, &defaultProtectedGetFn, "" );
   addField( "showFill",   TypeBool, Offset( mShowFill, GuiCrossHairHud ) );
   addField( "showFrame",  TypeBool, Offset( mShowFrame, GuiCrossHairHud ) );
   addField( "verticalOffset", TypeF32, Offset( mVerticalOffset, GuiCrossHairHud ) );
   addField( "WeaponRange", TypeF32, Offset( mWeaponRange, GuiCrossHairHud ) );
   addField( "LockOnTarget",  TypeBool, Offset( mLockonTarget, GuiCrossHairHud ) );
   endGroup("Misc");
}


//-----------------------------------------------------------------------------
bool GuiCrossHairHud::setBitmapName( void *obj, const char *data )
{
    // Prior to this, you couldn't do bitmap.bitmap = "foo.jpg" and have it work.
    // With protected console types you can now call the setBitmap function and
    // make it load the image.
    static_cast<GuiCrossHairHud *>( obj )->setBitmap( data );

    // Return false because the setBitmap method will assign 'mBitmapName' to the
    // argument we are specifying in the call.
    return false;
}

ConsoleMethod( GuiCrossHairHud, setValue, void, 4, 4, "(int xAxis, int yAxis)"
              "Set the offset of the crosshair.")
{
    object->setValue(dAtoi(argv[2]), dAtoi(argv[3]));
}

ConsoleMethod( GuiCrossHairHud, setBitmap, void, 3, 3, "(string filename)"
              "Set the bitmap displayed in the control. Note that it is limited in size, to 256x256.")
{
    object->setBitmap(argv[2]);
}

bool GuiCrossHairHud::onWake()
{
    if (! Parent::onWake())
        return false;
    setActive(true);
    setBitmap(mBitmapName);
    return true;
}

void GuiCrossHairHud::onSleep()
{
    mTextureHandle = NULL;
    Parent::onSleep();
}

void GuiCrossHairHud::setBitmap(const char *name, bool resize)
{
    mBitmapName = StringTable->insert(name);
    if (*mBitmapName) {
        mTextureHandle = TextureHandle(mBitmapName, BitmapTexture, true);

        // Resize the control to fit the bitmap
        if (resize) {
            TextureObject* texture = (TextureObject *) mTextureHandle;
            mBounds.extent.x = texture->bitmapWidth;
            mBounds.extent.y = texture->bitmapHeight;
            Point2I extent = getParent()->getExtent();
            parentResized(extent,extent);
        }
    }
    else
        mTextureHandle = NULL;
    setUpdate();
}

void GuiCrossHairHud::setValue(S32 x, S32 y)
{
    if (mTextureHandle)
    {
        TextureObject* texture = (TextureObject *) mTextureHandle;
        x+=texture->bitmapWidth/2;
        y+=texture->bitmapHeight/2;
    }
    while (x < 0)
        x += 256;
    startPoint.x = x % 256;

    while (y < 0)
        y += 256;
    startPoint.y = y % 256;
}

void GuiCrossHairHud::setBitmap(const TextureHandle &handle, bool resize)
{
    mTextureHandle = handle;

    // Resize the control to fit the bitmap
    if (resize) {
        TextureObject* texture = (TextureObject *) mTextureHandle;
        mBounds.extent.x = texture->bitmapWidth;
        mBounds.extent.y = texture->bitmapHeight;
        Point2I extent = getParent()->getExtent();
        parentResized(extent,extent);
    }
}

void GuiCrossHairHud::onRender(Point2I offset, const RectI &updateRect)
{
   Parent::onRender( offset, updateRect );

   // Must have a connection and player control object
   GameConnection* conn = GameConnection::getConnectionToServer();
   if (!conn)
      return;
   ShapeBase* control = conn->getControlObject();
   if (!control || !(control->getType() & ObjectMask) || !conn->isFirstPerson())
      return;

   // Must be in a TS Control
   GuiTSCtrl *parent = dynamic_cast<GuiTSCtrl*>(getParent());
   if (!parent) return;

   // Get control camera info
   MatrixF cam;
   Point3F camPos;
   VectorF camDir;
   conn->getControlCameraTransform(0,&cam);
   cam.getColumn(3, &camPos);
   cam.getColumn(1, &camDir);

   F32 camFov;
   conn->getControlCameraFov(&camFov);
   camFov = mDegToRad(camFov) / 2;

   // Visible distance info & name fading
   F32 visDistance = gClientSceneGraph->getVisibleDistance();
   F32 visDistanceSqr = visDistance * visDistance;
   F32 lockDistance = visDistance * mWeaponRange;
   F32 lockValue = 0.0;

   // Collision info. We're going to be running LOS tests and we
   // don't want to collide with the control object.
   static U32 losMask = TerrainObjectType | InteriorObjectType | ShapeBaseObjectType;
   control->disableCollision();

   // All ghosted objects are added to the server connection group,
   // so we can find all the shape base objects by iterating through
   // our current connection.
   for (SimSetIterator itr(conn); *itr; ++itr)
   {
       if ((*itr)->getType() & ShapeBaseObjectType)
       {
           ShapeBase* shape = static_cast<ShapeBase*>(*itr);
           if (shape != control && shape->getShapeName())
           {

               // Target pos to test, if it's a player run the LOS to his eye
               // point, otherwise we'll grab the generic box center.
               Point3F shapePos;
               if (shape->getType() & PlayerObjectType)
               {
                   MatrixF eye;

                   // Use the render eye transform, otherwise we'll see jittering
                   shape->getRenderEyeTransform(&eye);
                   eye.getColumn(3, &shapePos);
               }
               else
               {
                   // Use the render transform instead of the box center
                   // otherwise it'll jitter.
                   MatrixF srtMat = shape->getRenderTransform();
                   srtMat.getColumn(3, &shapePos);
               }

               VectorF shapeDir = shapePos - camPos;

               // Test to see if it's in range
               F32 shapeDist = shapeDir.lenSquared();
               if (shapeDist == 0 || shapeDist > visDistanceSqr)
                   continue;
               shapeDist = mSqrt(shapeDist);

               // Test to see if it's within our viewcone, this test doesn't
               // actually match the viewport very well, should consider
               // projection and box test.
               shapeDir.normalize();
               F32 dot = mDot(shapeDir, camDir);
               if (dot < camFov)
                   continue;

               // Test to see if it's behind something, and we want to
               // ignore anything it's mounted on when we run the LOS.
               RayInfo info;
               shape->disableCollision();
               ShapeBase *mount = shape->getObjectMount();

               if (mount)
                   mount->disableCollision();
               bool los = !gClientContainer.castRay(camPos, shapePos,losMask, &info);
               shape->enableCollision();
               if (mount)
                   mount->enableCollision();

               if (!los)
                   continue;

               // Project the shape pos into screen space and calculate
               // the distance opacity used to fade the labels into the
               // distance.
               Point3F projPnt;
               shapePos.z += mVerticalOffset;
               if (!parent->project(shapePos, &projPnt))
                   continue;

               // convert meters to a smaller number
               lockDistance *= 0.001;

               lockValue = (shapeDist < lockDistance)? 1.0:
                   1.0 - (shapeDist - lockDistance) / (visDistance - lockDistance);

               // Above .5, we have a valid target, and will show something. Closer we get to 1.0,
               // The tighter of a lock we'll have.

               // Render the shape's name
               if (lockValue >= 0.5) {

                   // Combat Starter Kit CODE BLOCK (factions) <<
                   // dont re-draw the player name here, its already being drawn.
                   //S32 myFaction = control->getFaction();
                   //drawName(Point2I((S32)projPnt.x, (S32)projPnt.y),shape->getShapeName(), myFaction, shape->getFaction(), lockValue);
                   // Combat Starter Kit CODE BLOCK (factions) <<

				   offset.x = projPnt.x;
                   offset.y = projPnt.y;
                   offset.y += mProfile->mFont->getHeight();
                   drawDamage(offset, shape->getDamageValue(), 1);
                   offset.y += mProfile->mFont->getHeight();
                   drawRange(offset, shapeDist, lockValue, 1);
               }
           }
       }
   }

   // Restore control object collision
   control->enableCollision();

   // Border last
   if (mShowFrame && lockValue >= 0.5)
       dglDrawRect(updateRect, mFrameColor);

   if (mTextureHandle)
   {
       S32 texWidth = mTextureHandle.getWidth();
       S32 texHeight = mTextureHandle.getWidth();
       S32 i, angle;
       Point2I renderPos, distancePoint;
       Point3F centerPoint, offSet;

       offSet.x = offset.x;
       offSet.y = offset.y;
       offSet.z = 0;

       centerPoint.x = (mBounds.extent.x / 2);
       centerPoint.y = (mBounds.extent.y / 2);
       centerPoint.z = 0;

       F32 lockTightness = sqrt(((centerPoint.x - offSet.x) * (centerPoint.x - offSet.x)) + ((centerPoint.y - offSet.y) * (centerPoint.y - offSet.y)));
       distancePoint.x = mClampF(lockTightness, 0, mBounds.extent.x);
       distancePoint.y = mClampF(lockTightness, 0, mBounds.extent.y);

       //Con::errorf("lockTightness = %f", lockTightness);
       if (mLockonTarget)
       {
           for(i = 0; i < 4; i++)
           {
               switch (i)
               {
               case 0:
                   renderPos.x = (mBounds.extent.x - texWidth - centerPoint.x + distancePoint.x);
                   renderPos.y = (mBounds.extent.y - texHeight - centerPoint.y + distancePoint.y);
                   angle = 180;
                   break;
               case 1:
                   renderPos.x = 0 + centerPoint.x - distancePoint.x;
                   renderPos.y = (mBounds.extent.y - texHeight - centerPoint.y + distancePoint.y);
                   angle = 90;
                   break;
               case 2:
                   renderPos.x = (mBounds.extent.x - texWidth - centerPoint.x + distancePoint.x);
                   renderPos.y = 0 + centerPoint.y - distancePoint.y;
                   angle = 270;
                   break;
               case 3:
                   renderPos.x = 0 + centerPoint.x - distancePoint.x;
                   renderPos.y = 0 + centerPoint.y - distancePoint.y;
                   angle = 0;
                   break;
               }
               dglClearBitmapModulation();
               dglDrawBitmapRotated(mTextureHandle, renderPos, angle);
               //Con::errorf("Case %d: Drawing xhair at %d %d, offset is %d %d", i, (int)renderPos.x, (int)renderPos.y, (int)offset.x, (int)offset.y);
           }
       }
       else
       {
           renderPos.x = (mBounds.extent.x / 2.f);
           renderPos.y = (mBounds.extent.y / 2.f);
           renderPos.x -= ( texWidth  * startPoint.x );
           renderPos.y -= ( texHeight * startPoint.y );

           dglClearBitmapModulation();
           dglDrawBitmap(mTextureHandle, renderPos);
       }
   }

  // renderChildControls(offset, updateRect);
}


//-----------------------------------------------------------------------------
/**
   Display a damage bar above the shape.
   This is a support function, called by onRender.
*/
void GuiCrossHairHud::drawDamage(Point2I offset, F32 damage, F32 opacity)
{
   mDamageFillColor.alpha = mDamageFrameColor.alpha = opacity;

   // Damage should be 0->1 (0 being no damage,or healthy), but
   // we'll just make sure here as we flip it.
   damage = mClampF(1 - damage, 0, 1);

   // Center the bar
   RectI rect(offset, mDamageRectSize);
   rect.point.x -= mDamageRectSize.x / 2;

   // Draw the border
   dglDrawRect(rect, mDamageFrameColor);

   // Draw the damage % fill
   rect.point += Point2I(1, 1);
   rect.extent -= Point2I(1, 1);
   rect.extent.x = (S32)(rect.extent.x * damage);
   if (rect.extent.x == 1)
      rect.extent.x = 2;
   if (rect.extent.x > 0)
      dglDrawRectFill(rect, mDamageFillColor);
}
//Combat Starter Kit

//----------------------------------------------------------------------------
/// Render object range.
///
/// Helper function for GuiShapeNameHud::onRender
///
/// @param   offset  Screen coordinates to render range. (Text is centered
///                  horizontally about this location, with bottom of text at
///                  specified y position.)
/// @param   range   String range to display.
/// @param   opacity Opacity of range (a fraction).
void GuiCrossHairHud::drawRange(Point2I offset, F32 range, F32 lockvalue, F32 opacity)
{
    char buf[25];
    //dSprintf (buf, sizeof(buf), "Range: %d Lock: %f", (S32)(range), lockvalue);
    dSprintf (buf, sizeof(buf), "Range: %d", (S32)(range));
    // Center the value
    offset.x -= mProfile->mFont->getStrWidth((const UTF8 *)buf) / 2;
    offset.y -= mProfile->mFont->getHeight();

    // Deal with opacity and draw.
    mTextColor.alpha = opacity;
    dglSetBitmapModulation(mTextColor);
    dglDrawText(mProfile->mFont, offset, buf);
    dglClearBitmapModulation();
}

//----------------------------------------------------------------------------
/// Render object names.
///
/// Helper function for GuiShapeNameHud::onRender
///
/// @param   offset  Screen coordinates to render name label. (Text is centered
///                  horizontally about this location, with bottom of text at
///                  specified y position.)
/// @param   name    String name to display.
/// @param   opacity Opacity of name (a fraction).
void GuiCrossHairHud::drawName(Point2I offset, const char *name, F32 opacity)
{
    // Center the name
    offset.x -= mProfile->mFont->getStrWidth((const UTF8 *)name) / 2;
    offset.y -= mProfile->mFont->getHeight();

    // Deal with opacity and draw.
    mTextColor.alpha = opacity;
    dglSetBitmapModulation(mTextColor);
    dglDrawText(mProfile->mFont, offset, name);
    dglClearBitmapModulation();
}

// Combat Starter Kit CODE BLOCK (factions) <<
void GuiCrossHairHud::drawName(Point2I offset, const char *name, S32 myFaction, S32 faction, F32 opacity)
{
    //this version of drawName draws the name in red if it's a different faction than ours
    //otherwise draws the name in Green

    // Center the name
    offset.x -= mProfile->mFont->getStrWidth((const UTF8 *)name) / 2;
    offset.y -= mProfile->mFont->getHeight();

    // Deal with opacity and draw.
    mTextColor.alpha = opacity;
    if(faction != myFaction)
        dglSetBitmapModulation(ColorF(1.0, 0.0, 0.0, 1.0));
    else
        dglSetBitmapModulation(ColorF(0.0, 1.0, 0.0, 1.0));

    dglDrawText(mProfile->mFont, offset, name);
    dglClearBitmapModulation();
}
// Combat Starter Kit CODE BLOCK (factions) <<
