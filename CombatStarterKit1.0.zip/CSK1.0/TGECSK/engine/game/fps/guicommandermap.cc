//-----------------------------------------------------------------------------
// Commander Map HUD
//
// Portions Copyright (c) GarageGames.Com
// Copyright (c) Ben Garney
// Extensively extended by Duncan Gray
//-----------------------------------------------------------------------------

// These includes are probably overkill -- BJG
// yes they are -- DG :)

#include "platform/platform.h"
#include "platform/platformVideo.h"
#include "platform/platformAudio.h"
#include "platform/platformInput.h"
#include "core/findMatch.h"

#include "dgl/dgl.h"
#include "game/game.h"
#include "math/mMath.h"
#include "console/simBase.h"
#include "console/console.h"
#include "terrain/terrData.h"
#include "terrain/terrRender.h"
#include "terrain/waterBlock.h"
#include "game/collisionTest.h"
#include "game/showTSShape.h"
#include "sceneGraph/sceneGraph.h"
#include "gui/core/guiTSControl.h"
#include "game/moveManager.h"
#include "console/consoleTypes.h"
#include "game/shapeBase.h"
#include "game/player.h"
#include "core/dnet.h"
#include "game/gameConnection.h"
#include "core/fileStream.h"
#include "gui/core/guiCanvas.h"
#include "dgl/gTexManager.h"
#include "sceneGraph/sceneLighting.h"
#include "terrain/sky.h"
#include "game/ambientAudioManager.h"
#include "core/frameAllocator.h"
#include "sceneGraph/detailManager.h"
#include "gui/controls/guiMLTextCtrl.h"
#include "platform/profiler.h"
#include "game/fx/underLava.h"
#include "game/gameConnection.h"
#include "editor/editTSCtrl.h"

//-----------------------------------------------------------------------------

struct MapMouseEvent
   {
	   Point3F wp;
	   Point3F sp;
	   bool inClickRange;
   };

class GuiIcon : public SimObject
{
private:
   typedef SimObject Parent;
   StringTableEntry mBitmapName;
   StringTableEntry mToolTip;
   Point2I mExtent;
   TextureHandle mTextureHandle[3];
   Resource<GFont>			mToolTipFont;
   U32 mToolTipWidth;
   ColorI mToolTipColor;
   void click();

public:
   Point2I getExtent() { return mExtent; }

   DECLARE_CONOBJECT(GuiIcon);
   GuiIcon(void);
   ~GuiIcon(void);
   static void initPersistFields();

   bool onAdd(void);
   void onRemove();
   void render(const Point3F &_pos, S32 MaxX, F32 &mCurZoom, S32 &team, MapMouseEvent &me );
   void setBitmap();
   void setNull();
};
IMPLEMENT_CONOBJECT(GuiIcon);

//-----------------------------------------------------------------------------
GuiIcon::GuiIcon()
{
   mExtent.set(1,1);
}

//-----------------------------------------------------------------------------
GuiIcon::~GuiIcon()
{
}

//-----------------------------------------------------------------------------
void GuiIcon::click()
{

}
//-----------------------------------------------------------------------------
void GuiIcon::initPersistFields()
{
   Parent::initPersistFields();
   addField("ToolTip",     TypeString,   Offset(mToolTip, GuiIcon));
   addField("ToolTipColor", TypeColorI, Offset(mToolTipColor, GuiIcon));
   addField("bitmapName",  TypeFilename,  Offset(mBitmapName, GuiIcon));
}

//-----------------------------------------------------------------------------
bool GuiIcon::onAdd()
{
   if(!Parent::onAdd())
      return false;

   Sim::getGuiDataGroup()->addObject(this);
   
   setBitmap();

	mToolTipFont = GFont::create("Arial", 16, Con::getVariable("$GUI::fontCacheDirectory"));
	mToolTipWidth = mToolTipFont->getStrWidth(mToolTip);


   return true;
}

//-----------------------------------------------------------------------------
void GuiIcon::onRemove()
{
   Parent::onRemove();
}

//-----------------------------------------------------------------------------
void GuiIcon::render(const Point3F &_pos, S32 MaxX, F32 &mCurZoom, S32 &team, MapMouseEvent &me )
{
	Point2I pos;
	pos.x = _pos.x;
	pos.y = _pos.y;

   if (!mTextureHandle[team])
   return;
   // zoom is about 0.2 for very close and 1.5 for far = ratio 1.5/0.2 = 7.5
   // size is about 60                      10           ratio = 60/10 = 6
   // default size = 64

   F32 mult = mCurZoom * 4.5;
   // Render the icon centered according to dimensions of texture
   S32 texWidth = 10 + mTextureHandle[team].getWidth() / mult;
   S32 texHeight = 10 + mTextureHandle[team].getWidth() / mult;
   mExtent.set(texWidth, texHeight);
   S32 halfWidth = texWidth/2;

   Point2I renderPos = pos;
   renderPos.x -= halfWidth;
   renderPos.y -= ( texHeight /2 );
   RectI rect(renderPos, mExtent);
   
   dglClearBitmapModulation();
   dglDrawBitmapStretch(mTextureHandle[team], rect);
   
   // is the cursor within the bounds of the icon?
   if(((me.sp.x >= renderPos.x)&&(me.sp.x <= renderPos.x + mExtent.x))&&
     ((me.sp.y >= renderPos.y)&&(me.sp.y <= renderPos.y + mExtent.y)))
	 {
	   S32 toffset = mToolTipWidth + halfWidth;
	   if((pos.x + toffset) > MaxX)
		   pos.x -= toffset;
	   else pos.x += halfWidth;
	   dglDrawText(mToolTipFont, pos, mToolTip, &mToolTipColor);
	   me.inClickRange = true;
	 }
	 else
		 me.inClickRange = false; 
		 
}
//-----------------------------------------------------------------------------

//-------------------------------------
void GuiIcon::setNull()
{
	mTextureHandle[0] = NULL;
	mTextureHandle[1] = NULL;
	mTextureHandle[2] = NULL;
}

//void GuiIcon::setBitmap(const char *name)
void GuiIcon::setBitmap()
{
   if (*mBitmapName)
   {
      char buffer[1024];
      char *p;
	  const char *name = mBitmapName;
      dStrcpy(buffer, name);
      p = buffer + dStrlen(buffer);

      mTextureHandle[0] = TextureHandle(buffer, BitmapTexture, true);
      if (!mTextureHandle[0])
      {
         dStrcpy(p, ".0");
         mTextureHandle[0] = TextureHandle(buffer, BitmapTexture, true);
      }
      if (!mTextureHandle[1])
      {
         dStrcpy(p, ".1");
         mTextureHandle[1] = TextureHandle(buffer, BitmapTexture, true);
      }
      if (!mTextureHandle[2])
      {
         dStrcpy(p, ".2");
         mTextureHandle[2] = TextureHandle(buffer, BitmapTexture, true);
      }
   }
   else
   {
      mTextureHandle[0] = NULL;
      mTextureHandle[1] = NULL;
      mTextureHandle[2] = NULL;
   }
}
//=================================================================================================
//=================================================================================================
//=================================================================================================
//=================================================================================================
//=================================================================================================
//-----------------------------------------------------------------------------
class GuiCommanderHud : public GuiTSCtrl
{
private:
   typedef GuiTSCtrl Parent;
   enum {numTeams=3};
   Point2F mPanSpeed;
   F32     mZoomSpeed;
   S32     mLastRenderTime;
   SimObjectPtr<GameConnection> mConnection;
   ColorF teamColor[numTeams];     
   bool useIcons;
   Point2I mousePos;
   MapMouseEvent mLastEvent;
   F32 maxHi, minHi, diffHi, cameraHi;
   Point3F storedCamPos;
   MatrixF storedCamMatrix;
   U32 startTime;
   void drawRipples(S32 x, S32 y);
   S32 clientTeam;
   Point3F clientPos;
   bool calcProject(Point3F &wp, Point3F &sp);
   S32 mShowTeam;
   bool project(const Point3F &pt, Point3F *dest);

public:	
   bool startSpawn, startSpawnCam, clickingAllowed, doSpawnInSweepCam;
   void onlyShowThisTeam(S32 showTeam){ mShowTeam = showTeam;}
   S32 getMyTeam(){return clientTeam;}
   void centerOnMe();

   

private:
   // screen editing additions
    enum {
         DefaultCursor = 0,
         MoveCursor,
		 UpDownCursor,
         NumCursors
      };

      bool grabCursors();
      GuiCursor *                mCurrentCursor;
      GuiCursor *                mCursors[NumCursors];
      void getCursor(GuiCursor *&cursor, bool &showCursor, const GuiEvent &lastGuiEvent);
      void setCursor(U32 cursor);

	  enum {
		  noIcon,
		  TankIcon,
		  JeepIcon,
		  GunshipIcon,
		  TransportIcon,
		  PersonIcon,
		  MediIcon,
		  AmmoIcon,
		  FlagIcon,
		  RadarIcon,
		  SpawnIcon,
		  WaypointIcon,
		  TargetIcon,
		  ParachuteIcon,
		  NumIcons
	  };
      bool grabIcons();
      GuiIcon *                mIcons[NumIcons];
      void getCursor(GuiIcon *&cursor, bool &showCursor, const GuiEvent &lastGuiEvent);
	  Vector<ShapeBase *> objectsInRange;
	  Player *clientPlayerObject;
	  StringTableEntry mBitmapName;
      TextureHandle mTextureHandle;
	  
	  F32 storedVis; 
	  F32 storedFog;
	  F32 renderDistance;

public:
   Point2F mPanGoal, mCurPan, mPosAtClick;
   F32     mZoomGoal, mCurZoom;
   F32 minZoom, maxZoom;
   ShapeBase *lastSelectedObject;

   GuiCommanderHud();

   bool processCameraQuery(CameraQuery *query);
   void renderWorld(const RectI &updateRect);

   void onRender( Point2I, const RectI &);
   void renderObjects();
   void drawSelectionBitmap(S32 x, S32 y);
   static void initPersistFields();

   void make3DMouseEvent(MapMouseEvent & gui3Devent, const GuiEvent &event);

   
    virtual void onMouseUp(const GuiEvent &event);
    virtual void onMouseDown(const GuiEvent &event);
    virtual void onMouseMove(const GuiEvent &event);
    virtual void onMouseDragged(const GuiEvent &event);
	virtual void onMouseEnter(const GuiEvent &event){};
	virtual void onMouseLeave(const GuiEvent &event){};

	virtual bool onMouseWheelUp(const GuiEvent &event);
	virtual bool onMouseWheelDown(const GuiEvent &event);

	virtual void onRightMouseDown(const GuiEvent &event);
	virtual void onRightMouseUp(const GuiEvent &event){};
	virtual void onRightMouseDragged(const GuiEvent &event){};

	virtual void onMiddleMouseDown(const GuiEvent &event);
	virtual void onMiddleMouseUp(const GuiEvent &event);
	virtual void onMiddleMouseDragged(const GuiEvent &event);

   bool onAdd();
   virtual bool onWake();
   virtual void onSleep();


   DECLARE_CONOBJECT( GuiCommanderHud );
};


//-----------------------------------------------------------------------------

IMPLEMENT_CONOBJECT( GuiCommanderHud );

GuiCommanderHud::GuiCommanderHud()
:   mPanSpeed(10, 10), mZoomSpeed(1), mCurPan(0,0), mCurZoom(M_PI_F/2),
    mPanGoal(0,0), mZoomGoal(M_PI_F/2), mLastRenderTime(0)
{
	teamColor[0].set(1,1,0,1);   // yellow
	teamColor[1].set(1,0,0,1);   // red
	teamColor[2].set(0,0.3,1,1); // blue	
	startTime = 0;
	minZoom = 0.1;
	maxZoom = 1.57;
	startSpawn = false;
	startSpawnCam = false;
	doSpawnInSweepCam = false;
	lastSelectedObject = NULL;
	
	renderDistance = 2000;
	storedVis = renderDistance;
	storedFog = renderDistance;
	mShowTeam = 0;
	clickingAllowed = true;
	clientPos.set(0,0,0);
	clientTeam = 0;
}

//-----------------------------------------------------------------------------
void GuiCommanderHud::initPersistFields()
{
   Parent::initPersistFields();

   addField("panSpeed",  TypePoint2F, Offset(mPanSpeed,  GuiCommanderHud), "Set the speed (x/y) we pan to our goal.");
   addField("zoomSpeed", TypeF32,     Offset(mZoomSpeed, GuiCommanderHud), "Set the speed we zoom with to our goal.");
   addField("bitmapName",  TypeFilename,  Offset(mBitmapName, GuiCommanderHud),"bitmap used to light a selected icon");
   addField("spawnInSweepCam",  TypeBool,  Offset(doSpawnInSweepCam, GuiCommanderHud),"boolean to set a sweeping spawn cam");
   
}
//-----------------------------------------------------------------------------

bool GuiCommanderHud::onAdd()
{
   if(!Parent::onAdd())
      return(false);

   grabCursors();
   useIcons = grabIcons();
 
   mTextureHandle = TextureHandle(mBitmapName, BitmapTexture, true);

   return(true);
}


bool GuiCommanderHud::project(const Point3F &pt, Point3F *dest)
{
   GLdouble winx, winy, winz;
   GLint result = gluProject(pt.x, pt.y, pt.z,
                     mSaveModelview, mSaveProjection, mSaveViewport,
                     &winx, &winy, &winz);
   if(result == GL_FALSE || winz < 0 || winz > 1.01)
      return false;
   dest->set(winx, winy, winz);
   return true;
}
//-----------------------------------------------------------------------------
bool GuiCommanderHud::processCameraQuery(CameraQuery *q)
{
  // Scale ranges based on the highest/lowest point in the terrain
   maxHi = gClientSceneGraph->getCurrentTerrain()->findSquare(8, 0,0)->maxHeight / 10;
   minHi = gClientSceneGraph->getCurrentTerrain()->findSquare(8, 0,0)->minHeight / 10;
   F32 desiredHeight = 1300 + minHi; //desired height above lowest point
    // some height added for when dealing with flat terrain
   cameraHi = maxHi > desiredHeight ? maxHi +10 : desiredHeight;  // kinda keeps the camera 1300m above lowest point

   q->object = NULL;
   q->nearPlane = 1;
   q->farPlane  = cameraHi / mCos(mCurZoom/2);
   Point3F camPos;

   if(!startSpawnCam)
   {
	   q->fov       = mCurZoom;

	   // Make us high up, facing straight down.   
	   q->cameraMatrix = MatrixF (EulerF(1.570796327, 0.0, 0.0)); // rotate us to look straight down
	   storedCamPos.set(mCurPan.x,mCurPan.y, cameraHi);
	   q->cameraMatrix.setPosition(storedCamPos); // and high enough we won't clip
	   storedCamMatrix = q->cameraMatrix;
   }
   else
   {

	   if(!doSpawnInSweepCam)
	   // dont do sweep
	   {
		   clientPlayerObject->setSpawnInSweep(false);
		   clientPlayerObject->setCamCatchupMode();

		   const char *cmd[1];
		   cmd[0] = "GuiCommanderHudClose";
		   Con::execute(1, cmd);
		   return true;
	   } else {
		   extern F32 FPS; // from main.cc
		   F32 TransTime = FPS * 0.75;
		   mCurZoom -= (mCurZoom - 1.57)/TransTime; // get back to player FOV
		   mZoomGoal = mCurZoom;
		   q->fov       = mCurZoom;

		   MatrixF mat;
		   clientPlayerObject->getRenderEyeTransform(&mat);
		   Point3F eyePos, tmpVec, tmpP;
		   mat.getColumn(3, &eyePos);
		   tmpVec = eyePos - storedCamPos;	
		   if(tmpVec.len() < 130)
		   {
			   clientPlayerObject->setStoredCamMatrix(storedCamMatrix);
			   clientPlayerObject->setSpawnInSweep(true);
			   clientPlayerObject->setCamCatchupMode();
			   const char *cmd[1];
			   cmd[0] = "GuiCommanderHudClose";
			   Con::execute(1, cmd);	
		   } 
		   tmpVec.normalize();
		   mat = MathUtils::createOrientFromDir( tmpVec ); // create a matrix from that vector	   
		   mat.setColumn(3,eyePos);
		   
		   clientPlayerObject->smoothMatrixTransition(storedCamMatrix, mat, 2.25);	   
		   storedCamMatrix.getColumn(3, &storedCamPos);
		   q->cameraMatrix = storedCamMatrix;
	   }
   }

   return true;
}

//-----------------------------------------------------------------------------
void GuiCommanderHud::renderWorld(const RectI &updateRect)
{
   // Set up state
   extern F32 FPS; // from main.cc
   F32 TransTime = FPS * 1.75;
	
	F32 oldVisDist = gClientSceneGraph->getVisibleDistance();
	F32 oldFogDist = gClientSceneGraph->getFogDistance();
	TerrainRender::mRenderingCommander = true;
	if(!startSpawnCam)
	{
		gClientSceneGraph->setVisibleDistance(renderDistance);
		gClientSceneGraph->setFogDistance(renderDistance);
		storedVis = storedFog = renderDistance;
	}
	else
	{
		storedVis -= (storedVis - oldVisDist)/TransTime;
		storedFog -= (storedFog - oldFogDist)/TransTime;
		gClientSceneGraph->setVisibleDistance(storedVis);
		gClientSceneGraph->setFogDistance(storedFog);
	}

   // set up the camera and viewport stuff:

   // Render (stolen from GameRenderWorld)
   PROFILE_START(GameRenderCommanderWorld);
   FrameAllocator::setWaterMark(0);

#if defined(GATHER_METRICS) && GATHER_METRICS > 1
   TextureManager::smTextureCacheMisses = 0;
#endif

   glEnable(GL_DEPTH_TEST);
   glDepthFunc(GL_LEQUAL);
   glClear(GL_DEPTH_BUFFER_BIT);
   glDisable(GL_CULL_FACE);
   glMatrixMode(GL_MODELVIEW);

   dglSetCanonicalState();
   // If you want to render other things, change this mask.
	if(!startSpawnCam)
       gClientSceneGraph->renderScene(    EnvironmentObjectType | TerrainObjectType | InteriorObjectType | WaterObjectType );
	else
       gClientSceneGraph->renderScene(    EnvironmentObjectType | TerrainObjectType | InteriorObjectType | WaterObjectType | ShapeBaseObjectType |  ExplosionObjectType );
   
   glDisable(GL_DEPTH_TEST);

#if defined(GATHER_METRICS) && GATHER_METRICS > 1
   Con::setFloatVariable("Video::texResidentPercentage",
                         TextureManager::getResidentFraction());
   Con::setIntVariable("Video::textureCacheMisses",
                       TextureManager::smTextureCacheMisses);
#endif

   AssertFatal(FrameAllocator::getWaterMark() == 0, "Error, someone didn't reset the water mark on the frame allocator!");
   FrameAllocator::setWaterMark(0);
   PROFILE_END();


   // Restore state
   gClientSceneGraph->setVisibleDistance(oldVisDist);
   gClientSceneGraph->setFogDistance    (oldFogDist);
   TerrainRender::mRenderingCommander = false;

   dglSetClipRect(updateRect);
   renderObjects();
}
//-------------------------------------------------------------------------------------------------------------
const F32 DEG2RAD = 3.14159/180;
void GuiCommanderHud::renderObjects()
{
	if(startSpawnCam)
		return;

	Point2F mypos;
	ShapeBase* control = NULL;
	GameConnection* conn = GameConnection::getConnectionToServer();
	if(conn) 
		control = conn->getControlObject();

	objectsInRange.clear();
	
	

	mConnection = GameConnection::getConnectionToServer();  
	//for (SimSetIterator itr(mConnection); *itr; ++itr)

	// need two loops, first to find what team this client is in
	clientPlayerObject = NULL;
	for (SimSetIterator itr(Sim::getRootGroup()); *itr; ++itr)
	{
		if ( (*itr)->getType() & PlayerObjectType)
		{
			if (ShapeBase* unit = dynamic_cast<ShapeBase*>(*itr))
			{			
				if(control == unit)				
				{
					clientPlayerObject = dynamic_cast<Player*>(control);
					clientTeam = unit->getTeam();
					clientPos = unit->getPosition();
					if(startSpawn)
					{
						startSpawn = false;
						startSpawnCam = true;
					}
					break;
				}
			}
		}
	}
	// now for the other stuff
	for (SimSetIterator itr(Sim::getRootGroup()); *itr; ++itr)
	{
		if ( (*itr)->getType() & PlayerObjectType||VehicleObjectType||ItemObjectType)
		{
			if (ShapeBase* unit = dynamic_cast<ShapeBase*>(*itr))
			{			
				Point3F screenPos;		
				//What team is it on?
				S32 team = unit->getTeam();		
				bool hideThis = unit->getTeamIcon() && (clientTeam != team) ;
				if(!hideThis)
					hideThis = (mShowTeam >0)? mShowTeam != team : false;

				if (project(unit->getPosition(), &screenPos) && !unit->isMounted() && unit->isClientObject() && !unit->getDataBlock()->hideIcon && !hideThis)
				{
					glColor3f(teamColor[team].red, teamColor[team].green, teamColor[team].blue);
					S32 icon = unit->getDataBlock()->IconType;
					if( useIcons && (icon > 0) && (team >= 0) && (team <= numTeams))
					{
						mIcons[icon]->render(screenPos, getWidth(), mCurZoom, team, mLastEvent);
						if((mLastEvent.inClickRange) && unit->getDataBlock()->iconCanBeClicked && clickingAllowed)
						{
							if(unit->getClassName()!= "SpawnSphere")
							{
								objectsInRange.push_back(unit);
								drawRipples(screenPos.x, screenPos.y);
							}
							else // yes its a spawnsphere							
								if(!clientPlayerObject) //don't encourage a new player if we already got one
								{
									objectsInRange.push_back(unit);
									drawRipples(screenPos.x, screenPos.y);
								}
						}
						if((unit == lastSelectedObject)&& mTextureHandle)
						{
							// draw halo on icon
							drawSelectionBitmap(screenPos.x, screenPos.y);
						}
					}
					if(control == unit)
					{
						F32 radius = 84/(mCurZoom * 4.5);
						glBegin(GL_LINE_LOOP);
						for (int i=0; i < 360; i++)
						{
							float degInRad = i*DEG2RAD;
							glVertex2f(screenPos.x + cos(degInRad)*radius,screenPos.y + sin(degInRad)*radius);
						}
						glEnd();						
					}

				}
		 }
		}
	}
	
	

}

//-----------------------------------------------------------------------
void GuiCommanderHud::drawSelectionBitmap(S32 x, S32 y)
{
	F32 mult = mCurZoom * 4.5;
	Point2I mExtent;
	// Render the icon centered according to dimensions of texture
	S32 texWidth = 30 + mTextureHandle.getWidth() / mult;
	S32 texHeight = 30 + mTextureHandle.getWidth() / mult;
	mExtent.set(texWidth, texHeight);
	S32 halfWidth = texWidth/2;

	Point2I renderPos;
	renderPos.x = x - halfWidth;
	renderPos.y = y - ( texHeight /2 );
	RectI rect(renderPos, mExtent);
    dglClearBitmapModulation();
    dglDrawBitmapStretch(mTextureHandle, rect);
}
//-----------------------------------------------------------------------

void GuiCommanderHud::drawRipples(S32 x, S32 y)
{
	if(startTime == 0)
		startTime = Platform::getRealMilliseconds();
	U32 nowTime = Platform::getRealMilliseconds();
	F32 diffTime = (nowTime-startTime);	

	diffTime /= 300;
	if(diffTime > 3.142)
	{
		diffTime = 0;
		startTime = Platform::getRealMilliseconds();
	}
	
	F32 mult = mCurZoom * 4.5;
	F32 radius = (64 + 100 * mSin(diffTime))/mult;

		glBegin(GL_LINE_LOOP);
		for (int i=0; i < 360; i++)
		{
			float degInRad = i*DEG2RAD;
			glVertex2f(x + cos(degInRad)*radius, y + sin(degInRad)*radius);
		}
		glEnd();
}
/*

   F32 currentRadius;
   U32 startTime;
      glBegin(GL_LINE_LOOP);
      glVertex2f(screenPos.x - offset, screenPos.y - offset);
      glVertex2f(screenPos.x + offset, screenPos.y - offset);
      glVertex2f(screenPos.x + offset, screenPos.y + offset);
      glVertex2f(screenPos.x - offset, screenPos.y + offset);
	  glEnd();
	  */
//-----------------------------------------------------------------------
void GuiCommanderHud::onRender(Point2I offset, const RectI &updateRect)
{
   // Update pan/zoom
   S32 time = Platform::getVirtualMilliseconds();
   S32 dt = time - mLastRenderTime;
   mLastRenderTime = time;

   mCurPan  += (mPanGoal  - mCurPan)  * (F32)dt/1000.f;
   mCurZoom += (mZoomGoal - mCurZoom) * (F32)dt/1000.f;

   // Render the world...
   Parent::onRender(offset, updateRect);

   // If you wanted to render custom GUI elements, like a sensor map, icons for
   // players/vehicles/objectives, you would do it here by calling project()
   // for all their positions and drawing bitmaps at the appropriate locations.
   //renderObjects();

    if( !mApplyFilterToChildren)
      Parent::renderChildControls(offset, updateRect);
}
void GuiCommanderHud::centerOnMe()
{
  mPanGoal.set(clientPos.x, clientPos.y);
}
//-----------------------------------------------------------------------------
ConsoleMethod(GuiCommanderHud, pan, void, 4, 4, "(x, y) Cut to a location.")
{
   object->mPanGoal.set(dAtof(argv[2]), dAtof(argv[3]));
   object->mCurPan.set (dAtof(argv[2]), dAtof(argv[3]));
}
//-----------------------------------------------------------------------------
ConsoleMethod(GuiCommanderHud, centerOnMe, void, 2, 2, "() Move to my location")
{
   object->centerOnMe();
}
//-----------------------------------------------------------------------------
ConsoleMethod(GuiCommanderHud, getMyTeam, S32, 2, 2, "() return my team")
{
   return object->getMyTeam();
}
//-----------------------------------------------------------------------------

ConsoleMethod(GuiCommanderHud, panTo, void, 4, 4, "(x, y) Smoothly pan to a location.")
{
   object->mPanGoal.set(dAtof(argv[2]), dAtof(argv[3]));
}

//-----------------------------------------------------------------------------
ConsoleMethod(GuiCommanderHud, zoom, void, 3, 3, "(val) Zoom to a specified level.")
{
   object->mZoomGoal = mClampF(dAtof(argv[2]), object->minZoom, object->maxZoom);
   object->mCurZoom  = mClampF(dAtof(argv[2]), object->minZoom, object->maxZoom);
}
//-----------------------------------------------------------------------------

ConsoleMethod(GuiCommanderHud, zoomTo, void, 3, 3, "(val) Smoothly zoom to a specified level.")
{
   object->mZoomGoal = mClampF(dAtof(argv[2]), object->minZoom, object->maxZoom);
}
//-----------------------------------------------------------------------------

ConsoleMethod(GuiCommanderHud, zoomToArea, void, 6, 7, "(top, left, right, bottom, bool cut) Smoothly zoom to view the specified area. If cut is set, we jump there.")
{
   // Parse arguments
   F32 top, left, right, bottom;

   top    = dAtof(argv[2]);
   left   = dAtof(argv[3]);
   right  = dAtof(argv[4]);
   bottom = dAtof(argv[5]);

   // Figure out the center of the area
   Point2F center;

   center.x = (left + right) * 0.5f;
   center.y = (top + bottom) * 0.5f;

   object->mZoomGoal = mFabs(left - right) / 200; // Cheesy scaling fakery.

   // And set our motion
   object->mPanGoal = center;

   // Cut if requested
   if(argc > 6)
      if(dAtob(argv[6]))
      {
         object->mCurPan  = object->mPanGoal;
         object->mCurZoom = object->mZoomGoal;
      }
}

ConsoleMethod(GuiCommanderHud, clickLastSelection, void, 2, 2, "clickLastSelection() re-select the last selected Icon.")
{
	if(object->lastSelectedObject == NULL)
		return;

	//static const char *cmd[2];
	//cmd[0] = "GuiCommanderHudIconClick";
	//cmd[1] = Con::getIntArg(object->lastSelectedObject->getId());		
	//Con::execute(2, cmd);		
	object->startSpawn = true;
}

ConsoleMethod(GuiCommanderHud, onlyShowThisTeam, void, 3, 3, "onlyShowThisTeam(s32 team) hide all except this teams icons.")
{
   object->onlyShowThisTeam(dAtoi(argv[2]));
}

ConsoleMethod(GuiCommanderHud, setClickingAllowed, void, 3, 3, "setClickingAllowed(bool) ignores clickable buttons if false.")
{
   object->clickingAllowed = (dAtob(argv[2]));
}

//-----------------------------------------------------------------------------

// From here down is the code dealing with mouse interaction 
void GuiCommanderHud::make3DMouseEvent(MapMouseEvent & MapMouseEvent, const GuiEvent & event)
{
   (GuiEvent&)(MapMouseEvent) = event;

   Point3F sp(event.mousePoint.x, event.mousePoint.y, 1);
   //Point3F wp;
   //unproject(sp, &wp);  //not to accurate

   //MapMouseEvent.wp = wp;
   MapMouseEvent.sp = sp;

   // Fix sp offset based on TGE quadrants
   sp.x -= mBounds.extent.x/2;
   sp.y -= mBounds.extent.y/2;
   sp.y *= -1;
   // calculate ground width from camera height and fov
   F32 angle = mCurZoom/2;
   F32 groundWidth = mTan(angle) * cameraHi * 2;
   // now get the ground to screen ratio
   F32 ratio = mBounds.extent.x/groundWidth;
   // now calculate screen pos	
   ratio *= 1.05; //hack for better accuracy
   MapMouseEvent.wp = sp/ratio;
   MapMouseEvent.wp += storedCamPos;
   MapMouseEvent.wp.z = 1;
}

//---------------------------------------------------------------------------------------------------------
void GuiCommanderHud::onMouseDown(const GuiEvent &event)
{	
	if(!clickingAllowed)
		return;
	make3DMouseEvent(mLastEvent, event);
	mPosAtClick.set(mLastEvent.wp.x, mLastEvent.wp.y);

	if(objectsInRange.size() == 0)
		setCursor(MoveCursor);
	else
	{
			static const char *argv[2];
			argv[0] = "GuiCommanderHudIconClick";
			for(S32 i = 0; i< objectsInRange.size();i++)
			{
				if(objectsInRange[i]->getDataBlock()->iconCanBeClicked)	
				{
					char buff[200];
					argv[1] = Con::getIntArg(objectsInRange[i]->getId());		
					Con::execute(2, argv);		
					lastSelectedObject = objectsInRange[i]; // tough if u clicked more than one in same time
					if((lastSelectedObject->getClassName()=="SpawnSphere")&& !clientPlayerObject && !startSpawn)
						startSpawn = true;
				}
			}
		
	}
}
//---------------------------------------------------------------------------------------------------------
void GuiCommanderHud::onMouseUp(const GuiEvent &event)
{
	setCursor(DefaultCursor);
}
//---------------------------------------------------------------------------------------------------------
void GuiCommanderHud::onMouseDragged(const GuiEvent &event)
{	
	if(!clickingAllowed)
		return;
	make3DMouseEvent(mLastEvent, event);
	Point2F motion;
    motion.x = mPosAtClick.x - mLastEvent.wp.x;
    motion.y = mPosAtClick.y - mLastEvent.wp.y;
    mCurPan += motion;
	mPanGoal = mCurPan;
}
//---------------------------------------------------------------------------------------------------------
void GuiCommanderHud::onMouseMove(const GuiEvent &event)
{
	if(!clickingAllowed)
		return;
	make3DMouseEvent(mLastEvent, event);
    mousePos.x = mLastEvent.sp.x;
    mousePos.y = mLastEvent.sp.y;
}
//---------------------------------------------------------------------------------------------------------
void GuiCommanderHud::onRightMouseDown(const GuiEvent &event)
{
	if(!clickingAllowed)
		return;

	make3DMouseEvent(mLastEvent, event);

	static const char *argv[2];
	char buff[100];
	argv[0] = "GuiCommanderHudRightClick";
	// get ground location
	TerrainBlock * terrain = dynamic_cast<TerrainBlock*>(Sim::findObject("Terrain"));
	if(terrain)
	{
		Point3F offset;
		Point2F pos;
		pos.x =  mLastEvent.wp.x;
		pos.y =  mLastEvent.wp.y;
		terrain->getTransform().getColumn(3, &offset);
		pos -= Point2F(offset.x, offset.y);
		terrain->getHeight(pos, &mLastEvent.wp.z);
		dSprintf(buff,sizeof(buff),"%g %g %g", mLastEvent.wp.x, mLastEvent.wp.y, mLastEvent.wp.z );
	}
	else
	   dSprintf(buff,sizeof(buff),"%g %g %g", mLastEvent.wp.x, mLastEvent.wp.y, maxHi );
	argv[1] = buff;
	Con::execute(2, argv);	

}
//---------------------------------------------------------------------------------------------------------
void GuiCommanderHud::onMiddleMouseDown(const GuiEvent &event)
{
	if(!clickingAllowed)
		return;
	make3DMouseEvent(mLastEvent, event);
	mPosAtClick.set(mLastEvent.wp.x, mLastEvent.wp.y);
	setCursor(UpDownCursor);
}
//---------------------------------------------------------------------------------------------------------
void GuiCommanderHud::onMiddleMouseUp(const GuiEvent &event)
{
	setCursor(DefaultCursor);
}
//---------------------------------------------------------------------------------------------------------
void GuiCommanderHud::onMiddleMouseDragged(const GuiEvent &event)
{
	if(!clickingAllowed)
		return;
	make3DMouseEvent(mLastEvent, event);
	Point2F motion;
    motion.x = mPosAtClick.x - mLastEvent.wp.x;
    motion.y = mPosAtClick.y - mLastEvent.wp.y;
    mCurZoom += motion.y /1000;
	mCurZoom = mClampF(mCurZoom, minZoom, maxZoom);
	mZoomGoal = mCurZoom;

}
//---------------------------------------------------------------------------------------------------------
bool GuiCommanderHud::onMouseWheelUp(const GuiEvent &event)
{	
	if(!clickingAllowed)
		return true;
  mZoomGoal = mClampF(mZoomGoal - 0.1, minZoom, maxZoom);
  return true;
}
//---------------------------------------------------------------------------------------------------------

bool GuiCommanderHud::onMouseWheelDown(const GuiEvent &event)
{
	if(!clickingAllowed)
		return true;
  mZoomGoal = mClampF(mZoomGoal + 0.1, minZoom, maxZoom);
  return true;
}
//---------------------------------------------------------------------------------------------------------
void GuiCommanderHud::getCursor(GuiCursor *&cursor, bool &visible, const GuiEvent &)
{
   cursor = mCurrentCursor;
   visible = true;
}
//---------------------------------------------------------------------------------------------------------

void GuiCommanderHud::setCursor(U32 cursor)
{
   AssertFatal(cursor < NumCursors, "GuiCommanderHud::setCursor: invalid cursor");
   mCurrentCursor = mCursors[cursor];
}

//---------------------------------------------------------------------------------------------------------
bool GuiCommanderHud::grabCursors()
{
   struct {
      U32 index;
      const char * name;
   } infos[] = {
      {DefaultCursor,            "DefaultCursor"         },
      {MoveCursor,               "MoveCursor"      },
      {UpDownCursor,             "UpDownCursor"      }
   };

   for(U32 i = 0; i < (sizeof(infos) / sizeof(infos[0])); i++) 
   {
      SimObject * obj = Sim::findObject(infos[i].name);
      if(!obj)
      {
         Con::errorf(ConsoleLogEntry::Script, "GuiCommanderHud::grabCursors: failed to find cursor '%s'.", infos[i].name);
         return(false);
      }

      GuiCursor *cursor = dynamic_cast<GuiCursor*>(obj);
      if(!cursor)
      {
         Con::errorf(ConsoleLogEntry::Script, "GuiCommanderHud::grabCursors: object is not a cursor '%s'.", infos[i].name);
         return(false);
      }
      mCursors[infos[i].index] = cursor;
   }

   mCurrentCursor = mCursors[DefaultCursor];
   return(true);
}
//---------------------------------------------------------------------------------------------------------
bool GuiCommanderHud::grabIcons()
{
   struct {
      U32 index;
      const char * name;
   } infos[] = {
      {noIcon,            ""         },
      {TankIcon,            "TankIcon"         },
      {JeepIcon,            "JeepIcon"         },
      {GunshipIcon,         "GunshipIcon"         },
      {TransportIcon,       "TransportIcon"         },
      {PersonIcon,          "PersonIcon"         },
      {MediIcon,            "MediIcon"         },
      {AmmoIcon,            "AmmoIcon"         },
      {FlagIcon,            "FlagIcon"         },
      {RadarIcon,           "RadarIcon"         },
      {SpawnIcon,           "SpawnIcon"         },
      {WaypointIcon,        "WaypointIcon"         },
      {TargetIcon,          "TargetIcon"         },
      {ParachuteIcon,       "ParachuteIcon"         },
   };

   // Note that this loop starts at one to skip the noIcon
   for(U32 i = 1; i < (sizeof(infos) / sizeof(infos[0])); i++)
   {
      SimObject * obj = Sim::findObject(infos[i].name);
      if(!obj)
      {
         Con::errorf(ConsoleLogEntry::Script, "GuiCommanderHud::grabIcons: failed to find Map Icon '%s'.", infos[i].name);
         return(false);
      }

      GuiIcon *icon = dynamic_cast<GuiIcon*>(obj);
      if(!icon)
      {
         Con::errorf(ConsoleLogEntry::Script, "GuiCommanderHud::grabIcons: object is not a Map Icon '%s'.", infos[i].name);
         return(false);
      }
      mIcons[infos[i].index] = icon;
	  icon->setBitmap();
   }

   return(true);
}
//---------------------------------------------------------------------------------------------------------
bool GuiCommanderHud::onWake()
{
	if (! Parent::onWake())
		return false;
	setActive(true);

	startSpawnCam = false;
	startSpawn = false;

	return true;
}


//-------------------------------------
void GuiCommanderHud::onSleep()
{
	Parent::onSleep();
}


bool GuiCommanderHud::calcProject(Point3F &wp, Point3F &sp)
{
	// calculate ground width from camera height and fov
	F32 angle = mCurZoom/2;
    F32 groundWidth = mSin(angle) * cameraHi * 2;
	// now get the ground to screen ratio
	F32 ratio = mBounds.extent.x/groundWidth;
	// now calculate screen pos
	sp = wp * ratio;
	return true;
}

//---------------------------------------------------------------------------------------------------------
// implement a shapebase console function to mark objects instances as clickable or not?
//---------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------