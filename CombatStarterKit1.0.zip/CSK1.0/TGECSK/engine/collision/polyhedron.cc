//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#include "platform/platform.h"
#include "dgl/dgl.h"
#include "console/console.h"
#include "collision/polyhedron.h"
#include "math/mMath.h"
#include "math/mathUtils.h"



void Polyhedron::buildPointyBox(const MatrixF& transform,const Box3F& box, const Point3F &point)
{
   // Box and point is assumed to be axis aligned in the source space.
   // Transform into geometry space
	MatrixF mat(1);
   Point3F xvec,yvec,zvec,min, pointPos;
   mat.getColumn(0,&xvec);
   xvec *= box.len_x();
   mat.getColumn(1,&yvec);
   yvec *= box.len_y();
   mat.getColumn(2,&zvec);
   zvec *= box.len_z();
   min = box.min;
   pointPos = point;
   //transform.mulP(box.min,&min);
   //transform.mulP(point,&pointPos);

   // You will have to draw these on a piece of paper to figure this out

   // Initial vertices
   pointList.setSize(9);
   pointList[0] = min;
   pointList[1] = min + yvec;
   pointList[2] = min + xvec + yvec;
   pointList[3] = min + xvec;
   pointList[4] = pointList[0] + zvec;
   pointList[5] = pointList[1] + zvec;
   pointList[6] = pointList[2] + zvec;
   pointList[7] = pointList[3] + zvec;
   pointList[8] = pointPos;

   F32 a90 = 1.570796327, zero = 0;
   // calculate LR angles for pointy faces
   F32 lenA = mFabs(pointPos.y - pointList[2].y);
   F32 lenB = mFabs(pointList[2].x - pointPos.x);
   F32 lenC = mFabs(pointList[1].x - pointPos.x);
   F32 angleL = atan(lenA/lenC);
   F32 angleR = (a90 + a90) - atan(lenA/lenB); // 180 - angle
   angleR -= a90;
   angleL += a90;
   // now make these Torque angles, 0 degrees is 0,1,0 and increases clockwise
   angleR -= a90; angleL -= a90;
   angleR *= -1; angleL *= -1;
   Point3F vecR, vecL;
   MathUtils::getVectorFromAngles( vecR, angleR, zero );
   MathUtils::getVectorFromAngles( vecL, angleL, zero );

   
   // calculate TB angles for pointy faces
   lenA = mFabs(pointPos.y - pointList[2].y);
   lenB = mFabs(pointList[2].z - pointPos.z);
   lenC = mFabs(pointList[6].z - pointPos.z);
   F32 angleT = atan(lenA/lenC) - a90;
   F32 angleB =  atan(lenA/lenB) - a90; 
   angleT -= a90;
   angleB -= a90;
   // now make these Torque angles, 0 degrees is 0,1,0 and increases clockwise
   //angleT += a90; angleB += a90;
   /**/ angleB *= -1; angleT *= 1;
   Point3F vecT, vecB;
   MathUtils::getVectorFromAngles( vecT, zero, angleT );
   MathUtils::getVectorFromAngles( vecB, zero, angleB );

   // transform loop
   for (S32 i=0; i< pointList.size();i++)
	   transform.mulP(pointList[i]);

   transform.mulV(vecL);
   transform.mulV(vecR);
   transform.mulV(vecT);
   transform.mulV(vecB);
   transform.mulV(xvec);
   transform.mulV(yvec);
   transform.mulV(zvec);

   // Initial faces
   planeList.setSize(9);
   planeList[0].set(pointList[0],xvec);
   planeList[0].invert();
   planeList[1].set(pointList[1],vecL); // 3 sides faces
   planeList[2].set(pointList[2],vecR); // 3 sides faces
   planeList[3].set(pointList[2],xvec);
   planeList[4].set(pointList[0],yvec);
   planeList[4].invert();
   planeList[5].set(pointList[0],zvec);
   planeList[5].invert();
   planeList[6].set(pointList[4],zvec);   
   planeList[7].set(pointPos,vecT); // 3 sides faces
   planeList[8].set(pointPos,vecB); // 3 sides faces
   planeList[7].invert();
   planeList[8].invert();
   

   // The edges are constructed so that the vertices
   // are oriented clockwise for face[0]
   edgeList.setSize(16);
   Edge* edge = edgeList.begin();
   
      edge->vertex[0] = 0; // get it from pointlist
      edge->vertex[1] = 1;
      edge->face[0] = 0;   // get it from planelist
      edge->face[1] = 5;
      edge++; // 1
      edge->vertex[0] = 1; // get it from pointlist
      edge->vertex[1] = 2;
      edge->face[0] = 8;   // get it from planelist
      edge->face[1] = 5;
      edge++; // 2
      edge->vertex[0] = 2; // get it from pointlist
      edge->vertex[1] = 3;
      edge->face[0] = 3;   // get it from planelist
      edge->face[1] = 5;
      edge++; // 3
      edge->vertex[0] = 3; // get it from pointlist
      edge->vertex[1] = 0;
      edge->face[0] = 4;   // get it from planelist
      edge->face[1] = 5;
      edge++; // 4
      edge->vertex[0] = 4; // get it from pointlist
      edge->vertex[1] = 5;
      edge->face[0] = 0;   // get it from planelist
      edge->face[1] = 6;
      edge++; // 5
      edge->vertex[0] = 5; // get it from pointlist
      edge->vertex[1] = 6;
      edge->face[0] = 7;   // get it from planelist
      edge->face[1] = 6;
      edge++; // 6
      edge->vertex[0] = 6; // get it from pointlist
      edge->vertex[1] = 7;
      edge->face[0] = 3;   // get it from planelist
      edge->face[1] = 6;
      edge++; // 7
      edge->vertex[0] = 7; // get it from pointlist
      edge->vertex[1] = 4;
      edge->face[0] = 4;   // get it from planelist
      edge->face[1] = 6;
      edge++; // 8
      edge->vertex[0] = 0; // get it from pointlist
      edge->vertex[1] = 4;
      edge->face[0] = 0;   // get it from planelist
      edge->face[1] = 4;
      edge++; // 9
      edge->vertex[0] = 5; // get it from pointlist
      edge->vertex[1] = 1;
      edge->face[0] = 0;   // get it from planelist
      edge->face[1] = 1;
      edge++; // 10
      edge->vertex[0] = 6; // get it from pointlist
      edge->vertex[1] = 2;
      edge->face[0] = 2;   // get it from planelist
      edge->face[1] = 3;
      edge++; // 11
      edge->vertex[0] = 7; // get it from pointlist
      edge->vertex[1] = 3;
      edge->face[0] = 3;   // get it from planelist
      edge->face[1] = 4;
      edge++; // 12
      edge->vertex[0] = 1; // get it from pointlist
      edge->vertex[1] = 8;
      edge->face[0] = 1;   // get it from planelist
      edge->face[1] = 8;
      edge++; // 13
      edge->vertex[0] = 5; // get it from pointlist
      edge->vertex[1] = 8;
      edge->face[0] = 1;   // get it from planelist
      edge->face[1] = 7;
      edge++; // 14
      edge->vertex[0] = 6; // get it from pointlist
      edge->vertex[1] = 8;
      edge->face[0] = 7;   // get it from planelist
      edge->face[1] = 2;
      edge++; // 15
      edge->vertex[0] = 2; // get it from pointlist
      edge->vertex[1] = 8;
      edge->face[0] = 8;   // get it from planelist
      edge->face[1] = 2;

}


//----------------------------------------------------------------------------

void Polyhedron::buildBox(const MatrixF& transform,const Box3F& box)
{
   // Box is assumed to be axis aligned in the source space.
   // Transform into geometry space
   Point3F xvec,yvec,zvec,min;
   transform.getColumn(0,&xvec);
   xvec *= box.len_x();
   transform.getColumn(1,&yvec);
   yvec *= box.len_y();
   transform.getColumn(2,&zvec);
   zvec *= box.len_z();
   transform.mulP(box.min,&min);

   // Initial vertices
   pointList.setSize(8);
   pointList[0] = min;
   pointList[1] = min + yvec;
   pointList[2] = min + xvec + yvec;
   pointList[3] = min + xvec;
   pointList[4] = pointList[0] + zvec;
   pointList[5] = pointList[1] + zvec;
   pointList[6] = pointList[2] + zvec;
   pointList[7] = pointList[3] + zvec;

   // Initial faces
   planeList.setSize(6);
   planeList[0].set(pointList[0],xvec);
   planeList[0].invert();
   planeList[1].set(pointList[2],yvec);
   planeList[2].set(pointList[2],xvec);
   planeList[3].set(pointList[0],yvec);
   planeList[3].invert();
   planeList[4].set(pointList[0],zvec);
   planeList[4].invert();
   planeList[5].set(pointList[4],zvec);

   // The edges are constructed so that the vertices
   // are oriented clockwise for face[0]
   edgeList.setSize(12);
   Edge* edge = edgeList.begin();
   S32 nextEdge = 0;
   for (int i = 0; i < 4; i++) {
      S32 n = ( i + 1 ) & 0x3;
      S32 p = ( i + 3 ) & 0x3;
      edge->vertex[0] = i;
      edge->vertex[1] = n;
      edge->face[0] = i;
      edge->face[1] = 4;
      edge++;
      edge->vertex[0] = 4 + i;
      edge->vertex[1] = 4 + n;
      edge->face[0] = 5;
      edge->face[1] = i;
      edge++;
      edge->vertex[0] = i;
      edge->vertex[1] = 4 + i;
      edge->face[0] = p;
      edge->face[1] = i;
      edge++;
   }
}


//----------------------------------------------------------------------------

void Polyhedron::render()
{
   glVertexPointer(3,GL_FLOAT,sizeof(Point3F),pointList.address());
   glEnableClientState(GL_VERTEX_ARRAY);
   glColor3f(1, 0, 1);

   for (S32 e = 0; e < edgeList.size(); e++)
      glDrawElements(GL_LINES,2,GL_UNSIGNED_INT,&edgeList[e].vertex);

   for (U32 i = 0; i < planeList.size(); i++) {
      Point3F origin(0, 0, 0);
      U32 num = 0;
      for (U32 j = 0; j < edgeList.size(); j++) {
         if (edgeList[j].face[0] == i || edgeList[j].face[1] == i) {
            origin += pointList[edgeList[j].vertex[0]];
            origin += pointList[edgeList[j].vertex[1]];
            num += 2;
         }
      }
      origin /= F32(num);

      glColor3f(1, 1, 1);
      glBegin(GL_LINES);
         glVertex3fv(origin);
         glVertex3f(origin.x + planeList[i].x * 0.2,
                    origin.y + planeList[i].y * 0.2,
                    origin.z + planeList[i].z * 0.2);
      glEnd();
   }

   glDisableClientState(GL_VERTEX_ARRAY);
}

void Polyhedron::render(const VectorF& vec,F32 time)
{
   bool faceVisible[50];
   for (int f = 0; f < planeList.size(); f++)
      faceVisible[f] = mDot(planeList[f],vec) > 0;

   VectorF tvec = vec;
   tvec *= time;
   for (int e = 0; e < edgeList.size(); e++) {
      Polyhedron::Edge const& edge = edgeList[e];
      if (faceVisible[edge.face[0]] || faceVisible[edge.face[1]]) {
         Point3F pp;

         glBegin(GL_LINE_LOOP);
         glColor3f(0.5,0.5,0.5);
         const Point3F& p1 = pointList[edge.vertex[0]];
         const Point3F& p2 = pointList[edge.vertex[1]];
         glVertex3fv(p1);
         glVertex3fv(p2);
         pp = p2 + vec;
         glVertex3fv(pp);
         pp = p1 + vec;
         glVertex3fv(pp);
         glEnd();

         if (time <= 1.0) {
            glBegin(GL_LINES);
            glColor3f(0.5,0.5,0);
            pp = pointList[edge.vertex[0]];
            pp += tvec;
            glVertex3fv(pp);
            pp = pointList[edge.vertex[1]];
            pp += tvec;
            glVertex3fv(pp);
            glEnd();
         }
      }
   }
}
