//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (c) 2002 BraveTree Productions
// Copyright (c) 2001 GarageGames.Com
// Portions Copyright (c) 2001 by Sierra Online, Inc.
//-----------------------------------------------------------------------------

//~server/scripts/car.cs
//-----------------------------------------------------------------------------

// Information extacted from the shape.
//
// Wheel Sequences
//    spring#        Wheel spring motion: time 0 = wheel fully extended,
//                   the hub must be displaced, but not directly animated
//                   as it will be rotated in code.
// Other Sequences
//    steering       Wheel steering: time 0 = full right, 0.5 = center
//    brakeLight     Brake light, time 0 = off, 1 = braking
//
// Wheel Nodes
//    hub#           Wheel hub, the hub must be in it's upper position
//                   from which the springs are mounted.
//
// The steering and animation sequences are optional.
// The center of the shape acts as the center of mass for the car.

//-----------------------------------------------------------------------------


//----------------------------------------------------------------------------

datablock StickyVehicleTire(s13Tire)
{
   // Tires act as springs and generate lateral and longitudinal
   // forces to move the vehicle. These distortion/spring forces
   // are what convert wheel angular velocity into forces that
   // act on the rigid body.
   shapeFile = "~/data/shapes/car/wheel.dts";
   staticFriction = 4;
   kineticFriction = 1.25;


   // Spring that generates lateral tire forces
   lateralForce = 6000;
   lateralDamping = 400;
   lateralRelaxation = 1;

   // Spring that generates longitudinal tire forces
   longitudinalForce = 6000;
   longitudinalDamping = 400;
   longitudinalRelaxation = 1;
};

datablock StickyVehicleSpring(s13Spring)
{
   // Wheel suspension properties
   length = 0.63;             // Suspension travel
   force = 3000;              // Spring force
   damping = 600;             // Spring damping
   antiSwayForce = 3;         // Lateral anti-sway force
};

//----------------------------------------------------------------------------
// Splash
//----------------------------------------------------------------------------



datablock StickyVehicleData(s13)
{
   category = "Vehicles";
   shapeFile = "~/data/shapes/s13/s13.dts";
   tireDB = "s13Tire";
   springDB = "s13Spring";

   emap = true;

   mountPose[0] = sitting;

   maxDamage = 1.5;
   destroyedLevel = 1.0;

   maxSteeringAngle = 0.785;  // Maximum steering angle, should match animation
   integration = 4;           // Force integration time: TickSec/Rate
   tireEmitter = TireEmitter; // All the tires use the same dust emitter

   // 3rd person camera settings
   cameraRoll = false;         // Roll the camera with the vehicle
   cameraMaxDist = 10;         // Far distance from vehicle
   cameraOffset = 1.5;        // Vertical offset from camera mount point
   cameraLag = 0.1;           // Velocity lag of camera
   cameraDecay = 0.75;        // Decay per sec. rate of velocity lag

   // Rigid Body
     mass = 260;
   
   massCenter = "0 -0.5 0";    // Center of mass for rigid body
   massBox = "0 0 0";         // Size of box used for moment of inertia,
                              // if zero it defaults to object bounding box
 
   drag = 0.6;
   bodyFriction = 0.6;
   bodyRestitution = 0.4;
   minImpactSpeed = 5;        // Impacts over this invoke the script callback
   softImpactSpeed = 5;       // Play SoftImpact Sound
   hardImpactSpeed = 15;      // Play HardImpact Sound
   collisionTol = 0.1;        // Collision distance tolerance
   contactTol = 0.1;          // Contact velocity tolerance

   // Engine
   engineTorque = 4500;       // Engine power
   engineBrake = 600;         // Braking when throttle is 0
   brakeTorque = 2000;        // When brakes are applied
   maxWheelSpeed = 36;        // Engine scale by current speed / max speed

   // Energy
   maxEnergy = 100;
   jetForce = 3000;
   minJetEnergy = 30;
   jetEnergyDrain = 2;

   // Splash
   splashFreqMod = 300.0;
   splashVelEpsilon = 0.60;
   splashEmitter[1] = CarSplashMistEmitter;
   mediumSplashSoundVelocity = 10.0;   
   hardSplashSoundVelocity = 20.0;   
   exitSplashSoundVelocity = 5.0;

   // Sounds
//   jetSound = ScoutThrustSound;
//   engineSound = ScoutEngineSound;
//   squealSound = ScoutSquealSound;
//   softImpactSound = SoftImpactSound;
//   hardImpactSound = HardImpactSound;
//   wheelImpactSound = WheelImpactSound;

//   explosion = VehicleExplosion;
};

//-----------------------------------------------------------------------------

function StickyVehicleData::create(%block)
{
   %obj = new StickyVehicle() {
      dataBlock = %block;
   };

   return(%obj);
}

//-----------------------------------------------------------------------------

// This is used for brakelights
datablock StaticShapeData(Taillight)
{
   category = "StaticShapes";
   shapeFile = "~/data/shapes/car/flash.dts";
};

//-----------------------------------------------------------------------------

function StickyVehicleData::onAdd(%this,%obj)
{
   // Setup the car with some defaults tires & springs
   for (%i = %obj.getWheelCount() - 1; %i >= 0; %i--) {
      %obj.setWheelTire(%i,%this.tireDB);
      %obj.setWheelSpring(%i,%this.springDB);
   }

   %obj.mountable = true;


}

function StickyVehicleData::onCollision(%this,%obj,%col,%vec,%speed)
{

   // Collision with other objects, including items
if ((%col.getClassName() $= "WheeledVehicle") || (%col.ClassName() $= "Projectile"))
VehicleData::damage(%this,%obj,0,%speed,5,%damageType);

//echo ("collision: this",%this);
//echo ("collision: obj",%obj);
//echo ("collision: col",%col);
//echo ("collision: vec", %vec);
//echo ("collision: speed",%speed);
return;
}



// Bind a key command for dropping the car
moveMap.bindCmd(keyboard, "ctrl g", "commandToServer(\'AddCar\');", "");

//-----------------------------------------------------------------------------




// Overrides the mouse yaw function
moveMap.bind( mouse, xaxis, caryaw );