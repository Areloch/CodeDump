//------------------------------------------------------
// Copyright Roaming Gamer, LLC.
//------------------------------------------------------

function readFile( %filename )
{
	%file = new FileObject();
	if(%file.openForRead(%filename))
	{
		while(!%file.isEOF())
		{
			%input = %file.readLine();
			%fileContents = ("" $= %fileContents) ? %input : %fileContents NL %input;
		}
	} else {
		%file.delete();
		return false;
	}
	%file.close();
	%file.delete();
	return %fileContents;
}

function writeFile( %filename , %data ) 
{
	%file = new FileObject();
	if(! %file.openforWrite( %filename ) )
	{
		%file.delete();
		return false;
	}
	%file.writeLine( %data );
	%file.close();
	%file.delete();
	return true;
}

function appendToFile( %filename , %data ) 
{
	%file = new FileObject();
	if(! %file.openforAppend( %filename ) )
	{
		%file.delete();
		return false;
	}
	%file.writeLine( %data );
	%file.close();
	%file.delete();
	return true;
}


function getFileList( %pattern ) {
   %filename = findFirstFile( %pattern );
   
   %fileList =  %filename;

   while("" !$= %filename ) 
   {
      %filename = findNextFile(%pattern );
    
      %fileList = %fileList SPC %filename;
   }
   return %fileList;
}


function findStringInFile( %filename , %string )
{
	%file = new FileObject();
	if(%file.openForRead(%filename))
	{
		while(!%file.isEOF())
		{
			%input = %file.readLine();
			//echo(%input);
			%position = strstr( %input, %string );
			if( -1 != %position )
			{
   	   	%file.close();
	         %file.delete();
	         return true;
			}
		}
	} else {
		%file.delete();
		return false;
	}
	%file.close();
	%file.delete();
	return false;
}

function extractFileSegment( %filename, %startKey, %endKey  )
{
   %startgrab = (%startKey $= "") ? true : false;
   %endgrab   = false;
   
	%file = new FileObject();
	if(%file.openForRead(%filename))
	{
		while(!%file.isEOF())
		{
			%input = %file.readLine();

         if( (%endKey !$= "") && strContains( %input, %endKey ) ) 
            %endgrab = true;

			if(%startGrab && !%endgrab)
			   %fileContents = ("" $= %fileContents) ? %input : %fileContents NL %input;
			   
         if( (!%startgrab) && strContains( %input, %startKey ) ) 
            %startgrab = true;

		}
	} else {
		%file.delete();
		return "";
	}
	%file.close();
	%file.delete();
	return %fileContents;
}


function extractFileLinesContaining( %filename, %searchKey  )
{
	%file = new FileObject();
	if(%file.openForRead(%filename))
	{
		while(!%file.isEOF())
		{
			%input = %file.readLine();

         if( strContains( %input, %searchKey ) ) 
         {
            %fileContents = %fileContents NL %input;
         }
		}
	} else {
		%file.delete();
		return "";
	}
	%file.close();
	%file.delete();
	return %fileContents;
}


// EFM - add forEachFile() and forEachFileStmt() functions???


////
//   Following routines are designed to operate on a previously opened file, line by line
//   These are similar to the above routines, but used for extracting (inserting) large amounts of data.
//   i.e. This overcomes Torque's ~4K string length limit (Torque crashes when you pass large strings).
////

// Open a file for reading and return the handle to that file (or 0 for failure)
function openFileForRead( %fileName )
{
	%fileObject = new FileObject();
	if(%fileObject.openForRead(%filename))
	{
	   return %fileObject;
	}

	%fileObject.delete();
	return 0;
}

function closeFileHandle( %handle ) 
{	
   %handle.close();
	%handle.delete();
}

function getNextFileLineInSegment( %handle, %startKey, %endKey  )
{
   if(!isObject(%handle)) return "";
   
   if( !%handle.grabbingSegment )
   {
      %handle.startgrab       = (%startKey $= "") ? true : false;
      %handle.endgrab         = false;
      %handle.grabbingSegment = true;
   }   
	
   while(!%handle.isEOF())
	{
		%input = %handle.readLine();

      if( (%endKey !$= "") && strContains( %input, %endKey ) )
      { 
         %handle.endgrab = true;
         %handle.grabbingSegment = false;
         return "";
      }

	   if(%handle.startgrab && !%handle.endgrab)
	   {
	      return %input;
	   }
   
      if( (!%handle.startgrab) && strContains( %input, %startKey ) ) 
          %handle.startgrab = true;
   }

	return "";
}


function getNextFileLineContaining( %handle, %searchKey  )
{
   if(!isObject(%handle)) return "";   
   
   while(!%handle.isEOF())
	{
		%input = %handle.readLine();

      if( strContains( %input, %searchKey ) ) 
      {
         return %input;
      }
   }
	
	return "";
}
