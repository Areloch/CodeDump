//------------------------------------------------------
// Copyright Roaming Gamer, LLC.
//------------------------------------------------------

////
//// Create a scriptObject named 'arrayObject' and use these methods 
//// to maintain a easily sortable array
////

function createArrayObject( %name )
{
   %obj = new ScriptObject( %name )
   {
      superClass = "arrayObject";
   };
   
   return %obj;
}

function arrayObject::onAdd( %this )
{
	%this.curIndex=0;
}

function arrayObject::addEntry( %this , %entry )
{
	%this.entry[%this.curIndex] = %entry;
	%this.curIndex++;
	return %entry;
}
function arrayObject::getCount( %this )
{
	return %this.curIndex;
}
function arrayObject::sort( %this  , %Decreasing )
{
	if(!%this.curIndex) return;

	new GuiTextListCtrl(sortProxy);

	for(%count=0; %count < %this.curIndex; %count++)
	{
		sortProxy.addRow( %count , %this.entry[%count] );
	}

	%sortOrder = !(%Decreasing);

	sortProxy.sort( 0 , %sortOrder );

	for(%count=0; %count < %this.curIndex; %count++)
	{
		%this.entry[%count] = sortProxy.getRowText(%count);
	}

	sortProxy.delete();

}
function arrayObject::getEntry( %this ,  %index )
{
	if( %index >= %this.curIndex) return "";
	return %this.entry[%index];
}

