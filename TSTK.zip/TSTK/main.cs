//------------------------------------------------------
// Copyright Roaming Gamer, LLC.
//------------------------------------------------------
if($TSTK::Initialized) return;

////
//   Enable Settings for loading the various script tool kits
//   and initializing the RG Event Router
////
$TSTK::LoadCommon = true;
$TSTK::LoadTGB = true;
$TSTK::LoadTGE = true;
$TSTK::InitEventRouter = true;

// TGB Specific Flags/Enables
$TSTK::Enable_ConfigDatablock_BehaviorFix = true;

$TSTK::Description    = "Torque Script Toolkit";
$TSTK::Version        = 103;
$TSTK::LastUpdate     = "23 APR 2009";

package TSTK_Package {
   function rgVersions()
   {
      Parent::rgVersions();
      echo( $TSTK::Description @ ":" SPC $TSTK::Version SPC "Last updated:" SPC $TSTK::LastUpdate );      
   }

   function onStart()
   {
     Parent::onStart();
      exec("./TSTK/main.cs");
      initTSTK();          
   }   
   
   function initTSTK()
   {  

      ////
      //  Load TSTK Preferences
      ////
      exec("./prefs.cs");

      if( $TSTK::LoadCommon )
      {
         exec("./common/ArrayObject.cs");
         exec("./common/Fields.cs");
         exec("./common/File.cs");
         exec("./common/GUI.cs");
         exec("./common/Math.cs");
         exec("./common/Objects.cs");
         exec("./common/Records.cs");
         exec("./common/SimSet.cs");
         exec("./common/Strings.cs");
         exec("./common/Words.cs");
      
         exec("./common/EventRouter/EventRouter.cs");
         exec("./common/EventRouter/EventBind.cs");
      }
      
      if( $TSTK::LoadTGB )
      {
         exec("./TGB/accessMethodGenerators.cs");
         exec("./TGB/behaviors.cs");
         exec("./TGB/EventManager.cs");
         exec("./TGB/ImageMaps.cs");
         exec("./TGB/levelLoading.cs" ); 
         exec("./TGB/t2dSceneObject.cs");
         exec("./TGB/WorldLimit.cs");
 
         exec("./TGB/editors/fieldTypes.ed.cs" ); 
         exec("./TGB/editors/levelEditor.ed.cs" );
      }
   
      if( $TSTK::LoadTGE )
      {
         exec("./TGE/GameBase.cs");
         exec("./TGE/Networking.cs");
         exec("./TGE/SceneObject.cs");   
      }
      
      if( $TSTK::InitEventRouter )
      {      
         initializeEventRouterSystem();
      }
      
      $TSTK::Initialized = true;
   }   
};

activatePackage( TSTK_Package );
