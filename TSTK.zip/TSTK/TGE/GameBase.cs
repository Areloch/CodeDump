//------------------------------------------------------
// Copyright Roaming Gamer, LLC.
//------------------------------------------------------

function isGameBase( %obj ) 
{
	return ( %obj.getType() == $TypeMasks::GameBaseObjectType );
}
