//------------------------------------------------------
// Copyright Roaming Gamer, LLC.
//------------------------------------------------------

//
// BehaviorInstance::broadcastMethod() -
//
// Calls named method on all other behaviors in current owner that 
// implement this method.
//
// This is designed to allow behaviors to blindly access
// callbacks in other behaviors (with the same owner) and can be thought
// of as a rudimentary message system.  It allows for the design
// of complex behavior interaction without knowing the name of those behaviors
// in advance.
//
// This feature is used by many of the RG damage & energy behaviors.
//

// EFM =>
// This should work, but doesn't (bug?) =>
// function BehaviorInstance::broadcastMethod(%this, %methodName, 
//

function SimObject::broadcastMethod(%this, %methodName, 
                                           %arg0, %arg1, %arg2, %arg3, %arg4,
                                           %arg5, %arg6, %arg7, %arg8, %arg9)
{
   // EFM =>
   // Temporary protection from mis-calls since we're forced to use the
   // SimObject namespace to scope the method.
   if(%this.getClassName() !$= "BehaviorInstance") return;
   
   %behaviorCount = %this.owner.getBehaviorCount();

   // Try to execute the named method on all behaviors in this owner
   // except for the sender
   for( %count = 0; %count < %behaviorCount; %count++)
   {
      %behavior = %this.owner.getBehaviorByIndex( %count );

      // Only try to execute the method on other behaviors
      if(%behavior == %this ) 
      {
         //echo("Skipping this behavior: ", %behavior );
         continue;
      }
      
      if(%behavior.isMethod( %methodName ))
      {
         //echo("Found method on behavior: ", %behavior);
         %behavior.call( %methodName, %arg0, %arg1, %arg2, %arg3, %arg4,
                         %arg5, %arg6, %arg7, %arg8, %arg9);
      }
   }
}

//EFM - fix for TGB 1.7.4, where setting DB doesn't remove or add behavior 
//instances in TGB builder
package TGB174_SetConfigDatablock_BehaviorFix
{
   function t2dSceneObject::setConfigDatablock( %this, %newDB )
   {
      // 1. Let the Parent:: version do its work.
      Parent::setConfigDatablock( %this, %newDB );
      
      // 2. Remove old behaviors from this object
      %behaviorCount = %this.getBehaviorCount();

      for( %count = 0; %count < %behaviorCount; %count++)
      {
         %behavior = %this.getBehaviorByIndex( %count );
         error("Removing behavior instance: ", %behavior );
         %this.removeBehavior(%behavior, true);
      }

      // 3. Remove old behaviors from this object again (bug: one is left over)
      %behaviorCount = %this.getBehaviorCount();

      for( %count = 0; %count < %behaviorCount; %count++)
      {
         %behavior = %this.getBehaviorByIndex( %count );
         error("Removing behavior instance: ", %behavior );
         %this.removeBehavior(%behavior, true);
      }
      
      // 4. Discover each behavior that was added to this OBJ, set it aside,
      // and clear the 'tracking' field'
      %count = 0;
      while( %this._behavior[%count] !$= "" )
      {
         error("Setting aside behavior string: ", %this._behavior[%count] );
         %tmpBehavior[%count] = %this._behavior[%count];
         %this._behavior[%count] = "";
         %count++;
      }
      %totalStrings = %count;
      
      // 5. Build new instances of each DB that was in the DB
      for(%count = 0; %count < %totalStrings; %count++)
      {
         %behavior = getField(%tmpBehavior[%count], 0);
         %instance = %behavior.createInstance();
         %this.addBehavior(%instance);
      }
      
      // Force Quick Edit GUI to update 
      schedule( 0, 0, updateQuickEdit );
   }   
};

if($TSTK::Enable_ConfigDatablock_BehaviorFix)
{
   activatePackage( TGB174_SetConfigDatablock_BehaviorFix );
}
   


