//------------------------------------------------------
// Copyright Roaming Gamer, LLC.
//------------------------------------------------------

function createImageMapDB( %name , %path , %imageMode , %smoothing , %cellWidth, %cellHeight )
{
   %cellWidth = (%cellWidth $= "") ? 0 : %cellWidth;
   %cellHeight = (%cellHeight $= "") ? %cellWidth : %cellHeight;

	%imageMap = new t2dImageMapDatablock(%name) {
		canSaveDynamicFields = "1";
		imageName = expandFileName(%path);
		imageMode = ("" $= %imageMode) ? "FULL" : %imageMode;
		frameCount = "-1";
		filterMode = ("" $= %smoothing) ? "SMOOTH" : %smoothing ;
		filterPad = "1";
		preferPerf = "0";
		cellRowOrder = "1";
		cellOffsetX = "0";
		cellOffsetY = "0";
		cellStrideX = "0";
		cellStrideY = "0";
		cellCountX = "-1";
		cellCountY = "-1";
		cellWidth = %cellWidth ;
		cellHeight = %cellHeight ;
		preload = "1";
		allowUnload = "0";
	};
	return %imageMap;
}

