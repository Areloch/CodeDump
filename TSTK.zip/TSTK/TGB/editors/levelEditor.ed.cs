//------------------------------------------------------
// Copyright Roaming Gamer, LLC.
//------------------------------------------------------

package RG_CaptureObjectSelection {


function LevelBuilderSceneEdit::onAcquireObject(%this, %object)
{   
   $TSTK::CurrentlySelectedObject = %object;
   Parent::onAcquireObject(%this, %object);
}

function LevelBuilderSceneEdit::onRelinquishObject(%this, %object)
{   
   $TSTK::CurrentlySelectedObject  = "";
   Parent::onRelinquishObject(%this, %object);
}

function getTGBLevelEditorCurrentSelection()
{
   return $TSTK::CurrentlySelectedObject;
}

};

activatePackage(RG_CaptureObjectSelection);