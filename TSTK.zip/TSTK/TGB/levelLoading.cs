//------------------------------------------------------
// Copyright Roaming Gamer, LLC.
//------------------------------------------------------

package RG_LevelLoading
{
   function sceneWindow2D::loadLevel( %this, %level )
   {
      $TSTK::CurrentLevel = %level;
      $TSTK::CurrentLevelPath = filePath( %level );
      
      %tmp   = strreplace( %level, "/", " " );
      %tmp   = strreplace( %tmp, "\\", " " );
      %tmp   = strreplace( %tmp, ".t2d", "" );
      %words = getWordCount( %tmp );
      %tmp   = getWord( %tmp, %words-1 );

      $TSTK::CurrentLevelPrefix = removeNumeric( %tmp );
      $TSTK::CurrentLevelNumber = removeAlpha( %tmp );
      
      error(" $TSTK::CurrentLevel       == ", $TSTK::CurrentLevel);
      error(" $TSTK::CurrentLevelPath   == ", $TSTK::CurrentLevelPath);
      error(" $TSTK::CurrentLevelPrefix == ", $TSTK::CurrentLevelPrefix);
      error(" $TSTK::CurrentLevelNumber == ", $TSTK::CurrentLevelNumber);

      Parent::loadLevel( %this, %level );
   }
};
activatePackage(RG_LevelLoading);
