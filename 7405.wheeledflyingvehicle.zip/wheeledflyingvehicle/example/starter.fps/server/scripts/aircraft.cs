//////////////////////////////////////////////////////////////////////////////
// Audio Profiles
datablock AudioProfile(AircraftThrustSound)
{
  fileName = "~/data/shapes/vehicles/dev_aircraft/sound/aircraft_thrust.wav";
  description = AudioDefaultLooping3d;
  preload = true;
};
datablock AudioProfile(AircraftEngineSound)
{
  fileName = "~/data/shapes/vehicles/dev_aircraft/sound/aircraft_engine.wav";
  description = AudioDefaultLooping3d;
  preload = true;
};
datablock AudioProfile(AircraftDiveSound)
{
  fileName = "~/data/shapes/vehicles/dev_aircraft/sound/aircraft_dive.wav";
  description = AudioDefaultLooping3d;
  preload = true;
};
datablock AudioProfile(AircraftManeuverSound)
{
  fileName = "~/data/shapes/vehicles/dev_aircraft/sound/aircraft_maneuver.wav";
  description = AudioDefaultLooping3d;
  preload = true;
};

//////////////////////////////////////////////////////////////////////////////
// Particle Emitters

// contrail
datablock ParticleData(AircraftTrailParticle)
{
  dragCoefficient      = 1.5;
  gravityCoefficient   = 0;
  inheritedVelFactor   = 0.2;
  constantAcceleration = 0.0;
  lifetimeMS           = 3000;
  lifetimeVarianceMS   = 0;
  textureName          = "~/data/shapes/vehicles/dev_aircraft/particles/trailParticle";
  colors[0]     = "0.6 0.6 0.6 0.5";
  colors[1]     = "0.2 0.2 0.2 0";
  sizes[0]      = 0.6;
  sizes[1]      = 5;
};

datablock ParticleEmitterData(AircraftTrailEmitter)
{
  ejectionPeriodMS = 50;
  periodVarianceMS = 0;
  ejectionVelocity = 1;
  velocityVariance = 1.0;
  ejectionOffset   = 0.0;
  thetaMin         = 0;
  thetaMax         = 180;
  phiReferenceVel  = 0;
  phiVariance      = 360;
  overrideAdvances = false;
  particles = "AircraftTrailParticle";
};

// forward
datablock ParticleData(AircraftForwardParticle)
{
  dragCoefficient      = 1.5;
  gravityCoefficient   = 0;
  inheritedVelFactor   = 0.2;
  constantAcceleration = 0.0;
  lifetimeMS           = 3000;
  lifetimeVarianceMS   = 0;
  textureName          = "~/data/shapes/vehicles/dev_aircraft/particles/forwardParticle";
  colors[0]     = "0.6 0.6 0.6 0.5";
  colors[1]     = "0.2 0.2 0.2 0";
  sizes[0]      = 0.6;
  sizes[1]      = 5;
};

datablock ParticleEmitterData(AircraftForwardEmitter)
{
  ejectionPeriodMS = 50;
  periodVarianceMS = 0;
  ejectionVelocity = 1;
  velocityVariance = 1.0;
  ejectionOffset   = 0.0;
  thetaMin         = 0;
  thetaMax         = 180;
  phiReferenceVel  = 0;
  phiVariance      = 360;
  overrideAdvances = false;
  particles = "AircraftForwardParticle";
};

// backward
datablock ParticleData(AircraftBackwardParticle)
{
  dragCoefficient      = 1.5;
  gravityCoefficient   = 0;
  inheritedVelFactor   = 0.2;
  constantAcceleration = 0.0;
  lifetimeMS           = 3000;
  lifetimeVarianceMS   = 0;
  textureName          = "~/data/shapes/vehicles/dev_aircraft/particles/backwardParticle";
  colors[0]     = "0.6 0.6 0.6 0.5";
  colors[1]     = "0.2 0.2 0.2 0";
  sizes[0]      = 0.6;
  sizes[1]      = 5;
};

datablock ParticleEmitterData(AircraftBackwardEmitter)
{
  ejectionPeriodMS = 50;
  periodVarianceMS = 0;
  ejectionVelocity = 1;
  velocityVariance = 1.0;
  ejectionOffset   = 0.0;
  thetaMin         = 0;
  thetaMax         = 180;
  phiReferenceVel  = 0;
  phiVariance      = 360;
  overrideAdvances = false;
  particles = "AircraftBackwardParticle";
};

// upward
datablock ParticleData(AircraftUpParticle)
{
  dragCoefficient      = 1.5;
  gravityCoefficient   = 0;
  inheritedVelFactor   = 0.2;
  constantAcceleration = 0.0;
  lifetimeMS           = 3000;
  lifetimeVarianceMS   = 0;
  textureName          = "~/data/shapes/vehicles/dev_aircraft/particles/upParticle";
  colors[0]     = "0.6 0.6 0.6 0.5";
  colors[1]     = "0.2 0.2 0.2 0";
  sizes[0]      = 0.6;
  sizes[1]      = 5;
};

datablock ParticleEmitterData(AircraftUpEmitter)
{
  ejectionPeriodMS = 50;
  periodVarianceMS = 0;
  ejectionVelocity = 1;
  velocityVariance = 1.0;
  ejectionOffset   = 0.0;
  thetaMin         = 0;
  thetaMax         = 180;
  phiReferenceVel  = 0;
  phiVariance      = 360;
  overrideAdvances = false;
  particles = "AircraftUpParticle";
};

// downward
datablock ParticleData(AircraftDownParticle)
{
  dragCoefficient      = 1.5;
  gravityCoefficient   = 0;
  inheritedVelFactor   = 0.2;
  constantAcceleration = 0.0;
  lifetimeMS           = 3000;
  lifetimeVarianceMS   = 0;
  textureName          = "~/data/shapes/vehicles/dev_aircraft/particles/downParticle";
  colors[0]     = "0.6 0.6 0.6 0.5";
  colors[1]     = "0.2 0.2 0.2 0";
  sizes[0]      = 0.6;
  sizes[1]      = 5;
};

datablock ParticleEmitterData(AircraftDownEmitter)
{
  ejectionPeriodMS = 50;
  periodVarianceMS = 0;
  ejectionVelocity = 1;
  velocityVariance = 1.0;
  ejectionOffset   = 0.0;
  thetaMin         = 0;
  thetaMax         = 180;
  phiReferenceVel  = 0;
  phiVariance      = 360;
  overrideAdvances = false;
  particles = "AircraftDownParticle";
};

//-----------------------------------------------------------------------------
datablock ParticleData(TireParticle)
{
   textureName          = "~/data/shapes/vehicles/dev_aircraft/particles/dustParticle";
   dragCoefficient      = 2.0;
   gravityCoefficient   = -0.1;
   inheritedVelFactor   = 0.1;
   constantAcceleration = 0.0;
   lifetimeMS           = 1000;
   lifetimeVarianceMS   = 0;
   colors[0]     = "0.46 0.36 0.26 1.0";
   colors[1]     = "0.46 0.46 0.36 0.0";
   sizes[0]      = 0.80;
   sizes[1]      = 1.0;
};

datablock ParticleEmitterData(TireEmitter)
{
   ejectionPeriodMS = 10;
   periodVarianceMS = 0;
   ejectionVelocity = 1;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 5;
   thetaMax         = 20;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvances = false;
   particles = "TireParticle";
};

//////////////////////////////////////////////////////////////////////////////
// WheeledVehicleTire
datablock WheeledVehicleTire(AircraftTire)
{
   // Tires act as springs and generate lateral and longitudinal
   // forces to move the vehicle. These distortion/spring forces
   // are what convert wheel angular velocity into forces that
   // act on the rigid body.
   shapeFile = "~/data/shapes/vehicles/dev_aircraft/wheel.dts";
   friction = 1.5;

   // Spring that generates lateral tire forces
   lateralForce = 6000;
   lateralDamping = 400;
   lateralRelaxation = 1;

   // Spring that generates longitudinal tire forces
   longitudinalForce = 6000;
   longitudinalDamping = 400;
   longitudinalRelaxation = 1;
};

datablock WheeledVehicleSpring(AircraftSpring)
{
   // Wheel suspension properties
   length = 0.73;             // Suspension travel
   force = 3000;              // Spring force
   damping = 600;             // Spring damping
   antiSwayForce = 3;         // Lateral anti-sway force
};

//////////////////////////////////////////////////////////////////////////////
// DebrisData

datablock DebrisData( AircraftDebris )
{
   explodeOnMaxBounce = false;

   elasticity = 0.15;
   friction = 0.5;

   lifetime = 4.0;
   lifetimeVariance = 0.0;

   minSpinSpeed = 5;
   maxSpinSpeed = 40;

   numBounces = 5;
   bounceVariance = 0;

   staticOnMaxBounce = true;
   gravModifier = 1.0;

   useRadiusMass = true;
   baseRadius = 1;

   velocity = 5.0;
   velocityVariance = 12.0;
};             

//////////////////////////////////////////////////////////////////////////////
// Vehicle Datablock

datablock WheeledFlyingVehicleData(AirCraft)
{
	spawnOffset			= "0 0 2";
	emap				= true;
	category			= "Vehicles";
	shapeFile			= "~/data/shapes/vehicles/dev_aircraft/dev_aircraft.dts";
	multipassenger			= false;
	computeCRC			= true;
							
	debrisShapeName		= "~/data/shapes/vehicles/dev_aircraft/dev_aircraft.dts";
	debris			    = AircraftDebris;
	renderWhenDestroyed = false;

    drag				= 0.15;
	density				= 3.0;

	mountPose[0]			= sitting;
	numMountPoints			= 1;
	isProtectedMountPoint[0]= true;
	cameraMaxDist			= 10.0; // <- rfb 02-20-2005
	cameraOffset			= 0.0;
	cameraLag			    = 0.0;
    cameraRoll 			    = true;         // Roll the camera with the vehicle

    // explosion			= AircraftVehicleExplosion;
	explosionDamage			= 10.5;
	explosionRadius			= 15.0;
	maxDamage			    = 50.40;
	destroyedLevel			= 50.40;
									
	isShielded			    = true; 
	energyPerDamagePoint	= 160;
	maxEnergy			    = 280;      // Afterburner and any energy weapon pool
	rechargeRate			= 0.8;

    //////////////////////////////////////////////////////////////////////////
    // FlyingVehicle parameters

	minDrag				    = 30;       // Linear Drag (eventually slows you down when not thrusting...constant drag)
	rotationalDrag			= 20;       // Anguler Drag (dampens the drift after you stop moving the mouse...also tumble drag)

	maxAutoSpeed			= 10;       // Autostabilizer kicks in when less than this speed. (meters/second)
	autoAngularForce		= 200;      // Angular stabilizer force (this force levels you out when autostabilizer kicks in)
	autoLinearForce			= 200;      // Linear stabilzer force (this slows you down when autostabilizer kicks in)
	autoInputDamping		= 0.95;     // Dampen control input so you don't` whack out at very slow speeds
	integration 			= 6;        // Physics integration: TickSec/Rate
	collisionTol 			= 0.2;      // Collision distance tolerance
	contactTol 			    = 0.1;
   
	// Maneuvering
	maxFlightSteeringAngle = 0.4;     // lower numbers are more manueverable
	horizontalSurfaceForce	= 40;     // Horizontal center "wing" (provides "bite" into the wind for climbing/diving and turning)
	verticalSurfaceForce	= 4;      // Vertical center "wing" (controls side slip. lower numbers make MORE slide.)
    // RFB 02-22-2005 ->
	maneuveringForce1		= 300;      // Horizontal jets (W,S,D,A key thrust)
    maneuveringForce2		= 600;      // Horizontal jets (W,S,D,A key thrust)
    maneuveringForce3		= 1200;      // Horizontal jets (W,S,D,A key thrust)
    // <- RFB 02-22-2005
    steeringForce			= 300;    // Steering jets (force applied when you move the mouse)
	steeringRollForce		= 300;     // Steering jets (how much you heel over when you turn)
	rollForce			    = 0;      // Auto-roll (self-correction to right you after you roll/invert)
	hoverHeight			    = 1;      // Height off the ground at rest
	createHoverHeight		= 1;      // Height off the ground when created
	
	// Turbo Jet
	jetForce			    = 300;   // Afterburner thrust (this is in addition to normal thrust)
	minJetEnergy			= 0.0;     // Afterburner can't be used if below this threshhold.
	jetEnergyDrain			= 0.0;    // Energy use of the afterburners (low number is less drain...can be fractional)                                                                                                                                                                                                                                                                                          // Auto stabilize speed
	vertThrustMultiple		= 0.0;

	// Rigid body
	mass				    = 30;     // Mass of the vehicle
	bodyFriction			= 1;      // Don't mess with this.
	bodyRestitution			= 0;      // When you hit the ground, how much you rebound. (between 0 and 1)
	minRollSpeed			= 2000;   // Don't mess with this.
	softImpactSpeed			= 3;      // Sound hooks. This is the soft hit.
	hardImpactSpeed			= 15;     // Sound hooks. This is the hard hit.

	// Ground Impact Damage (uses DamageType::Ground)
	minImpactSpeed			= 0;      // If hit ground at speed above this then it's an impact. Meters/second
	speedDamageScale		= 1.0;

	// Object Impact Damage (uses DamageType::Impact)
	collDamageThresholdVel		= 23.0;
	collDamageMultiplier		= 0.02;

	//
	minTrailSpeed			= 15;      // The speed your contrail shows up at.
	trailEmitter			= AircraftTrailEmitter;
	forwardJetEmitter		= AircraftForwardEmitter;
	downJetEmitter		    = AircraftDownEmitter;
    
	//
	jetSound			= AircraftThrustSound;
	engineSound			= AircraftEngineSound;

    //////////////////////////////////////////////////////////////////////////
    // WheeledVehicle parameters
    // Engine
    engineTorque = 4000;       // Engine power
    engineBrake = 600;         // Braking when throttle is 0
    brakeTorque = 8000;        // When brakes are applied
    maxWheelSpeed = 40;        // Engine scale by current speed / max speed

    maxSteeringAngle = 0.785;  // Maximum steering angle, should match animation
    integration = 4;           // Force integration time: TickSec/Rate
    tireEmitter = TireEmitter; // All the tires use the same dust emitter

    //////////////////////////////////////////////////////////////////////////
    // Common parameters
    minModeChangeSpeed = 30.0;
    maxModeChangeSpeed = 15.0;
    modeChangeEnergyDrain = 0;       // Energy per mode change
    minModeChangeEnergy = 0;
    modeChangeDelay = 30;             // Delay time in ticks
    createMode = 0;
    
	//softImpactSound		= DroneSoftImpactSound;
	//hardImpactSound		= DroneHardImpactSound;
	//
	//softSplashSoundVelocity	= 10.0;
	//mediumSplashSoundVelocity	= 15.0;
	//hardSplashSoundVelocity	= 20.0;
	//exitSplashSoundVelocity	= 10.0;

	//exitingWater			= DroneExitWaterMediumSound;
	//impactWaterEasy		= DroneImpactWaterSoftSound;
	//impactWaterMedium		= DroneImpactWaterMediumSound;
	//impactWaterHard		= DroneImpactWaterMediumSound;
	//waterWakeSound		= DroneWakeMediumSplashSound;

//	dustEmitter			= VehicleLiftoffDustEmitter;
	
	triggerDustHeight		= 4.0;
	dustHeight			    = 1.0;

//	damageEmitter[0]		= LightDamageSmoke;

//	damageEmitter[1]		= MediumDamageSmoke;

//	damageEmitter[2]		= HeavyDamageSmoke;

	damageEmitterOffset[0]	= "0.0 -3.0 0.0 ";
	damageLevelTolerance[0]	= 0.3;
	damageLevelTolerance[1]	= 0.7;
	numDmgEmitterAreas		= 3;
						
	//splashEmitter[0]		= AircraftFoamDropletsEmitter;
	//splashEmitter[1]		= AircraftFoamEmitter;
	
	observeParameters		= "0 0 0";
    //
	//max[RocketAmmo]		= 1000;
};

//////////////////////////////////////////////////////////////////////////////
// Creation

function WheeledFlyingVehicleData::create(%block)
{
    %obj = new WheeledFlyingVehicle() {
       dataBlock = %block;
    };
    return(%obj);
}

function WheeledFlyingVehicleData::onAdd(%data, %obj)
{
   echo("WheeledFlyingVehicleData::onAdd() getWheelCount()=" @ %obj.getWheelCount());
   // Setup the aircraft with some defaults tires & springs
   for (%i = %obj.getWheelCount() - 1; %i >= 0; %i--) {
      %obj.setWheelTire(%i,AircraftTire);
      %obj.setWheelSpring(%i,AircraftSpring);
   }

   %obj.setRechargeRate(%data.rechargeRate);
   %obj.setEnergyLevel(%data.MaxEnergy);
}

//////////////////////////////////////////////////////////////////////////////
// Collision, Impact, and Damage

function WheeledFlyingVehicleData::onImpact(%this, %obj, %collidedObject, %vec, %vecLen)
{
   %obj.damage(0, VectorAdd(%obj.getPosition(),%vec),
      %vecLen * %this.speedDamageScale, "Impact");
}

function WheeledFlyingVehicleData::onCollision(%this,%obj,%col,%vec,%speed)
{
   if (%col.getClassName() $= "Item") {
      %obj.pickup(%col);
      return;
   }
}

function WheeledFlyingVehicleData::damage(%this, %obj, %sourceObject, %position, %damage, %damageType)
{
   if (%obj.getDamageState() $= "Destroyed")
      return;

   %obj.applyDamage(%damage);
   %location = "Body";

   // Deal with client callbacks here because we don't have this
   // information in the onDamage or onDisable methods
   %client = %obj.client;
   %sourceClient = %sourceObject ? %sourceObject.client : 0;

   if (%obj.getDamageState() $= "Destroyed")
      %client.onDeath(%sourceObject, %sourceClient, %damageType, %location);
}

function WheeledFlyingVehicleData::onDamage(%this, %obj, %delta)
{
   %damage = %obj.getDamageLevel();

   if (%damage >= %this.destroyedLevel)
   {
      if(%obj.getDamageState() !$= "Destroyed")
      {
         %obj.setDamageState(Destroyed);
      }
   }
   else
   {
      if(%obj.getDamageState() !$= "Enabled")
         %obj.setDamageState(Enabled);

      // If the pain is excessive, let's hear about it.
      if (%delta > 10)
         %obj.playPain();
   }
}

function WheeledFlyingVehicleData::onDestroyed(%data, %obj, %prevState)
{
   // The player object sets the "disabled" state when damage exceeds
   // it's maxDamage value.  This is method is invoked by ShapeBase
   // state mangement code.

   // If we want to deal with the damage information that actually
   // caused this death, then we would have to move this code into
   // the script "damage" method.
   %obj.playDeathCry();
   %obj.playDeathAnimation();
   %obj.setDamageFlash(0.75);

   // Release the main weapon trigger
   %obj.setImageTrigger(0,false);

   // Schedule corpse removal.  Just keeping the place clean.
   %obj.schedule($CorpseTimeoutValue - 1000, "startFade", 1000, 0, true);
   %obj.schedule($CorpseTimeoutValue, "delete");
}

//////////////////////////////////////////////////////////////////////////////
//

function WheeledFlyingVehicleData::onTrigger(%data, %obj, %trigger, %state)
{

   //echo("WheeledFlyingVehicleData::onTrigger(" @ %trigger @ "," @ %state @ ")");
   if(%trigger == 0)
   {
      switch (%state)
      {
         case 0:
            %obj.fireWeapon = false;
            %obj.setImageTrigger(0, false);
            %obj.setImageTrigger(1, false);
         case 1:
            %obj.fireWeapon = true;
            if(%obj.nextWeaponFire == 0)
            {
               %obj.setImageTrigger(0, true);
               %obj.setImageTrigger(1, false);
            }
            else
            {
               %obj.setImageTrigger(0, false);
               %obj.setImageTrigger(1, true);
            }
      }
   }
   // RFB -> this logic can optionally be used to play mode change transition animations
   else if (%trigger == 2) // brakes
   {
      switch (%state)
      {
      case 1:
         %mode = %obj.getMode();
         %prevMode = %obj.prevMode;
         if (!(%mode $= %prevMode)) {
            %obj.changeMode(%obj, %mode);
            %obj.prevMode = %mode;
         }
      }
   }
   else if (%trigger == 3) // jets
   {
      switch (%state)
      {
      case 1:
         %mode = %obj.getMode();
         %prevMode = %obj.prevMode;
         if (!(%mode $= %prevMode)) {
            %obj.changeMode(%obj, %mode);
            %obj.prevMode = %mode;
         }
      }
   }
}

//function WheeledFlyingVehicleData::onModeChanged(%this, %obj, %mode)
//{
//   %obj.changeMode(%obj, %mode);
//}

function WheeledFlyingVehicle::changeMode(%this, %obj, %mode)
{
   //echo(%mode);
   //echo(%obj.getMode());

   if (%mode $= "flying")
   {
      // play animation 
   }
   else // driving
   {
      // play animation
   }
}

//////////////////////////////////////////////////////////////////////////////
//
function serverCmdThrottleUp(%client)
{
   %vehicle = %client.player;
   if (isObject(%vehicle))
      %vehicle.setThrottleLevel(%vehicle.getThrottleLevel() + 1);
}

function serverCmdThrottleDown(%client)
{
   %vehicle = %client.player;
   if (isObject(%vehicle))
      %vehicle.setThrottleLevel(%vehicle.getThrottleLevel() - 1);
}