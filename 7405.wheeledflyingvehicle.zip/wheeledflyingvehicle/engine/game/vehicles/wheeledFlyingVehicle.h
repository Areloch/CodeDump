//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#ifndef _WHEELEDFLYINGVEHICLE_H_
#define _WHEELEDFLYINGVEHICLE_H_

#ifndef _WHEELEDVEHICLE_H_
#include "game/vehicles/wheeledvehicle.h"
#endif

#ifndef _CLIPPEDPOLYLIST_H_
#include "collision/clippedPolyList.h"
#endif

// RFB -> adding lights
#ifndef _LIGHTMANAGER_H_
#include "sceneGraph/lightManager.h"
#endif
// <- RFB

class ParticleEmitter;
class ParticleEmitterData;

//----------------------------------------------------------------------------

struct WheeledFlyingVehicleData: public VehicleData {
   typedef VehicleData Parent;

   enum Constants {
      MaxWheels = 8,
      MaxWheelBits = 3
   };

   enum Sounds {
      JetSound,
      EngineSound,
      SquealSound,
      WheelImpactSound,
      MaxSounds,
   };
   AudioProfile* sound[MaxSounds];

   ParticleEmitterData* tireEmitter;

   F32 maxWheelSpeed;            // Engine torque is scale based on wheel speed
   F32 engineTorque;             // Engine force controlled through throttle
   F32 engineBrake;              // Break force applied when throttle is 0
   F32 brakeTorque;              // Force used when brakeing

   // Initialized onAdd
   struct Wheel {
      S32 opposite;              // Opposite wheel on Y axis (or -1 for none)
      Point3F pos;               // Root pos of spring
      S32 springNode;            // Wheel spring/hub node
      S32 springSequence;        // Suspension animation
      F32 springLength;          // Suspension animation length
   } wheel[MaxWheels];
   U32 wheelCount;
   ClippedPolyList rigidBody;    // Extracted from shape
   S32 brakeLightSequence;       // Brakes
   S32 propellerSequence;        // Prop animation
   S32 steeringSequence;         // Steering animation
   S32 elevatorSequence;         // Elevator animation

   // RFB -> borrowed from FlyingVehicleData
   enum Jets {
      // These enums index into a static name list.
      ForwardJetEmitter,      // Thrust forward
      BackwardJetEmitter,     // Thrust backward
      DownwardJetEmitter,     // Thrust down
      TrailEmitter,           // Contrail
      MaxJetEmitters,
   };
   ParticleEmitterData* jetEmitter[MaxJetEmitters];
   F32 minTrailSpeed;

   //
   F32 maxFlightSteeringAngle;
   // RFB 02-22-2005 ->
   F32 maneuveringForce1;
   F32 maneuveringForce2;
   F32 maneuveringForce3;
   // <- RFB 02-22-2005
   F32 horizontalSurfaceForce;
   F32 verticalSurfaceForce;
   F32 autoInputDamping;
   F32 steeringForce;
   F32 steeringRollForce;
   F32 rollForce;
   F32 autoAngularForce;
   F32 rotationalDrag;
   F32 maxAutoSpeed;
   F32 autoLinearForce;
   F32 hoverHeight;
   F32 createHoverHeight;
   F32 vertThrustMultiple;
   
   // Initialized in preload
   S32 surfaceCount;
   F32 maxSpeed;

   enum JetNodes {
      // These enums index into a static name list.
      ForwardJetNode,
      ForwardJetNode1,
      BackwardJetNode,
      BackwardJetNode1,
      DownwardJetNode,
      DownwardJetNode1,
      //
      TrailNode,
      TrailNode1,
      TrailNode2,
      TrailNode3,
      //
      MaxJetNodes,
      MaxDirectionJets = 2,
      ThrustJetStart = ForwardJetNode,
      NumThrustJets = TrailNode,
      MaxTrails = 4,
   };
   static const char *sJetNode[MaxJetNodes];
   S32 jetNode[MaxJetNodes];
   // <-RFB
   // RFB -> borrowed from Player
   F32 modeChangeEnergyDrain;       // Energy per mode change
   F32 minModeChangeEnergy;
   F32 minModeChangeSpeed;
   F32 maxModeChangeSpeed;
   S32 modeChangeDelay;             // Delay time in ticks
   // <- RFB
   // RFB -> added
   S32 createMode;
   // <- RFB
   // RFB -> adding lights
   enum LightNodes {
      Light01,
      Light02,
	  Light03,
	  Light04,
	  Light05,
	  Light06,
	  Light07,
	  Light08,
	  MaxLights };
   
   S32 lightType[MaxLights];
   F32 lightRadius[MaxLights];
   ColorF lightColor[MaxLights];
   S32 lightTime[MaxLights];
   F32 lightDistance[MaxLights];
   static const char *sLightNode[MaxLights];
   S32 lightNode[MaxLights];
   // <- RFB

   //
   WheeledFlyingVehicleData();
   DECLARE_CONOBJECT(WheeledFlyingVehicleData);
   static void initPersistFields();
   bool preload(bool, char errorBuffer[256]);
   bool mirrorWheel(Wheel* we);
   virtual void packData(BitStream* stream);
   virtual void unpackData(BitStream* stream);
};


//----------------------------------------------------------------------------

class WheeledFlyingVehicle: public Vehicle
{
   typedef Vehicle Parent;

   enum MaskBits {
      WheelMask    = Parent::NextFreeMask << 0,
	  HoverHeight  = Parent::NextFreeMask << 1,
	  NextFreeMask = Parent::NextFreeMask << 2
   };

   bool createHeightOn;
   F32 mCeilingFactor;

   enum ThrustDirection {
      // Enums index into sJetActivationTable
      ThrustForward,
      ThrustBackward,
      ThrustDown,
	  // RFB 2-20-2005 ->
	  ThrustUp,
	  // <- RFB 2-20-2005
      NumThrustDirections,
      NumThrustBits = 3
   };
   Point2F mThrust;
   ThrustDirection mThrustDirection;

   // Jet Threads
   enum Jets {
      // These enums index into a static name list.
      BackActivate,
      BackMaintain,
      BottomActivate,
      BottomMaintain,
      JetAnimCount
   };
   static const char* sJetSequence[WheeledFlyingVehicle::JetAnimCount];
   TSThread* mJetThread[JetAnimCount];
   S32 mJetSeq[JetAnimCount];
   bool mBackMaintainOn;
   bool mBottomMaintainOn;
   // Jet Particles
   struct JetActivation {
      // Convert thrust direction into nodes & emitters
      S32 node;
      S32 emitter;
   };
   static JetActivation sJetActivation[NumThrustDirections];
   SimObjectPtr<ParticleEmitter> mJetEmitter[WheeledFlyingVehicleData::MaxJetNodes];
   // <- RFB
   // RFB -> added
   enum Modes { Driving, Flying, ModeCount };
   static const char* sMode[WheeledFlyingVehicle::ModeCount];
   S32 mMode;
   //S32 mPrevMode;
   S32 mModeChangeDelay;
   // <- RFB

   WheeledFlyingVehicleData* mDataBlock;

   bool mBraking;
   TSThread* mTailLightThread;
   AUDIOHANDLE mJetSound;
   AUDIOHANDLE mEngineSound;
   AUDIOHANDLE mSquealSound;

   struct Wheel {
      WheeledVehicleTire *tire;
      WheeledVehicleSpring *spring;
      WheeledFlyingVehicleData::Wheel* data;

      F32 extension;          // Spring extension (0-1)
      F32 avel;               // Angular velocity 
      F32 apos;               // Anuglar position (client side only)
      F32 Dy,Dx;              // Current tire deformation

      struct Surface {
         bool contact;        // Wheel is touching a surface
         Point3F normal;      // Surface normal
         U32 material;        // Surface material
         Point3F pos;         // Point of contact
         SceneObject* object; // Object in contact with
      } surface;

      TSShapeInstance* shapeInstance;
      TSThread* springThread;

      F32 steering;           // Wheel steering scale
      bool powered;           // Powered by engine
      bool slipping;          // Traction on last tick 
      F32 torqueScale;        // Max torque % applied to wheel (0-1)
      F32 slip;               // Amount of wheel slip (0-1)
      SimObjectPtr<ParticleEmitter> emitter;
   };
   Wheel mWheel[WheeledFlyingVehicleData::MaxWheels];
   TSThread* mPropellerThread;
   TSThread* mSteeringThread;
   TSThread* mElevatorThread;
   
   //
   bool onNewDataBlock(GameBaseData* dptr);
   void processTick(const Move* move);
   void updateMove(const Move *move);
   void updateForces(F32 dt);
   
   void renderImage(SceneState* state, SceneRenderImage*);
   void extendWheels();
   // RFB -> added
   void withdrawWheels();
   // <- RFB
   
   // Client sounds & particles
   void updateWheelThreads();
   void updateWheelParticles(F32 dt);
   void updateEngineSound(F32 level);
   void updateSquealSound(F32 level);
   void updateJetSound();

   // RFB -> borrowed from FlyingVehicle
   F32 getHeight();
   void updateJet(F32 dt);
   void updateEmitter(bool active,F32 dt,ParticleEmitterData *emitter,S32 idx,S32 count);
   // RFB 2-20-2005 ->
   bool mDiving;

   enum ThrottleLevels {
	   ThrottleSlow,
	   ThrottleMedium,
	   ThrottleFast,
	   MaxThrottleLevels,
   };

   S32 mThrottleLevel;
   // <- RFB 2-20-2005
   // <- RFB
   // RFB -> adding lights
   void registerLights(LightManager * lightManager, bool lightingScene);
   bool mLightOn[WheeledFlyingVehicleData::MaxLights];
   S32 mLightTime;
   LightInfo mLight[WheeledFlyingVehicleData::MaxLights];
   //S32 mPrevObjectId[WheeledFlyingVehicleData::MaxLights];
   // <- RFB

   U32 getCollisionMask();

public:
   DECLARE_CONOBJECT(WheeledFlyingVehicle);
   static void initPersistFields();

   WheeledFlyingVehicle();
   ~WheeledFlyingVehicle();

   // RFB -> adding lights
   enum LightType 
   {
      ConstantLight = 0,
      PulsingLight,
      NumLightTypes,
   };
   // <- RFB

   bool onAdd();
   void onRemove();
   void advanceTime(F32 dt);
   bool buildPolyList(AbstractPolyList* polyList, const Box3F&, const SphereF&);

   S32 getWheelCount();
   void setWheelSteering(S32 wheel,F32 steering);
   void setWheelPowered(S32 wheel,bool powered);
   void setWheelTire(S32 wheel,WheeledVehicleTire*);
   void setWheelSpring(S32 wheel,WheeledVehicleSpring*);

   void writePacketData(GameConnection *, BitStream *stream);
   void readPacketData(GameConnection *, BitStream *stream);
   U32  packUpdate(NetConnection *, U32 mask, BitStream *stream);
   void unpackUpdate(NetConnection *, BitStream *stream);
   // RFB -> added
   const char* getMode();
   // RFB 02-22-2005 -> various throttle levels
   void setThrottleLevel(S32 level);
   S32 getThrottleLevel();
   // <- RFB 02-22-2005
   // <- RFB
   // RFB -> borrow from FlyingVehicle
   void useCreateHeight(bool val);
   // <- RFB
   // RFB -> added
   bool  canChangeMode();
   // <- RFB
   // RFB -> adding lights
   void setLightOn(S32 light, bool status);
   // <- RFB
};


#endif
