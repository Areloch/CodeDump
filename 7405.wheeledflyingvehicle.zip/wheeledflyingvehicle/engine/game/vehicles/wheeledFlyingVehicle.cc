//-----------------------------------------------------------------------------
// Torque Game Engine 
// Copyright (C) GarageGames.com, Inc.
//-----------------------------------------------------------------------------

#include "game/vehicles/wheeledFlyingVehicle.h"

#include "platform/platform.h"
#include "dgl/dgl.h"
#include "game/game.h"
#include "math/mMath.h"
#include "math/mathIO.h"
#include "console/simBase.h"
#include "console/console.h"
#include "console/consoleTypes.h"
#include "collision/clippedPolyList.h"
#include "collision/planeExtractor.h"
#include "game/moveManager.h"
#include "core/bitStream.h"
#include "core/dnet.h"
#include "game/gameConnection.h"
#include "ts/tsShapeInstance.h"
#include "game/fx/particleEngine.h"
#include "audio/audio.h"
#include "sceneGraph/sceneGraph.h"
#include "sim/decalManager.h"
#include "dgl/materialPropertyMap.h"
#include "terrain/terrData.h"
// RFB -> borrowed from FlyingVehicle
#include "game/missionArea.h"
// <- RFB
// RFB ->
#include "game/shadow.h"
// <- RFB

//----------------------------------------------------------------------------

// Collision masks are used to determin what type of objects the
// wheeled vehicle will collide with.
static U32 sClientCollisionMask = 
      TerrainObjectType    | InteriorObjectType       |
      PlayerObjectType     | StaticShapeObjectType    |
      VehicleObjectType    | VehicleBlockerObjectType |
      StaticTSObjectType;

// Gravity constant
static F32 sWheeledFlyingVehicleGravity = -20;

// Misc. sound constants
static F32 sMinSquealVolume = 0.05;
static F32 sIdleEngineVolume = 0.2;

// RFB ->
const char* WheeledFlyingVehicle::sMode[WheeledFlyingVehicle::ModeCount] =
{
   "driving",    
   "flying",
};
// <- RFB

// RFB -> borrow from FlyingVehicle
const char* WheeledFlyingVehicle::sJetSequence[WheeledFlyingVehicle::JetAnimCount] =
{
   "activateBack",    
   "maintainBack",
   "activateBot",    
   "maintainBot",
};

const char* WheeledFlyingVehicleData::sJetNode[WheeledFlyingVehicleData::MaxJetNodes] =
{
   "JetNozzle0",  // Thrust Forward
   "JetNozzle1",
   "JetNozzleX",  // Thrust Backward
   "JetNozzleX",
   "JetNozzle2",  // Thrust Downward
   "JetNozzle3",
   "contrail0",   // Trail
   "contrail1",
   "contrail2",
   "contrail3",
};

// Convert thrust direction into nodes & emitters
WheeledFlyingVehicle::JetActivation WheeledFlyingVehicle::sJetActivation[NumThrustDirections] = {
   { WheeledFlyingVehicleData::ForwardJetNode, WheeledFlyingVehicleData::ForwardJetEmitter },
   { WheeledFlyingVehicleData::BackwardJetNode, WheeledFlyingVehicleData::BackwardJetEmitter },
   { WheeledFlyingVehicleData::DownwardJetNode, WheeledFlyingVehicleData::DownwardJetEmitter },
};
// <- RFB

// RFB -> adding lights
const char* WheeledFlyingVehicleData::sLightNode[WheeledFlyingVehicleData::MaxLights] =
{
   "Light0",
   "Light1",
   "Light2",
   "Light3",
   "Light4",
   "Light5",
   "Light6",
   "Light7",
};
// <- RFB

// RFB 02-22-2005 -> TODO: move to datablock
#define ENABLE_BACKWARDS_THRUST false
#define SPEED_PITCH_SCALE	0.01
// <- RFB 02-22-2005

//----------------------------------------------------------------------------
// Wheeled Flying Vehicle Data Block
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------

IMPLEMENT_CO_DATABLOCK_V1(WheeledFlyingVehicleData);

WheeledFlyingVehicleData::WheeledFlyingVehicleData()
{
   tireEmitter = 0;
   maxWheelSpeed = 40;
   engineTorque = 1;
   engineBrake = 1;
   brakeTorque = 1;
   brakeLightSequence = -1;

   for (S32 i = 0; i < MaxSounds; i++)
      sound[i] = 0;

   // RFB -> add flight specific steering angle because flight steering and driving steering are so different
   maxFlightSteeringAngle = 0.785; // 45 deg.
   // RFB -> borrow from FlyingVehicle
   // RFB 02-22-2005 ->
   maneuveringForce1 = 0;
   maneuveringForce2 = 0;
   maneuveringForce3 = 0;
   // <- RFB 02-22-2005
   horizontalSurfaceForce = 0;
   verticalSurfaceForce = 0;
   autoInputDamping = 1;
   steeringForce = 1;
   steeringRollForce = 1;
   rollForce = 1;
   autoAngularForce = 0;
   rotationalDrag = 0;
   autoLinearForce = 0;
   maxAutoSpeed = 0;
   hoverHeight = 2;
   createHoverHeight = 2;
   maxSteeringAngle = M_PI;
   minTrailSpeed = 1;
   maxSpeed = 100;
   
   for (S32 k = 0; k < MaxJetNodes; k++)
      jetNode[k] = -1;

   for (S32 j = 0; j < MaxJetEmitters; j++)
      jetEmitter[j] = 0;

   vertThrustMultiple = 1.0;
   // <- RFB
   // RFB -> added
   modeChangeEnergyDrain = 0;
   minModeChangeEnergy = 0;
   minModeChangeSpeed = 500;
   maxModeChangeSpeed = minModeChangeSpeed * 2;
   modeChangeDelay = 30;
   createMode = 0;
   // <- RFB
   // RFB -> adding lights
   for (int i=0; i<MaxLights;i++) {
      lightType[i] = WheeledFlyingVehicle::ConstantLight;
	  lightRadius[i] = 1;
	  lightColor[i].set(1, 1, 1);
	  lightTime[i] = 1000;
	  lightDistance[i] = 0;
   }
   // <- RFB
}


//----------------------------------------------------------------------------
/** Load the vehicle shape
   Loads and extracts information from the vehicle shape.

   Wheel Sequences
      spring#        Wheel spring motion: time 0 = wheel fully extended,
                     the hub must be displaced, but not directly animated
                     as it will be rotated in code.
   Other Sequences
      steering       Wheel steering: time 0 = full right, 0.5 = center
      breakLight     Break light, time 0 = off, 1 = breaking

   Wheel Nodes
      hub#           Wheel hub

   The steering and animation sequences are optional.
*/
bool WheeledFlyingVehicleData::preload(bool server, char errorBuffer[256])
{
   if (!Parent::preload(server, errorBuffer))
      return false;

   // A temporary shape instance is created so that we can
   // animate the shape and extract wheel information.
   TSShapeInstance* si = new TSShapeInstance(shape, false);

   // Resolve objects transmitted from server
   if (!server) {
      for (S32 i = 0; i < MaxSounds; i++)
         if (sound[i])
            Sim::findObject(SimObjectId(sound[i]),sound[i]);

      if (tireEmitter)
         Sim::findObject(SimObjectId(tireEmitter),tireEmitter);

	  // RFB -> borrow from FlyingVehicle
	  for (S32 j = 0; j < MaxJetEmitters; j++)
         if (jetEmitter[j])
            Sim::findObject(SimObjectId(jetEmitter[j]),jetEmitter[j]);
	  // <- RFB
   }

   // Extract wheel information from the shape
   TSThread* thread = si->addThread();
   Wheel* wp = wheel;
   char buff[10];
   for (S32 i = 0; i < MaxWheels; i++) {

      // The wheel must have a hub node to operate at all.
      dSprintf(buff,sizeof(buff),"hub%d",i);
      wp->springNode = shape->findNode(buff);
      if (wp->springNode != -1) {

         // Check for spring animation.. If there is none we just grab
         // the current position of the hub. Otherwise we'll animate
         // and get the position at time 0.
         dSprintf(buff,sizeof(buff),"spring%d",i);
         wp->springSequence = shape->findSequence(buff);
         if (wp->springSequence == -1)
            si->mNodeTransforms[wp->springNode].getColumn(3, &wp->pos);
         else {
            si->setSequence(thread,wp->springSequence,0);
            si->animate();
            si->mNodeTransforms[wp->springNode].getColumn(3, &wp->pos);

            // Determin the length of the animation so we can scale it
            // according the actual wheel position.
            Point3F downPos;
            si->setSequence(thread,wp->springSequence,1);
            si->animate();
            si->mNodeTransforms[wp->springNode].getColumn(3, &downPos);
            wp->springLength = wp->pos.z - downPos.z;
            if (!wp->springLength)
               wp->springSequence = -1;
         }

         // Match wheels that are mirrored along the Y axis.
         mirrorWheel(wp);
         wp++;
      }
   }
   wheelCount = wp - wheel;

   // Check for steering. Should think about normalizing the
   // steering animation the way the suspension is, but I don't
   // think it's as critical.
   steeringSequence = shape->findSequence("steering");

   propellerSequence = shape->findSequence("propeller");

   elevatorSequence = shape->findSequence("elevators");

   // Brakes
   brakeLightSequence = shape->findSequence("brakelight");

   /*
   // Extract collision planes from shape collision detail level
   if (collisionDetails[0] != -1) {
      MatrixF imat(1);
      SphereF sphere;
      sphere.center = shape->center;
      sphere.radius = shape->radius;
      PlaneExtractorPolyList polyList;
      polyList.mPlaneList = &rigidBody.mPlaneList;
      polyList.setTransform(&imat, Point3F(1,1,1));
      si->buildPolyList(&polyList,collisionDetails[0]);
   }
   */
   // RFB 02-16-2005 -> use all available collision details
   int nDetailNumber = 0;
   while (collisionDetails[nDetailNumber] != -1)
   {
   //if (collisionDetails[0] != -1) {
      MatrixF imat(1);
      PlaneExtractorPolyList polyList;
      polyList.mPlaneList = &rigidBody.mPlaneList;
      polyList.setTransform(&imat, Point3F(1,1,1));
      si->animate(collisionDetails[nDetailNumber]);
      si->buildPolyList(&polyList,collisionDetails[nDetailNumber]);
	  nDetailNumber ++;
   }
   // <- RFB 02-16-2005

   // RFB -> borrow from FlyingVehicle
   // Resolve jet nodes
   for (S32 j = 0; j < MaxJetNodes; j++)
      jetNode[j] = shape->findNode(sJetNode[j]);

   // 
   //maxSpeed = maneuveringForce / minDrag;
   // RFB 02-22-2005 ->
   maxSpeed = maneuveringForce3 / minDrag;
   // <- RFB 02-22-2005
   // <- RFB
   // RFB -> adding lights
   for (S32 k=0; k<MaxLights; k++)
   {
      lightNode[k] = shape->findNode(sLightNode[k]);
	  lightColor[k].clamp();
   }
   // <- RFB

   delete si;
   return true;
}


//----------------------------------------------------------------------------
/** Find a matching lateral wheel
   Looks for a matching wheeling mirrored along the Y axis, within some
   tolerance (current 0.5m), if one is found, the two wheels are lined up.
*/
bool WheeledFlyingVehicleData::mirrorWheel(Wheel* we)
{
   we->opposite = -1;
   for (Wheel* wp = wheel; wp != we; wp++)
      if (mFabs(wp->pos.y - we->pos.y) < 0.5) {
         we->pos.x = -wp->pos.x;
         we->pos.y = wp->pos.y;
         we->pos.z = wp->pos.z;
         we->opposite = wp - wheel;
         wp->opposite = we - wheel;
         return true;
      }
   return false;
}


//----------------------------------------------------------------------------

void WheeledFlyingVehicleData::initPersistFields()
{
   Parent::initPersistFields();

   addField("jetSound", TypeAudioProfilePtr, Offset(sound[JetSound], WheeledFlyingVehicleData));
   addField("engineSound", TypeAudioProfilePtr, Offset(sound[EngineSound], WheeledFlyingVehicleData));
   addField("squealSound", TypeAudioProfilePtr, Offset(sound[SquealSound], WheeledFlyingVehicleData));
   addField("WheelImpactSound", TypeAudioProfilePtr, Offset(sound[WheelImpactSound], WheeledFlyingVehicleData));

   addField("tireEmitter",TypeParticleEmitterDataPtr, Offset(tireEmitter, WheeledFlyingVehicleData));
   addField("maxWheelSpeed", TypeF32, Offset(maxWheelSpeed, WheeledFlyingVehicleData));
   addField("engineTorque", TypeF32, Offset(engineTorque, WheeledFlyingVehicleData));
   addField("engineBrake", TypeF32, Offset(engineBrake, WheeledFlyingVehicleData));
   addField("brakeTorque", TypeF32, Offset(brakeTorque, WheeledFlyingVehicleData));

   // RFB -> add flight specific steering angle
   addField("maxFlightSteeringAngle", TypeF32, Offset(maxFlightSteeringAngle, WheeledFlyingVehicleData));
   // <- RFB
   // RFB -> borrow from FlyingVehicle
   // RFB 02-22-2005 ->
   addField("maneuveringForce1", TypeF32, Offset(maneuveringForce1, WheeledFlyingVehicleData));
   addField("maneuveringForce2", TypeF32, Offset(maneuveringForce2, WheeledFlyingVehicleData));
   addField("maneuveringForce3", TypeF32, Offset(maneuveringForce3, WheeledFlyingVehicleData));
   // <- RFB 02-22-2005
   addField("horizontalSurfaceForce", TypeF32, Offset(horizontalSurfaceForce, WheeledFlyingVehicleData));
   addField("verticalSurfaceForce", TypeF32, Offset(verticalSurfaceForce, WheeledFlyingVehicleData));
   addField("autoInputDamping", TypeF32, Offset(autoInputDamping, WheeledFlyingVehicleData));
   addField("steeringForce", TypeF32, Offset(steeringForce, WheeledFlyingVehicleData));
   addField("steeringRollForce", TypeF32, Offset(steeringRollForce, WheeledFlyingVehicleData));
   addField("rollForce", TypeF32, Offset(rollForce, WheeledFlyingVehicleData));
   addField("autoAngularForce", TypeF32, Offset(autoAngularForce, WheeledFlyingVehicleData));
   addField("rotationalDrag", TypeF32, Offset(rotationalDrag, WheeledFlyingVehicleData));
   addField("autoLinearForce", TypeF32, Offset(autoLinearForce, WheeledFlyingVehicleData));
   addField("maxAutoSpeed", TypeF32, Offset(maxAutoSpeed, WheeledFlyingVehicleData));
   addField("hoverHeight", TypeF32, Offset(hoverHeight, WheeledFlyingVehicleData));
   addField("createHoverHeight", TypeF32, Offset(createHoverHeight, WheeledFlyingVehicleData));

   addField("forwardJetEmitter",TypeParticleEmitterDataPtr, Offset(jetEmitter[ForwardJetEmitter], WheeledFlyingVehicleData));
   addField("backwardJetEmitter",TypeParticleEmitterDataPtr, Offset(jetEmitter[BackwardJetEmitter], WheeledFlyingVehicleData));
   addField("downJetEmitter",TypeParticleEmitterDataPtr, Offset(jetEmitter[DownwardJetEmitter], WheeledFlyingVehicleData));
   addField("trailEmitter",TypeParticleEmitterDataPtr, Offset(jetEmitter[TrailEmitter], WheeledFlyingVehicleData));
   addField("minTrailSpeed", TypeF32, Offset(minTrailSpeed, WheeledFlyingVehicleData));
   addField("vertThrustMultiple", TypeF32, Offset(vertThrustMultiple, WheeledFlyingVehicleData));
   // <- RFB
   // RFB -> added
   addField("modeChangeEnergyDrain", TypeF32, Offset(modeChangeEnergyDrain, WheeledFlyingVehicleData));
   addField("minModeChangeEnergy", TypeF32, Offset(minModeChangeEnergy, WheeledFlyingVehicleData));
   addField("minModeChangeSpeed", TypeF32, Offset(minModeChangeSpeed, WheeledFlyingVehicleData));
   addField("maxModeChangeSpeed", TypeF32, Offset(maxModeChangeSpeed, WheeledFlyingVehicleData));
   addField("modeChangeDelay", TypeS32, Offset(modeChangeDelay, WheeledFlyingVehicleData));
   addField("createMode", TypeS32, Offset(createMode, WheeledFlyingVehicleData));
   // <- RFB
   // RFB -> adding lights
   addField("lightType", TypeS32, Offset(lightType, WheeledFlyingVehicleData), WheeledFlyingVehicleData::MaxLights);
   addField("lightRadius", TypeF32, Offset(lightRadius, WheeledFlyingVehicleData), WheeledFlyingVehicleData::MaxLights);
   addField("lightColor", TypeColorF, Offset(lightColor, WheeledFlyingVehicleData), WheeledFlyingVehicleData::MaxLights);
   addField("lightTime", TypeS32, Offset(lightTime, WheeledFlyingVehicleData), WheeledFlyingVehicleData::MaxLights);
   addField("lightDistance", TypeF32, Offset(lightDistance, WheeledFlyingVehicleData), WheeledFlyingVehicleData::MaxLights);
   // <- RFB
}


//----------------------------------------------------------------------------

void WheeledFlyingVehicleData::packData(BitStream* stream)
{
   Parent::packData(stream);

   if (stream->writeFlag(tireEmitter))
      stream->writeRangedU32(packed? SimObjectId(tireEmitter):
         tireEmitter->getId(),DataBlockObjectIdFirst,DataBlockObjectIdLast);

   for (S32 i = 0; i < MaxSounds; i++)
      if (stream->writeFlag(sound[i]))
         stream->writeRangedU32(packed? SimObjectId(sound[i]):
            sound[i]->getId(),DataBlockObjectIdFirst,DataBlockObjectIdLast);

   // RFB -> borrow from FlyingVehicle
   for (S32 j = 0; j < MaxJetEmitters; j++)
   {
      if (stream->writeFlag(jetEmitter[j]))
      {
         SimObjectId writtenId = packed ? SimObjectId(jetEmitter[j]) : jetEmitter[j]->getId();
         stream->writeRangedU32(writtenId, DataBlockObjectIdFirst,DataBlockObjectIdLast);
      }
   }

   // RFB -> adding lights
   for (S32 k = 0; k <MaxLights; k++)
   {
      if(stream->writeFlag(lightNode[k] != -1))
      {
	     stream->writeInt(lightType[k], 2);
		 stream->writeFloat(lightRadius[k]/20.0, 8);
		 stream->writeFloat(lightColor[k].red,7);
         stream->writeFloat(lightColor[k].green,7);
         stream->writeFloat(lightColor[k].blue,7);
		 stream->write(lightTime[k]);
         stream->writeFloat(lightDistance[k]/20.0, 8);
      }
   }
   // <- RFB

   // RFB -> add flight specific steering
   stream->write(maxFlightSteeringAngle);
   // <- RFB
   // RFB 02-22-2005 ->
   stream->write(maneuveringForce1);
   stream->write(maneuveringForce2);
   stream->write(maneuveringForce3);
   // <- RFB 02-22-2005
   stream->write(horizontalSurfaceForce);
   stream->write(verticalSurfaceForce);
   stream->write(autoInputDamping);
   stream->write(steeringForce);
   stream->write(steeringRollForce);
   stream->write(rollForce);
   stream->write(autoAngularForce);
   stream->write(rotationalDrag);
   stream->write(autoLinearForce);
   stream->write(maxAutoSpeed);
   stream->write(hoverHeight);
   stream->write(createHoverHeight);
   stream->write(minTrailSpeed);
   stream->write(vertThrustMultiple);
   // <- RFB
   // RFB -> added
   stream->write(modeChangeEnergyDrain);
   stream->write(minModeChangeEnergy);
   stream->write(minModeChangeSpeed);
   stream->write(maxModeChangeSpeed);
   stream->write(modeChangeDelay);
   stream->write(createMode);
   // <- RFB

   stream->write(maxWheelSpeed);
   stream->write(engineTorque);
   stream->write(engineBrake);
   stream->write(brakeTorque);
}

void WheeledFlyingVehicleData::unpackData(BitStream* stream)
{
   Parent::unpackData(stream);

   tireEmitter = stream->readFlag()?
      (ParticleEmitterData*) stream->readRangedU32(DataBlockObjectIdFirst,
         DataBlockObjectIdLast): 0;

   for (S32 i = 0; i < MaxSounds; i++)
      sound[i] = stream->readFlag()?
         (AudioProfile*) stream->readRangedU32(DataBlockObjectIdFirst,
            DataBlockObjectIdLast): 0;

   // RFB -> borrow from FlyingVehicle
   for (S32 j = 0; j < MaxJetEmitters; j++) {
      jetEmitter[j] = NULL;
      if (stream->readFlag())
         jetEmitter[j] = (ParticleEmitterData*)stream->readRangedU32(DataBlockObjectIdFirst,
                                                                     DataBlockObjectIdLast);
   }

   // RFB ->
   bool light;
   for (S32 k=0; k<MaxLights; k++)
   {
      light = stream->readFlag();
	  if (light)
	  {
         lightType[k] = stream->readInt(2);
		 lightRadius[k] = stream->readFloat(8) * 20;
		 lightColor[k].red = stream->readFloat(7);
         lightColor[k].green = stream->readFloat(7);
         lightColor[k].blue = stream->readFloat(7);
		 stream->read(&lightTime[k]);
		 lightDistance[k] = stream->readFloat(8) * 20;
	  }
   }
   // <- RFB

   // RFB -> add flight specific steering angle
   stream->read(&maxFlightSteeringAngle);
   // <- RFB
   // RFB 02-22-2005 ->
   stream->read(&maneuveringForce1);
   stream->read(&maneuveringForce2);
   stream->read(&maneuveringForce3);
   // <- RFB 02-22-2005
   stream->read(&horizontalSurfaceForce);
   stream->read(&verticalSurfaceForce);
   stream->read(&autoInputDamping);
   stream->read(&steeringForce);
   stream->read(&steeringRollForce);
   stream->read(&rollForce);
   stream->read(&autoAngularForce);
   stream->read(&rotationalDrag);
   stream->read(&autoLinearForce);
   stream->read(&maxAutoSpeed);
   stream->read(&hoverHeight);
   stream->read(&createHoverHeight);
   stream->read(&minTrailSpeed);
   stream->read(&vertThrustMultiple);
   // <- RFB
   // RFB -> added
   stream->read(&modeChangeEnergyDrain);
   stream->read(&minModeChangeEnergy);
   stream->read(&minModeChangeSpeed);
   stream->read(&maxModeChangeSpeed);
   stream->read(&modeChangeDelay);
   stream->read(&createMode);
   // <- RFB

   stream->read(&maxWheelSpeed);
   stream->read(&engineTorque);
   stream->read(&engineBrake);
   stream->read(&brakeTorque);
}


//----------------------------------------------------------------------------
// Wheeled Vehicle Class
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------

IMPLEMENT_CO_NETOBJECT_V1(WheeledFlyingVehicle);

WheeledFlyingVehicle::WheeledFlyingVehicle()
{
   mDataBlock = 0;
   mGenerateShadow = true;
   mBraking = false;
   mJetSound = 0;
   mEngineSound = 0;
   mSquealSound = 0;
   mTailLightThread = 0;
   mSteeringThread = 0;

   for (S32 i = 0; i < WheeledFlyingVehicleData::MaxWheels; i++) {
      mWheel[i].springThread = 0;
      mWheel[i].Dy = mWheel[i].Dx = 0;
      mWheel[i].tire = 0;
      mWheel[i].spring = 0;
      mWheel[i].shapeInstance = 0;
      mWheel[i].steering = 0;
      mWheel[i].powered = true;
      mWheel[i].slipping = false;
   }

   // RFB -> borrowed from FlyingVehicle
   mSteering.set(0,0);
   mThrottle = 0;
   mJetting = false;
   // RFB 02-20-2005 -> some flyers may need to descend
   mDiving = false;
   mThrottleLevel = 0; // various throttle levels (speeds)
   // <- RFB 02-20-2005

   mBackMaintainOn = false;
   mBottomMaintainOn = false;
   createHeightOn = false;

   for (S32 i = 0; i < JetAnimCount; i++)
      mJetThread[i] = 0;
   // <- RFB
   // RFB -> added
   mMode = Driving;
   //mPrevMode = mMode;
   mModeChangeDelay = 30;
   // <- RFB
   // RFB -> adding lights
   for (S32 k = 0; k < WheeledFlyingVehicleData::MaxLights; k++)
   {
      mLightOn[k] = false;
      //mPrevObjectId[k] = -1;
   }
   // <- RFB
}

WheeledFlyingVehicle::~WheeledFlyingVehicle()
{
   // RFB -> borrowed from FlyingVehicle	
   if (mJetSound)
      alxStop(mJetSound);
   if (mEngineSound)
      alxStop(mEngineSound);
   // <- RFB
   // RFB -> added
   if (mSquealSound)
      alxStop(mSquealSound);
   // <- RFB
}

void WheeledFlyingVehicle::initPersistFields()
{
   Parent::initPersistFields();
}   


//----------------------------------------------------------------------------

bool WheeledFlyingVehicle::onAdd()
{
   if(!Parent::onAdd())
      return false;

   if (!isServerObject()) 
   {
	   for (S32 k=0; k<WheeledFlyingVehicleData::MaxLights; k++)
	   {
          if (mDataBlock->lightNode[k] != -1)
		  {
             Sim::getLightSet()->addObject(this);
			 mLightTime = Sim::getCurrentTime();
			 break;
		  }
	   }
   }

   addToScene();
   if (isServerObject())
      scriptOnAdd();
   return true;
}

void WheeledFlyingVehicle::onRemove()
{
   // Delete the wheel resources
   if (mDataBlock != NULL)  {
      Wheel* wend = &mWheel[mDataBlock->wheelCount];
      for (Wheel* wheel = mWheel; wheel < wend; wheel++) {
         if (!wheel->emitter.isNull())
            wheel->emitter->deleteWhenEmpty();
         delete wheel->shapeInstance;
      }
   }

   // Stop the sounds
   if (mJetSound)
      alxStop(mJetSound);
   if (mEngineSound)
      alxStop(mEngineSound);
   if (mSquealSound)
      alxStop(mSquealSound);

   //
   scriptOnRemove();
   removeFromScene();
   Parent::onRemove();
}


//----------------------------------------------------------------------------

bool WheeledFlyingVehicle::onNewDataBlock(GameBaseData* dptr)
{
   // Delete any existing wheel resources if we're switching 
   // datablocks.
   if (mDataBlock) {
      Wheel* wend = &mWheel[mDataBlock->wheelCount];
      for (Wheel* wheel = mWheel; wheel < wend; wheel++) {
         if (!wheel->emitter.isNull()) {
            wheel->emitter->deleteWhenEmpty();
            wheel->emitter = 0;
         }
         delete wheel->shapeInstance;
         wheel->shapeInstance = 0;
      }
   }

   // Load up the new datablock
   mDataBlock = dynamic_cast<WheeledFlyingVehicleData*>(dptr);
   if (!mDataBlock || !Parent::onNewDataBlock(dptr))
      return false;

   F32 frontStatic = 0;
   F32 backStatic = 0;
   F32 fCount = 0;
   F32 bCount = 0;

   // Set inertial tensor, default for the vehicle is sphere
   if (mDataBlock->massBox.x > 0 && mDataBlock->massBox.y > 0 && mDataBlock->massBox.z > 0)
      mRigid.setObjectInertia(mDataBlock->massBox);
   else
      mRigid.setObjectInertia(mObjBox.max - mObjBox.min);

   // Initialize the wheels...
   for (S32 i = 0; i < mDataBlock->wheelCount; i++) {
      Wheel* wheel = &mWheel[i];
      wheel->data = &mDataBlock->wheel[i];
      wheel->tire = 0;
      wheel->spring = 0;

      wheel->surface.contact = false;
      wheel->surface.object  = NULL;
      wheel->avel = 0;
      wheel->apos = 0;
      wheel->extension = 1;
      wheel->slip = 0;

      wheel->springThread = 0;
      wheel->emitter = 0;
      
      // Steering on the front tires by default
      if (wheel->data->pos.y > 0)
         wheel->steering = 1;

      // Build wheel animation threads
      if (wheel->data->springSequence != -1) {
         wheel->springThread = mShapeInstance->addThread();
         mShapeInstance->setSequence(wheel->springThread,wheel->data->springSequence,0);
      }

      // Each wheel get's it's own particle emitter
      if (mDataBlock->tireEmitter) {
         wheel->emitter = new ParticleEmitter;
         wheel->emitter->onNewDataBlock(mDataBlock->tireEmitter);
         wheel->emitter->registerObject();
      }
   }

   // Steering sequence
   if (mDataBlock->steeringSequence != -1) {
      mSteeringThread = mShapeInstance->addThread();
      mShapeInstance->setSequence(mSteeringThread,mDataBlock->steeringSequence,0);
   }
   else
      mSteeringThread = 0;

   // Propeller sequence
   if (mDataBlock->propellerSequence != -1) {
      mPropellerThread = mShapeInstance->addThread();
      mShapeInstance->setSequence(mPropellerThread,mDataBlock->propellerSequence,0);
   }
   else
      mPropellerThread = 0;

   // Elevator sequence
   if (mDataBlock->elevatorSequence != -1) {
      mElevatorThread = mShapeInstance->addThread();
      mShapeInstance->setSequence(mElevatorThread,mDataBlock->elevatorSequence,0);
   }
   else
      mElevatorThread = 0;

   // Break light sequence
   if (mDataBlock->brakeLightSequence != -1) {
      mTailLightThread = mShapeInstance->addThread();
      mShapeInstance->setSequence(mTailLightThread,mDataBlock->brakeLightSequence,0);
   }
   else
      mTailLightThread = 0;

   // Stop any existing sounds in case where switching datablocks
   if (mJetSound) {
      alxStop(mJetSound);
      mJetSound = 0;
   }
   if (mEngineSound) {
      alxStop(mEngineSound);
      mEngineSound = 0;
   }
   if (mSquealSound) {
      alxStop(mSquealSound);
      mSquealSound = 0;
   }
   if (isGhost()) {
      // Start the engine
      if (mDataBlock->sound[WheeledFlyingVehicleData::EngineSound])
         mEngineSound = alxPlay(mDataBlock->sound[WheeledFlyingVehicleData::EngineSound], &getTransform());
   }

   // RFB -> borrowed from FlyingVehicle
   // Jet Sequences
   for (S32 i = 0; i < JetAnimCount; i++) {
      TSShape const* shape = mShapeInstance->getShape();
      mJetSeq[i] = shape->findSequence(sJetSequence[i]);
      if (mJetSeq[i] != -1) {
         if (i == BackActivate || i == BottomActivate) {
            mJetThread[i] = mShapeInstance->addThread();
            mShapeInstance->setSequence(mJetThread[i],mJetSeq[i],0);
            mShapeInstance->setTimeScale(mJetThread[i],0);
         }
      }
      else
         mJetThread[i] = 0;
   }
   // <- RFB
   // RFB -> added
   mMode = mDataBlock->createMode;
   // <- RFB

   scriptOnNewDataBlock();
   return true;
}
// RFB -> adding lights
void WheeledFlyingVehicle::registerLights(LightManager * lightManager, bool lightingScene)
{
   if(lightingScene)
      return;

   Point3F defaultDir(0.57f,0.57f,-0.57f);

   for (S32 k=0; k<WheeledFlyingVehicleData::MaxLights; k++)
   {
      if (mDataBlock->lightNode[k] != -1)
	  {
	     // if the light was pointing at shapebase object and is turned off
	     // then reset the light direction on the object
	     //if (mLightOn[k] == false)
		 //{
		 //   ShapeBase* ptr;
         //   if (mPrevObjectId[k] != -1 && Sim::findObject(mPrevObjectId[k], ptr))
		 //	{
		 //	   ptr->setLightDirection(defaultDir);
         //      mPrevObjectId[k] = -1;
		 //	}
         //   continue;
		 //}

		 MatrixF mat;
		 mat.mul(getRenderTransform(), 
		    mShapeInstance->mNodeTransforms[mDataBlock->lightNode[k]]);
         mat.getColumn(3,&mLight[k].mPos);
		 mat.getColumn(1,&mLight[k].mDirection);

		 // if lightDistance > 0 then we're casting a ray from the light node
		 // in the model to some point in space in front of the car. The angle
		 // at which the ray is cast is determined by the node transform. If
		 // we hit something, then we will adjust the distance at which we
		 // will register the light.
		 if (mDataBlock->lightDistance[k] > 0)
		 {
			 VectorF scale = mLight[k].mDirection * mDataBlock->lightDistance[k];
             VectorF endPoint = mLight[k].mPos + scale;
			 RayInfo rInfo;
		     if (getContainer()->castRay(mLight[k].mPos, endPoint,
                                      sClientCollisionMask,
                                      &rInfo) == true)
		     {
			    //ShapeBase* obj = dynamic_cast<ShapeBase*>(rInfo.object);
				//S32 objId = rInfo.object->getId();
				//if (obj)
				//{
				//	if (objId != mPrevObjectId[k])
				//	{
				//	   ShapeBase* ptr;
			    //       if (mPrevObjectId[k] != -1 && Sim::findObject(mPrevObjectId[k], ptr))
                //          ptr->setLightDirection(defaultDir);
				//	   obj->setLightDirection(mLight[k].mDirection);
				//	   mPrevObjectId[k] = objId;
				//	}
				//	else
				//	   obj->setLightDirection(mLight[k].mDirection);
				//}
				//else
				//{
                //   ShapeBase* ptr;
                //   if (mPrevObjectId[k] != -1 && Sim::findObject(mPrevObjectId[k], ptr)) {
			    //      ptr->setLightDirection(defaultDir);
				//      mPrevObjectId[k] = -1;
				//   } 
				//}
			    mLight[k].mPos = rInfo.point;
		     }
			 //else
			 //{
			 //   ShapeBase* ptr;
		     //   if (mPrevObjectId[k] != -1 && Sim::findObject(mPrevObjectId[k], ptr)) {
			 //      ptr->setLightDirection(defaultDir);
			 //      mPrevObjectId[k] = -1;
			 //   } 
             //   mLight[k].mPos = endPoint;
	         //}
		 }
         //
		 mLight[k].mType = LightInfo::Point;
		 mLight[k].mRadius = mDataBlock->lightRadius[k];

		 F32 intensity;
         switch(mDataBlock->lightType[k])
         {
            case ConstantLight:
               intensity = mFadeVal;
               break;
         
            case PulsingLight:
            {
               F32 delta = Sim::getCurrentTime() - mLightTime;
               intensity = 0.5f + 0.5f * mSin(M_PI * delta / F32(mDataBlock->lightTime[k]));
               intensity = 0.15f + intensity * 0.85f;
               intensity *= mFadeVal;  // fade out light on flags
               break;
            }

            default:
               return;
         }
         mLight[k].mColor  = mDataBlock->lightColor[k] * intensity;
		 		 
		 lightManager->addLight(&mLight[k]);
      }
   }
}
// <- RFB
//----------------------------------------------------------------------------

S32 WheeledFlyingVehicle::getWheelCount()
{
   // Return # of hubs defined on the car body
   return mDataBlock? mDataBlock->wheelCount: 0;
}

void WheeledFlyingVehicle::setWheelSteering(S32 wheel,F32 steering)
{
   AssertFatal(wheel >= 0 && wheel < WheeledFlyingVehicleData::MaxWheels,"Wheel index out of bounds");
   mWheel[wheel].steering = mClampF(steering,-1,1);
   setMaskBits(WheelMask);
}

void WheeledFlyingVehicle::setWheelPowered(S32 wheel,bool powered)
{
   AssertFatal(wheel >= 0 && wheel < WheeledFlyingVehicleData::MaxWheels,"Wheel index out of bounds");
   mWheel[wheel].powered = powered;
   setMaskBits(WheelMask);
}

void WheeledFlyingVehicle::setWheelTire(S32 wheel,WheeledVehicleTire* tire)
{
   AssertFatal(wheel >= 0 && wheel < WheeledFlyingVehicleData::MaxWheels,"Wheel index out of bounds");
   mWheel[wheel].tire = tire;
   setMaskBits(WheelMask);
}

void WheeledFlyingVehicle::setWheelSpring(S32 wheel,WheeledVehicleSpring* spring)
{
   AssertFatal(wheel >= 0 && wheel < WheeledFlyingVehicleData::MaxWheels,"Wheel index out of bounds");
   mWheel[wheel].spring = spring;
   setMaskBits(WheelMask);
}


//----------------------------------------------------------------------------

void WheeledFlyingVehicle::processTick(const Move* move)
{
   F32 speed = mRigid.linVelocity.len();
   // RFB -> added, check trigger states and change modes before Parent::processTick so we
   // can pick up on the Trigger states sent to client by shapebase
   // if we're flying, and we press the breaks, we let out the landing gear and switch to driving mode
   if (move && mMode == Flying && speed <= mDataBlock->maxModeChangeSpeed && canChangeMode())
   {
      mMode = Driving;
      mModeChangeDelay = mDataBlock->modeChangeDelay;
      mEnergy -= mDataBlock->modeChangeEnergyDrain;
	  setWheelSteering(0, mDataBlock->maxSteeringAngle);
	  setWheelSteering(1, mDataBlock->maxSteeringAngle);
	  //if (isGhost() && mMode != mPrevMode)
	  //{
      //   char buff[32];
	  //   dSprintf(buff,sizeof(buff),"%s",sMode[mMode]);
	  //   Con::executef(mDataBlock,3,"onModeChanged",scriptThis(), buff);
	  //}
	  //mPrevMode = mMode;
   }
   // if we're driving and we apply the jets, we retract the landing gear and switch into flying mode
   else if (move && mMode == Driving && speed >= mDataBlock->minModeChangeSpeed && canChangeMode())
   {
      mMode = Flying;
      mModeChangeDelay = mDataBlock->modeChangeDelay;
      mEnergy -= mDataBlock->modeChangeEnergyDrain;
	  setWheelSteering(0, 0);
	  setWheelSteering(1, 0);
	  //if (isGhost() && mMode != mPrevMode)
	  //{
	  //   char buff[32];
	  //   dSprintf(buff,sizeof(buff),"%s",sMode[mMode]);
	  //   Con::executef(mDataBlock,3,"onModeChanged",scriptThis(), buff);
	  //}
      //mPrevMode = mMode;
   }
   else
   {
      mModeChangeDelay--;
	  if (mModeChangeDelay < 0)
	     mModeChangeDelay = 0;
   }
   // <- RFB

   Parent::processTick(move);
}

// RFB -> added
bool WheeledFlyingVehicle::canChangeMode()
{
   F32 speed = mRigid.linVelocity.len();
   return mDamageState == Enabled && mModeChangeDelay == 0 && mEnergy >= mDataBlock->minModeChangeEnergy; /* &&  speed >= mDataBlock->minModeChangeSpeed && speed <= mDataBlock->maxModeChangeSpeed; */
}
// <- RFB

void WheeledFlyingVehicle::updateMove(const Move* move)
{
   Parent::updateMove(move);

   if (mMode == Driving)
   {
      // Break on trigger
      mBraking = move->trigger[2];

      // Set the tail brake light thread direction based on the brake state.
      if (mTailLightThread)
         mShapeInstance->setTimeScale(mTailLightThread,mBraking? 1: -1);
   }
   else // flying
   {
      if (move == &NullMove)
         mSteering.set(0,0);

	  // Diving flag
      mDiving = move->trigger[4];

      F32 speed = mRigid.linVelocity.len();
      if (speed < mDataBlock->maxAutoSpeed)
         mSteering *= mDataBlock->autoInputDamping;

      // Check the mission area to get the factor for the flight ceiling
      MissionArea * obj = dynamic_cast<MissionArea*>(Sim::findObject("MissionArea"));
      mCeilingFactor = 1.0f;
      if (obj != NULL)
      { 
         F32 flightCeiling = obj->getFlightCeiling();
         F32 ceilingRange  = obj->getFlightCeilingRange();

         if (mRigid.linPosition.z > flightCeiling)
         {
            // Thrust starts to fade at the ceiling, and is 0 at ceil + range
            if (ceilingRange == 0)
            {
               mCeilingFactor = 0;
            }
            else
            {
               mCeilingFactor = 1.0f - ((mRigid.linPosition.z - flightCeiling) / (flightCeiling + ceilingRange));
               if (mCeilingFactor < 0.0f)
                  mCeilingFactor = 0.0f;
            }
         }
      }

      mThrust.x = move->x;
	  // RFB ->
      //mThrust.y = move->y;
	  mThrust.y = 1;
	  // <- RFB

      if (mThrust.y != 0.0f)
         if (mThrust.y > 0)
            mThrustDirection = ThrustForward;
         else
            mThrustDirection = ThrustBackward;
      // RFB 02-20-2005 -> provisions for additional thrust directions
      else {
         if (mDiving)
            mThrustDirection = ThrustUp;
         else
            mThrustDirection = ThrustDown;
      }
      // <- RFB 02-20-2005

      if (mCeilingFactor != 1.0f)
         mJetting = false;
   }
}


//----------------------------------------------------------------------------

void WheeledFlyingVehicle::advanceTime(F32 dt)
{
   Parent::advanceTime(dt);

   if (mMode == Driving)
   {
      // Stick the wheels to the ground.  This is purely so they look
      // good while the vehicle is being interpolated.
      extendWheels();

      // Update wheel angular position and slip, this is a client visual
      // feature only, it has no affect on the physics.
      F32 slipTotal = 0;
      F32 torqueTotal = 0;

      Wheel* wend = &mWheel[mDataBlock->wheelCount];
      for (Wheel* wheel = mWheel; wheel < wend; wheel++)
         if (wheel->tire && wheel->spring) {
            // Update angular position
            wheel->apos += (wheel->avel * dt) / M_2PI;
            wheel->apos -= mFloor(wheel->apos);
            if (wheel->apos < 0)
               wheel->apos = 1 - wheel->apos;

            // Keep track of largest slip
            slipTotal += wheel->slip;
            torqueTotal += wheel->torqueScale;
         }

      // Update the sounds based on wheel slip and torque output
      updateSquealSound(slipTotal / mDataBlock->wheelCount);
      updateEngineSound(sIdleEngineVolume + (1 - sIdleEngineVolume) *
         (1 - (torqueTotal / mDataBlock->wheelCount)));
      updateJetSound();

      updateWheelThreads();
      updateWheelParticles(dt);

      // Animate the tail light. The direction of the thread is
      // set based on vehicle braking.
      if (mTailLightThread)
         mShapeInstance->advanceTime(dt,mTailLightThread);
   }
   else // flying
   {
      // Withdraw the wheels.  This is purely so they look
      // good while the vehicle is flying.
      withdrawWheels();
	  updateEngineSound(1);
      updateJet(dt);
      updateWheelThreads();
      updateWheelParticles(dt);
   }

   // Update the steering animation: sequence time 0 is full right,
   // and time 0.5 is straight ahead.
   if (mSteeringThread) {
      F32 t = (mSteering.x * mFabs(mSteering.x)) / mDataBlock->maxSteeringAngle;
      mShapeInstance->setPos(mSteeringThread,0.5 - t * 0.5);
   }

   if (mPropellerThread) {
	   mShapeInstance->setTimeScale(mPropellerThread, 1);
	   mShapeInstance->advanceTime(dt*mThrottleLevel, mPropellerThread);
   }

   // Update the steering animation: sequence time 0 is full right,
   // and time 0.5 is straight ahead.
   if (mElevatorThread) {
      F32 t = (mSteering.y * mFabs(mSteering.y)) / mDataBlock->maxFlightSteeringAngle;
      mShapeInstance->setPos(mElevatorThread,0.5 - t * 0.5);
   }
}   


//----------------------------------------------------------------------------
/** Update the rigid body forces on the vehicle
   This method calculates the forces acting on the body, including gravity,
   suspension & tire forces.
*/
void WheeledFlyingVehicle::updateForces(F32 dt)
{
   if (mMode == Driving)
   {
      extendWheels();

      F32 oneOverSprungMass = 1 / (mMass * 0.8);
      F32 aMomentum = mMass / mDataBlock->wheelCount;

      // Get the current matrix and extact vectors
      MatrixF currMatrix;
      mRigid.getTransform(&currMatrix);

      Point3F bx,by,bz;
      currMatrix.getColumn(0,&bx);
      currMatrix.getColumn(1,&by);
      currMatrix.getColumn(2,&bz);

      // Steering angles from current steering wheel position
      F32 quadraticSteering = -(mSteering.x * mFabs(mSteering.x));
      F32 cosSteering,sinSteering;
      mSinCos(quadraticSteering, sinSteering, cosSteering);

      // Calculate Engine and brake torque values used later by in
      // wheel calculations.
      F32 engineTorque,brakeVel;
      if (mBraking) {
         brakeVel = (mDataBlock->brakeTorque / aMomentum) * dt;
         engineTorque = 0;
      }
      else {
         if (mThrottleLevel) {
            engineTorque = mDataBlock->engineTorque * mThrottleLevel;
            brakeVel = 0;
            // Double the engineTorque to help out the jets
            if (mThrottleLevel > 0 && mJetting)
               engineTorque *= 2;
         }
         else {
            // Engine break.
            brakeVel = (mDataBlock->engineBrake / aMomentum) * dt;
            engineTorque = 0;
         }
      }

      // Integrate forces, we'll do this ourselves here instead of
      // relying on the rigid class which does it during movement.
      Wheel* wend = &mWheel[mDataBlock->wheelCount];
      mRigid.force.set(0, 0, 0);
      mRigid.torque.set(0, 0, 0);

      // Calculate vertical load for friction.  Divide up the spring
      // forces across all the wheels that are in contact with
      // the ground.
      U32 contactCount = 0;
      F32 verticalLoad = 0;
      for (Wheel* wheel = mWheel; wheel < wend; wheel++) {
         if (wheel->tire && wheel->spring && wheel->surface.contact) {
            verticalLoad += wheel->spring->force * (1 - wheel->extension);
            contactCount++;
         }
      }
      if (contactCount)
         verticalLoad /= contactCount;

      // Sum up spring and wheel torque forces
      for (Wheel* wheel = mWheel; wheel < wend; wheel++)  {
         if (!wheel->tire || !wheel->spring)
            continue;

         F32 Fy = 0;
         if (wheel->surface.contact) {

            // First, let's compute the wheel's position, and worldspace velocity
            Point3F pos, r, localVel;
            currMatrix.mulP(wheel->data->pos, &pos);
            mRigid.getOriginVector(pos,&r);
            mRigid.getVelocity(r, &localVel);

            // Spring force & damping
            F32 spring  = wheel->spring->force * (1 - wheel->extension);
            F32 damping = wheel->spring->damping * -(mDot(bz, localVel) / wheel->spring->length);
            if (damping < 0)
               damping = 0;

            // Anti-sway force based on difference in suspension extension
            F32 antiSway = 0;
            if (wheel->data->opposite != -1) {
               Wheel* oppositeWheel = &mWheel[wheel->data->opposite];
               if (oppositeWheel->surface.contact)
                  antiSway = ((oppositeWheel->extension - wheel->extension) *
                     wheel->spring->antiSway);
               if (antiSway < 0)
                  antiSway = 0;
            }

            // Spring forces act straight up and are applied at the
            // spring's root position.
            Point3F t, forceVector = bz * (spring + damping + antiSway);
            mCross(r, forceVector, &t);
            mRigid.torque += t;
            mRigid.force += forceVector;

            // Tire direction vectors perpendicular to surface normal
            Point3F wheelXVec = bx * cosSteering;
            wheelXVec += by * sinSteering * wheel->steering;
            Point3F tireX, tireY;
            mCross(wheel->surface.normal, wheelXVec, &tireY);
            tireY.normalize();
            mCross(tireY, wheel->surface.normal, &tireX);
            tireX.normalize();

            // Velocity of tire at the surface contact
            Point3F wheelContact, wheelVelocity;
            mRigid.getOriginVector(wheel->surface.pos,&wheelContact);
            mRigid.getVelocity(wheelContact, &wheelVelocity);
	           F32 xVelocity = mDot(tireX, wheelVelocity);
            F32 yVelocity = mDot(tireY, wheelVelocity);

            // Tires act as springs and generate lateral and longitudinal
            // forces to move the vehicle. These distortion/spring forces
            // are what convert wheel angular velocity into forces that
            // act on the rigid body.

            // Longitudinal tire deformation force
            F32 ddy = (wheel->avel * wheel->tire->radius - yVelocity) -
               wheel->tire->longitudinalRelaxation *
               mFabs(wheel->avel) * wheel->Dy;
            wheel->Dy += ddy * dt;
            Fy = (wheel->tire->longitudinalForce * wheel->Dy +
               wheel->tire->longitudinalDamping * ddy);

            // Lateral tire deformation force
            F32 ddx = xVelocity - wheel->tire->lateralRelaxation *
               mFabs(wheel->avel) * wheel->Dx;
            wheel->Dx += ddx * dt;
            F32 Fx = -(wheel->tire->lateralForce * wheel->Dx +
               wheel->tire->lateralDamping * ddx);

            // Vertical load on the tire
            verticalLoad = spring + damping + antiSway;
            if (verticalLoad < 0)
               verticalLoad = 0;

            // Adjust tire forces based on friction
            F32 surfaceFriction = 1;
            F32 mu = surfaceFriction * (wheel->slipping)?
               wheel->tire->kineticFriction:
               wheel->tire->staticFriction;
            F32 Fn = verticalLoad * mu; Fn *= Fn;
            F32 Fw = Fx * Fx + Fy * Fy;
            if (Fw > Fn) {
               F32 K = mSqrt(Fn / Fw);
               Fy *= K;
               Fx *= K;
               wheel->Dy *= K;
               wheel->Dx *= K;
               wheel->slip = 1 - K;
               wheel->slipping = true;
            }
            else {
               wheel->slipping = false;
               wheel->slip = 0;
            }

            // Tire forces act through the tire direction vectors parallel
            // to the surface and are applied at the wheel hub.
            forceVector = (tireX * Fx) + (tireY * Fy);
            pos -= bz * (wheel->spring->length * wheel->extension);
            mRigid.getOriginVector(pos,&r);
            mCross(r, forceVector, &t);
            mRigid.torque += t;
            mRigid.force += forceVector;
         }
         else {
            // Wheel not in contact with the ground
            wheel->torqueScale  = 0;
            wheel->slip = 0;

            // Relax the tire deformation
            wheel->Dy += (-wheel->tire->longitudinalRelaxation *
                          mFabs(wheel->avel) * wheel->Dy) * dt;
            wheel->Dx += (-wheel->tire->lateralRelaxation *
                          mFabs(wheel->avel) * wheel->Dx) * dt;
         }

         // Adjust the wheel's angular velocity based on engine torque
         // and tire deformation forces.
         if (wheel->powered) {
            F32 maxAvel = mDataBlock->maxWheelSpeed / wheel->tire->radius;
            wheel->torqueScale = (mFabs(wheel->avel) > maxAvel) ? 0 :
               1 - (mFabs(wheel->avel) / maxAvel);
         }
         else
            wheel->torqueScale = 0;
         wheel->avel += (((wheel->torqueScale * engineTorque) - Fy *
            wheel->tire->radius) / aMomentum) * dt;

         // Adjust the wheel's angular velocity based on break torque.
         // This is done after avel update to make sure we come to a
         // complete stop.
         if (brakeVel > mFabs(wheel->avel))
            wheel->avel = 0;
         else
            if (wheel->avel > 0)
               wheel->avel -= brakeVel;
            else
               wheel->avel += brakeVel;
      }

      // Jet Force
      if (mJetting)
         mRigid.force += by * mDataBlock->jetForce;

      // Container drag & buoyancy
      mRigid.force  += Point3F(0, 0, -mBuoyancy * sWheeledFlyingVehicleGravity * mRigid.mass);
      mRigid.force  -= mRigid.linVelocity * mDrag;
      mRigid.torque -= mRigid.angMomentum * mDrag;

      // If we've added anything other than gravity, then we're no
      // longer at rest. Could test this a little more efficiently...
      if (mRigid.atRest && (mRigid.force.len() || mRigid.torque.len()))
         mRigid.atRest = false;

      // Gravity
      mRigid.force += Point3F(0, 0, sWheeledFlyingVehicleGravity * mRigid.mass);

      // Integrate and update velocity
      mRigid.linMomentum += mRigid.force * dt;
      mRigid.angMomentum += mRigid.torque * dt;
      mRigid.updateVelocity();

      // Since we've already done all the work, just need to clear this out.
      mRigid.force.set(0, 0, 0);
      mRigid.torque.set(0, 0, 0);

      // If we're still atRest, make sure we're not accumulating anything
      if (mRigid.atRest)
         mRigid.setAtRest();
   }
   else // flying
   {
      MatrixF currPosMat;
      mRigid.getTransform(&currPosMat);
      mRigid.atRest = false;

      Point3F massCenter;
      currPosMat.mulP(mDataBlock->massCenter,&massCenter);

      Point3F xv,yv,zv;
      currPosMat.getColumn(0,&xv);
      currPosMat.getColumn(1,&yv);
      currPosMat.getColumn(2,&zv);
      F32 speed = mRigid.linVelocity.len();

	  // RFB 02-22-2005 -> when our speed drops sufficiently, we should drop like a rock
      F32 speedInducedGravity = sWheeledFlyingVehicleGravity;
      if (speed)
	     speedInducedGravity *= 1 / speed;
      Point3F force  = Point3F(0, 0, speedInducedGravity * mRigid.mass * mGravityMod);
      //Point3F force  = Point3F(0, 0, sWheeledFlyingVehicleGravity * mRigid.mass * mGravityMod);
      // <- RFB 02-22-2005
      
      Point3F torque = Point3F(0, 0, 0);

      // Drag at any speed
      force  -= mRigid.linVelocity * mDataBlock->minDrag;
      torque -= mRigid.angMomentum * mDataBlock->rotationalDrag;

      // Auto-stop at low speeds
      if (speed < mDataBlock->maxAutoSpeed) {
         F32 autoScale = 1 - speed / mDataBlock->maxAutoSpeed;

         // Gyroscope
         F32 gf = mDataBlock->autoAngularForce * autoScale;
         torque -= xv * gf * mDot(yv,Point3F(0,0,1));

         // Manuevering jets
         F32 sf = mDataBlock->autoLinearForce * autoScale;
         force -= yv * sf * mDot(yv, mRigid.linVelocity);
         force -= xv * sf * mDot(xv, mRigid.linVelocity);
      }

      // RFB ->
	  // Hovering Jet
      //F32 vf = -sWheeledFlyingVehicleGravity * mRigid.mass * mGravityMod;
      //F32 h  = getHeight();
      //if (h <= 1) {
      //   if (h > 0) {
      //      vf -= vf * h * 0.1;
      //   } else {
      //      vf += mDataBlock->jetForce * -h;
      //   }
      //}
      //force += zv * vf;
	  // <- RFB

      // Damping "surfaces"
      force -= xv * speed * mDot(xv,mRigid.linVelocity) * mDataBlock->horizontalSurfaceForce;
      force -= zv * speed * mDot(zv,mRigid.linVelocity) * mDataBlock->verticalSurfaceForce;

      // Turbo Jet
      if (mJetting) {
         if (mThrustDirection == ThrustForward)
            force += yv * mDataBlock->jetForce * mCeilingFactor;
         else if (mThrustDirection == ThrustBackward)
            force -= yv * mDataBlock->jetForce * mCeilingFactor;
         //else
         //   force += zv * mDataBlock->jetForce * mDataBlock->vertThrustMultiple * mCeilingFactor;
      }

      // Maneuvering jets
	  F32 currManeuveringForce;
	  switch (mThrottleLevel)
	  {
	  case ThrottleSlow:
	     currManeuveringForce = mDataBlock->maneuveringForce1;
		 break;
	  case ThrottleMedium:
		 currManeuveringForce = mDataBlock->maneuveringForce2;
		 break;
	  case ThrottleFast:
		 currManeuveringForce = mDataBlock->maneuveringForce3;
		 break;
	  }

	  // RFB 02-22-2005 -> support for various speeds
	  force += yv * (currManeuveringForce * mCeilingFactor);
	  //force += xv * (mThrust.x * currManeuveringForce * mCeilingFactor);
	  // <- RFB 02-22-2005

      // Steering
      Point2F steering;
      steering.x = mSteering.x / mDataBlock->maxFlightSteeringAngle;
      steering.x *= mFabs(steering.x);
      steering.y = mSteering.y / mDataBlock->maxFlightSteeringAngle;
      steering.y *= mFabs(steering.y);
      torque -= xv * steering.y * mDataBlock->steeringForce;
      torque -= zv * steering.x * mDataBlock->steeringForce;

	  // RFB 02-22-2005 -> auto-pitch
      VectorF vec = mRigid.linVelocity;
      //vec.normalize();
      //F32 speed = mRigid.linVelocity.len();
      if (mDiving)
         torque -= xv * speed * mDataBlock->steeringForce * SPEED_PITCH_SCALE;
      else if (mJetting)
         torque += xv * speed * mDataBlock->steeringForce * SPEED_PITCH_SCALE;
      // <- RFB 02-22-2005

      // Roll
      torque += yv * steering.x * mDataBlock->steeringRollForce;
      F32 ar = mDataBlock->autoAngularForce * mDot(xv,Point3F(0,0,1));
      ar -= mDataBlock->rollForce * mDot(xv, mRigid.linVelocity);
      torque += yv * ar;

      // Add in force from physical zones...
      force += mAppliedForce;

      // Container buoyancy & drag
      force -= Point3F(0, 0, 1) * (mBuoyancy * sWheeledFlyingVehicleGravity * mRigid.mass * mGravityMod);
      force -= mRigid.linVelocity * mDrag;
   
      //
      mRigid.force  = force;
      mRigid.torque = torque;
   }
}


//----------------------------------------------------------------------------
/** Extend the wheels
   The wheels are extended until they contact a surface. The extension
   is instantaneous.  The wheels are extended before force calculations and
   also on during client side interpolation (so that the wheels are glued
   to the ground).
*/
void WheeledFlyingVehicle::extendWheels()
{
   disableCollision();

   MatrixF currMatrix;
   mRigid.getTransform(&currMatrix);

   // Does a single ray cast down for now... this will have to be
   // changed to something a little more complicated to avoid getting
   // stuck in cracks.
   Wheel* wend = &mWheel[mDataBlock->wheelCount];
   for (Wheel* wheel = mWheel; wheel < wend; wheel++) {
      if (wheel->tire && wheel->spring) {
         wheel->extension = 1;

         // The ray is cast from the spring mount point to the tip of
         // the tire.  If there is a collision the spring extension is
         // adjust to remove the tire radius.
         Point3F sp,vec;
         currMatrix.mulP(wheel->data->pos,&sp);
         currMatrix.mulV(VectorF(0,0,-wheel->spring->length),&vec);
         F32 ts = wheel->tire->radius / wheel->spring->length;
         Point3F ep = sp + (vec * (1 + ts));
         ts = ts / (1+ts);

         RayInfo rInfo;
         if (mContainer->castRay(sp, ep, sClientCollisionMask & ~PlayerObjectType, &rInfo)) {
            wheel->surface.contact  = true;
            wheel->extension = (rInfo.t < ts)? 0: (rInfo.t - ts) / (1 - ts);
            wheel->surface.normal   = rInfo.normal;
            wheel->surface.pos      = rInfo.point;
            wheel->surface.material = rInfo.material;
            wheel->surface.object   = rInfo.object;
         }
         else {
            wheel->surface.contact = false;
            wheel->slipping = true;
         }
      }
   }
   enableCollision();
}

// RFB -> added
/** Withdraw the wheels
   The wheels are withdraw until they contact a surface. The extension
   is instantaneous.  The wheels are extended before force calculations and
   also on during client side interpolation (so that the wheels are glued
   to the ground).
*/
void WheeledFlyingVehicle::withdrawWheels()
{
   disableCollision();

   MatrixF currMatrix;
   mRigid.getTransform(&currMatrix);

   // Does a single ray cast down for now... this will have to be
   // changed to something a little more complicated to avoid getting
   // stuck in cracks.
   Wheel* wend = &mWheel[mDataBlock->wheelCount];
   for (Wheel* wheel = mWheel; wheel < wend; wheel++) {
      if (wheel->tire && wheel->spring) {
         wheel->extension = 0;
         /*
         // The ray is cast from the spring mount point to the tip of
         // the tire.  If there is a collision the spring extension is
         // adjust to remove the tire radius.
         Point3F sp,vec;
         currMatrix.mulP(wheel->data->pos,&sp);
         currMatrix.mulV(VectorF(0,0,-wheel->spring->length),&vec);
         F32 ts = wheel->tire->radius / wheel->spring->length;
         Point3F ep = sp + (vec * (1 + ts));
         ts = ts / (1+ts);

         RayInfo rInfo;
         if (mContainer->castRay(sp, ep, sClientCollisionMask & ~PlayerObjectType, &rInfo)) {
            wheel->surface.contact  = true;
            wheel->extension = (rInfo.t < ts)? 0: (rInfo.t - ts) / (1 - ts);
            wheel->surface.normal   = rInfo.normal;
            wheel->surface.pos      = rInfo.point;
            wheel->surface.material = rInfo.material;
            wheel->surface.object   = rInfo.object;
         }
         else {
            wheel->surface.contact = false;
            wheel->slipping = true;
         }
		 */
      }
   }
   enableCollision();
}
// <- RFB


//----------------------------------------------------------------------------
/** Update wheel steering and suspension threads.
   These animations are purely cosmetic and this method is only invoked
   on the client.
*/
void WheeledFlyingVehicle::updateWheelThreads()
{
   Wheel* wend = &mWheel[mDataBlock->wheelCount];
   for (Wheel* wheel = mWheel; wheel < wend; wheel++) {
      if (wheel->tire && wheel->spring && wheel->springThread) {
         // Scale the spring animation time to match the current
         // position of the wheel.  We'll also check to make sure
         // the animation is long enough, if it isn't, just stick
         // it at the end.
         F32 pos = wheel->extension * wheel->spring->length;
         if (pos > wheel->data->springLength)
            pos = 1;
         else
            pos /= wheel->data->springLength;
         mShapeInstance->setPos(wheel->springThread,pos);
      }
   }
}

//----------------------------------------------------------------------------
/** Update wheel particles effects
   These animations are purely cosmetic and this method is only invoked
   on the client.  Particles are emitted as long as the moving.
*/
void WheeledFlyingVehicle::updateWheelParticles(F32 dt)
{
   Point3F vel = Parent::getVelocity();
   F32 speed = vel.len();
   if (speed > 1.0f)  {
      MaterialPropertyMap* matMap = static_cast<MaterialPropertyMap*>
         (Sim::findObject("MaterialPropertyMap"));
      Point3F axis = vel;
      axis.normalize();

      // Only emit dust on the terrain
      Wheel* wend = &mWheel[mDataBlock->wheelCount];
      for (Wheel* wheel = mWheel; wheel < wend; wheel++) {
         if (wheel->tire && wheel->spring && !wheel->emitter.isNull() &&
               wheel->surface.contact && wheel->surface.object &&
               wheel->surface.object->getTypeMask() & TerrainObjectType) {
            TerrainBlock* tBlock = static_cast<TerrainBlock*>(wheel->surface.object);
            S32 mapIndex = tBlock->mMPMIndex[0];

            // Override the dust color with the material property
            const MaterialPropertyMap::MapEntry* pEntry;
            if (matMap && mapIndex != -1 && 
                  (pEntry = matMap->getMapEntryFromIndex(mapIndex)) != 0) {
               ColorF colorList[ParticleEngine::PC_COLOR_KEYS];
               for (S32 x = 0; x < 2; ++x)
                  colorList[x].set(pEntry->puffColor[x].red,
                     pEntry->puffColor[x].green,
                     pEntry->puffColor[x].blue,
                     pEntry->puffColor[x].alpha);
               for(S32 x = 2; x < ParticleEngine::PC_COLOR_KEYS; ++x)
                  colorList[x].set( 1.0, 1.0, 1.0, 0.0 );
               wheel->emitter->setColors( colorList );
            }

            // Emit the dust, the density (time) is scaled by the
            // the vehicles velocity.
            wheel->emitter->emitParticles(wheel->surface.pos,true,
               axis, vel, dt * (speed / mDataBlock->maxWheelSpeed) * 1000 * wheel->slip);
         }
      }
   }
}


//----------------------------------------------------------------------------
/** Update engine sound
   This method is only invoked by clients.
*/
void WheeledFlyingVehicle::updateEngineSound(F32 level)
{
   if (mEngineSound) {
      alxSourceMatrixF(mEngineSound, &getTransform());
      alxSourcef(mEngineSound, AL_GAIN_LINEAR, level);
   }
}


//----------------------------------------------------------------------------
/** Update wheel skid sound
   This method is only invoked by clients.
*/
void WheeledFlyingVehicle::updateSquealSound(F32 level)
{
   if (!mDataBlock->sound[WheeledFlyingVehicleData::SquealSound])
      return;
   // Allocate/Deallocate voice on demand.
   if (level < sMinSquealVolume) {
      if (mSquealSound) {
         alxStop(mSquealSound);
         mSquealSound = 0;
      }
   }
   else {
      if (!mSquealSound)
         mSquealSound = alxPlay(mDataBlock->sound[WheeledFlyingVehicleData::SquealSound], &getTransform());

      alxSourceMatrixF(mSquealSound, &getTransform());
      alxSourcef(mSquealSound, AL_GAIN_LINEAR, level);
   }
}   


//----------------------------------------------------------------------------
/** Update jet sound
   This method is only invoked by clients.
*/
void WheeledFlyingVehicle::updateJetSound()
{
   if (!mDataBlock->sound[WheeledFlyingVehicleData::JetSound])
      return;

   // Allocate/Deallocate voice on demand.
   if (!mJetting) {
      if (mJetSound) {
         alxStop(mJetSound);
         mJetSound = 0;
      }
   }
   else {
      if (!mJetSound)
         mJetSound = alxPlay(mDataBlock->sound[WheeledFlyingVehicleData::JetSound], &getTransform());
      alxSourceMatrixF(mJetSound, &getTransform());
   }
}


//----------------------------------------------------------------------------

U32 WheeledFlyingVehicle::getCollisionMask()
{
   return sClientCollisionMask;
}


//----------------------------------------------------------------------------
/** Build a collision polylist
   The polylist is filled with polygons representing the collision volume
   and the wheels.
*/
bool WheeledFlyingVehicle::buildPolyList(AbstractPolyList* polyList, const Box3F& box, const SphereF& sphere)
{
   // Parent will take care of body collision.
   Parent::buildPolyList(polyList,box,sphere);

   // Add wheels as boxes.
   Wheel* wend = &mWheel[mDataBlock->wheelCount];
   for (Wheel* wheel = mWheel; wheel < wend; wheel++) {
      if (wheel->tire && wheel->spring) {
         Box3F wbox;
         F32 radius = wheel->tire->radius;
         wbox.min.x = -(wbox.max.x = radius / 2);
         wbox.min.y = -(wbox.max.y = radius);
         wbox.min.z = -(wbox.max.z = radius);
         MatrixF mat = mObjToWorld;

         Point3F sp,vec;
         mObjToWorld.mulP(wheel->data->pos,&sp);
         mObjToWorld.mulV(VectorF(0,0,-wheel->spring->length),&vec);
         Point3F ep = sp + (vec * wheel->extension);
         mat.setColumn(3,ep);
         polyList->setTransform(&mat,Point3F(1,1,1));
         polyList->addBox(wbox);
      }
   }
   return !polyList->isEmpty();
}


//----------------------------------------------------------------------------

void WheeledFlyingVehicle::renderImage(SceneState* state, SceneRenderImage* image)
{
   Parent::renderImage(state, image);

   // Shape transform
   glPushMatrix();
   dglMultMatrix(&getRenderTransform());

   Wheel* wend = &mWheel[mDataBlock->wheelCount];
   for (Wheel* wheel = mWheel; wheel < wend; wheel++) {
      if (wheel->shapeInstance) {
         glPushMatrix();

         // Steering & spring extension
         MatrixF hub(EulerF(0,0,mSteering.x * wheel->steering));
         Point3F pos = wheel->data->pos;
         pos.z -= wheel->spring->length * wheel->extension;
         hub.setColumn(3,pos);
         dglMultMatrix(&hub);

         // Wheel rotation
         MatrixF rot(EulerF(wheel->apos * M_2PI,0,0));
         dglMultMatrix(&rot);

		 // Rotation the tire to face the right direction
         // (could pre-calculate this)
         MatrixF wrot(EulerF(0,0,(wheel->data->pos.x > 0)? M_PI/2: -M_PI/2));
         dglMultMatrix(&wrot);
		 		 
         // Render it
         wheel->shapeInstance->animate();
         wheel->shapeInstance->render();
		 glPopMatrix();
      }
   }

   glPopMatrix();
}

// RFB -> borrowed from FlyingVehicle
F32 WheeledFlyingVehicle::getHeight()
{
   Point3F sp,ep;
   RayInfo collision;
   F32 height = (createHeightOn) ? mDataBlock->createHoverHeight : mDataBlock->hoverHeight;
   F32 r = 10 + height;
   getTransform().getColumn(3, &sp);
   ep.x = sp.x;
   ep.y = sp.y;
   ep.z = sp.z - r;
   disableCollision();
   if (!mContainer->castRay(sp,ep,-1,&collision))
      collision.t = 1;
   enableCollision();
   return (r * collision.t - height) / 10;
}

void WheeledFlyingVehicle::updateJet(F32 dt)
{
   // Thrust Animation threads 
   //  Back
   if (mJetSeq[BackActivate] >=0 ) {
      if(!mBackMaintainOn || mThrustDirection != ThrustForward) {
         if(mBackMaintainOn) {
            mShapeInstance->setPos(mJetThread[BackActivate], 1);
            mShapeInstance->destroyThread(mJetThread[BackMaintain]); 
            mBackMaintainOn = false;
         }
         mShapeInstance->setTimeScale(mJetThread[BackActivate],
            (mThrustDirection == ThrustForward)? 1: -1);
         mShapeInstance->advanceTime(dt,mJetThread[BackActivate]);
      }
      if(mJetSeq[BackMaintain] >= 0 && !mBackMaintainOn && 
            mShapeInstance->getPos(mJetThread[BackActivate]) >= 1.0) {
         mShapeInstance->setPos(mJetThread[BackActivate], 0);
         mShapeInstance->setTimeScale(mJetThread[BackActivate], 0);
         mJetThread[BackMaintain] = mShapeInstance->addThread();
         mShapeInstance->setSequence(mJetThread[BackMaintain],mJetSeq[BackMaintain],0);
         mShapeInstance->setTimeScale(mJetThread[BackMaintain],1); 
         mBackMaintainOn = true;
      }         
      if(mBackMaintainOn)    
         mShapeInstance->advanceTime(dt,mJetThread[BackMaintain]);
   }

   // Thrust Animation threads 
   //   Bottom
   if (mJetSeq[BottomActivate] >=0 ) {
      if(!mBottomMaintainOn || mThrustDirection != ThrustDown || !mJetting) {
         if(mBottomMaintainOn) {
            mShapeInstance->setPos(mJetThread[BottomActivate], 1);
            mShapeInstance->destroyThread(mJetThread[BottomMaintain]); 
            mBottomMaintainOn = false;
         }
         mShapeInstance->setTimeScale(mJetThread[BottomActivate],
            (mThrustDirection == ThrustDown && mJetting)? 1: -1);
         mShapeInstance->advanceTime(dt,mJetThread[BottomActivate]);
      }
      if(mJetSeq[BottomMaintain] >= 0 && !mBottomMaintainOn && 
            mShapeInstance->getPos(mJetThread[BottomActivate]) >= 1.0) {
         mShapeInstance->setPos(mJetThread[BottomActivate], 0);
         mShapeInstance->setTimeScale(mJetThread[BottomActivate], 0);
         mJetThread[BottomMaintain] = mShapeInstance->addThread();
         mShapeInstance->setSequence(mJetThread[BottomMaintain],mJetSeq[BottomMaintain],0);
         mShapeInstance->setTimeScale(mJetThread[BottomMaintain],1); 
         mBottomMaintainOn = true;
      }         
      if(mBottomMaintainOn)    
         mShapeInstance->advanceTime(dt,mJetThread[BottomMaintain]);
   }

   // Jet particles
   for (S32 j = 0; j < NumThrustDirections; j++) {
      JetActivation& jet = sJetActivation[j];
      updateEmitter((mJetting || mDiving) && j == mThrustDirection,dt,mDataBlock->jetEmitter[jet.emitter],
                    jet.node,WheeledFlyingVehicleData::MaxDirectionJets);
   }

   // Trail jets
   Point3F yv;
   mObjToWorld.getColumn(1,&yv);
   F32 speed = mFabs(mDot(yv,mRigid.linVelocity));
   F32 trail = 0;
   if (speed > mDataBlock->minTrailSpeed) {
      trail = dt;
      if (speed < mDataBlock->maxSpeed)
         trail *= (speed - mDataBlock->minTrailSpeed) / mDataBlock->maxSpeed;
   }
   updateEmitter(trail,trail,mDataBlock->jetEmitter[WheeledFlyingVehicleData::TrailEmitter],
                 WheeledFlyingVehicleData::TrailNode,WheeledFlyingVehicleData::MaxTrails);

   // Allocate/Deallocate voice on demand.
   if (!mDataBlock->sound[WheeledFlyingVehicleData::JetSound])
      return;
   if (!mJetting) {
      if (mJetSound) {
         alxStop(mJetSound);
         mJetSound = 0;
      }
   }
   else {
      if (!mJetSound)
         mJetSound = alxPlay(mDataBlock->sound[WheeledFlyingVehicleData::JetSound], &getTransform());

      alxSourceMatrixF(mJetSound, &getTransform());
   }
}

//----------------------------------------------------------------------------

void WheeledFlyingVehicle::updateEmitter(bool active,F32 dt,ParticleEmitterData *emitter,S32 idx,S32 count)
{
   if (!emitter)
      return;
   for (S32 j = idx; j < idx + count; j++)
      if (active) {
         if (mDataBlock->jetNode[j] != -1) {
            if (!bool(mJetEmitter[j])) {
               mJetEmitter[j] = new ParticleEmitter;
               mJetEmitter[j]->onNewDataBlock(emitter);
               mJetEmitter[j]->registerObject();
            }
            MatrixF mat;
            Point3F pos,axis;
            mat.mul(getRenderTransform(),
                    mShapeInstance->mNodeTransforms[mDataBlock->jetNode[j]]);
            mat.getColumn(1,&axis);
            mat.getColumn(3,&pos);
            mJetEmitter[j]->emitParticles(pos,true,axis,getVelocity(),dt * 1000);
         }
      }
      else {
         for (S32 j = idx; j < idx + count; j++)
            if (bool(mJetEmitter[j])) {
               mJetEmitter[j]->deleteWhenEmpty();
               mJetEmitter[j] = 0;
            }
      }
}
// <- RFB

//----------------------------------------------------------------------------

void WheeledFlyingVehicle::writePacketData(GameConnection *connection, BitStream *stream)
{
   /* bool ret = */ Parent::writePacketData(connection, stream);
   stream->writeFlag(mBraking);

   Wheel* wend = &mWheel[mDataBlock->wheelCount];
   for (Wheel* wheel = mWheel; wheel < wend; wheel++) {
      stream->write(wheel->avel);
      stream->write(wheel->Dy);
      stream->write(wheel->Dx);
      stream->writeFlag(wheel->slipping);
   }
   //return ret;
}

void WheeledFlyingVehicle::readPacketData(GameConnection *connection, BitStream *stream)
{
   Parent::readPacketData(connection, stream);
   mBraking = stream->readFlag();

   Wheel* wend = &mWheel[mDataBlock->wheelCount];
   for (Wheel* wheel = mWheel; wheel < wend; wheel++) {
      stream->read(&wheel->avel);
      stream->read(&wheel->Dy);
      stream->read(&wheel->Dx);
      wheel->slipping = stream->readFlag();
   }

   // Rigid state is transmitted by the parent...
   setPosition(mRigid.linPosition,mRigid.angPosition);
   mDelta.pos = mRigid.linPosition;
   mDelta.rot[1] = mRigid.angPosition;
}


//----------------------------------------------------------------------------

U32 WheeledFlyingVehicle::packUpdate(NetConnection *con, U32 mask, BitStream *stream)
{
   U32 retMask = Parent::packUpdate(con, mask, stream);

   // Update wheel datablock information
   if (stream->writeFlag(mask & PositionMask)) {
      Wheel* wend = &mWheel[mDataBlock->wheelCount];
      for (Wheel* wheel = mWheel; wheel < wend; wheel++) {
         if (stream->writeFlag(wheel->tire && wheel->spring)) {
            stream->writeRangedU32(wheel->tire->getId(),
               DataBlockObjectIdFirst,DataBlockObjectIdLast);
            stream->writeRangedU32(wheel->spring->getId(),
               DataBlockObjectIdFirst,DataBlockObjectIdLast);
            stream->writeFlag(wheel->powered);
            stream->writeSignedFloat(wheel->steering,16);
         }
      }

	  // RFB -> support for various speeds
      stream->writeInt(mThrottleLevel,2);
      // <- RFB

	  // RFB -> adding lights
	  for (int k=0; k<WheeledFlyingVehicleData::MaxLights; k++)
         stream->writeFlag(mLightOn[k]);
      // <- RFB
   }

   // The rest of the data is part of the control object packet update.
   // If we're controlled by this client, we don't need to send it.
   if (((GameConnection *) con)->getControlObject() == this && !(mask & InitialUpdateMask))
      return retMask;

   stream->writeFlag(mBraking);

   if (stream->writeFlag(mask & PositionMask)) {
      Wheel* wend = &mWheel[mDataBlock->wheelCount];
      for (Wheel* wheel = mWheel; wheel < wend; wheel++) {
         stream->write(wheel->avel);
         stream->write(wheel->Dy);
         stream->write(wheel->Dx);
      }
   }

   // RFB -> borrowed from flyingvehicle
   stream->writeFlag(createHeightOn);

   stream->writeInt(mThrustDirection,NumThrustBits);
   // <- RFB

   return retMask;
}

void WheeledFlyingVehicle::unpackUpdate(NetConnection *con, BitStream *stream)
{
   Parent::unpackUpdate(con,stream);

   // Update wheel datablock information
   if (stream->readFlag()) {
      Wheel* wend = &mWheel[mDataBlock->wheelCount];
      for (Wheel* wheel = mWheel; wheel < wend; wheel++) {
         if (stream->readFlag()) {
            SimObjectId tid = stream->readRangedU32(DataBlockObjectIdFirst,DataBlockObjectIdLast);
            SimObjectId sid = stream->readRangedU32(DataBlockObjectIdFirst,DataBlockObjectIdLast);
            if (!Sim::findObject(tid,wheel->tire) || !Sim::findObject(sid,wheel->spring)) {
               con->setLastError("Invalid packet WheeledFlyingVehicle::unpackUpdate()");
               return;
            }
            wheel->powered = stream->readFlag();
            wheel->steering = stream->readSignedFloat(16);

            // Create an instance of the tire for rendering
            delete wheel->shapeInstance;
            wheel->shapeInstance = (wheel->tire->shape.isNull())? 0:
               new TSShapeInstance(wheel->tire->shape);
         }
      }

	  // RFB -> support for various speeds
      mThrottleLevel = stream->readInt(2);
      // <- RFB

	  // RFB -> adding lights
      for (int k=0; k<WheeledFlyingVehicleData::MaxLights; k++)
         mLightOn[k] = stream->readFlag();
      // <- RFB
   }

   // After this is data that is stuff we don't need if we're the
   // controlling client.
   if (((GameConnection *) con)->getControlObject() == this)
      return;

   mBraking = stream->readFlag();

   if (stream->readFlag()) {
      Wheel* wend = &mWheel[mDataBlock->wheelCount];
      for (Wheel* wheel = mWheel; wheel < wend; wheel++) {
         stream->read(&wheel->avel);
         stream->read(&wheel->Dy);
         stream->read(&wheel->Dx);
      }
   }

   // RFB -> borrowed from flyingvehicle
   createHeightOn = stream->readFlag();            

   mThrustDirection = ThrustDirection(stream->readInt(NumThrustBits));
   // <- RFB
}


//----------------------------------------------------------------------------
// Console Methods
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------

ConsoleMethod(WheeledFlyingVehicle, setWheelSteering, bool, 4, 4, "obj.setWheelSteering(wheel#,float)")
{
   WheeledFlyingVehicle* wv = static_cast<WheeledFlyingVehicle*>(object);
   S32 wheel = dAtoi(argv[2]);
   if (wheel >= 0 && wheel < wv->getWheelCount()) {
      wv->setWheelSteering(wheel,dAtof(argv[3]));
      return true;
   }
   else
      Con::warnf("setWheelSteering: wheel index out of bounds, vehicle has %d hubs",
         argv[3],wv->getWheelCount());
   return false;
}   

ConsoleMethod(WheeledFlyingVehicle, setWheelPowered, bool, 4, 4, "obj.setWheelPowered(wheel#,bool)")
{
   WheeledFlyingVehicle* wv = static_cast<WheeledFlyingVehicle*>(object);
   S32 wheel = dAtoi(argv[2]);
   if (wheel >= 0 && wheel < wv->getWheelCount()) {
      wv->setWheelPowered(wheel,dAtob(argv[3]));
      return true;
   }
   else
      Con::warnf("setWheelPowered: wheel index out of bounds, vehicle has %d hubs",
         argv[3],wv->getWheelCount());
   return false;
}   

ConsoleMethod(WheeledFlyingVehicle, setWheelTire, bool, 4, 4, "obj.setWheelTire(wheel#,tire)")
{
   WheeledFlyingVehicle* wv = static_cast<WheeledFlyingVehicle*>(object);
   WheeledVehicleTire* tire;
   if (Sim::findObject(argv[3],tire)) {
      S32 wheel = dAtoi(argv[2]);
      if (wheel >= 0 && wheel < wv->getWheelCount()) {
         wv->setWheelTire(wheel,tire);
         return true;
      }
      else
         Con::warnf("setWheelTire: wheel index out of bounds, vehicle has %d hubs",
            argv[3],wv->getWheelCount());
   }
   else
      Con::warnf("setWheelTire: %s datablock does not exist (or is not a tire)",argv[3]);
   return false;
}   

ConsoleMethod(WheeledFlyingVehicle, setWheelSpring, bool, 4, 4, "obj.setWheelSpring(wheel#,spring)")
{
   WheeledFlyingVehicle* wv = static_cast<WheeledFlyingVehicle*>(object);
   WheeledVehicleSpring* spring;
   if (Sim::findObject(argv[3],spring)) {
      S32 wheel = dAtoi(argv[2]);
      if (wheel >= 0 && wheel < wv->getWheelCount()) {
         wv->setWheelSpring(wheel,spring);
         return true;
      }
      else
         Con::warnf("setWheelSpring: wheel index out of bounds, vehicle has %d hubs",
            argv[3],wv->getWheelCount());
   }
   else
      Con::warnf("setWheelSpring: %s datablock does not exist (or is not a spring)",argv[3]);
   return false;
}   

ConsoleMethod(WheeledFlyingVehicle, getWheelCount, S32, 2, 2, "obj.getWheelCount()")
{
   WheeledFlyingVehicle* wv = static_cast<WheeledFlyingVehicle*>(object);
   return wv->getWheelCount();
}

// RFB ->
ConsoleMethod(WheeledFlyingVehicle, getMode, const char *, 2, 2, "obj.getMode()")
{
   WheeledFlyingVehicle* wv = static_cast<WheeledFlyingVehicle*>(object);
   char *returnBuffer = Con::getReturnBuffer( 256 );
   dSprintf( returnBuffer, 256, "%s", wv->getMode());

   return returnBuffer;
}

const char* WheeledFlyingVehicle::getMode()
{
   return sMode[mMode];
}

// <- RFB
// RFB -> adding lights
ConsoleMethod(WheeledFlyingVehicle, setLightOn, void, 4, 4, "obj.setLightOn(light, status)")
{
   WheeledFlyingVehicle* wv = static_cast<WheeledFlyingVehicle*>(object);
   if (!wv) return;
   wv->setLightOn(dAtoi(argv[2]), dAtob(argv[3]));
}

void WheeledFlyingVehicle::setLightOn(S32 light, bool status)
{
   // Set Attribute.
   mLightOn[light] = status;
   // Set Config Change Mask.
   if (isServerObject())
      setMaskBits(PositionMask);
}
// <- RFB

// RFB -> borrowed from flyingvehicle
ConsoleMethod(WheeledFlyingVehicle, useCreateHeight, void, 3, 3, "obj.useCreateHeight(bool)")
{
   WheeledFlyingVehicle* wv = static_cast<WheeledFlyingVehicle*>(object);
   if (!wv) return;
   wv->useCreateHeight(dAtoi(argv[2]));
}

void WheeledFlyingVehicle::useCreateHeight(bool val)
{
   createHeightOn = val;
   if (isServerObject())
      setMaskBits(HoverHeight);   
}
// <- RFB

// RFB 02-22-2005 -> support for various speeds
ConsoleMethod(WheeledFlyingVehicle, setThrottleLevel, void, 3, 3, "obj.setThrottleLevel(level)")
{
   WheeledFlyingVehicle* fv = static_cast<WheeledFlyingVehicle*>(object);
   if (!fv) return;
   fv->setThrottleLevel(dAtoi(argv[2]));
}

void WheeledFlyingVehicle::setThrottleLevel(S32 level)
{
   // Set Attribute.
   if (level >= 0 && level < MaxThrottleLevels)
      mThrottleLevel = level;
   // Set Config Change Mask, reuse position mask
   if (isServerObject())
      setMaskBits(PositionMask);
}

ConsoleMethod( WheeledFlyingVehicle, getThrottleLevel, S32, 2, 2, "()"
              "Returns the current throttle level.")
{
   return object->getThrottleLevel();   
}

S32 WheeledFlyingVehicle::getThrottleLevel()
{
   return mThrottleLevel;
}
// <- RFB 02-22-2005
