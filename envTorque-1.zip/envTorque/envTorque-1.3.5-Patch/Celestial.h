#ifndef _DAYCYCLE_H_
#define _DAYCYCLE_H_

#ifndef _NETOBJECT_H_
#include "sim/netObject.h"
#endif
#ifndef _LIGHTMANAGER_H_
#include "sceneGraph/lightManager.h"
#endif
#ifndef _SUN_H_
#include "terrain/sun.h"
#endif
#ifndef _SKY_H_
#include "terrain/sky.h"
#endif

// defines for working with radians and degrees
#ifndef PI
#define PI   (3.141592653589793238462643f)
#endif

#define RADIAN (180/PI)
#define TORADIANS(x) (((x)/360) * (2*PI))
#define TODEGREES(x) (((x)/(2*PI)) * 360)

typedef struct _color_target{
	F32		elevation; // maximum target elevation
	ColorF	color; //normalized 0 = 1.0 ... 
	F32		bandMod;  //6 is max
	ColorF	bandColor;
} COLOR_TARGET, *LPCOLOR_TARGET;
typedef Vector<COLOR_TARGET> COLOR_TARGETS;

/**
	The Celestials class manages the heavens: major lights, minor lights, scene
	lighting effects, celestial object positioning, seasons, and star fields.
*/
class Celestials : public SceneObject
{
public:
	Celestials();
	
	typedef SceneObject Parent;
	
	// Sun position stuff
	void UpdateSunPosition(void);
	// void UpdateSunPosition(fxSunLight *sunLight);
	F32 getAzimuthRads() {return mAzimuth;}
	F32 getElevationRads() {return mElevation;}
	F32 getAzimuthDegrees() {return TODEGREES(mAzimuth);}
	F32 getElevationDegrees() {return TODEGREES(mElevation);}


	// Scene lighting (Adapted from Joshua Ritter's Day/Night cycle code)
	// I changed references to pointers on the basis of principle. ;-)
	void EnableLighting(F32 emissiveScale = 1.0);
	void DisableLighting();
	void GetColor(ColorF& color);
	void InitColors();
	void AddColorTarget(F32 ele, ColorF& color, F32 bandMod, ColorF& bandColor);
	F32 GetIntensity() 
	{ return (mCurrentColor.blue + mCurrentColor.green + mCurrentColor.red) / 3; }

	// Manages scriptable initializations
	static void initPersistFields();

  protected:
   bool onAdd();

private:
	// Get a pointer to the sun's light object
	Sun* GetSunObject();

	// return Azimuth in radians
	F32 Azimuth(F32 viewerLatitude, F32 objectDecline, F32 medianAngle);
	F32 Elevation(F32 viewerLatitude, F32 objectDecline, F32 medianAngle);

	// return number between 0 and 1 representing color variance
	F32 getColorVariance();

public:
	F32 mAzimuth;		// Angle from true north of celestial object in radians
	F32 mElevation;		// Angle from horizon of celestial object in radians
	VectorF mSunVector; // the sun vector
 

	//Accessor Functions for Date and Time variables (SP)
	
	void setSecsPerHour(F32 SecsPerHour);	// In Real-Time Seconds

	void setHoursInDay(U32 HoursInDay);		// In Game-Hours
	void setDaysInWeek(U32 DaysInWeek);		// In Game-Days
	void setDaysInMonth(U32 DaysInMonth);	// In Game-Days
	void setMonthsInYear(U32 MonthsInYear);	// In Game-Months
	
	void setInitialHour(U32 InitialHour);	// In Game-Hours
	void setInitialDay(U32 InitialDay);		// In Game-Days
	void setInitialMonth(U32 InitialMonth);	// In Game-Months
	void setInitialYear(U32 InitialYear);	// In Game-Year
	

		// Conversion Functions
	void setDayLen();		// Conversion based on existing variablese
	void setYearLen();		// Conversion based on existing variablese
	void setTimeOfDay();	// Conversion based on existing variablese
	void setTimeOfYear();	// Conversion based on existing variablese
	
	
	//--

	F32 getSecsPerHour();	// Out Real-Time Seconds

	U32 getHoursInDay();		// Out Game-Hours
	U32 getDaysInWeek();		// Out Game-Days
	U32 getDaysInMonth();	// Out Game-Days
	U32 getMonthsInYear();	// Out Game-Months
	
	U32 getInitialHour();	// Out Game-Hours
	U32 getInitialDay();		// Out Game-Days
	U32 getInitialMonth();	// Out Game-Months
	U32 getInitialYear();	// Out Game-Year

	// No 'Get' for the Conversion Functions
	// If you want it - write it :-P



private:
	// Vars for GameManager Integration (SP)
	
		// *** REAL TIME CONVERSTION FACTOR ***
	F32 mSecsPerHour;	// Real-Time Seconds per Game-Hour

	U32 mHoursInDay;	// Number of Game-Hours per Game-day
	U32 mDaysInWeek;	// Number of Game-Days per Game-Week
	U32 mDaysInMonth;	// Number of Game-Days per Game-Month
	U32 mMonthsInYear;	// Number of Game-Months per Game-Year
	
	U32 mInitialHour;	// Hour of Game-Day at initilization
	U32 mInitialDay;	// Day of Game-Month at initilization
	U32 mInitialMonth;	// Month of Game-Year at initilization
	U32 mInitialYear;	// arbatrairy Game-Year at initilization
	
	

	// Date tracking stuff
	SimTime mStartTime;	// The time this object was created.
	SimTime mDayLen;	// length of day in real world milliseconds
	SimTime mTimeOfDay; // in game milliseconds standard time (one_game_minute = (mDayLen / 24) / 60)	
	U32 mYearLen;		// Length of year in virtual days
	U32 mTimeOfYear;	// Number of days since the last winter equinox

	// Global positioning stuff
	F32 mLongitude;		// longitudinal position of this mission
	F32 mLatitude;		// latitudinal position of this missiion
	F32 mAxisTilt;		// angle between global equator and tropic

	// color management
	COLOR_TARGETS mColorTargets;

public:
	ColorF mCurrentColor;
	F32 mBandMod;
	ColorF mCurrentBandColor;

private:
	// PersistFields preparation
	bool mConvertedToRads; // initPersist takes arguments in degtrees. Have we converted?

public:
	DECLARE_CONOBJECT(Celestials);
};

extern Celestials *gCelestials;

#endif