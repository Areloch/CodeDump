Read Me:

This Resource Currently Includes:

 	- Stand-Alone "GameManager" Scripting Mod (updated)
	- "Enviro-Torque" Patch & Mod for:
		- Integrated day/night cycles
		- Weather
		- Fractal Skies


--------------------------
Installation Instructions:
--------------------------

GameMangaer-2.0
---------------
    As stated before this is the GameManager time/weather only.
It is primarily a scripting mod, However several bug fixes
need to be made to the engine. 


Engine-Setup:
	
       1) approx: line 245  -  precipitation.cc
          fix the spelling of "setPercentange" -> setPercentage
          in precipitation.cc

       2) approx: line 340  -  precipitation.cc
          In precipitation.cc in packUpdate get rid of this chunk of code
<snip> !(mask & ~(DataMask | PercentageMask | StormMask)) </snip>

	and make it just
               if (stream->writeFlag( mask & StormMask))

	3) aprox: line 1428 - sky.cc
CHANGE FROM:
 mTexCoords[y * 5 + x].set ( x * mTextureScale.x + mBaseOffset.x,
                             y * mTextureScale.y + mBaseOffset.y);

TO:
 mTexCoords[y * 5 + x].set ( x * mTextureScale.x + mBaseOffset.x,
                             y * mTextureScale.y - mBaseOffset.y);



	  
Install the Mod:


1. Unzip the resource into your game directory. Any game will do (and this will work with an out-of-the-box starter.fps)
2. Go into the file server/game.cs and in the onServerCreated() function, add the following line:

exec("./gameMgr.cs");


3. In the same file add the following code to the startGame() function:

// Start the GameManager
new ScriptObject(GameManager);
MissionCleanup.add(GameManager);
GameManager.init();


4. Add the following line to the endGame() function:

// Stop the GameManager
GameManager.delete();


1) In: clients/scripts/default.bind.cs
	Call clients/scripts/gm_KeyBinds.cs with:
		exec("./gm_KeyBinds.cs");

5. Launch the game and wait.

Time and weather changes will start. There are two hotkeys setup for you.
F6 will display the current time and date
F9 will display the current weather


		
Enviro-Torque
---------------
This is a Three step process:

 	First:
           1) apply the patch - either automatically or manually
	   	It should apply cleanly to TGE 1.3 and 1.3.5(lighting pack)
           2) If your are patching by hand - you may wish to simply use 
		the sky.h and sky.cc files I have provided, since they 
		have chanaged alot. Otherwise you will not need them.
	   3) Copy in the celestial.c and celestial.h files.
		Remember to add them to your VC6, VC7 projects and/or
		private CVS archive.
	  
	Second:
 	   1) Use the steps listed above (GameMangaer-2.0 | "Install the Mod:")
		but use the version in the "envTorque-1.3.5-mod" folder instead.
	   
	   NOTE: the bug-fixes to the engine should have been done in the patch
		so you don't have to worry about them.

	Three:
	    1) Add a section like this to your *.mis file.

new Celestials(SunCycles) {
      position = "0 0 0";
      rotation = "1 0 0 0";
      scale = "1 1 1";
      secsPerGameHour = "37";
      hoursInDay = "24";
      daysInWeek = "7";
      daysInMonth = "28";
      monthsInYear = "10";
      initialHour = "12";
      initialDay = "1";
      initialMonth = "3";
      initialYear = "1228";
      axistilt = "3.60671e-015";
      longitude = "0";
      latitude = "3.75696e-015";
      yearlength = "280";
      daylength = "900000";
      date = "57";
      time = "142235";
   };


KEY:
	position 	=	don't know
	rotation	=	don't know
	scale		=	don't know
	secsPerGameHour	=	Real-time secs. per game hour
				  - THIS MUST BE AN INTEGER!
	hoursInDay	=	How many game-hours in a game-day?
	daysInWeek 	=	How many game-days in a game-week?
	daysInMonth	=	How many game-days in a game-month?
	monthsInYear	= 	How many game-months in a game-year?
	initialHour 	=	Starting game-time
	initialDay 	=	Starting game-day of current game-month
	initialMonth 	=	starting game-month of current game-year
	initialYear 	=	starting game-year
	asixtilt	=	tilt of "planet"
	longitude	=	your maps longitude
	latitude	=	your maps latitude

	DON'T CHANGE THESE - FOR DISPLAY PURPOSES ONLY
	yearlength	=	game-days per game year
	daylength	=	milliseconds per game-day
	date 		= 	current game-day of game-year
	time		=	current millisecond of game-day


-----------------------	


Original Sources for these Patches/Mods:
http://www.garagegames.com/index.php?sec=mg&mod=resource&page=view&qid=6107
http://www.garagegames.com/index.php?sec=mg&mod=resource&page=view&qid=5417
http://www.garagegames.com/mg/forums/result.thread.php?qt=22228

	   




