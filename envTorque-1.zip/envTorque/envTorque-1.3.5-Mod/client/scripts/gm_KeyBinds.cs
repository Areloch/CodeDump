//-----------------------------------------------------------------------------
// Torque Game Engine
// Copyright (C) GarageGames.com, Inc.
// Time GameManager mod by Bil Simser (bsimser@shaw.ca)
// Revised by: Steven Peterson
//
// This filed added by: Steven Peterson (9/11//2005)
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// SETUP:
//
// 1) Add to client/scripts/default.bind.cs: exec("./gm_KeyBinds.cs");
//
//-----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
// This sets custom key bindings to display:
//      - The Time    (F6)
//      - The Weather (F9)
//-----------------------------------------------------------------------------


function displayTime(%val)
{
    if(%val)
        commandToServer('DoTime');
}
GlobalActionMap.bind(keyboard, "F6", displayTime);


function displayWeather(%val)
{
    if(%val)
        commandToServer('DoWeather');
}
GlobalActionMap.bind(keyboard, "F9", displayWeather);