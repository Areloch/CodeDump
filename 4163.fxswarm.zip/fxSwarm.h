//-----------------------------------------------------------------------------
// Torque Game Engine
// 
// Written by Dylan Sale, 20th April 2003, based on Melv May's fxRenderObject.
// THANKS MELV ;)
//
// Basically what this does is has a control object that creates particles, then
// when the control object renders, it passes in each particle to a series of rule
// methods that modify their velocity based on :
//		Where the leader is
//		Whether they are in the given area (the position of the contol object + the sparseness)
//		How far from the center of mass of the swarm they are
//		How far from nearby particles they are (repels them, stops them from forming a single point)
// It then gets all of their positions and then renders them as points or billboards if there is a texture given.
//
// The weight fields affect how much each of the rules accelerate the particles.
// mSize: changes the size of the points/billboards.
// mPaused: stops the swarm from animating, can be toggled from the console with swarm.togglePause();
// mSelfOptimize: contains the target frames per second, when non-zero it will add or subtract particles
//				  until the target is reached (with an error of 5fps). It also prints the number of 
//				  particles to the console.
//
// TODO: I want to make the particles more autonomous so that they dont rely on a central object to
//		 modify their velocities, they should do that internally.
//		 I also want to hook them into the physics engine somehow, and maybe the network as well.
//
//	Eventually I cant to add a primative AI that will let them learn very basic skills like avoiding
//	danger or something.
//
//  This was inspired by the book PREY by Michael Crighton (probably spelt wrong.. he did Jurassic Park)
//	I used the same basic structure as a java applet I found on the web somewhere. 
//	It was created by Jeremy Brooks http://kahuna.clayton.edu/~jbrooks/applets
//	I ported it to Torque and added a third dimension. I also tweaked it so its pretty much completely different.
//-----------------------------------------------------------------------------

#ifndef _SWARM_H_
#define _SWARM_H_

#ifndef _SCENEOBJECT_H_
#include "sim/sceneObject.h"
#endif
#define MAX_PARTICLES 1000
class swarmParticle;
//------------------------------------------------------------------------------
// Class: swarmObject
//------------------------------------------------------------------------------
class fxSwarmObject : public SceneObject
{
private:
	typedef SceneObject		Parent;

protected:

	// Create and use these to specify custom events.
	//
	// NOTE:-	Using these allows you to group the changes into related
	//			events.  No need to change everything if something minor
	//			changes.  Only really important if you have *lots* of these
	//			objects at start-up or you send alot of changes whilst the
	//			game is in progress.
	//
	//			Use "setMaskBits(fxRenderObjectMask)" to signal.

	enum {	fxSwarmObjectMask		= (1 << 0),
			fxSwarmObjectMoveTo	= (1 << 1), 
			fxSwarmObjectPause	= (1 << 2),
			fxSwarmObjectReset	= (1 << 3) };

	S32								mLastRenderTime;
	TextureHandle					mTextureHandle;
	U32								mPointRender;
	F32								mSize;
	U32								mPaused;
	// Fields.
	F32								mSparseness;	  //This determines the area that the particles can swarm in.
    StringTableEntry				mTextureName;
	S32								mNumParticles;
	F32								mParticleSlowDown;//Its really a misnomer. Should be mParticleShape as it affects the particle behaviour.
	S32								mSelfOptimize;	  //It is called the particle coefficient in the editor. 
													  //Low values make the group stick together and act more mechanical, High values push it apart and act more organic.
	swarmParticle*					mParticleArray[MAX_PARTICLES];	//pointers to the particles
	
	F32								mLeaderWeight; //These are weights for each of the rules keeping the particles swarming
	F32								mBoundsWeight;
	F32								mCenterWeight;
	F32								mRepelWeight;
	F32								mVelocityWeight;
	S32								mSelfSwarming; //This determines if the swarm follows itself or is guided by something.

public:
	fxSwarmObject();
	~fxSwarmObject();

	// gameBase
	void renderObject(SceneState*, SceneRenderImage*);
	virtual bool prepRenderImage(SceneState*, const U32 stateKey, const U32 startZone,
								const bool modifyBaseZoneState = false);
	void processTick(const Move*);
	void interpolateTick(F32 delta);
	void advanceTime(F32);
	// SimObject      
	bool onAdd();
	void onRemove();
	void onEditorEnable();
	void onEditorDisable();
	void inspectPostApply();

	bool isSelfSwarming(){return (bool)mSelfSwarming;}
	F32 getParticleCoeff(){return mParticleSlowDown;}
	F32	getSparseness(){return mSparseness;}
	S32 getNumParticles(){	return mNumParticles;}
	//swarm functions
	void moveTo(Point3F point);
	void selfSwarm();
	void reset();
	void togglePause();
	Point3F followLeader(S32 current);
	Point3F checkBounds(S32 current);
	Point3F moveToCentOfMass(S32 current);
	Point3F checkDistance(S32 current);
	Point3F matchVelocity(S32 current);
	


	// NetObject
	U32 packUpdate(NetConnection *, U32, BitStream *);
	void unpackUpdate(NetConnection *, BitStream *);

	// ConObject.
	static void initPersistFields();

	// Declare Console Object.
	DECLARE_CONOBJECT(fxSwarmObject);
};
//------------------------------------------------------------------------------
// Class: swarmParticle
//------------------------------------------------------------------------------
class swarmParticle
{
private:
	Point3F							vel;
	MatrixF							pos;
	fxSwarmObject*					swarm;
public:
	static MRandom*					randomGen;
	swarmParticle();
	~swarmParticle();
	
	Point3F getPos(){return pos.getPosition();}
	MatrixF getTransform(){return pos;}

	Point3F getVel(){return vel;}
	void renderObject(SceneState*, SceneRenderImage*);
	void onAdd(fxSwarmObject* swarm);
	void update(Point3F toCentre,Point3F keepShape,Point3F matchVel,Point3F repelFromBounds,Point3F followLeader,S32 i);
	
};
MRandom* swarmParticle::randomGen = new MRandom();

#endif // _SWARM_H_
