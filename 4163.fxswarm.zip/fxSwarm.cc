//-----------------------------------------------------------------------------
// Torque Game Engine
// 
// Written by Dylan Sale, 20 April 2003. Based on Melv May's fxRenderObject
//
// See the fxSwarm.h
//
//-----------------------------------------------------------------------------

#include "dgl/dgl.h"
#include "console/consoleTypes.h"
#include "core/bitStream.h"
#include "math/mathIO.h"
#include "game/gameConnection.h"
#include "console/simBase.h"
#include "sceneGraph/sceneGraph.h"
#include "sceneGraph/sgUtil.h"
#include "fxSwarm.h"
#include "console/typeValidators.h"

//------------------------------------------------------------------------------
//
//	Put the function in /example/common/editor/ObjectBuilderGui.gui [around line 458] ...
//
//	function ObjectBuilderGui::buildswarmObject(%this)
//	{
//		%this.className = "swarmObject";
//		%this.process();
//	}
//
//------------------------------------------------------------------------------
//
//	Put this in /example/common/editor/EditorGui.cs in [function Creator::init( %this )]
//
//   %Environment_Item[ next free entry ] = "swarmObject";  <-- ADD THIS.
//
//------------------------------------------------------------------------------
extern bool gEditingMission;

//------------------------------------------------------------------------------

IMPLEMENT_CO_NETOBJECT_V1(fxSwarmObject);

//Removes the leader, instead the swarm follows the given point.
ConsoleMethod( fxSwarmObject, moveTo, void, 3, 3, "swarm.moveTo(point (in the form \"x y z\")")
{
   fxSwarmObject* swarm= static_cast<fxSwarmObject*>(object);
   Point3F point;
   
   dSscanf(argv[2], "%f %f %f",&point.x, &point.y, &point.z);
   swarm->moveTo(point);
}

//reverts back to normal
ConsoleMethod( fxSwarmObject, selfSwarm, void, 2, 2, "swarm.selfSwarm()")
{
   fxSwarmObject* swarm= static_cast<fxSwarmObject*>(object);
   swarm->selfSwarm();
}

//resets the swarm to default positions.
ConsoleMethod( fxSwarmObject, reset, void, 2, 2, "swarm.reset()")
{
   fxSwarmObject* swarm= static_cast<fxSwarmObject*>(object);
   swarm->reset();
}

ConsoleMethod( fxSwarmObject, togglePause, void, 2, 2, "swarm.togglePause()")
{
   fxSwarmObject* swarm= static_cast<fxSwarmObject*>(object);
   swarm->togglePause();
}

ConsoleMethod( fxSwarmObject, numParticles, S32, 2, 2, "swarm.togglePause()")
{
   fxSwarmObject* swarm= static_cast<fxSwarmObject*>(object);
   S32 num = swarm->getNumParticles();
   Con::printf("Swarm %i has %i particles", swarm->getId(), num);
   return num;
}

void fxSwarmObject::reset(){
/*	for(int i=0; i<mNumParticles;i++){
		mParticleArray[i]->onAdd(getPosition(),mSparseness);
	}
*/	setMaskBits(fxSwarmObjectReset);
}
void fxSwarmObject::togglePause(){
	mPaused = !mPaused;
	setMaskBits(fxSwarmObjectPause);
}	
//------------------------------------------------------------------------------
// Class: fxSwarmObject
//------------------------------------------------------------------------------

fxSwarmObject::fxSwarmObject()
{
	// Setup NetObject.
	mTypeMask |= StaticObjectType | StaticTSObjectType | StaticRenderedObjectType;
	mNetFlags.set(Ghostable);

	// Reset Last Render Time.
	mLastRenderTime = 0;

	// Texture Handle.
	mTextureHandle = NULL;
	// Flare Texture Name.
	mTextureName = StringTable->insert("");
	mPointRender = false;
	mSize = 0.5f;
	mPaused = false;
	// Reset Quad Size.
	mSparseness = 10.0f;
	mSelfOptimize = 0;

	mLeaderWeight = 1; 
	mBoundsWeight = 1;
	mCenterWeight = 1;
	mRepelWeight = 1;
	mVelocityWeight = 1;
	
	mSelfSwarming = true;
	
	mNumParticles = 150;
	mParticleSlowDown = 500; 
	for (int i=0;i<MAX_PARTICLES;i++){
		mParticleArray[i] = NULL;
	}
}

//------------------------------------------------------------------------------

fxSwarmObject::~fxSwarmObject()
{
}

//------------------------------------------------------------------------------

void fxSwarmObject::initPersistFields()
{
	// Initialise parents' persistent fields.
	Parent::initPersistFields();

	// Add out own persistent fields.
	addGroup( "Swarm Fields" );
    addField( "Sparseness",		TypeF32,		Offset( mSparseness,		fxSwarmObject ) );
    addField( "ParticleCoeff",	TypeF32,		Offset( mParticleSlowDown,	fxSwarmObject ) );
	addField( "LeaderWeight",	TypeF32,		Offset(	mLeaderWeight,		fxSwarmObject ) );
	addField( "BoundsWeight",	TypeF32,		Offset(	mBoundsWeight,		fxSwarmObject ) );
	addField( "CenterWeight",	TypeF32,		Offset(	mCenterWeight,		fxSwarmObject ) );
	addField( "RepelWeight",	TypeF32,		Offset(	mRepelWeight,		fxSwarmObject ) );
	addField( "VelocityWeight",	TypeF32,		Offset(	mVelocityWeight,	fxSwarmObject ) );
    addField( "NumberOfParticles",	TypeS32,	Offset( mNumParticles,		fxSwarmObject ) );
    addField( "SelfOptimize",		TypeS32,	Offset( mSelfOptimize,		fxSwarmObject ) );
	endGroup( "Swarm Fields" );

	addGroup( "Render Fields" );
    addField( "Texture",		TypeFilename,	Offset( mTextureName,		fxSwarmObject ) );
	addField( "ParticleSize",	TypeF32,		Offset( mSize,				fxSwarmObject ) );
	endGroup( "Render Fields" );
}

//------------------------------------------------------------------------------

bool fxSwarmObject::onAdd()
{
//	Con::printf("%i",mNumParticles);
//	AssertFatal(mNumParticles <= MAX_PARTICLES,"number of particles in swarm is greater than max");
	if(mNumParticles > MAX_PARTICLES)
		mNumParticles = MAX_PARTICLES;
	if(mNumParticles < 2)
		mNumParticles = 2;

	if(!Parent::onAdd()) return(false);
	if(mTextureHandle.getGLName() == NULL)
		mPointRender = true;
	// Calculate Quad Radius.
	F32 halfSize = mSparseness;

	// Set initial bounding box.
	//
	// NOTE:-	Set this box to completely encapsulate your object.
	//			You must reset the world box and set the render transform
	//			after changing this.
	mObjBox.min.set( -halfSize, -halfSize, -halfSize );
	mObjBox.max.set(  halfSize, halfSize,  halfSize );
	for(int i=0; i<mNumParticles;i++){
		mParticleArray[i] = new swarmParticle();
		mParticleArray[i]->onAdd(this);
	}
	// Reset the World Box.
	resetWorldBox();
	// Set the Render Transform.
	setRenderTransform(mObjToWorld);

	// Add to Scene.
	addToScene();

	// Return OK.
	return(true);
}

//------------------------------------------------------------------------------

void fxSwarmObject::onRemove()
{
	for(int i=0; i<mNumParticles;i++){
		delete mParticleArray[i];
		mParticleArray[i] = NULL;
	}
	// Remove from Scene.
	removeFromScene();

	// Do Parent.
	Parent::onRemove();
}

//------------------------------------------------------------------------------

void fxSwarmObject::inspectPostApply()
{
	// Set Parent.
	Parent::inspectPostApply();

	if(mNumParticles<2)
		mNumParticles=2;
	if(mNumParticles>MAX_PARTICLES)
		mNumParticles=MAX_PARTICLES;

	// Set swarm Mask.
	setMaskBits(fxSwarmObjectMask);
}

//------------------------------------------------------------------------------

void fxSwarmObject::onEditorEnable()
{
}

//------------------------------------------------------------------------------

void fxSwarmObject::onEditorDisable()
{
}

//------------------------------------------------------------------------------

bool fxSwarmObject::prepRenderImage(	SceneState* state, const U32 stateKey, const U32 startZone,
										const bool modifyBaseZoneState)
{
	// Return if last state.
	if (isLastState(state, stateKey)) return false;
	// Set Last State.
	setLastState(state, stateKey);

   // Is Object Rendered?
   if (state->isObjectRendered(this))
   {	   
		// Yes, so get a SceneRenderImage.
		SceneRenderImage* image = new SceneRenderImage;
		// Populate it.
		image->obj = this;
		image->isTranslucent = false;
		image->sortType = SceneRenderImage::Normal;
		
		// Insert it into the scene images.
		state->insertRenderImage(image);
   }

   return false;
}

//------------------------------------------------------------------------------

void fxSwarmObject::renderObject(SceneState* state, SceneRenderImage* image)
{
	// Check we are in Canonical State.
	AssertFatal(dglIsInCanonicalState(), "Error, GL not in canonical state on entry");
	// Calculate Elapsed Time and take new Timestamp.
	S32 Time = Platform::getVirtualMilliseconds();
	F32 ElapsedTime = (Time - mLastRenderTime) * 0.001f;
	// Return if we don't have a texture.
	//if (!mTextureHandle) return;

	// Save state.
	RectI viewport;

	// Save Projection Matrix so we can restore Canonical state at exit.
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();

	// Save Viewport so we can restore Canonical state at exit.
	dglGetViewport(&viewport);

	// Setup the projection to the current frustum.
	//
	// NOTE:-	You should let the SceneGraph drive the frustum as it
	//			determines portal clipping etc.
	//			It also leaves us with the MODELVIEW current.
	//
	state->setupBaseProjection();

	// Save ModelView Matrix so we can restore Canonical state at exit.
	glPushMatrix();

	//This optimizes the number of particles in the swarm so that it looks natural (doesnt render too fast or slow)
	if(mSelfOptimize){
		if((1/ElapsedTime >= (mSelfOptimize - 5.0f) && 1/ElapsedTime < (mSelfOptimize+5.0f)) || (mNumParticles+(S32)(1/ElapsedTime))>MAX_PARTICLES || (mNumParticles-(S32)((ElapsedTime+1)*10))<2)
			 mSelfOptimize = 0;
		if(1/ElapsedTime >= mSelfOptimize && mNumParticles!=MAX_PARTICLES){
			for(S32 numNewParticles = (S32)(1/ElapsedTime);numNewParticles>=0&&(mNumParticles+numNewParticles)<MAX_PARTICLES;numNewParticles--){
				if(mParticleArray[mNumParticles]==NULL){
					mParticleArray[mNumParticles] = new swarmParticle();
					mParticleArray[mNumParticles]->onAdd(this);
				}
				mNumParticles++;
			}
			Con::printf("%i particles",mNumParticles);
			setMaskBits(fxSwarmObjectMask);
		}
		if(1/ElapsedTime < mSelfOptimize && mNumParticles!=2){
			for(S32 numParticlesRemoved = (S32)((ElapsedTime+1)*10);numParticlesRemoved>=0&&(mNumParticles-numParticlesRemoved)>2;numParticlesRemoved--){
				mNumParticles--;
				if(mParticleArray[mNumParticles]!=NULL){
					delete mParticleArray[mNumParticles];
					mParticleArray[mNumParticles] = NULL;
				}
			}
			Con::printf("%i particles",mNumParticles);
			setMaskBits(fxSwarmObjectMask);
		}
	}
	
	U32 i;
	 //this is a frame limiter, dont want it to go too fast
//	if(ElapsedTime >= 1.0f/30.0f){
		mLastRenderTime = Time;
		//Determine the current postitions of the particles
		if(!mPaused)
		for(i=0;i<mNumParticles;i++){
			mParticleArray[i]->update(moveToCentOfMass(i)*mCenterWeight,checkDistance(i)*mRepelWeight,
									  matchVelocity(i)*mVelocityWeight,checkBounds(i)*mBoundsWeight,
									  followLeader(i)*mLeaderWeight,i); //Sends the acceleration to the particle
		}
//	}
		//If there is no texture then use points
		if(mPointRender){
			glColor4f(1,0,1,0.8);
			F32 pointSize;
			glGetFloatv(GL_POINT_SIZE,&pointSize);
			glPointSize(mSize);

			glBegin(GL_POINTS);
			for(i=0;i<mNumParticles;i++){
				glVertex3fv(mParticleArray[i]->getPos());
				glColor4f(0,0,1,0.8);
			}
			glEnd();

			glPointSize(pointSize);
		}else{
					// Setup Render State.
				glEnable            ( GL_TEXTURE_2D );
				glBindTexture		( GL_TEXTURE_2D, mTextureHandle.getGLName());
				glEnable			( GL_BLEND );
				glBlendFunc			( GL_SRC_ALPHA , GL_ONE_MINUS_SRC_ALPHA );
				glTexEnvi           ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
				glEnable			( GL_ALPHA_TEST );
				glEnable			( GL_CULL_FACE );
				
				swarmParticle*	pParticle;

				// Step through Particles.
				for (i = 0; i < mNumParticles; i++)
				{

					// Fetch the particle
					pParticle = mParticleArray[i];
					
					//Calculate and render the billboarding
				   Point3F particlePos;
/*				   if(ElapsedTime < 1.0f/30.0f){
					   particlePos = pParticle->getPos() + pParticle->getVel(); 
					   particlePos.normalize(1/30.0f/ElapsedTime);
				   }else
*/				   particlePos = pParticle->getPos(); 
				   Point3F dirFromCam = particlePos - state->getCameraPosition();
				   Point3F crossDir;
				   Point3F vel = pParticle->getVel(); //rotate the billboard around the velocity.
				   mCross( dirFromCam, vel, &crossDir );
				   crossDir.normalize();
				   vel.normalize();

				   glBegin(GL_QUADS);

					  glColor4f(1.0f, 1.0f, 1.0f, 1.0f);


					  F32 width = mSize* 0.5;

					  vel *= width;
					  crossDir *= width;
					  Point3F start = particlePos  - vel;
					  Point3F end = particlePos  + vel;


					  glTexCoord2f(0, 0);
					  glVertex3fv( start + crossDir );

					  glTexCoord2f(0, 1);
					  glVertex3fv( start - crossDir );

					  glTexCoord2f(1, 1);
					  glVertex3fv( end - crossDir );

					  glTexCoord2f(1, 0);
					  glVertex3fv( end + crossDir );

				   glEnd();
				}
					
				

				// Restore rendering state.
				glTexEnvi			( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE );
				glDisable			( GL_CULL_FACE );
				glDisable			( GL_ALPHA_TEST );
				glDisable			( GL_BLEND );
				glDisable			( GL_TEXTURE_2D );
		}
	

	// Restore our canonical rendering state.
	glDisable(GL_BLEND);
	glDisable(GL_TEXTURE_2D);
	// Restore our canonical matrix state.
	glPopMatrix();
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
	// Restore our canonical viewport state.
	dglSetViewport(viewport);

	// Check we have restored Canonical State.
	AssertFatal(dglIsInCanonicalState(), "Error, GL not in canonical state on exit");
}

//------------------------------------------------------------------------------

U32 fxSwarmObject::packUpdate(NetConnection * con, U32 mask, BitStream * stream)
{
	// Pack Parent.
	U32 retMask = Parent::packUpdate(con, mask, stream);

	// Write fxPortal Mask Flag.
	if (stream->writeFlag(mask & fxSwarmObjectMask))
	{
		// Write Object Transform.
		stream->writeAffineTransform(mObjToWorld);
		// Write Texture Name.
		stream->writeString(mTextureName);
		// Write Quad Size.
		stream->write(mSize);
		stream->write(mSparseness);
		// Write Quad Rotate Speed.
//		stream->write(mQuadRotateSpeed);
		stream->write(mParticleSlowDown);
		stream->write(mLeaderWeight); //These are weights for each of the rules keeping the particles swarming
		stream->write(mBoundsWeight);
		stream->write(mCenterWeight);
		stream->write(mRepelWeight);
		stream->write(mVelocityWeight);
		stream->write(mNumParticles);
		stream->write(mSelfOptimize);
		stream->writeFlag(mPaused);
	}
	if(stream->writeFlag(mask & fxSwarmObjectMoveTo)){
		stream->writeFlag(mSelfSwarming);
		stream->writeAffineTransform(mObjToWorld);

	}
	if(stream->writeFlag(mask & fxSwarmObjectPause)){
		stream->writeFlag(mPaused);
	}
	stream->writeFlag(mask & fxSwarmObjectReset);

	// Were done ...
	return(retMask);
}

//------------------------------------------------------------------------------

void fxSwarmObject::unpackUpdate(NetConnection * con, BitStream * stream)
{
	// Unpack Parent.
	Parent::unpackUpdate(con, stream);
	MatrixF		ObjectMatrix;

	// Read fxPortal Mask Flag.
	if(stream->readFlag())
	{

		// Read Object Transform.
		stream->readAffineTransform(&ObjectMatrix);
		// Read Texture Name.
		mTextureName = StringTable->insert(stream->readSTString());
		stream->read(&mSize);
		stream->read(&mSparseness);
		// Read Quad Rotate Speed.
//		stream->read(&mQuadRotateSpeed);
		
		stream->read(&mParticleSlowDown);
		stream->read(&mLeaderWeight); //These are weights for each of the rules keeping the particles swarming
		stream->read(&mBoundsWeight);
		stream->read(&mCenterWeight);
		stream->read(&mRepelWeight);
		stream->read(&mVelocityWeight);

		stream->read(&mNumParticles);
		stream->read(&mSelfOptimize);
		mPaused = stream->readFlag();
		// Set Transform.
		setTransform(ObjectMatrix);

		// Reset our previous texture handle.
		mTextureHandle = NULL;    
		// Load the texture (if we've got one)
		if (*mTextureName) mTextureHandle = TextureHandle(mTextureName, BitmapTexture, true);

		// Calculate Quad Radius.
		F32 halfSize = mSparseness;

		// Set bounding box.
		//
		// NOTE:-	Set this box to completely encapsulate your object.
		//			You must reset the world box and set the render transform
		//			after changing this.
		mObjBox.min.set( -halfSize, -halfSize, -halfSize );
		mObjBox.max.set(  halfSize, halfSize,  halfSize );
		// Reset the World Box.
		resetWorldBox();
		// Set the Render Transform.
		setRenderTransform(mObjToWorld);
	}
	if(stream->readFlag()){
		mSelfSwarming = stream->readFlag();
		stream->readAffineTransform(&ObjectMatrix);
		// Set Transform.
		setTransform(ObjectMatrix);
				resetWorldBox();
		// Set the Render Transform.
		setRenderTransform(mObjToWorld);
	}
	if(stream->readFlag()){
		mPaused = stream->readFlag();
	}
	U32 reset = stream->readFlag();

	for(S32 i=0;i<mNumParticles;i++){
		if(mParticleArray[i] != NULL && reset){
			delete mParticleArray[i];
			mParticleArray[i] = NULL;
		}
		if(mParticleArray[i] == NULL){
			mParticleArray[i] = new swarmParticle();
			mParticleArray[i]->onAdd(this);
		}
	}


}

void fxSwarmObject::processTick(const Move*){ //hmm was going to put update stuff here, but ill do it in render
}
void fxSwarmObject::advanceTime(F32 delta){
}
void fxSwarmObject::interpolateTick(F32 delta){
}

Point3F fxSwarmObject::followLeader(S32 current){
	Point3F vel;
	vel.zero();
	Point3F diff;
	if(mSelfSwarming){
		if(current!=0)	
		{
			diff = (mParticleArray[0]->getPos()) - (mParticleArray[current]->getPos());
			vel.set(diff);
		}
		else if(current==0)
		{
			diff = (mParticleArray[current]->getPos()) - (mParticleArray[1]->getPos());
			vel.set(-diff);
		}
	}else{
		diff = getPosition() - mParticleArray[current]->getPos();
		vel.set(diff);
	}
	return (vel/mParticleSlowDown);
}
Point3F fxSwarmObject::checkBounds(S32 current){
	Point3F vel;
	Point3F currPos = mParticleArray[current]->getPos();
	vel.zero();	
	if(mSelfSwarming){
		if(currPos.x - getPosition().x < -mSparseness)
			vel.x = 1.0;
		if(currPos.x - getPosition().x > mSparseness)
			vel.x = -1.0;
		if(currPos.y - getPosition().y < -mSparseness)
			vel.y = 1.0;
		if(currPos.y - getPosition().y > mSparseness)
			vel.y = -1.0;
		if(currPos.z - getPosition().z < -mSparseness)
			vel.z = 1.0;
		if(currPos.z - getPosition().z > mSparseness)
			vel.z = -1.0;
	}
		
	return vel;
}

Point3F fxSwarmObject::moveToCentOfMass(S32 current){
		Point3F vel;
		Point3F posDiff;
		vel.zero();
		for(int i = 0; i < mNumParticles; i++)
		{
			if(i!=current)
			{
				vel+=mParticleArray[i]->getPos();

			}
		}
		
		vel=(vel/(mNumParticles-1));
		vel = (vel - mParticleArray[current]->getPos());

		return vel/mParticleSlowDown ;
}
Point3F fxSwarmObject::checkDistance(S32 current){
	Point3F vel;
	vel.zero();
	Point3F posDiff;
		for(int i = 0; i < mNumParticles; i++)
        {
			posDiff = mParticleArray[current]->getPos()-mParticleArray[i]->getPos();
			if(i!=current)
            {
				if(posDiff.len() < (0.1f*mSparseness)){
//					posDiff.normalize(1/posDiff.len());
					vel += posDiff;
				}
		    }
        }

		return vel/mParticleSlowDown;

}
Point3F fxSwarmObject::matchVelocity(S32 current){
	Point3F vel;
	vel.zero();
	for(int i = 0; i < mNumParticles; i++)
		{
			if(i!=current)
            {
				vel += mParticleArray[i]->getVel();
            }
		}

	vel = (vel/(mNumParticles-1));

	return (vel/mParticleSlowDown);//*mSparseness;
}
void fxSwarmObject::moveTo(Point3F point){
	setMaskBits(fxSwarmObjectMoveTo);
	mSelfSwarming = false;
	setPosition(point);
}

void fxSwarmObject::selfSwarm(){
	setMaskBits(fxSwarmObjectMoveTo);
	mSelfSwarming = true;
}


/////////////////////////////////////////////////////////////////////////////////
//Class: swarmParticle
/////////////////////////////////////////////////////////////////////////////////	
swarmParticle::swarmParticle(){
	swarm = NULL;
	pos.setPosition(Point3F(0,0,0));
	vel.set(0,0,0);
}

//sets the starting pos and vel for the particle
void swarmParticle::onAdd(fxSwarmObject* creator){
	swarm = creator;
	vel.set((randomGen->randF(-1.0,1.0)*swarm->getSparseness()),(randomGen->randF(-1.0,1.0)*swarm->getSparseness()),(randomGen->randF(-1.0,1.0)*swarm->getSparseness()));
	pos.setPosition(Point3F(swarm->getPosition()+vel));
}
/*inline Point3F reciprocalPoint3F(Point3F point){
	point.x = 1/point.x;
	point.y = 1/point.y;
	point.z = 1/point.z;
	return point;
}*/
//called every frame on the client
void swarmParticle::update(Point3F toCentre, Point3F keepShape, Point3F matchVel, Point3F repelFromBounds, Point3F followLeader,S32 i){
	vel += toCentre+keepShape+matchVel+repelFromBounds+followLeader+
		   Point3F((randomGen->randF(0.0,0.0001)*swarm->getSparseness()),(randomGen->randF(0.0,0.0001)*swarm->getSparseness()),(randomGen->randF(0.0,0.0001)*swarm->getSparseness())); //add em all up
	
	if(swarm->isSelfSwarming()){
		if(i==0)
		{
			pos.setPosition(pos.getPosition()+vel*1.2f); 
		}
		if(vel.len()>3)
			vel.normalize(3);
	}else{
		if(vel.len()>3*(swarm->getSparseness()/swarm->getParticleCoeff()))
			vel.normalize(3*(swarm->getSparseness()/swarm->getParticleCoeff()));
	}

/*	if(mAbs(vel.x) > 1.0f)
			vel.x = (vel.x/mAbs(vel.x))*1.0f;

	if(mAbs(vel.y) > 1.0f)
			vel.y = (vel.y/mAbs(vel.y))*1.0f;

	if(mAbs(vel.z) > 1.0f)
			vel.z = (vel.z/mAbs(vel.z))*1.0f;
*/
	pos.setPosition(pos.getPosition()+vel);

}

//does nothing for now.
void swarmParticle::renderObject(SceneState* state, SceneRenderImage* image){
}

swarmParticle::~swarmParticle(){
}